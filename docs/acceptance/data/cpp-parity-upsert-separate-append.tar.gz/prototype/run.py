"""Compare separated append against the frozen direct parent."""
from pathlib import Path
import json, subprocess
root=Path("target/parity-profile/upsert-separate-append")
reference="target/parity-profile/upsert-flat-result/candidate-bins/parity"
candidate=str(root/"candidate-bins/parity")
runs=[]
cases=[("candidate",c) for c in ["upsert/shared-hot/1","upsert/uniform/1","upsert/worker-hot/4","read/shared-hot/1","rmw/shared-hot/1"]]
cases += [("control",c) for c in ["upsert/shared-hot/1","read/shared-hot/1"]]
for name,case in cases:
 out=root/(name+"-"+case.replace("/","-"))
 command=["python3","tools/performance/compare.py","--rust",reference if name=="control" else candidate,"--baseline-rust",reference,"--output",str(out),"--min-throughput","0.98","--max-p99","1.10","--case",case]
 result=subprocess.run(command,capture_output=True,text=True)
 (root/(out.name+".log")).write_text(result.stdout+result.stderr)
 runs.append({"case":case,"name":name,"command":command,"exit_code":result.returncode})
 (root/"benchmark-runs.json").write_text(json.dumps(runs,indent=2)+"\n")
 assert (out/"comparison.json").exists(), result.stderr
 for row in json.loads((out/"comparison.json").read_text()):
  print(name,case,{k:row[k] for k in ["throughput_ratio","p99_ratio","passed"]},flush=True)
