//! Upsert Keep generated values while waiting for space;Get the latest link head in the same key quorum for each release.
use super::{
    Engine, SessionRuntime,
    pending::{PendingTask, TaskStep},
};
use crate::{
    api::{
        Submission,
        completion::{Completer, OperationResult, Outcome, Ticket},
        operation::{UpdateDecision, UpsertOperation},
    },
    device::IoCompletion,
    index::{EntrySnapshot, IndexHead, PublishResult},
    log::ValueAccess,
    schema::{OwnedValueOf, Schema, ValueLayout, ValueUpdate, value::ValuePlan},
    types::*,
};
use std::{
    panic::{AssertUnwindSafe, catch_unwind},
    sync::{Arc, atomic::Ordering},
};
struct Prepared<S: Schema, T> {
    value: Option<OwnedValueOf<S>>,
    output: Option<T>,
    plan: ValuePlan,
}
// Keep the common return value independent of the public error payload.
// Failures are moved into the caller's local slot without allocating.
enum UpsertStep<T> {
    Ready(T),
    Retry,
    Failed,
}
struct UpsertTask<S: Schema, O: UpsertOperation<S>> {
    engine: Arc<Engine<S>>,
    monitor: super::metrics::Monitor,
    request: Option<O>,
    prepared: Option<Prepared<S, O::Output>>,
    key: super::EncodedKey,
    hash: KeyHash,
    effect: Effect,
    complete: Option<Completer<O::Output>>,
    mailbox: super::io_hub::OperationRoute,
    serial: Serial,
    version: CheckpointVersion,
    permit: Option<super::version_permit::VersionPermit>,
}
impl<S: Schema, O: UpsertOperation<S>> UpsertTask<S, O> {
    fn advance(
        &mut self,
        hint: Option<&mut crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>>,
    ) -> Result<Option<O::Output>, Error> {
        let engine = &self.engine;
        let resolved = match hint.as_ref() {
            Some(hint) => engine.resolve_index_guarded(self.hash, &self.key, hint.guard)?,
            None => engine.resolve_index(self.hash, &self.key)?,
        };
        let entry = resolved.entry;
        let head = resolved.head;
        if self.prepared.is_none() {
            let request = self.request.as_mut().expect("Request not completed");
            let borrowed = match hint {
                Some(hint) => engine.log.mutable_head_borrowed(&self.key, head, hint)?,
                None => None,
            };
            // A miss preserves the full collision-chain and Pending paths.
            // The borrowed view remains inside the initial record epoch scope.
            let lease = if borrowed.is_none() {
                engine.log.find_mutable(&self.key, head)?
            } else {
                None
            };
            let record = borrowed.or_else(|| lease.as_ref().map(|lease| lease.borrow()));
            if let Some(record) = record.filter(|record| !record.is_tombstone()) {
                self.effect = Effect::Unknown;
                match record.update_at_version(self.version, |view| {
                    request.update_in_place(ValueUpdate { view })
                })? {
                    ValueAccess::Ready(Some(UpdateDecision::Updated(output))) => {
                        self.effect = Effect::Applied;
                        return Ok(Some(output));
                    }
                    ValueAccess::Ready(Some(UpdateDecision::Append) | None) => {
                        self.effect = Effect::NotApplied
                    }
                    ValueAccess::Contended => {
                        self.effect = Effect::NotApplied;
                        return Ok(None);
                    }
                }
            }
        }
        self.append(entry, head)
    }
    // Keep allocation and initialization out of the in-place update frame.
    // Pending requests retain their prepared value and use the same append path.
    #[inline(never)]
    fn append(
        &mut self,
        entry: EntrySnapshot,
        head: Option<LogAddress>,
    ) -> Result<Option<O::Output>, Error> {
        let engine = &self.engine;
        if self.prepared.is_none() {
            let (value, output) = self
                .request
                .as_mut()
                .expect("Request not completed")
                .replacement()?;
            let plan = engine.schema.value_layout().plan(&value)?.validate()?;
            engine.log.record_fits(self.key.len(), plan)?;
            self.prepared = Some(Prepared {
                value: Some(value),
                output: Some(output),
                plan,
            });
        }
        let prepared = self.prepared.as_mut().expect("Already possessive value");
        let allocation = match engine.log.allocate_record(&self.key, head, prepared.plan) {
            Ok(allocation) => allocation,
            Err(Error::CapacityExceeded) if engine.storage.device.capabilities().supports_files => {
                return Ok(None);
            }
            Err(error) => return Err(error),
        };
        let reservation =
            allocation.initialize(prepared.value.take().expect("Value not yet consumed"))?;
        let address = engine
            .log
            .finish_initialization(reservation.with_version(self.version))?;
        match engine
            .index
            .compare_publish(entry, IndexHead::Log(address))?
        {
            PublishResult::Published => {
                self.effect = Effect::Applied;
                let output = prepared.output.take().expect("Output not delivered yet");
                self.prepared = None;
                Ok(Some(output))
            }
            PublishResult::Conflict(_) => {
                engine.log.retire(address)?;
                self.monitor.invalidate();
                Err(Error::Busy)
            }
        }
    }
    fn finalize(
        &mut self,
        mut result: OperationResult<O::Output>,
    ) -> Option<OperationResult<O::Output>> {
        let request = self.request.take()?;
        if catch_unwind(AssertUnwindSafe(|| drop(self.prepared.take()))).is_err() {
            self.engine.failed.store(true, Ordering::SeqCst);
            let _ = catch_unwind(AssertUnwindSafe(|| drop(result)));
            result = Err(OperationError {
                cause: Error::InvalidState("Destruction panic of pending value"),
                effect: self.effect,
            });
        }
        Some(self.engine.finish_request(request, result, self.effect))
    }
    fn finish(&mut self, result: OperationResult<O::Output>) {
        if let Some(result) = self.finalize(result) {
            if let Some(complete) = &self.complete {
                self.engine.complete_tracked(
                    &mut self.monitor,
                    self.mailbox.registered_id(),
                    complete,
                    result,
                );
            } else {
                // There is no ticket yet for the first simultaneous promotion;Exception expansion can only end and fail to close,Can't pretend to be informed.
                self.engine.failed.store(true, Ordering::SeqCst);
                self.monitor
                    .finish(super::metrics::Completed::Failed(Effect::Unknown), None);
                let _ = catch_unwind(AssertUnwindSafe(|| drop(result)));
            }
        }
    }
    fn run_locked(
        &mut self,
        hint: Option<&mut crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>>,
        failure: &mut Option<OperationError>,
    ) -> UpsertStep<O::Output> {
        if self.engine.failed.load(Ordering::SeqCst) {
            *failure = Some(OperationError {
                cause: Error::InvalidState("engine_failed_closed"),
                effect: self.effect,
            });
            return UpsertStep::Failed;
        }
        match self
            .engine
            .version_permits
            .ready_initial(self.hash, self.permit.as_ref())
        {
            Ok(true) => {}
            Ok(false) => return UpsertStep::Retry,
            Err(cause) => {
                *failure = Some(OperationError {
                    cause,
                    effect: self.effect,
                });
                return UpsertStep::Failed;
            }
        }
        let result = match catch_unwind(AssertUnwindSafe(|| self.advance(hint))) {
            Ok(result) => result,
            Err(_) => {
                self.engine.failed.store(true, Ordering::SeqCst);
                Err(Error::InvalidState("Write callback panic"))
            }
        };
        if matches!(result, Ok(None)) {
            return UpsertStep::Retry;
        }
        if result.is_err() && self.effect == Effect::Unknown {
            self.engine.failed.store(true, Ordering::SeqCst);
        }
        match result {
            Ok(value) => UpsertStep::Ready(value.expect("Waiting space excluded")),
            Err(cause) => {
                *failure = Some(OperationError {
                    cause,
                    effect: self.effect,
                });
                UpsertStep::Failed
            }
        }
    }
}
impl<S: Schema, O: UpsertOperation<S>> PendingTask for UpsertTask<S, O> {
    fn id(&self) -> RequestId {
        self.mailbox.id()
    }
    fn serial(&self) -> Serial {
        self.serial
    }
    fn version(&self) -> CheckpointVersion {
        self.version
    }
    fn on_io(&mut self, _: IoCompletion) -> Result<(), Error> {
        Err(Error::InvalidState("Upsert Don't own the device request"))
    }
    fn step(&mut self, _: PollBudget) -> TaskStep {
        if self.request.is_none() {
            return TaskStep::Complete;
        }
        let engine = self.engine.clone();
        let _gate =
            match engine.operations[self.hash.0 as usize % engine.operations.len()].try_lock() {
                Ok(guard) => guard,
                Err(std::sync::TryLockError::WouldBlock) => return TaskStep::Retry,
                Err(_) => {
                    self.abandon(OperationError {
                        cause: Error::InvalidState("Operation arbitration lock poisoning"),
                        effect: self.effect,
                    });
                    return TaskStep::Complete;
                }
            };
        let mut failure = None;
        match self.run_locked(None, &mut failure) {
            UpsertStep::Retry => TaskStep::Retry,
            UpsertStep::Ready(result) => {
                self.finish(Ok(Outcome::Success(result)));
                TaskStep::Complete
            }
            UpsertStep::Failed => {
                self.finish(Err(failure.expect("Failed steps provide an error")));
                TaskStep::Complete
            }
        }
    }
    fn abandon(&mut self, error: OperationError) {
        self.finish(Err(error));
    }
}
impl<S: Schema, O: UpsertOperation<S>> Drop for UpsertTask<S, O> {
    fn drop(&mut self) {
        if self.request.is_some() {
            self.abandon(OperationError {
                cause: Error::SessionAbandoned,
                effect: self.effect,
            });
        }
        let _ = self.engine.io.release_operation(&mut self.mailbox);
    }
}
impl<S: Schema> Engine<S> {
    pub(crate) fn upsert<O: UpsertOperation<S>>(
        self: &Arc<Self>,
        session: &mut SessionRuntime,
        serial: Serial,
        request: O,
        mut hint: crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>,
    ) -> Result<Submission<O::Output>, Rejected<O>> {
        if let Err(reason) = self.observe_session(session) {
            return Err(Rejected { request, reason });
        }
        let (hash, key) = match self.prepare(session, serial, &request) {
            Ok(value) => value,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let _gate = match super::operation_gate::try_lock(
            &self.operations[hash.0 as usize % self.operations.len()],
        ) {
            Ok(guard) => guard,
            Err(_) => {
                return Err(Rejected {
                    request,
                    reason: Error::Busy,
                });
            }
        };
        if session.pending() >= self.config.session.max_pending {
            return Err(Rejected {
                request,
                reason: Error::Busy,
            });
        }
        let credit = match session.reserve_result(self.config.session.max_results) {
            Ok(credit) => credit,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let mut mailbox = match self.reserve_operation(session) {
            Ok(mailbox) => mailbox,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let id = mailbox.id();
        let permit = match self
            .version_permits
            .reserve_initial(hash, session.current.version)
        {
            Ok(permit) => permit,
            Err(reason) => {
                let _ = self.io.release_operation(&mut mailbox);
                return Err(Rejected { request, reason });
            }
        };
        if let Err(reason) = self.admit(session, serial) {
            let _ = self.io.release_operation(&mut mailbox);
            return Err(Rejected { request, reason });
        }
        let mut task = UpsertTask {
            monitor: session.tracker.accept(super::metrics::Kind::Upsert),
            engine: self.clone(),
            request: Some(request),
            prepared: None,
            key,
            hash,
            effect: Effect::NotApplied,
            complete: None,
            mailbox,
            serial,
            version: session.current.version,
            permit,
        };
        let mut failure = None;
        let result = match task.run_locked(Some(&mut hint), &mut failure) {
            UpsertStep::Ready(result) => Ok(Outcome::Success(result)),
            UpsertStep::Failed => Err(failure.expect("Failed steps provide an error")),
            UpsertStep::Retry => {
                if let Err(cause) = self
                    .version_permits
                    .activate(hash, task.version, &mut task.permit)
                    .and_then(|()| self.io.activate_operation(&mut task.mailbox))
                {
                    let result = task
                        .finalize(Err(OperationError {
                            cause,
                            effect: task.effect,
                        }))
                        .expect("Rejected mailbox registration is finalized");
                    self.record_ready(&mut task.monitor, task.mailbox.registered_id(), &result);
                    self.retain_operation(session, &mut task.mailbox);
                    return Ok(Submission::Ready(result));
                }
                let (ticket, complete) = Ticket::pair_bounded(id, credit);
                task.complete = Some(complete);
                task.monitor.pending();
                session.current.tasks.insert(id.slot, Box::new(task));
                return Ok(Submission::Pending(ticket));
            }
        };
        let result = task
            .finalize(result)
            .expect("Synchronous requests are terminated only once");
        self.record_ready(&mut task.monitor, task.mailbox.registered_id(), &result);
        self.retain_operation(session, &mut task.mailbox);
        Ok(Submission::Ready(result))
    }
}
