Repeated variable-memory diagnostic for runtime 17211f7 versus 1768626.
Each of 18 measured processes runs 32 fresh-store repetitions of the unchanged 16384-operation workload and verifies 2048 live keys per repetition. The same worker, callbacks, model, input bytes, and driver sources are used for both runtimes. The baseline and control binaries are identical.
This is not checkpoint/recovery acceptance or C++ parity. engine_ns sums execute intervals including API adaptation and user callbacks, not exclusive engine CPU time. Setup, final live-key verification, and teardown are outside each measured window.
The 2-repeat smoke outputs and ordinary-mode check are correctness checks only, not performance samples. Damaged count, trace, and repetition outputs were rejected by the validator.
The candidate did not reproduce its short-window 3% regression here, but its native Read regressions remained and the runtime was withdrawn. Source and binary restoration checks are included.
The final ordinary-mode check still completed checkpoint/recovery and all final-key checks.
Binary payloads are omitted; exact modified runtime modules, driver sources and binary hashes are included. Trace files are deduplicated by SHA256 and mapped by trace-references.json.
