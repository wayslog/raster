from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path(__file__).parent
checks=[]
commands=[('tests',['cargo','test','--locked','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('build',['cargo','build','--locked','--release','--all-features','--example','parity','--example','parity_scan','--example','benchmark','--example','benchmark_probe'])]
for name,cmd in commands:
 r=subprocess.run(cmd,capture_output=True,text=True)
 log=(r.stdout+r.stderr).replace(str(Path.cwd()),'worktree').replace(str(Path.home()),'user_directory')
 (root/(name+'.log')).write_text(log);checks.append({'name':name,'command':cmd,'exit_code':r.returncode});(root/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode: print(log[-2500:]);raise SystemExit(r.returncode)
m=json.loads((root/'manifest.json').read_text());m['source_sha256']={}
for name in ['src/engine/mod.rs','src/engine/upsert.rs','src/engine/upsert_ownership_tests.rs','src/engine/task.rs']:
 p=root/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(name).read_bytes());m['source_sha256'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'candidate-bins').mkdir(exist_ok=False);m['candidate_sha256']={}
for name in ['parity','parity_scan','benchmark','benchmark_probe']:
 p=root/'candidate-bins'/name;shutil.copyfile(Path('target/release/examples')/name,p);p.chmod(0o755);m['candidate_sha256'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',(root/'tests.log').read_text());m['tests']={'passed':sum(int(a) for a,b in rows),'failed':sum(int(b) for a,b in rows)}
m['status']='Ownership fixtures and full engineering checks passed; performance not yet measured.'
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Frozen',m['tests'],flush=True)
