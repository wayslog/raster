use super::*;
use crate::{
    RasterKV, Submission,
    api::{Outcome, operation::*},
    schema::{
        ValueRead, ValueUpdate,
        builtin::{AtomicU64Value, SchemaPair, U64Key},
    },
};
use std::{
    sync::mpsc,
    time::{Duration, Instant},
};

type Schema = SchemaPair<U64Key, AtomicU64Value>;
struct Request(u64);
impl Keyed<Schema> for Request {
    fn key(&self) -> &u64 {
        &1
    }
}
impl UpsertOperation<Schema> for Request {
    type Output = ();
    fn replacement(&mut self) -> Result<(u64, ()), Error> {
        Ok((self.0, ()))
    }
    fn update_in_place(
        &mut self,
        mut value: ValueUpdate<'_, Schema>,
    ) -> Result<UpdateDecision<()>, Error> {
        value
            .view_mut()
            .store(self.0, std::sync::atomic::Ordering::SeqCst);
        Ok(UpdateDecision::Updated(()))
    }
}
impl ReadOperation<Schema> for Request {
    type Output = u64;
    fn read(&mut self, value: ValueRead<'_, Schema>) -> Result<u64, Error> {
        Ok(*value.view())
    }
}
fn deadline() -> Deadline {
    Deadline(Instant::now() + Duration::from_secs(5))
}

#[test]
fn resident_operations_do_not_serialize_on_read_only_record_metadata() {
    let store = RasterKV::builder(SchemaPair::new(U64Key, AtomicU64Value))
        .device(Box::new(crate::device::null::NullDeviceFactory))
        .create()
        .unwrap();
    let mut owner = store.start_session(Default::default()).unwrap();
    assert!(matches!(
        owner.upsert(Serial(0), Request(7)),
        Ok(Submission::Ready(Ok(Outcome::Success(()))))
    ));
    let result = std::thread::scope(|scope| {
        let (ready_tx, ready_rx) = mpsc::sync_channel(1);
        let (start_tx, start_rx) = mpsc::sync_channel(1);
        let (result_tx, result_rx) = mpsc::sync_channel(1);
        let store = &store;
        let worker = scope.spawn(move || {
            let mut session = store.start_session(Default::default()).unwrap();
            ready_tx.send(()).unwrap();
            start_rx.recv().unwrap();
            let read = matches!(
                session.read(Serial(1), Request(0), ReadOptions::default()),
                Ok(Submission::Ready(Ok(Outcome::Success(7))))
            );
            let write = matches!(
                session.upsert(Serial(2), Request(11)),
                Ok(Submission::Ready(Ok(Outcome::Success(()))))
            );
            result_tx.send((read, write)).unwrap();
            session.close(deadline()).unwrap();
        });
        ready_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        let metadata = store.inner.log.records.read().unwrap();
        start_tx.send(()).unwrap();
        let early = result_rx.recv_timeout(Duration::from_secs(2));
        // Release the artificial stall before collecting a late result or
        // joining. The baseline must fail on the stall, not on cleanup.
        drop(metadata);
        let completed = match early {
            Ok(result) => result,
            Err(_) => result_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
        };
        worker.join().unwrap();
        assert_eq!(completed, (true, true));
        early
    });
    assert!(matches!(
        owner.read(Serial(1), Request(0), ReadOptions::default()),
        Ok(Submission::Ready(Ok(Outcome::Success(11))))
    ));
    owner.close(deadline()).unwrap();
    store.shutdown(deadline()).unwrap();
    assert_eq!(result, Ok((true, true)));
}
