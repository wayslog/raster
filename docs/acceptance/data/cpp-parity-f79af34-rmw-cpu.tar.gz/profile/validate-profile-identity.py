"""Verify profile source/binary identity and extract observed leaf-PC fragments."""
from pathlib import Path
import argparse,hashlib,io,json,re,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('head');a=p.parse_args();root=a.root
assert (root/'environment.txt').read_text().splitlines()[0]==a.head
raw=subprocess.check_output(['git','archive','--format=tar',a.head,'src'])
with tarfile.open(fileobj=io.BytesIO(raw)) as t:expected={p.name:hashlib.sha256(t.extractfile(p).read()).hexdigest() for p in t if p.isfile()}
observed={line.split(maxsplit=1)[1]:line.split()[0] for line in (root/'native-code/candidate-source.sha256').read_text().splitlines()};assert expected==observed
metadata=json.loads((root/'cpu-profile/environment.json').read_text());bins={line.split(maxsplit=1)[1]:line.split()[0] for line in (root/'native-code/binaries.sha256').read_text().splitlines()};assert metadata['binary_sha256']['rust']==bins['target/release/examples/parity']
lines=(root/'native-code/candidate-parity.asm').read_text().splitlines();symbols={};instructions={}
for i,line in enumerate(lines):
 m=re.match(r'^([0-9a-f]+) <(.+)>:$',line)
 if m:symbols[m[2]]=int(m[1],16)
 m=re.match(r'^\s*([0-9a-f]+):',line)
 if m:instructions[int(m[1],16)]=i
analysis=next(r for r in json.loads((root/'profile-analysis.json').read_text()) if r['engine']=='rust');fragments=[]
for symbol,n in analysis['leaf_offsets'][:18]:
 m=re.match(r'(.+)\+0x([0-9a-f]+)$',symbol)
 if not m or m[1] not in symbols:continue
 address=symbols[m[1]]+int(m[2],16);i=instructions[address];fragments.append({'symbol':symbol,'samples':n,'address':hex(address),'instructions':lines[max(0,i-3):i+4]})
assert len(fragments)>=10
(root/'hot-instructions.json').write_text(json.dumps(fragments,indent=2)+'\n');(root/'identity-validation.json').write_text(json.dumps({'head':a.head,'source_files':len(expected),'rust_binary_sha256':metadata['binary_sha256']['rust'],'source_and_profile_disassembly_identity':'verified','raw_outputs_and_perf_data_hashes':'verified by summarize-parity-evidence.py','hot_instruction_fragments':len(fragments),'limitation':'Leaf samples identify hot code; unresolved callers are not evidence of a complete call tree.'},indent=2)+'\n')
for f in fragments[:5]:print(f['symbol'],f['samples'],'\n'+'\n'.join(f['instructions']))
