import json,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
cases=['read/uniform/1','read/uniform/4','read/worker-hot/4','read/shared-hot/4','upsert/uniform/1','upsert/uniform/4','rmw/worker-hot/4']
results=[]
for case in cases+['control/upsert/worker-hot/4','control/read/uniform/4']:
 control=case.startswith('control/');selected=case.removeprefix('control/');out=root/'focus'/case.replace('/','-')
 command=[sys.executable,'tools/performance/compare.py','--rust',str(root/('baseline-bins' if control else 'candidate-bins')/'parity'),'--baseline-rust',str(root/'baseline-bins/parity'),'--case',selected,'--output',str(out),'--min-throughput','.98','--max-p99','1.10']
 r=subprocess.run(command,capture_output=True,text=True);print(case,r.stdout,flush=True)
 results.append({'case':case,'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(root/'focus-runs.json').write_text(json.dumps(results,indent=2)+'\n')
 if not (out/'comparison.json').exists():raise RuntimeError(r.stderr)
