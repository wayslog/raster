//! The read context is held by the session;Disk waits separated from result slots,The callback is only executed on the advancing thread.
use super::{
    Engine, SessionRuntime,
    io_hub::CompletionHub,
    pending::TaskStep,
    task::{BorrowedTask, TaskWork},
};
use crate::{
    api::{
        Submission,
        completion::{AbortReason, Completer, OperationResult, Outcome, Ticket},
        operation::{ReadOperation, ReadOptions},
    },
    device::IoCompletion,
    log::lookup::{LogLookup, LookupStep},
    schema::{Schema, ValueRead},
    types::*,
};
use std::{
    panic::{AssertUnwindSafe, catch_unwind},
    sync::{Arc, atomic::Ordering},
};
struct ReadTask<S: Schema, O: ReadOperation<S>> {
    schema: std::marker::PhantomData<fn() -> S>,
    monitor: super::metrics::Monitor,
    request: Option<O>,
    lookup: Option<LogLookup>,
    observed: Option<crate::index::EntrySnapshot>,
    key: super::EncodedKey,
    hash: KeyHash,
    options: ReadOptions,
    complete: Option<Completer<O::Output>>,
    ready: Option<OperationResult<O::Output>>,
    mailbox: super::io_hub::OperationRoute,
    serial: Serial,
    version: CheckpointVersion,
    permit: Option<super::version_permit::VersionPermit>,
}
impl<S: Schema, O: ReadOperation<S>> ReadTask<S, O> {
    fn invoke_read(
        request: &mut O,
        options: ReadOptions,
        value: crate::log::resident::BorrowedRecord<'_, crate::schema::SharedValue<S>>,
    ) -> Result<crate::log::ValueAccess<Outcome<O::Output>>, Error> {
        let tombstone = || {
            if options.abort_if_tombstone {
                Outcome::Aborted(AbortReason::Tombstone)
            } else {
                Outcome::NotFound
            }
        };
        if value.is_tombstone() {
            return Ok(crate::log::ValueAccess::Ready(tombstone()));
        }
        match value.try_read_live(|view| request.read(ValueRead { view }))? {
            crate::log::ValueAccess::Ready(Some(value)) => {
                value.map(|value| crate::log::ValueAccess::Ready(Outcome::Success(value)))
            }
            crate::log::ValueAccess::Ready(None) => Ok(crate::log::ValueAccess::Ready(tombstone())),
            crate::log::ValueAccess::Contended => Ok(crate::log::ValueAccess::Contended),
        }
    }
    fn finish_read_access(
        &mut self,
        result: crate::log::ValueAccess<Outcome<O::Output>>,
    ) -> Result<Option<Outcome<O::Output>>, Error> {
        match result {
            crate::log::ValueAccess::Ready(value) => Ok(Some(value)),
            crate::log::ValueAccess::Contended => {
                self.lookup = None;
                self.observed = None;
                Ok(None)
            }
        }
    }
    fn read_resident(
        &mut self,
        value: crate::log::RecordLease<crate::schema::SharedValue<S>>,
    ) -> Result<Option<Outcome<O::Output>>, Error> {
        let result = Self::invoke_read(
            self.request
                .as_mut()
                .expect("The request has not yet been finalized"),
            self.options,
            value.borrow(),
        )?;
        self.finish_read_access(result)
    }
    fn step_with_hint(
        &mut self,
        engine: &Arc<Engine<S>>,
        budget: PollBudget,
        mut hint: Option<crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>>,
    ) -> TaskStep {
        if self.request.is_none() {
            return TaskStep::Complete;
        }
        if engine.failed.load(Ordering::SeqCst) {
            self.abandon(
                engine,
                OperationError {
                    cause: Error::InvalidState("engine_failed_closed"),
                    effect: Effect::NotApplied,
                },
            );
            return TaskStep::Complete;
        }
        match engine
            .version_permits
            .ready_initial(self.hash, self.permit.as_ref())
        {
            Ok(true) => {}
            Ok(false) => return TaskStep::Retry,
            Err(cause) => {
                self.abandon(
                    engine,
                    OperationError {
                        cause,
                        effect: Effect::NotApplied,
                    },
                );
                return TaskStep::Complete;
            }
        }
        let result = catch_unwind(AssertUnwindSafe(
            || -> Result<Option<Outcome<O::Output>>, Error> {
                if self.lookup.is_none() {
                    let resolved = if let Some(hint) = hint.as_ref() {
                        engine.resolve_index_guarded(self.hash, &self.key, hint.guard)?
                    } else {
                        engine.resolve_index(self.hash, &self.key)?
                    };
                    if engine.config.cache.enabled {
                        engine.metrics.cache(super::metrics::CacheEvent::Lookup);
                    }
                    if let Some(record) = resolved.cached {
                        if record.source < engine.log.frontiers()?.begin {
                            // GC Cache header replaced;Reparse index,Live keys after migration cannot be reported as truncated.
                            return Ok(None);
                        }
                        let encoded = crate::format::Record::decode(record.encoded())?;
                        if encoded.header.version != record.version {
                            return Err(Error::InvalidState("Cache record version mismatch"));
                        }
                        engine.metrics.cache(super::metrics::CacheEvent::Hit);
                        if let crate::index::IndexHead::Cache(address) = resolved.entry.head {
                            engine.cache.touch(address)?;
                        }
                        let value = engine.log.decode_temporary(encoded.value)?;
                        return value
                            .read(|view| {
                                self.request
                                    .as_mut()
                                    .expect("The request has not yet been finalized")
                                    .read(ValueRead { view })
                            })?
                            .map(|value| Some(Outcome::Success(value)));
                    }
                    if let Some(hint) = hint.as_mut() {
                        if let Some(value) =
                            engine
                                .log
                                .resident_head_borrowed(&self.key, resolved.head, hint)?
                        {
                            let result = Self::invoke_read(
                                self.request
                                    .as_mut()
                                    .expect("The request has not yet been finalized"),
                                self.options,
                                value,
                            )?;
                            return self.finish_read_access(result);
                        }
                    } else if let Some(value) =
                        engine.log.resident_head(&self.key, resolved.head)?
                    {
                        // Keep tombstone and callback behavior identical to the chain lookup.
                        if value.is_tombstone() {
                            return Ok(Some(if self.options.abort_if_tombstone {
                                Outcome::Aborted(AbortReason::Tombstone)
                            } else {
                                Outcome::NotFound
                            }));
                        }
                        return self.read_resident(value);
                    }
                    self.observed = Some(resolved.entry);
                    let mut lookup = engine.log.lookup_deferred(
                        &engine.storage,
                        self.key.clone(),
                        resolved.head,
                        CompletionHub::route(self.mailbox.id()),
                    )?;
                    if self.mailbox.registered_id().is_some() {
                        lookup.enable_io();
                    }
                    self.lookup = Some(lookup);
                }
                let request = self
                    .request
                    .as_mut()
                    .expect("The request has not yet been finalized");
                match self.lookup.as_mut().expect("query_created").step(
                    &engine.log,
                    &engine.storage,
                    budget,
                )? {
                    LookupStep::Continue | LookupStep::AwaitingIo => Ok(None),
                    LookupStep::Present => {
                        Err(Error::InvalidState("Value query only returned metadata"))
                    }
                    LookupStep::Missing => {
                        // Compaction may have moved the chain head and pushed forward while the cold read was waiting begin;Missing old link does not mean missing key.
                        if self.observed != Some(engine.index.prepare(self.hash)?) {
                            self.lookup = None;
                            self.observed = None;
                            Ok(None)
                        } else {
                            Ok(Some(Outcome::NotFound))
                        }
                    }
                    LookupStep::Tombstone => Ok(Some(if self.options.abort_if_tombstone {
                        Outcome::Aborted(AbortReason::Tombstone)
                    } else {
                        Outcome::NotFound
                    })),
                    LookupStep::Resident(value) => self.read_resident(value),
                    LookupStep::Decoded(value) => {
                        engine.populate_cache(
                            self.hash,
                            self.observed.expect("Index snapshot saved"),
                            self.lookup.as_ref().expect("query_created"),
                        )?;
                        value
                            .read(|view| request.read(ValueRead { view }))?
                            .map(|value| Some(Outcome::Success(value)))
                    }
                }
            },
        ));
        match result {
            Ok(Ok(None)) => TaskStep::Retry,
            Ok(result) => {
                self.finish(
                    engine,
                    result
                        .map(|value| value.expect("Incomplete results excluded"))
                        .map_err(|cause| OperationError {
                            cause,
                            effect: Effect::NotApplied,
                        }),
                );
                TaskStep::Complete
            }
            Err(_) => {
                engine.failed.store(true, Ordering::SeqCst);
                self.abandon(
                    engine,
                    OperationError {
                        cause: Error::InvalidState("Read callback panic"),
                        effect: Effect::NotApplied,
                    },
                );
                TaskStep::Complete
            }
        }
    }
    fn prepare_pending(&mut self, engine: &Arc<Engine<S>>) -> Result<bool, Error> {
        let awaiting_route = self.lookup.as_ref().is_some_and(LogLookup::awaiting_route);
        engine
            .version_permits
            .activate(self.hash, self.version, &mut self.permit)?;
        engine.io.activate_operation(&mut self.mailbox)?;
        if let Some(lookup) = &mut self.lookup {
            lookup.enable_io();
        }
        Ok(awaiting_route)
    }
    fn run_initial(
        &mut self,
        engine: &Arc<Engine<S>>,
        budget: PollBudget,
        hint: crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>,
    ) -> TaskStep {
        if matches!(
            self.step_with_hint(engine, budget, Some(hint)),
            TaskStep::Complete
        ) {
            return TaskStep::Complete;
        }
        match self.prepare_pending(engine) {
            // Only the pre-I/O suspension is resumed here. It has not called
            // a value callback or submitted any device request yet.
            Ok(true) => self.step(engine, budget),
            Ok(false) => TaskStep::Retry,
            Err(cause) => {
                self.finish(
                    engine,
                    Err(OperationError {
                        cause,
                        effect: Effect::NotApplied,
                    }),
                );
                TaskStep::Complete
            }
        }
    }
    fn finish(&mut self, engine: &Arc<Engine<S>>, result: OperationResult<O::Output>) {
        if let Some(request) = self.request.take() {
            let result = engine.finish_request(request, result, Effect::NotApplied);
            if let Some(complete) = &self.complete {
                engine.complete_tracked(
                    &mut self.monitor,
                    self.mailbox.registered_id(),
                    complete,
                    result,
                );
            } else {
                engine.record_ready(&mut self.monitor, self.mailbox.registered_id(), &result);
                self.ready = Some(result);
            }
        }
    }
}
impl<S: Schema, O: ReadOperation<S>> TaskWork<S> for ReadTask<S, O> {
    fn id(&self) -> RequestId {
        self.mailbox.id()
    }
    fn serial(&self) -> Serial {
        self.serial
    }
    fn version(&self) -> CheckpointVersion {
        self.version
    }
    fn on_io(&mut self, engine: &Arc<Engine<S>>, completion: IoCompletion) -> Result<(), Error> {
        self.lookup
            .as_mut()
            .ok_or(Error::InvalidState("Read without waiting for disk query"))?
            .accept(&engine.storage, completion)
            .map_err(|rejected| rejected.reason)
    }
    fn step(&mut self, engine: &Arc<Engine<S>>, budget: PollBudget) -> TaskStep {
        self.step_with_hint(engine, budget, None)
    }
    fn abandon(&mut self, engine: &Arc<Engine<S>>, error: OperationError) {
        self.finish(engine, Err(error));
    }
    fn cleanup(&mut self, engine: &Arc<Engine<S>>) {
        if self.request.is_some() {
            self.abandon(
                engine,
                OperationError {
                    cause: Error::SessionAbandoned,
                    effect: Effect::NotApplied,
                },
            );
        }
        let _ = engine.io.release_operation(&mut self.mailbox);
    }
}
impl<S: Schema> Engine<S> {
    pub(crate) fn read<O: ReadOperation<S>>(
        self: &Arc<Self>,
        session: &mut SessionRuntime,
        serial: Serial,
        request: O,
        options: ReadOptions,
        hint: crate::log::resident::ReadHint<'_, '_, crate::schema::SharedValue<S>>,
    ) -> Result<Submission<O::Output>, Rejected<O>> {
        if let Err(reason) = self.observe_session(session) {
            return Err(Rejected { request, reason });
        }
        let (hash, key) = match self.prepare(session, serial, &request) {
            Ok(value) => value,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let _gate = match super::operation_gate::try_lock(
            &self.operations[hash.0 as usize % self.operations.len()],
        ) {
            Ok(guard) => guard,
            Err(_) => {
                return Err(Rejected {
                    request,
                    reason: Error::Busy,
                });
            }
        };
        if session.pending() >= self.config.session.max_pending {
            return Err(Rejected {
                request,
                reason: Error::Busy,
            });
        }
        let credit = match session.reserve_result(self.config.session.max_results) {
            Ok(credit) => credit,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let mut mailbox = match self.reserve_operation(session) {
            Ok(mailbox) => mailbox,
            Err(reason) => return Err(Rejected { request, reason }),
        };
        let id = mailbox.id();
        let permit = match self
            .version_permits
            .reserve_initial(hash, session.current.version)
        {
            Ok(permit) => permit,
            Err(reason) => {
                let _ = self.io.release_operation(&mut mailbox);
                return Err(Rejected { request, reason });
            }
        };
        if let Err(reason) = self.admit(session, serial) {
            let _ = self.io.release_operation(&mut mailbox);
            return Err(Rejected { request, reason });
        }
        let mut task = BorrowedTask::new(
            self,
            ReadTask {
                monitor: session.tracker.accept(super::metrics::Kind::Read),
                schema: std::marker::PhantomData,
                request: Some(request),
                lookup: None,
                observed: None,
                key,
                hash,
                options,
                complete: None,
                ready: None,
                mailbox,
                serial,
                version: session.current.version,
                permit,
            },
        );
        if matches!(
            task.run_initial(self, PollBudget::default(), hint),
            TaskStep::Complete
        ) {
            self.retain_operation(session, &mut task.mailbox);
            Ok(Submission::Ready(
                task.ready
                    .take()
                    .expect("Synchronous read completed exactly once"),
            ))
        } else {
            // Reserve the result credit before admission, but allocate a ticket
            // only when completion must outlive this call.
            let (ticket, complete) = Ticket::pair_bounded(id, credit);
            task.complete = Some(complete);
            task.monitor.pending();
            session
                .current
                .tasks
                .insert(id.slot, Box::new(task.into_owned()));
            Ok(Submission::Pending(ticket))
        }
    }
}
