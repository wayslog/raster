"""Validate fixed-parent and initial-prototype comparisons from raw outputs."""
from pathlib import Path
import hashlib,json,statistics,sys
sys.path.insert(0,'tools/performance')
from cpu_profile import validate_output
from compare_repeat import validate,KINDS
from focused_compare import LABELS,ORDERS
root=Path('target/parity-profile/rmw-resident-copy');base=Path('target/parity-profile/key-preparation-inline/candidate-bins');initial=Path('target/parity-profile/rmw-resident-borrow/candidate-bins')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path in ['src/api/session.rs','src/engine/rmw.rs','tests/p3_failures.rs']:assert Path(path).read_bytes()==(root/('candidate-'+Path(path).name)).read_bytes()
for name,digest in read(root/'binary-sha256.json').items():assert sha(root/'candidate-bins'/name)==digest
ordinary=[];count=0
for run in read(root/'runs.json'):
 name=run['name']
 if name.startswith('variable'):continue
 d=root/name;env=read(d/'environment.json');rows=read(d/'comparison.json');assert len(rows)==1;r=rows[0];case=r['case']
 assert env['binary_sha256']['baseline']==sha(base/'parity') and env['binary_sha256']['rust']==sha((base if name.startswith('aa-') else root/'candidate-bins')/'parity')
 threads=int(case.split('/')[-1]);n=env['count']//threads;samples=threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
 for label in ['baseline','rust']:
  for i in range(-1,env['rounds']):
   prefix=d/f"{case.replace('/','-')}-{i}-{label}";value=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,env['count']);assert value['samples']==samples and not prefix.with_suffix('.stderr').read_text()
   if i>=0:assert value==r['rows'][label][i]
   count+=1
 med=lambda label,key:statistics.median(row[key] for row in r['rows'][label]);t=med('baseline','elapsed_ns')/med('rust','elapsed_ns');p=med('rust','p99_ns')/med('baseline','p99_ns')
 assert r['throughput_ratio']==t and r['p99_ratio']==p and r['passed']==(t>=.98 and p<=1.1)
 ordinary.append({'name':name,'case':case,'throughput_ratio':t,'p99_ratio':p,'passed':r['passed']}|({'reciprocal_control_valid':.98<=t<=1/.98 and 1/1.1<=p<=1.1} if name.startswith('aa-') else {}))
assert count==80
variable={}
for name,reference in [('variable-parent',base),('variable-initial',initial)]:
 d=root/name;env=read(d/'environment.json');pairs=read(d/'pairs.json');assert len(pairs)==6
 assert env['binary_sha256']['baseline']==env['binary_sha256']['control']==sha(reference/'benchmark_probe') and env['binary_sha256']['candidate']==sha(root/'candidate-bins/benchmark_probe')
 for i,pair in enumerate(pairs):
  assert pair['order']==list(ORDERS[i])
  for label in LABELS:assert validate(d/f'pair{i}-{label}',32)==pair['samples'][label]
 medians={label:{'elapsed_ns':statistics.median(p['samples'][label]['elapsed_ns'] for p in pairs),'overall_p99_ns':statistics.median(p['samples'][label]['overall_p99_ns'] for p in pairs),'engine_ns':[statistics.median(p['samples'][label]['engine_ns'][i] for p in pairs) for i in range(4)]} for label in LABELS}
 result=read(d/'comparison.json');assert medians==result['medians']
 for label in ['candidate','control']:
  t=medians['baseline']['elapsed_ns']/medians[label]['elapsed_ns'];p=medians[label]['overall_p99_ns']/medians['baseline']['overall_p99_ns']
  assert result['comparisons'][label]=={'throughput_ratio':t,'p99_ratio':p,'passed':t>=.98 and p<=1.1,'operation_time_ratios':{kind:medians[label]['engine_ns'][i]/medians['baseline']['engine_ns'][i] for i,kind in enumerate(KINDS)}}
 variable[name]=result['comparisons']
 control=variable[name]['control'];control['reciprocal_control_valid']=.98<=control['throughput_ratio']<=1/.98 and 1/1.1<=control['p99_ratio']<=1.1
report={'integer_outputs':count,'variable_processes':36,'variable_trajectories':1152,'source_and_binary_identity':'verified','ordinary':ordinary,'variable':variable,'checks':read(root/'checks.json'),'status':'Focused variable regression removed with valid controls; single RMW gain retained; four-thread control invalid. Full local/native regressions pending.'}
(root/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
