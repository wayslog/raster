"""Compare the copy refinement with the fixed parent and initial prototype."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/rmw-resident-copy');base=Path('target/parity-profile/key-preparation-inline/candidate-bins');initial=Path('target/parity-profile/rmw-resident-borrow/candidate-bins');candidate=root/'candidate-bins'
commands=[]
for name,reference in [('variable-parent',base),('variable-initial',initial)]:
 commands.append((name,['python3','tools/performance/compare_repeat.py','--candidate',str(candidate/'benchmark_probe'),'--baseline',str(reference/'benchmark_probe')]))
for name,case in [('rmw-uniform','rmw/uniform/1'),('rmw-worker-four','rmw/worker-hot/4'),('rmw-shared-four','rmw/shared-hot/4'),('rmw-uniform-four','rmw/uniform/4'),('read-uniform','read/uniform/1'),('upsert-uniform','upsert/uniform/1'),('aa-rmw-uniform','rmw/uniform/1'),('aa-rmw-worker-four','rmw/worker-hot/4')]:
 binary=base if name.startswith('aa-') else candidate
 commands.append((name,['python3','tools/performance/compare.py','--rust',str(binary/'parity'),'--baseline-rust',str(base/'parity'),'--case',case,'--min-throughput','.98','--max-p99','1.10']))
runs=[]
for name,cmd in commands:
 cmd+=['--output',str(root/name)];print('START',name,flush=True)
 with (root/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 runs.append({'name':name,'command':cmd,'exit_code':p.returncode});(root/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 assert (root/name/'comparison.json').exists(),name
 if name.startswith('variable'):print(name,json.loads((root/name/'comparison.json').read_text())['comparisons'],flush=True)
 else:print((root/(name+'.log')).read_text(),flush=True)
