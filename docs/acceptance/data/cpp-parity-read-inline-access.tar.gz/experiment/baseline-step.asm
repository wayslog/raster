000000010004dce8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint>:
10004dce8: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10004dcec: a90167fa    	stp	x26, x25, [sp, #0x10]
10004dcf0: a9025ff8    	stp	x24, x23, [sp, #0x20]
10004dcf4: a90357f6    	stp	x22, x21, [sp, #0x30]
10004dcf8: a9044ff4    	stp	x20, x19, [sp, #0x40]
10004dcfc: a9057bfd    	stp	x29, x30, [sp, #0x50]
10004dd00: 910143fd    	add	x29, sp, #0x50
10004dd04: d10c03ff    	sub	sp, sp, #0x300
10004dd08: aa0003f3    	mov	x19, x0
10004dd0c: a90297e4    	stp	x4, x5, [sp, #0x28]
10004dd10: f9400028    	ldr	x8, [x1]
10004dd14: b40004c8    	cbz	x8, 0x10004ddac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc4>
10004dd18: aa0103f4    	mov	x20, x1
10004dd1c: f9400055    	ldr	x21, [x2]
10004dd20: 52838508    	mov	w8, #0x1c28             ; =7208
10004dd24: 8b0802ba    	add	x26, x21, x8
10004dd28: 08dfff48    	ldarb	w8, [x26]
10004dd2c: 34000128    	cbz	w8, 0x10004dd50 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x68>
10004dd30: 90000488    	adrp	x8, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x4c>
10004dd34: 9101c108    	add	x8, x8, #0x70
10004dd38: 528000e9    	mov	w9, #0x7                ; =7
10004dd3c: f9010be9    	str	x9, [sp, #0x210]
10004dd40: f9010fe8    	str	x8, [sp, #0x218]
10004dd44: 52800288    	mov	w8, #0x14               ; =20
10004dd48: f90113e8    	str	x8, [sp, #0x220]
10004dd4c: 14000013    	b	0x10004dd98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb0>
10004dd50: aa0303f7    	mov	x23, x3
10004dd54: 910683fb    	add	x27, sp, #0x1a0
10004dd58: 910283fc    	add	x28, sp, #0xa0
10004dd5c: f940ca81    	ldr	x1, [x20, #0x190]
10004dd60: 9106e288    	add	x8, x20, #0x1b8
10004dd64: f940de89    	ldr	x9, [x20, #0x1b8]
10004dd68: f100013f    	cmp	x9, #0x0
10004dd6c: 9a8803e2    	csel	x2, xzr, x8, eq
10004dd70: 9104c3e8    	add	x8, sp, #0x130
10004dd74: 910d02a0    	add	x0, x21, #0x340
10004dd78: 940043bd    	bl	0x10005ec6c <<raster::engine::version_permit::VersionPermits>::ready_initial>
10004dd7c: f9409be8    	ldr	x8, [sp, #0x130]
10004dd80: b100051f    	cmn	x8, #0x1
10004dd84: 54000280    	b.eq	0x10004ddd4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xec>
10004dd88: ad448780    	ldp	q0, q1, [x28, #0x90]
10004dd8c: ad038760    	stp	q0, q1, [x27, #0x70]
10004dd90: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004dd94: 3d802760    	str	q0, [x27, #0x90]
10004dd98: 390903ff    	strb	wzr, [sp, #0x240]
10004dd9c: 910843e2    	add	x2, sp, #0x210
10004dda0: aa1403e0    	mov	x0, x20
10004dda4: aa1503e1    	mov	x1, x21
10004dda8: 94000308    	bl	0x10004e9c8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004ddac: 52800248    	mov	w8, #0x12               ; =18
10004ddb0: f9000268    	str	x8, [x19]
10004ddb4: 910c03ff    	add	sp, sp, #0x300
10004ddb8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10004ddbc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10004ddc0: a94357f6    	ldp	x22, x21, [sp, #0x30]
10004ddc4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10004ddc8: a94167fa    	ldp	x26, x25, [sp, #0x10]
10004ddcc: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10004ddd0: d65f03c0    	ret
10004ddd4: 3944e3e8    	ldrb	w8, [sp, #0x138]
10004ddd8: 7100051f    	cmp	w8, #0x1
10004dddc: 54003d81    	b.ne	0x10004e58c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8a4>
10004dde0: aa1403f6    	mov	x22, x20
10004dde4: f8418ec8    	ldr	x8, [x22, #0x18]!
10004dde8: 910283e9    	add	x9, sp, #0xa0
10004ddec: 9100412a    	add	x10, x9, #0x10
10004ddf0: f90013ea    	str	x10, [sp, #0x20]
10004ddf4: b27d0139    	orr	x25, x9, #0x8
10004ddf8: f100091f    	cmp	x8, #0x2
10004ddfc: 540028c1    	b.ne	0x10004e314 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x62c>
10004de00: f94017e8    	ldr	x8, [sp, #0x28]
10004de04: b4000188    	cbz	x8, 0x10004de34 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x14c>
10004de08: f940ca98    	ldr	x24, [x20, #0x190]
10004de0c: 9104e280    	add	x0, x20, #0x138
10004de10: 9400e923    	bl	0x10008829c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004de14: aa0003e2    	mov	x2, x0
10004de18: aa0103e3    	mov	x3, x1
10004de1c: f94017e4    	ldr	x4, [sp, #0x28]
10004de20: 910843e8    	add	x8, sp, #0x210
10004de24: 910202a0    	add	x0, x21, #0x80
10004de28: aa1803e1    	mov	x1, x24
10004de2c: 97fefdbe    	bl	0x10000d524 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index_guarded>
10004de30: 1400000a    	b	0x10004de58 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x170>
10004de34: f940ca98    	ldr	x24, [x20, #0x190]
10004de38: 9104e280    	add	x0, x20, #0x138
10004de3c: 9400e918    	bl	0x10008829c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004de40: aa0003e2    	mov	x2, x0
10004de44: aa0103e3    	mov	x3, x1
10004de48: 910843e8    	add	x8, sp, #0x210
10004de4c: 910202a0    	add	x0, x21, #0x80
10004de50: aa1803e1    	mov	x1, x24
10004de54: 97fefb90    	bl	0x10000cc94 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index>
10004de58: f9410be8    	ldr	x8, [sp, #0x210]
10004de5c: 3cc78360    	ldur	q0, [x27, #0x78]
10004de60: 3cc88361    	ldur	q1, [x27, #0x88]
10004de64: ad048780    	stp	q0, q1, [x28, #0x90]
10004de68: 3cc98360    	ldur	q0, [x27, #0x98]
10004de6c: 3d802f80    	str	q0, [x28, #0xb0]
10004de70: f100091f    	cmp	x8, #0x2
10004de74: 540000c1    	b.ne	0x10004de8c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1a4>
10004de78: ad448780    	ldp	q0, q1, [x28, #0x90]
10004de7c: 3d802be0    	str	q0, [sp, #0xa0]
10004de80: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004de84: ad008381    	stp	q1, q0, [x28, #0x10]
10004de88: 140001ad    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004de8c: 3cca8360    	ldur	q0, [x27, #0xa8]
10004de90: 3c868380    	stur	q0, [x28, #0x68]
10004de94: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004de98: 3c878380    	stur	q0, [x28, #0x78]
10004de9c: f94137e9    	ldr	x9, [sp, #0x268]
10004dea0: ad448780    	ldp	q0, q1, [x28, #0x90]
10004dea4: 3c838380    	stur	q0, [x28, #0x38]
10004dea8: 3c848381    	stur	q1, [x28, #0x48]
10004deac: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004deb0: 3c858380    	stur	q0, [x28, #0x58]
10004deb4: f90097e9    	str	x9, [sp, #0x128]
10004deb8: f9006be8    	str	x8, [sp, #0xd0]
10004debc: 394702a8    	ldrb	w8, [x21, #0x1c0]
10004dec0: 360000c8    	tbz	w8, #0x0, 0x10004ded8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1f0>
10004dec4: f9417ea8    	ldr	x8, [x21, #0x2f8]
10004dec8: 52800038    	mov	w24, #0x1               ; =1
10004decc: 91004100    	add	x0, x8, #0x10
10004ded0: 52800001    	mov	w1, #0x0                ; =0
10004ded4: 940118bf    	bl	0x1000941d0 <<raster::engine::metrics::Metrics>::cache>
10004ded8: f94097f8    	ldr	x24, [sp, #0x128]
10004dedc: b4000218    	cbz	x24, 0x10004df1c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x234>
10004dee0: f81703b8    	stur	x24, [x29, #-0x90]
10004dee4: 910843e8    	add	x8, sp, #0x210
10004dee8: 911522a0    	add	x0, x21, #0x548
10004deec: 97ff3728    	bl	0x10001bb8c <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::frontiers>
10004def0: f9410be9    	ldr	x9, [sp, #0x210]
10004def4: f9410fe8    	ldr	x8, [sp, #0x218]
10004def8: f100053f    	cmp	x9, #0x1
10004defc: 54000401    	b.ne	0x10004df7c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x294>
10004df00: ad440760    	ldp	q0, q1, [x27, #0x80]
10004df04: ad048780    	stp	q0, q1, [x28, #0x90]
10004df08: f94123e9    	ldr	x9, [sp, #0x240]
10004df0c: f900abe9    	str	x9, [sp, #0x150]
10004df10: ad000720    	stp	q0, q1, [x25]
10004df14: f9001329    	str	x9, [x25, #0x20]
10004df18: 1400001f    	b	0x10004df94 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2ac>
10004df1c: f94017e8    	ldr	x8, [sp, #0x28]
10004df20: b4000608    	cbz	x8, 0x10004dfe0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2f8>
10004df24: 52800038    	mov	w24, #0x1               ; =1
10004df28: 9104e280    	add	x0, x20, #0x138
10004df2c: 9400e8dc    	bl	0x10008829c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004df30: aa0003e2    	mov	x2, x0
10004df34: aa0103e6    	mov	x6, x1
10004df38: a95193e3    	ldp	x3, x4, [sp, #0x118]
10004df3c: 910843e8    	add	x8, sp, #0x210
10004df40: 911522a0    	add	x0, x21, #0x548
10004df44: 9100a3e5    	add	x5, sp, #0x28
10004df48: aa0203e1    	mov	x1, x2
10004df4c: aa0603e2    	mov	x2, x6
10004df50: a9010fe4    	stp	x4, x3, [sp, #0x10]
10004df54: 97ff2d44    	bl	0x100019464 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head_borrowed>
10004df58: f9410be8    	ldr	x8, [sp, #0x210]
10004df5c: f9410fe3    	ldr	x3, [sp, #0x218]
10004df60: b100051f    	cmn	x8, #0x1
10004df64: 54000680    	b.eq	0x10004e034 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x34c>
10004df68: ad440760    	ldp	q0, q1, [x27, #0x80]
10004df6c: f94013e9    	ldr	x9, [sp, #0x20]
10004df70: ad000520    	stp	q0, q1, [x9]
10004df74: a90a0fe8    	stp	x8, x3, [sp, #0xa0]
10004df78: 14000171    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004df7c: f9401f09    	ldr	x9, [x24, #0x38]
10004df80: eb08013f    	cmp	x9, x8
10004df84: 540001e2    	b.hs	0x10004dfc0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2d8>
10004df88: 52801fe8    	mov	w8, #0xff               ; =255
10004df8c: 3902a3e8    	strb	w8, [sp, #0xa8]
10004df90: 92800008    	mov	x8, #-0x1               ; =-1
10004df94: f90053e8    	str	x8, [sp, #0xa0]
10004df98: f85703a8    	ldur	x8, [x29, #-0x90]
10004df9c: 92800009    	mov	x9, #-0x1               ; =-1
10004dfa0: f8690108    	ldaddl	x9, x8, [x8]
10004dfa4: f100051f    	cmp	x8, #0x1
10004dfa8: 54002ca1    	b.ne	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004dfac: d50339bf    	dmb	ishld
10004dfb0: 52800018    	mov	w24, #0x0               ; =0
10004dfb4: d10243a0    	sub	x0, x29, #0x90
10004dfb8: 9400c098    	bl	0x10007e218 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004dfbc: 14000160    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004dfc0: f85703a8    	ldur	x8, [x29, #-0x90]
10004dfc4: f9400909    	ldr	x9, [x8, #0x10]
10004dfc8: f100053f    	cmp	x9, #0x1
10004dfcc: 540005e1    	b.ne	0x10004e088 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3a0>
10004dfd0: a941a909    	ldp	x9, x10, [x8, #0x18]
10004dfd4: f9401129    	ldr	x9, [x9, #0x20]
10004dfd8: 8b0a0120    	add	x0, x9, x10
10004dfdc: 1400002c    	b	0x10004e08c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3a4>
10004dfe0: 52800038    	mov	w24, #0x1               ; =1
10004dfe4: 9104e280    	add	x0, x20, #0x138
10004dfe8: 9400e8ad    	bl	0x10008829c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004dfec: aa0003e2    	mov	x2, x0
10004dff0: aa0103e5    	mov	x5, x1
10004dff4: a95193e3    	ldp	x3, x4, [sp, #0x118]
10004dff8: 910843e8    	add	x8, sp, #0x210
10004dffc: 911522a0    	add	x0, x21, #0x548
10004e000: aa0203e1    	mov	x1, x2
10004e004: aa0503e2    	mov	x2, x5
10004e008: a9010fe4    	stp	x4, x3, [sp, #0x10]
10004e00c: 97ff27bc    	bl	0x100017efc <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head>
10004e010: f9410be8    	ldr	x8, [sp, #0x210]
10004e014: f9410fe2    	ldr	x2, [sp, #0x218]
10004e018: b100051f    	cmn	x8, #0x1
10004e01c: 54000840    	b.eq	0x10004e124 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x43c>
10004e020: ad440760    	ldp	q0, q1, [x27, #0x80]
10004e024: f94013e9    	ldr	x9, [sp, #0x20]
10004e028: ad000520    	stp	q0, q1, [x9]
10004e02c: a90a0be8    	stp	x8, x2, [sp, #0xa0]
10004e030: 14000143    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e034: b40009c3    	cbz	x3, 0x10004e16c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x484>
10004e038: f9400288    	ldr	x8, [x20]
10004e03c: f100051f    	cmp	x8, #0x1
10004e040: 54003d21    	b.ne	0x10004e7e4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xafc>
10004e044: 39476282    	ldrb	w2, [x20, #0x1d8]
10004e048: 910843e0    	add	x0, sp, #0x210
10004e04c: 91002281    	add	x1, x20, #0x8
10004e050: 97fffe0c    	bl	0x10004d880 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::invoke_read>
10004e054: f9410be8    	ldr	x8, [sp, #0x210]
10004e058: 3cc78360    	ldur	q0, [x27, #0x78]
10004e05c: 3d802780    	str	q0, [x28, #0x90]
10004e060: b100051f    	cmn	x8, #0x1
10004e064: 54003240    	b.eq	0x10004e6ac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9c4>
10004e068: 3cc88360    	ldur	q0, [x27, #0x88]
10004e06c: 3c818380    	stur	q0, [x28, #0x18]
10004e070: f9411fe9    	ldr	x9, [sp, #0x238]
10004e074: 3dc02780    	ldr	q0, [x28, #0x90]
10004e078: 3d800320    	str	q0, [x25]
10004e07c: f90067e9    	str	x9, [sp, #0xc8]
10004e080: f90053e8    	str	x8, [sp, #0xa0]
10004e084: 1400012e    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e088: f9401100    	ldr	x0, [x8, #0x20]
10004e08c: f9401501    	ldr	x1, [x8, #0x28]
10004e090: 910843e8    	add	x8, sp, #0x210
10004e094: 9400a95b    	bl	0x100078600 <<raster::format::record::Record>::decode>
10004e098: f9410be8    	ldr	x8, [sp, #0x210]
10004e09c: f100091f    	cmp	x8, #0x2
10004e0a0: 54000101    	b.ne	0x10004e0c0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3d8>
10004e0a4: 3cc88360    	ldur	q0, [x27, #0x88]
10004e0a8: 3cc98361    	ldur	q1, [x27, #0x98]
10004e0ac: f94013e8    	ldr	x8, [sp, #0x20]
10004e0b0: ad000500    	stp	q0, q1, [x8]
10004e0b4: 3cc78360    	ldur	q0, [x27, #0x78]
10004e0b8: 3d802be0    	str	q0, [sp, #0xa0]
10004e0bc: 17ffffb7    	b	0x10004df98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e0c0: f94113e8    	ldr	x8, [sp, #0x220]
10004e0c4: f85703a9    	ldur	x9, [x29, #-0x90]
10004e0c8: f9402129    	ldr	x9, [x9, #0x40]
10004e0cc: eb09011f    	cmp	x8, x9
10004e0d0: 540006a1    	b.ne	0x10004e1a4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4bc>
10004e0d4: f94127f6    	ldr	x22, [sp, #0x248]
10004e0d8: f9412bf7    	ldr	x23, [sp, #0x250]
10004e0dc: f9417ea8    	ldr	x8, [x21, #0x2f8]
10004e0e0: 91004100    	add	x0, x8, #0x10
10004e0e4: 52800021    	mov	w1, #0x1                ; =1
10004e0e8: 9401183a    	bl	0x1000941d0 <<raster::engine::metrics::Metrics>::cache>
10004e0ec: f94073e8    	ldr	x8, [sp, #0xe0]
10004e0f0: f100091f    	cmp	x8, #0x2
10004e0f4: 54000661    	b.ne	0x10004e1c0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4d8>
10004e0f8: f94077e1    	ldr	x1, [sp, #0xe8]
10004e0fc: 910843e8    	add	x8, sp, #0x210
10004e100: 9109a2a0    	add	x0, x21, #0x268
10004e104: 9400df50    	bl	0x100085e44 <<raster::cache::ReadCache>::touch>
10004e108: f9410be8    	ldr	x8, [sp, #0x210]
10004e10c: b100051f    	cmn	x8, #0x1
10004e110: 54000580    	b.eq	0x10004e1c0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4d8>
10004e114: ad438760    	ldp	q0, q1, [x27, #0x70]
10004e118: 3d802be0    	str	q0, [sp, #0xa0]
10004e11c: 3dc02760    	ldr	q0, [x27, #0x90]
10004e120: 1400003d    	b	0x10004e214 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x52c>
10004e124: b4000242    	cbz	x2, 0x10004e16c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x484>
10004e128: f9010be2    	str	x2, [sp, #0x210]
10004e12c: 9101e448    	add	x8, x2, #0x79
10004e130: 08dffd08    	ldarb	w8, [x8]
10004e134: 340031e8    	cbz	w8, 0x10004e770 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa88>
10004e138: 39476288    	ldrb	w8, [x20, #0x1d8]
10004e13c: 11000508    	add	w8, w8, #0x1
10004e140: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e144: 3902a7ff    	strb	wzr, [sp, #0xa9]
10004e148: 92800008    	mov	x8, #-0x1               ; =-1
10004e14c: f90053e8    	str	x8, [sp, #0xa0]
10004e150: f8680048    	ldaddl	x8, x8, [x2]
10004e154: f100051f    	cmp	x8, #0x1
10004e158: 54001f21    	b.ne	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e15c: d50339bf    	dmb	ishld
10004e160: 910843e0    	add	x0, sp, #0x210
10004e164: 97ff9fbf    	bl	0x100036060 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004e168: 140000f5    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e16c: ad428780    	ldp	q0, q1, [x28, #0x50]
10004e170: ad058680    	stp	q0, q1, [x20, #0xb0]
10004e174: f9408be8    	ldr	x8, [sp, #0x110]
10004e178: f9006a88    	str	x8, [x20, #0xd0]
10004e17c: ad418381    	ldp	q1, q0, [x28, #0x30]
10004e180: ad048281    	stp	q1, q0, [x20, #0x90]
10004e184: 3944e288    	ldrb	w8, [x20, #0x138]
10004e188: 7100051f    	cmp	w8, #0x1
10004e18c: 54000481    	b.ne	0x10004e21c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x534>
10004e190: 910683e8    	add	x8, sp, #0x1a0
10004e194: 91002108    	add	x8, x8, #0x8
10004e198: 91050280    	add	x0, x20, #0x140
10004e19c: 97ffd337    	bl	0x100042e78 <<alloc::vec::Vec<u8> as core::clone::Clone>::clone>
10004e1a0: 14000025    	b	0x10004e234 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x54c>
10004e1a4: 528000e8    	mov	w8, #0x7                ; =7
10004e1a8: d0000469    	adrp	x9, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x188>
10004e1ac: 913f5d29    	add	x9, x9, #0xfd7
10004e1b0: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e1b4: 528003a8    	mov	w8, #0x1d               ; =29
10004e1b8: f9005be8    	str	x8, [sp, #0xb0]
10004e1bc: 17ffff77    	b	0x10004df98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e1c0: f942aaa8    	ldr	x8, [x21, #0x550]
10004e1c4: 52800029    	mov	w9, #0x1                ; =1
10004e1c8: f8290108    	ldadd	x9, x8, [x8]
10004e1cc: b7f83188    	tbnz	x8, #0x3f, 0x10004e7fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb14>
10004e1d0: f942aaa0    	ldr	x0, [x21, #0x550]
10004e1d4: f942e2a3    	ldr	x3, [x21, #0x5c0]
10004e1d8: 910843e8    	add	x8, sp, #0x210
10004e1dc: aa1603e1    	mov	x1, x22
10004e1e0: aa1703e2    	mov	x2, x23
10004e1e4: 97ffb458    	bl	0x10003b344 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::decode>
10004e1e8: f9410be8    	ldr	x8, [sp, #0x210]
10004e1ec: 3cc78360    	ldur	q0, [x27, #0x78]
10004e1f0: 3cc88361    	ldur	q1, [x27, #0x88]
10004e1f4: ad080780    	stp	q0, q1, [x28, #0x100]
10004e1f8: 3cc98360    	ldur	q0, [x27, #0x98]
10004e1fc: 3d804b80    	str	q0, [x28, #0x120]
10004e200: f100091f    	cmp	x8, #0x2
10004e204: 54002701    	b.ne	0x10004e6e4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9fc>
10004e208: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e20c: 3d802be0    	str	q0, [sp, #0xa0]
10004e210: 3dc04b80    	ldr	q0, [x28, #0x120]
10004e214: ad008381    	stp	q1, q0, [x28, #0x10]
10004e218: 17ffff60    	b	0x10004df98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e21c: 52800018    	mov	w24, #0x0               ; =0
10004e220: 9104ea88    	add	x8, x20, #0x13a
10004e224: 3dc00100    	ldr	q0, [x8]
10004e228: 3c802360    	stur	q0, [x27, #0x2]
10004e22c: 3944e688    	ldrb	w8, [x20, #0x139]
10004e230: 390687e8    	strb	w8, [sp, #0x1a1]
10004e234: 390683f8    	strb	w24, [sp, #0x1a0]
10004e238: f940be85    	ldr	x5, [x20, #0x178]
10004e23c: 910843e8    	add	x8, sp, #0x210
10004e240: 911522a0    	add	x0, x21, #0x548
10004e244: 910822a1    	add	x1, x21, #0x208
10004e248: 910683e2    	add	x2, sp, #0x1a0
10004e24c: a9410fe4    	ldp	x4, x3, [sp, #0x10]
10004e250: 97ff1d46    	bl	0x100015768 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::lookup_deferred::<raster::schema::encoded_key::EncodedKey>>
10004e254: f9410bf8    	ldr	x24, [sp, #0x210]
10004e258: 3cc78360    	ldur	q0, [x27, #0x78]
10004e25c: 3cc88361    	ldur	q1, [x27, #0x88]
10004e260: ad048780    	stp	q0, q1, [x28, #0x90]
10004e264: 3cc98360    	ldur	q0, [x27, #0x98]
10004e268: 3d802f80    	str	q0, [x28, #0xb0]
10004e26c: f1000b1f    	cmp	x24, #0x2
10004e270: 54ffe040    	b.eq	0x10004de78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x190>
10004e274: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e278: 3ccb8361    	ldur	q1, [x27, #0xb8]
10004e27c: ad000760    	stp	q0, q1, [x27]
10004e280: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e284: 3d800b60    	str	q0, [x27, #0x20]
10004e288: 3ccd2360    	ldur	q0, [x27, #0xd2]
10004e28c: 3c82a360    	stur	q0, [x27, #0x2a]
10004e290: 394a0be8    	ldrb	w8, [sp, #0x282]
10004e294: 394a0fe9    	ldrb	w9, [sp, #0x283]
10004e298: b94287ea    	ldr	w10, [sp, #0x284]
10004e29c: b9001bea    	str	w10, [sp, #0x18]
10004e2a0: ad448780    	ldp	q0, q1, [x28, #0x90]
10004e2a4: ad020760    	stp	q0, q1, [x27, #0x40]
10004e2a8: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004e2ac: 3d801b60    	str	q0, [x27, #0x60]
10004e2b0: 3946228a    	ldrb	w10, [x20, #0x188]
10004e2b4: 7100015f    	cmp	w10, #0x0
10004e2b8: 1a8913e9    	csel	w9, wzr, w9, ne
10004e2bc: 1a9f0508    	csinc	w8, w8, wzr, eq
10004e2c0: 2901a7e8    	stp	w8, w9, [sp, #0xc]
10004e2c4: f9400e88    	ldr	x8, [x20, #0x18]
10004e2c8: f100091f    	cmp	x8, #0x2
10004e2cc: 54000060    	b.eq	0x10004e2d8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x5f0>
10004e2d0: aa1603e0    	mov	x0, x22
10004e2d4: 97fffc30    	bl	0x10004d394 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e2d8: f9000e98    	str	x24, [x20, #0x18]
10004e2dc: ad420760    	ldp	q0, q1, [x27, #0x40]
10004e2e0: ad010680    	stp	q0, q1, [x20, #0x20]
10004e2e4: 3dc01b60    	ldr	q0, [x27, #0x60]
10004e2e8: ad400b61    	ldp	q1, q2, [x27]
10004e2ec: ad020680    	stp	q0, q1, [x20, #0x40]
10004e2f0: 3dc00b60    	ldr	q0, [x27, #0x20]
10004e2f4: ad030282    	stp	q2, q0, [x20, #0x60]
10004e2f8: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004e2fc: 3c87a280    	stur	q0, [x20, #0x7a]
10004e300: 2941a3e9    	ldp	w9, w8, [sp, #0xc]
10004e304: 39022a89    	strb	w9, [x20, #0x8a]
10004e308: 39022e88    	strb	w8, [x20, #0x8b]
10004e30c: b9401be8    	ldr	w8, [sp, #0x18]
10004e310: b9008e88    	str	w8, [x20, #0x8c]
10004e314: b9400288    	ldr	w8, [x20]
10004e318: 360023e8    	tbz	w8, #0x0, 0x10004e794 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xaac>
10004e31c: 910843e8    	add	x8, sp, #0x210
10004e320: 911522a1    	add	x1, x21, #0x548
10004e324: 910822a2    	add	x2, x21, #0x208
10004e328: aa1603e0    	mov	x0, x22
10004e32c: aa1703e3    	mov	x3, x23
10004e330: 97ffa2c5    	bl	0x100036e44 <<raster::log::lookup::LogLookup>::step::<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>
10004e334: f9410be8    	ldr	x8, [sp, #0x210]
10004e338: f9410fe2    	ldr	x2, [sp, #0x218]
10004e33c: ad440760    	ldp	q0, q1, [x27, #0x80]
10004e340: ad078760    	stp	q0, q1, [x27, #0xf0]
10004e344: f94123e9    	ldr	x9, [sp, #0x240]
10004e348: f81603a9    	stur	x9, [x29, #-0xa0]
10004e34c: b100051f    	cmn	x8, #0x1
10004e350: 54000740    	b.eq	0x10004e438 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x750>
10004e354: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e358: 3c8b8380    	stur	q0, [x28, #0xb8]
10004e35c: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e360: 3c8c8380    	stur	q0, [x28, #0xc8]
10004e364: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e368: 3c8d8380    	stur	q0, [x28, #0xd8]
10004e36c: f9413fe9    	ldr	x9, [sp, #0x278]
10004e370: ad478760    	ldp	q0, q1, [x27, #0xf0]
10004e374: f85603aa    	ldur	x10, [x29, #-0xa0]
10004e378: f900c7e9    	str	x9, [sp, #0x188]
10004e37c: f900abea    	str	x10, [sp, #0x150]
10004e380: d1000909    	sub	x9, x8, #0x2
10004e384: f100051f    	cmp	x8, #0x1
10004e388: 9a9f8529    	csinc	x9, x9, xzr, hi
10004e38c: ad048780    	stp	q0, q1, [x28, #0x90]
10004e390: f100093f    	cmp	x9, #0x2
10004e394: 540005ec    	b.gt	0x10004e450 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x768>
10004e398: b40007a9    	cbz	x9, 0x10004e48c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7a4>
10004e39c: f100053f    	cmp	x9, #0x1
10004e3a0: 540007e1    	b.ne	0x10004e49c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7b4>
10004e3a4: f9010be8    	str	x8, [sp, #0x210]
10004e3a8: f9010fe2    	str	x2, [sp, #0x218]
10004e3ac: ad458780    	ldp	q0, q1, [x28, #0xb0]
10004e3b0: ad050760    	stp	q0, q1, [x27, #0xa0]
10004e3b4: ad468780    	ldp	q0, q1, [x28, #0xd0]
10004e3b8: ad060760    	stp	q0, q1, [x27, #0xc0]
10004e3bc: ad448780    	ldp	q0, q1, [x28, #0x90]
10004e3c0: ad040760    	stp	q0, q1, [x27, #0x80]
10004e3c4: f9404a88    	ldr	x8, [x20, #0x90]
10004e3c8: f100091f    	cmp	x8, #0x2
10004e3cc: 54001f20    	b.eq	0x10004e7b0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xac8>
10004e3d0: f940ca81    	ldr	x1, [x20, #0x190]
10004e3d4: f9006be8    	str	x8, [sp, #0xd0]
10004e3d8: 3cc98280    	ldur	q0, [x20, #0x98]
10004e3dc: 3c838380    	stur	q0, [x28, #0x38]
10004e3e0: 3cca8280    	ldur	q0, [x20, #0xa8]
10004e3e4: 3c848380    	stur	q0, [x28, #0x48]
10004e3e8: 3ccb8280    	ldur	q0, [x20, #0xb8]
10004e3ec: 3c858380    	stur	q0, [x28, #0x58]
10004e3f0: 3ccc8280    	ldur	q0, [x20, #0xc8]
10004e3f4: 3c868380    	stur	q0, [x28, #0x68]
10004e3f8: f9400e88    	ldr	x8, [x20, #0x18]
10004e3fc: f100091f    	cmp	x8, #0x2
10004e400: 54001e40    	b.eq	0x10004e7c8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xae0>
10004e404: d10243a8    	sub	x8, x29, #0x90
10004e408: 910202a0    	add	x0, x21, #0x80
10004e40c: 910343e2    	add	x2, sp, #0xd0
10004e410: aa1603e3    	mov	x3, x22
10004e414: 97fefa5c    	bl	0x10000cd84 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::populate_cache>
10004e418: f85703a8    	ldur	x8, [x29, #-0x90]
10004e41c: b100051f    	cmn	x8, #0x1
10004e420: 540006c0    	b.eq	0x10004e4f8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x810>
10004e424: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e428: 3d802be0    	str	q0, [sp, #0xa0]
10004e42c: 3dc05360    	ldr	q0, [x27, #0x140]
10004e430: ad008381    	stp	q1, q0, [x28, #0x10]
10004e434: 14000040    	b	0x10004e534 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x84c>
10004e438: ad478760    	ldp	q0, q1, [x27, #0xf0]
10004e43c: ad000720    	stp	q0, q1, [x25]
10004e440: f85603a8    	ldur	x8, [x29, #-0xa0]
10004e444: f9001328    	str	x8, [x25, #0x20]
10004e448: f90053e2    	str	x2, [sp, #0xa0]
10004e44c: 1400003c    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e450: d1001528    	sub	x8, x9, #0x5
10004e454: f100091f    	cmp	x8, #0x2
10004e458: 54000082    	b.hs	0x10004e468 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x780>
10004e45c: 52801fe8    	mov	w8, #0xff               ; =255
10004e460: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e464: 14000007    	b	0x10004e480 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x798>
10004e468: f1000d3f    	cmp	x9, #0x3
10004e46c: 54000261    	b.ne	0x10004e4b8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7d0>
10004e470: 39476288    	ldrb	w8, [x20, #0x1d8]
10004e474: 11000508    	add	w8, w8, #0x1
10004e478: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e47c: 3902a7ff    	strb	wzr, [sp, #0xa9]
10004e480: 92800008    	mov	x8, #-0x1               ; =-1
10004e484: f90053e8    	str	x8, [sp, #0xa0]
10004e488: 1400002d    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e48c: 910283e0    	add	x0, sp, #0xa0
10004e490: aa1403e1    	mov	x1, x20
10004e494: 97fffd88    	bl	0x10004dab4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
10004e498: 14000029    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e49c: 528000e8    	mov	w8, #0x7                ; =7
10004e4a0: f0000469    	adrp	x9, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x4c>
10004e4a4: 9100ed29    	add	x9, x9, #0x3b
10004e4a8: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e4ac: 52800448    	mov	w8, #0x22               ; =34
10004e4b0: f9005be8    	str	x8, [sp, #0xb0]
10004e4b4: 14000022    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e4b8: f940ca81    	ldr	x1, [x20, #0x190]
10004e4bc: 910843e8    	add	x8, sp, #0x210
10004e4c0: 910202a0    	add	x0, x21, #0x80
10004e4c4: 94005516    	bl	0x10006391c <<raster::index::growth::MemIndex>::prepare>
10004e4c8: f9410be8    	ldr	x8, [sp, #0x210]
10004e4cc: 3cc78360    	ldur	q0, [x27, #0x78]
10004e4d0: 3cc88361    	ldur	q1, [x27, #0x88]
10004e4d4: ad090760    	stp	q0, q1, [x27, #0x120]
10004e4d8: 3cc98360    	ldur	q0, [x27, #0x98]
10004e4dc: 3d805360    	str	q0, [x27, #0x140]
10004e4e0: f100091f    	cmp	x8, #0x2
10004e4e4: 54000a21    	b.ne	0x10004e628 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x940>
10004e4e8: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e4ec: 3d802be0    	str	q0, [sp, #0xa0]
10004e4f0: 3dc05360    	ldr	q0, [x27, #0x140]
10004e4f4: 17fffe64    	b	0x10004de84 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x19c>
10004e4f8: 910343e8    	add	x8, sp, #0xd0
10004e4fc: 910843e0    	add	x0, sp, #0x210
10004e500: 91002281    	add	x1, x20, #0x8
10004e504: 97ffaea3    	bl	0x100039f90 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#2}>>
10004e508: a94d23ea    	ldp	x10, x8, [sp, #0xd0]
10004e50c: f94073e9    	ldr	x9, [sp, #0xe0]
10004e510: 3cc48380    	ldur	q0, [x28, #0x48]
10004e514: 3cc58381    	ldur	q1, [x28, #0x58]
10004e518: ad090760    	stp	q0, q1, [x27, #0x120]
10004e51c: f100055f    	cmp	x10, #0x1
10004e520: 54000ba1    	b.ne	0x10004e694 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9ac>
10004e524: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e528: f94013ea    	ldr	x10, [sp, #0x20]
10004e52c: ad000540    	stp	q0, q1, [x10]
10004e530: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e534: 910843e0    	add	x0, sp, #0x210
10004e538: 97fffae6    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e53c: a94a5be8    	ldp	x8, x22, [sp, #0xa0]
10004e540: ad408780    	ldp	q0, q1, [x28, #0x10]
10004e544: a903dbe8    	stp	x8, x22, [sp, #0x38]
10004e548: 3c8583e1    	stur	q1, [sp, #0x58]
10004e54c: 3c8483e0    	stur	q0, [sp, #0x48]
10004e550: b100091f    	cmn	x8, #0x2
10004e554: 54000200    	b.eq	0x10004e594 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8ac>
10004e558: b100051f    	cmn	x8, #0x1
10004e55c: 54000501    	b.ne	0x10004e5fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x914>
10004e560: 52801fe8    	mov	w8, #0xff               ; =255
10004e564: 6a36011f    	bics	wzr, w8, w22
10004e568: 54000120    	b.eq	0x10004e58c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8a4>
10004e56c: f84413e8    	ldur	x8, [sp, #0x41]
10004e570: f8079368    	stur	x8, [x27, #0x79]
10004e574: f94027e8    	ldr	x8, [sp, #0x48]
10004e578: f90113e8    	str	x8, [sp, #0x220]
10004e57c: 390863f6    	strb	w22, [sp, #0x218]
10004e580: 92800008    	mov	x8, #-0x1               ; =-1
10004e584: f9010be8    	str	x8, [sp, #0x210]
10004e588: 17fffe05    	b	0x10004dd9c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb4>
10004e58c: 52800268    	mov	w8, #0x13               ; =19
10004e590: 17fffe08    	b	0x10004ddb0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc8>
10004e594: 9e660017    	fmov	x23, d0
10004e598: 52800028    	mov	w8, #0x1                ; =1
10004e59c: 089fff48    	stlrb	w8, [x26]
10004e5a0: f0000468    	adrp	x8, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x4c>
10004e5a4: 91017508    	add	x8, x8, #0x5d
10004e5a8: 528000e9    	mov	w9, #0x7                ; =7
10004e5ac: a906a3e9    	stp	x9, x8, [sp, #0x68]
10004e5b0: 52800268    	mov	w8, #0x13               ; =19
10004e5b4: f9003fe8    	str	x8, [sp, #0x78]
10004e5b8: 390263ff    	strb	wzr, [sp, #0x98]
10004e5bc: 9101a3e2    	add	x2, sp, #0x68
10004e5c0: aa1403e0    	mov	x0, x20
10004e5c4: aa1503e1    	mov	x1, x21
10004e5c8: 94000100    	bl	0x10004e9c8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004e5cc: 52800248    	mov	w8, #0x12               ; =18
10004e5d0: f9000268    	str	x8, [x19]
10004e5d4: f94002e8    	ldr	x8, [x23]
10004e5d8: b4000068    	cbz	x8, 0x10004e5e4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8fc>
10004e5dc: aa1603e0    	mov	x0, x22
10004e5e0: d63f0100    	blr	x8
10004e5e4: f94006e1    	ldr	x1, [x23, #0x8]
10004e5e8: b4ffbe61    	cbz	x1, 0x10004ddb4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcc>
10004e5ec: f9400ae2    	ldr	x2, [x23, #0x10]
10004e5f0: aa1603e0    	mov	x0, x22
10004e5f4: 94000396    	bl	0x10004f44c <__rustc::__rust_dealloc>
10004e5f8: 17fffdef    	b	0x10004ddb4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcc>
10004e5fc: 3cc503e0    	ldur	q0, [sp, #0x50]
10004e600: 3c888360    	stur	q0, [x27, #0x88]
10004e604: f94033e9    	ldr	x9, [sp, #0x60]
10004e608: f84413ea    	ldur	x10, [sp, #0x41]
10004e60c: f807936a    	stur	x10, [x27, #0x79]
10004e610: f94027ea    	ldr	x10, [sp, #0x48]
10004e614: f9011fe9    	str	x9, [sp, #0x238]
10004e618: f90113ea    	str	x10, [sp, #0x220]
10004e61c: f9010be8    	str	x8, [sp, #0x210]
10004e620: 390863f6    	strb	w22, [sp, #0x218]
10004e624: 17fffddd    	b	0x10004dd98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb0>
10004e628: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e62c: 3c868380    	stur	q0, [x28, #0x68]
10004e630: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e634: 3c838380    	stur	q0, [x28, #0x38]
10004e638: 3c848381    	stur	q1, [x28, #0x48]
10004e63c: 3dc05360    	ldr	q0, [x27, #0x140]
10004e640: 3c858380    	stur	q0, [x28, #0x58]
10004e644: f9006be8    	str	x8, [sp, #0xd0]
10004e648: aa1403f7    	mov	x23, x20
10004e64c: f8490ee8    	ldr	x8, [x23, #0x90]!
10004e650: f100091f    	cmp	x8, #0x2
10004e654: 540000e0    	b.eq	0x10004e670 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x988>
10004e658: 910343e1    	add	x1, sp, #0xd0
10004e65c: aa1703e0    	mov	x0, x23
10004e660: 940002cf    	bl	0x10004f19c <<raster::index::EntrySnapshot as core::cmp::PartialEq>::eq>
10004e664: 36000060    	tbz	w0, #0x0, 0x10004e670 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x988>
10004e668: 52800028    	mov	w8, #0x1                ; =1
10004e66c: 17ffff7d    	b	0x10004e460 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x778>
10004e670: f94002c8    	ldr	x8, [x22]
10004e674: f100091f    	cmp	x8, #0x2
10004e678: 54000060    	b.eq	0x10004e684 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x99c>
10004e67c: aa1603e0    	mov	x0, x22
10004e680: 97fffb45    	bl	0x10004d394 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e684: 52800048    	mov	w8, #0x2                ; =2
10004e688: f90002c8    	str	x8, [x22]
10004e68c: f90002e8    	str	x8, [x23]
10004e690: 17ffff73    	b	0x10004e45c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x774>
10004e694: b100051f    	cmn	x8, #0x1
10004e698: 54000180    	b.eq	0x10004e6c8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9e0>
10004e69c: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e6a0: f94013ea    	ldr	x10, [sp, #0x20]
10004e6a4: ad000540    	stp	q0, q1, [x10]
10004e6a8: 1400000a    	b	0x10004e6d0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9e8>
10004e6ac: 3dc02780    	ldr	q0, [x28, #0x90]
10004e6b0: 3d801f60    	str	q0, [x27, #0x70]
10004e6b4: 910283e0    	add	x0, sp, #0xa0
10004e6b8: 910843e2    	add	x2, sp, #0x210
10004e6bc: aa1403e1    	mov	x1, x20
10004e6c0: 940000a2    	bl	0x10004e948 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish_read_access>
10004e6c4: 17ffff9e    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e6c8: 3902a3ff    	strb	wzr, [sp, #0xa8]
10004e6cc: f94013f9    	ldr	x25, [sp, #0x20]
10004e6d0: f9000329    	str	x9, [x25]
10004e6d4: f90053e8    	str	x8, [sp, #0xa0]
10004e6d8: 910843e0    	add	x0, sp, #0x210
10004e6dc: 97fffa7d    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e6e0: 17ffff97    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e6e4: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e6e8: 3c8c8380    	stur	q0, [x28, #0xc8]
10004e6ec: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e6f0: 3c8d8380    	stur	q0, [x28, #0xd8]
10004e6f4: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e6f8: 3c8e8380    	stur	q0, [x28, #0xe8]
10004e6fc: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e700: 3c898380    	stur	q0, [x28, #0x98]
10004e704: f9413fe9    	ldr	x9, [sp, #0x278]
10004e708: 3c8a8381    	stur	q1, [x28, #0xa8]
10004e70c: 3dc04b80    	ldr	q0, [x28, #0x120]
10004e710: 3c8b8380    	stur	q0, [x28, #0xb8]
10004e714: f900cfe9    	str	x9, [sp, #0x198]
10004e718: f9009be8    	str	x8, [sp, #0x130]
10004e71c: 910843e8    	add	x8, sp, #0x210
10004e720: 9104c3e0    	add	x0, sp, #0x130
10004e724: aa1403e1    	mov	x1, x20
10004e728: 97ffad92    	bl	0x100039d70 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#0}>>
10004e72c: f9410bea    	ldr	x10, [sp, #0x210]
10004e730: f9410fe9    	ldr	x9, [sp, #0x218]
10004e734: f94113e8    	ldr	x8, [sp, #0x220]
10004e738: 3cc88360    	ldur	q0, [x27, #0x88]
10004e73c: 3cc98361    	ldur	q1, [x27, #0x98]
10004e740: ad080780    	stp	q0, q1, [x28, #0x100]
10004e744: f100055f    	cmp	x10, #0x1
10004e748: 54000060    	b.eq	0x10004e754 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa6c>
10004e74c: b100053f    	cmn	x9, #0x1
10004e750: 54000180    	b.eq	0x10004e780 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa98>
10004e754: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e758: f94013ea    	ldr	x10, [sp, #0x20]
10004e75c: ad000540    	stp	q0, q1, [x10]
10004e760: a90a23e9    	stp	x9, x8, [sp, #0xa0]
10004e764: 9104c3e0    	add	x0, sp, #0x130
10004e768: 97fffa5a    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e76c: 17fffe0b    	b	0x10004df98 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e770: 910283e0    	add	x0, sp, #0xa0
10004e774: aa1403e1    	mov	x1, x20
10004e778: 97fffccf    	bl	0x10004dab4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
10004e77c: 17ffff70    	b	0x10004e53c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e780: 3902a3ff    	strb	wzr, [sp, #0xa8]
10004e784: f9005be8    	str	x8, [sp, #0xb0]
10004e788: 92800008    	mov	x8, #-0x1               ; =-1
10004e78c: f90053e8    	str	x8, [sp, #0xa0]
10004e790: 17fffff5    	b	0x10004e764 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa7c>
10004e794: d0000460    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x188>
10004e798: 913fd000    	add	x0, x0, #0xff4
10004e79c: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7a0: 912cc042    	add	x2, x2, #0xb30
10004e7a4: 528004c1    	mov	w1, #0x26               ; =38
10004e7a8: 9401fda0    	bl	0x1000cde28 <core::option::expect_failed>
10004e7ac: 14000014    	b	0x10004e7fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb14>
10004e7b0: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7b4: 912d2042    	add	x2, x2, #0xb48
10004e7b8: 52800281    	mov	w1, #0x14               ; =20
10004e7bc: f0000460    	adrp	x0, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x4c>
10004e7c0: 91009c00    	add	x0, x0, #0x27
10004e7c4: 14000006    	b	0x10004e7dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xaf4>
10004e7c8: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7cc: 912d8042    	add	x2, x2, #0xb60
10004e7d0: 528001a1    	mov	w1, #0xd                ; =13
10004e7d4: f0000460    	adrp	x0, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x4c>
10004e7d8: 91006800    	add	x0, x0, #0x1a
10004e7dc: 9401fd93    	bl	0x1000cde28 <core::option::expect_failed>
10004e7e0: 14000007    	b	0x10004e7fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb14>
10004e7e4: d0000460    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x188>
10004e7e8: 913fd000    	add	x0, x0, #0xff4
10004e7ec: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7f0: 912c6042    	add	x2, x2, #0xb18
10004e7f4: 528004c1    	mov	w1, #0x26               ; =38
10004e7f8: 9401fd8c    	bl	0x1000cde28 <core::option::expect_failed>
10004e7fc: d4200020    	brk	#0x1
10004e800: 1400001b    	b	0x10004e86c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb84>
10004e804: aa0003f7    	mov	x23, x0
10004e808: f9000e98    	str	x24, [x20, #0x18]
10004e80c: ad420760    	ldp	q0, q1, [x27, #0x40]
10004e810: ad010680    	stp	q0, q1, [x20, #0x20]
10004e814: 3dc01b60    	ldr	q0, [x27, #0x60]
10004e818: ad400b61    	ldp	q1, q2, [x27]
10004e81c: ad020680    	stp	q0, q1, [x20, #0x40]
10004e820: 3dc00b60    	ldr	q0, [x27, #0x20]
10004e824: ad030282    	stp	q2, q0, [x20, #0x60]
10004e828: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004e82c: 3c87a280    	stur	q0, [x20, #0x7a]
10004e830: 2941a3e9    	ldp	w9, w8, [sp, #0xc]
10004e834: 39022a89    	strb	w9, [x20, #0x8a]
10004e838: 39022e88    	strb	w8, [x20, #0x8b]
10004e83c: 52800038    	mov	w24, #0x1               ; =1
10004e840: b9401be8    	ldr	w8, [sp, #0x18]
10004e844: b9008e88    	str	w8, [x20, #0x8c]
10004e848: 14000025    	b	0x10004e8dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbf4>
10004e84c: aa0003f7    	mov	x23, x0
10004e850: 9104c3e0    	add	x0, sp, #0x130
10004e854: 97fffa1f    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e858: 14000011    	b	0x10004e89c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbb4>
10004e85c: aa0003f7    	mov	x23, x0
10004e860: 52800048    	mov	w8, #0x2                ; =2
10004e864: f90002c8    	str	x8, [x22]
10004e868: 1400002f    	b	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e86c: aa0003f7    	mov	x23, x0
10004e870: 52800038    	mov	w24, #0x1               ; =1
10004e874: 1400001a    	b	0x10004e8dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbf4>
10004e878: aa0003f3    	mov	x19, x0
10004e87c: f94006e1    	ldr	x1, [x23, #0x8]
10004e880: b4000261    	cbz	x1, 0x10004e8cc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbe4>
10004e884: f9400ae2    	ldr	x2, [x23, #0x10]
10004e888: aa1603e0    	mov	x0, x22
10004e88c: 940002f0    	bl	0x10004f44c <__rustc::__rust_dealloc>
10004e890: aa1303e0    	mov	x0, x19
10004e894: 9401fe73    	bl	0x1000ce260 <dyld_stub_binder+0x1000ce260>
10004e898: aa0003f7    	mov	x23, x0
10004e89c: f85703a8    	ldur	x8, [x29, #-0x90]
10004e8a0: 92800009    	mov	x9, #-0x1               ; =-1
10004e8a4: f8690108    	ldaddl	x9, x8, [x8]
10004e8a8: f100051f    	cmp	x8, #0x1
10004e8ac: 540003c1    	b.ne	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e8b0: d50339bf    	dmb	ishld
10004e8b4: d10243a0    	sub	x0, x29, #0x90
10004e8b8: 9400be58    	bl	0x10007e218 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e8bc: 1400001a    	b	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e8c0: aa0003f3    	mov	x19, x0
10004e8c4: 9100e3e0    	add	x0, sp, #0x38
10004e8c8: 97fff990    	bl	0x10004cf08 <core::ptr::drop_glue::<core::result::Result<core::result::Result<core::option::Option<raster::api::completion::Outcome<u64>>, raster::types::error::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
10004e8cc: aa1303e0    	mov	x0, x19
10004e8d0: 9401fe64    	bl	0x1000ce260 <dyld_stub_binder+0x1000ce260>
10004e8d4: 9401fd82    	bl	0x1000cdedc <core::panicking::panic_in_cleanup>
10004e8d8: aa0003f7    	mov	x23, x0
10004e8dc: 34000258    	cbz	w24, 0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e8e0: f94097e8    	ldr	x8, [sp, #0x128]
10004e8e4: b4000208    	cbz	x8, 0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e8e8: 92800009    	mov	x9, #-0x1               ; =-1
10004e8ec: f8690108    	ldaddl	x9, x8, [x8]
10004e8f0: f100051f    	cmp	x8, #0x1
10004e8f4: 54000181    	b.ne	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e8f8: 910343e8    	add	x8, sp, #0xd0
10004e8fc: d50339bf    	dmb	ishld
10004e900: 91016100    	add	x0, x8, #0x58
10004e904: 9400be45    	bl	0x10007e218 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e908: 14000007    	b	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e90c: aa0003f7    	mov	x23, x0
10004e910: 910843e0    	add	x0, sp, #0x210
10004e914: 97fff9ef    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e918: 14000003    	b	0x10004e924 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e91c: 9401fd70    	bl	0x1000cdedc <core::panicking::panic_in_cleanup>
10004e920: aa0003f7    	mov	x23, x0
10004e924: aa1703e0    	mov	x0, x23
10004e928: 9401fc40    	bl	0x1000cda28 <std::panicking::catch_unwind::cleanup>
10004e92c: aa0003f6    	mov	x22, x0
10004e930: aa0103f7    	mov	x23, x1
10004e934: a90407e0    	stp	x0, x1, [sp, #0x40]
10004e938: 92800028    	mov	x8, #-0x2               ; =-2
10004e93c: f9001fe8    	str	x8, [sp, #0x38]
10004e940: 17ffff16    	b	0x10004e598 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8b0>
10004e944: 9401fdb5    	bl	0x1000ce018 <core::panicking::panic_cannot_unwind>

