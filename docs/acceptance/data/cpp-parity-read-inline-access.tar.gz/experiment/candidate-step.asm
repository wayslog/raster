000000010004dc10 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint>:
10004dc10: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10004dc14: a90167fa    	stp	x26, x25, [sp, #0x10]
10004dc18: a9025ff8    	stp	x24, x23, [sp, #0x20]
10004dc1c: a90357f6    	stp	x22, x21, [sp, #0x30]
10004dc20: a9044ff4    	stp	x20, x19, [sp, #0x40]
10004dc24: a9057bfd    	stp	x29, x30, [sp, #0x50]
10004dc28: 910143fd    	add	x29, sp, #0x50
10004dc2c: d10c03ff    	sub	sp, sp, #0x300
10004dc30: aa0003f3    	mov	x19, x0
10004dc34: a90297e4    	stp	x4, x5, [sp, #0x28]
10004dc38: f9400028    	ldr	x8, [x1]
10004dc3c: b40004c8    	cbz	x8, 0x10004dcd4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc4>
10004dc40: aa0103f4    	mov	x20, x1
10004dc44: f9400055    	ldr	x21, [x2]
10004dc48: 52838508    	mov	w8, #0x1c28             ; =7208
10004dc4c: 8b0802ba    	add	x26, x21, x8
10004dc50: 08dfff48    	ldarb	w8, [x26]
10004dc54: 34000128    	cbz	w8, 0x10004dc78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x68>
10004dc58: 90000488    	adrp	x8, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x5c>
10004dc5c: 91018108    	add	x8, x8, #0x60
10004dc60: 528000e9    	mov	w9, #0x7                ; =7
10004dc64: f9010be9    	str	x9, [sp, #0x210]
10004dc68: f9010fe8    	str	x8, [sp, #0x218]
10004dc6c: 52800288    	mov	w8, #0x14               ; =20
10004dc70: f90113e8    	str	x8, [sp, #0x220]
10004dc74: 14000013    	b	0x10004dcc0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb0>
10004dc78: aa0303f7    	mov	x23, x3
10004dc7c: 910683fb    	add	x27, sp, #0x1a0
10004dc80: 910283fc    	add	x28, sp, #0xa0
10004dc84: f940ca81    	ldr	x1, [x20, #0x190]
10004dc88: 9106e288    	add	x8, x20, #0x1b8
10004dc8c: f940de89    	ldr	x9, [x20, #0x1b8]
10004dc90: f100013f    	cmp	x9, #0x0
10004dc94: 9a8803e2    	csel	x2, xzr, x8, eq
10004dc98: 9104c3e8    	add	x8, sp, #0x130
10004dc9c: 910d02a0    	add	x0, x21, #0x340
10004dca0: 940043eb    	bl	0x10005ec4c <<raster::engine::version_permit::VersionPermits>::ready_initial>
10004dca4: f9409be8    	ldr	x8, [sp, #0x130]
10004dca8: b100051f    	cmn	x8, #0x1
10004dcac: 54000280    	b.eq	0x10004dcfc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xec>
10004dcb0: ad448780    	ldp	q0, q1, [x28, #0x90]
10004dcb4: ad038760    	stp	q0, q1, [x27, #0x70]
10004dcb8: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004dcbc: 3d802760    	str	q0, [x27, #0x90]
10004dcc0: 390903ff    	strb	wzr, [sp, #0x240]
10004dcc4: 910843e2    	add	x2, sp, #0x210
10004dcc8: aa1403e0    	mov	x0, x20
10004dccc: aa1503e1    	mov	x1, x21
10004dcd0: 94000336    	bl	0x10004e9a8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004dcd4: 52800248    	mov	w8, #0x12               ; =18
10004dcd8: f9000268    	str	x8, [x19]
10004dcdc: 910c03ff    	add	sp, sp, #0x300
10004dce0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10004dce4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10004dce8: a94357f6    	ldp	x22, x21, [sp, #0x30]
10004dcec: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10004dcf0: a94167fa    	ldp	x26, x25, [sp, #0x10]
10004dcf4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10004dcf8: d65f03c0    	ret
10004dcfc: 3944e3e8    	ldrb	w8, [sp, #0x138]
10004dd00: 7100051f    	cmp	w8, #0x1
10004dd04: 54003d81    	b.ne	0x10004e4b4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8a4>
10004dd08: aa1403f6    	mov	x22, x20
10004dd0c: f8418ec8    	ldr	x8, [x22, #0x18]!
10004dd10: 910283e9    	add	x9, sp, #0xa0
10004dd14: 9100412a    	add	x10, x9, #0x10
10004dd18: f90013ea    	str	x10, [sp, #0x20]
10004dd1c: b27d0139    	orr	x25, x9, #0x8
10004dd20: f100091f    	cmp	x8, #0x2
10004dd24: 540028c1    	b.ne	0x10004e23c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x62c>
10004dd28: f94017e8    	ldr	x8, [sp, #0x28]
10004dd2c: b4000188    	cbz	x8, 0x10004dd5c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x14c>
10004dd30: f940ca98    	ldr	x24, [x20, #0x190]
10004dd34: 9104e280    	add	x0, x20, #0x138
10004dd38: 9400e951    	bl	0x10008827c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004dd3c: aa0003e2    	mov	x2, x0
10004dd40: aa0103e3    	mov	x3, x1
10004dd44: f94017e4    	ldr	x4, [sp, #0x28]
10004dd48: 910843e8    	add	x8, sp, #0x210
10004dd4c: 910202a0    	add	x0, x21, #0x80
10004dd50: aa1803e1    	mov	x1, x24
10004dd54: 97fefdf4    	bl	0x10000d524 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index_guarded>
10004dd58: 1400000a    	b	0x10004dd80 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x170>
10004dd5c: f940ca98    	ldr	x24, [x20, #0x190]
10004dd60: 9104e280    	add	x0, x20, #0x138
10004dd64: 9400e946    	bl	0x10008827c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004dd68: aa0003e2    	mov	x2, x0
10004dd6c: aa0103e3    	mov	x3, x1
10004dd70: 910843e8    	add	x8, sp, #0x210
10004dd74: 910202a0    	add	x0, x21, #0x80
10004dd78: aa1803e1    	mov	x1, x24
10004dd7c: 97fefbc6    	bl	0x10000cc94 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index>
10004dd80: f9410be8    	ldr	x8, [sp, #0x210]
10004dd84: 3cc78360    	ldur	q0, [x27, #0x78]
10004dd88: 3cc88361    	ldur	q1, [x27, #0x88]
10004dd8c: ad048780    	stp	q0, q1, [x28, #0x90]
10004dd90: 3cc98360    	ldur	q0, [x27, #0x98]
10004dd94: 3d802f80    	str	q0, [x28, #0xb0]
10004dd98: f100091f    	cmp	x8, #0x2
10004dd9c: 540000c1    	b.ne	0x10004ddb4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1a4>
10004dda0: ad448780    	ldp	q0, q1, [x28, #0x90]
10004dda4: 3d802be0    	str	q0, [sp, #0xa0]
10004dda8: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004ddac: ad008381    	stp	q1, q0, [x28, #0x10]
10004ddb0: 140001ad    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004ddb4: 3cca8360    	ldur	q0, [x27, #0xa8]
10004ddb8: 3c868380    	stur	q0, [x28, #0x68]
10004ddbc: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004ddc0: 3c878380    	stur	q0, [x28, #0x78]
10004ddc4: f94137e9    	ldr	x9, [sp, #0x268]
10004ddc8: ad448780    	ldp	q0, q1, [x28, #0x90]
10004ddcc: 3c838380    	stur	q0, [x28, #0x38]
10004ddd0: 3c848381    	stur	q1, [x28, #0x48]
10004ddd4: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004ddd8: 3c858380    	stur	q0, [x28, #0x58]
10004dddc: f90097e9    	str	x9, [sp, #0x128]
10004dde0: f9006be8    	str	x8, [sp, #0xd0]
10004dde4: 394702a8    	ldrb	w8, [x21, #0x1c0]
10004dde8: 360000c8    	tbz	w8, #0x0, 0x10004de00 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1f0>
10004ddec: f9417ea8    	ldr	x8, [x21, #0x2f8]
10004ddf0: 52800038    	mov	w24, #0x1               ; =1
10004ddf4: 91004100    	add	x0, x8, #0x10
10004ddf8: 52800001    	mov	w1, #0x0                ; =0
10004ddfc: 940118ed    	bl	0x1000941b0 <<raster::engine::metrics::Metrics>::cache>
10004de00: f94097f8    	ldr	x24, [sp, #0x128]
10004de04: b4000218    	cbz	x24, 0x10004de44 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x234>
10004de08: f81703b8    	stur	x24, [x29, #-0x90]
10004de0c: 910843e8    	add	x8, sp, #0x210
10004de10: 911522a0    	add	x0, x21, #0x548
10004de14: 97ff375e    	bl	0x10001bb8c <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::frontiers>
10004de18: f9410be9    	ldr	x9, [sp, #0x210]
10004de1c: f9410fe8    	ldr	x8, [sp, #0x218]
10004de20: f100053f    	cmp	x9, #0x1
10004de24: 54000401    	b.ne	0x10004dea4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x294>
10004de28: ad440760    	ldp	q0, q1, [x27, #0x80]
10004de2c: ad048780    	stp	q0, q1, [x28, #0x90]
10004de30: f94123e9    	ldr	x9, [sp, #0x240]
10004de34: f900abe9    	str	x9, [sp, #0x150]
10004de38: ad000720    	stp	q0, q1, [x25]
10004de3c: f9001329    	str	x9, [x25, #0x20]
10004de40: 1400001f    	b	0x10004debc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2ac>
10004de44: f94017e8    	ldr	x8, [sp, #0x28]
10004de48: b4000608    	cbz	x8, 0x10004df08 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2f8>
10004de4c: 52800038    	mov	w24, #0x1               ; =1
10004de50: 9104e280    	add	x0, x20, #0x138
10004de54: 9400e90a    	bl	0x10008827c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004de58: aa0003e2    	mov	x2, x0
10004de5c: aa0103e6    	mov	x6, x1
10004de60: a95193e3    	ldp	x3, x4, [sp, #0x118]
10004de64: 910843e8    	add	x8, sp, #0x210
10004de68: 911522a0    	add	x0, x21, #0x548
10004de6c: 9100a3e5    	add	x5, sp, #0x28
10004de70: aa0203e1    	mov	x1, x2
10004de74: aa0603e2    	mov	x2, x6
10004de78: a9010fe4    	stp	x4, x3, [sp, #0x10]
10004de7c: 97ff2d7a    	bl	0x100019464 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head_borrowed>
10004de80: f9410be8    	ldr	x8, [sp, #0x210]
10004de84: f9410fe0    	ldr	x0, [sp, #0x218]
10004de88: b100051f    	cmn	x8, #0x1
10004de8c: 54000680    	b.eq	0x10004df5c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x34c>
10004de90: ad440760    	ldp	q0, q1, [x27, #0x80]
10004de94: f94013e9    	ldr	x9, [sp, #0x20]
10004de98: ad000520    	stp	q0, q1, [x9]
10004de9c: a90a03e8    	stp	x8, x0, [sp, #0xa0]
10004dea0: 14000171    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004dea4: f9401f09    	ldr	x9, [x24, #0x38]
10004dea8: eb08013f    	cmp	x9, x8
10004deac: 540001e2    	b.hs	0x10004dee8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2d8>
10004deb0: 52801fe8    	mov	w8, #0xff               ; =255
10004deb4: 3902a3e8    	strb	w8, [sp, #0xa8]
10004deb8: 92800008    	mov	x8, #-0x1               ; =-1
10004debc: f90053e8    	str	x8, [sp, #0xa0]
10004dec0: f85703a8    	ldur	x8, [x29, #-0x90]
10004dec4: 92800009    	mov	x9, #-0x1               ; =-1
10004dec8: f8690108    	ldaddl	x9, x8, [x8]
10004decc: f100051f    	cmp	x8, #0x1
10004ded0: 54002ca1    	b.ne	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004ded4: d50339bf    	dmb	ishld
10004ded8: 52800018    	mov	w24, #0x0               ; =0
10004dedc: d10243a0    	sub	x0, x29, #0x90
10004dee0: 9400c0c6    	bl	0x10007e1f8 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004dee4: 14000160    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004dee8: f85703a8    	ldur	x8, [x29, #-0x90]
10004deec: f9400909    	ldr	x9, [x8, #0x10]
10004def0: f100053f    	cmp	x9, #0x1
10004def4: 540005e1    	b.ne	0x10004dfb0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3a0>
10004def8: a941a909    	ldp	x9, x10, [x8, #0x18]
10004defc: f9401129    	ldr	x9, [x9, #0x20]
10004df00: 8b0a0120    	add	x0, x9, x10
10004df04: 1400002c    	b	0x10004dfb4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3a4>
10004df08: 52800038    	mov	w24, #0x1               ; =1
10004df0c: 9104e280    	add	x0, x20, #0x138
10004df10: 9400e8db    	bl	0x10008827c <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004df14: aa0003e2    	mov	x2, x0
10004df18: aa0103e5    	mov	x5, x1
10004df1c: a95193e3    	ldp	x3, x4, [sp, #0x118]
10004df20: 910843e8    	add	x8, sp, #0x210
10004df24: 911522a0    	add	x0, x21, #0x548
10004df28: aa0203e1    	mov	x1, x2
10004df2c: aa0503e2    	mov	x2, x5
10004df30: a9010fe4    	stp	x4, x3, [sp, #0x10]
10004df34: 97ff27f2    	bl	0x100017efc <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head>
10004df38: f9410be8    	ldr	x8, [sp, #0x210]
10004df3c: f9410fe2    	ldr	x2, [sp, #0x218]
10004df40: b100051f    	cmn	x8, #0x1
10004df44: 54000840    	b.eq	0x10004e04c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x43c>
10004df48: ad440760    	ldp	q0, q1, [x27, #0x80]
10004df4c: f94013e9    	ldr	x9, [sp, #0x20]
10004df50: ad000520    	stp	q0, q1, [x9]
10004df54: a90a0be8    	stp	x8, x2, [sp, #0xa0]
10004df58: 14000143    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004df5c: b40009c0    	cbz	x0, 0x10004e094 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x484>
10004df60: f9400288    	ldr	x8, [x20]
10004df64: f100051f    	cmp	x8, #0x1
10004df68: 540042e1    	b.ne	0x10004e7c4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbb4>
10004df6c: 39476296    	ldrb	w22, [x20, #0x1d8]
10004df70: 9101a408    	add	x8, x0, #0x69
10004df74: 08dffd08    	ldarb	w8, [x8]
10004df78: 340032e8    	cbz	w8, 0x10004e5d4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9c4>
10004df7c: d280000a    	mov	x10, #0x0               ; =0
10004df80: d2800009    	mov	x9, #0x0                ; =0
10004df84: 110006cc    	add	w12, w22, #0x1
10004df88: d370bd4a    	lsl	x10, x10, #16
10004df8c: b3781d2a    	bfi	x10, x9, #8, #8
10004df90: b3401d8a    	bfxil	x10, x12, #0, #8
10004df94: f9010bea    	str	x10, [sp, #0x210]
10004df98: f9010fe8    	str	x8, [sp, #0x218]
10004df9c: 910283e0    	add	x0, sp, #0xa0
10004dfa0: 910843e2    	add	x2, sp, #0x210
10004dfa4: aa1403e1    	mov	x1, x20
10004dfa8: 94000260    	bl	0x10004e928 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish_read_access>
10004dfac: 1400012e    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004dfb0: f9401100    	ldr	x0, [x8, #0x20]
10004dfb4: f9401501    	ldr	x1, [x8, #0x28]
10004dfb8: 910843e8    	add	x8, sp, #0x210
10004dfbc: 9400a989    	bl	0x1000785e0 <<raster::format::record::Record>::decode>
10004dfc0: f9410be8    	ldr	x8, [sp, #0x210]
10004dfc4: f100091f    	cmp	x8, #0x2
10004dfc8: 54000101    	b.ne	0x10004dfe8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3d8>
10004dfcc: 3cc88360    	ldur	q0, [x27, #0x88]
10004dfd0: 3cc98361    	ldur	q1, [x27, #0x98]
10004dfd4: f94013e8    	ldr	x8, [sp, #0x20]
10004dfd8: ad000500    	stp	q0, q1, [x8]
10004dfdc: 3cc78360    	ldur	q0, [x27, #0x78]
10004dfe0: 3d802be0    	str	q0, [sp, #0xa0]
10004dfe4: 17ffffb7    	b	0x10004dec0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004dfe8: f94113e8    	ldr	x8, [sp, #0x220]
10004dfec: f85703a9    	ldur	x9, [x29, #-0x90]
10004dff0: f9402129    	ldr	x9, [x9, #0x40]
10004dff4: eb09011f    	cmp	x8, x9
10004dff8: 540006a1    	b.ne	0x10004e0cc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4bc>
10004dffc: f94127f6    	ldr	x22, [sp, #0x248]
10004e000: f9412bf7    	ldr	x23, [sp, #0x250]
10004e004: f9417ea8    	ldr	x8, [x21, #0x2f8]
10004e008: 91004100    	add	x0, x8, #0x10
10004e00c: 52800021    	mov	w1, #0x1                ; =1
10004e010: 94011868    	bl	0x1000941b0 <<raster::engine::metrics::Metrics>::cache>
10004e014: f94073e8    	ldr	x8, [sp, #0xe0]
10004e018: f100091f    	cmp	x8, #0x2
10004e01c: 54000661    	b.ne	0x10004e0e8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4d8>
10004e020: f94077e1    	ldr	x1, [sp, #0xe8]
10004e024: 910843e8    	add	x8, sp, #0x210
10004e028: 9109a2a0    	add	x0, x21, #0x268
10004e02c: 9400df7e    	bl	0x100085e24 <<raster::cache::ReadCache>::touch>
10004e030: f9410be8    	ldr	x8, [sp, #0x210]
10004e034: b100051f    	cmn	x8, #0x1
10004e038: 54000580    	b.eq	0x10004e0e8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4d8>
10004e03c: ad438760    	ldp	q0, q1, [x27, #0x70]
10004e040: 3d802be0    	str	q0, [sp, #0xa0]
10004e044: 3dc02760    	ldr	q0, [x27, #0x90]
10004e048: 1400003d    	b	0x10004e13c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x52c>
10004e04c: b4000242    	cbz	x2, 0x10004e094 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x484>
10004e050: f9010be2    	str	x2, [sp, #0x210]
10004e054: 9101e448    	add	x8, x2, #0x79
10004e058: 08dffd08    	ldarb	w8, [x8]
10004e05c: 340033e8    	cbz	w8, 0x10004e6d8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xac8>
10004e060: 39476288    	ldrb	w8, [x20, #0x1d8]
10004e064: 11000508    	add	w8, w8, #0x1
10004e068: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e06c: 3902a7ff    	strb	wzr, [sp, #0xa9]
10004e070: 92800008    	mov	x8, #-0x1               ; =-1
10004e074: f90053e8    	str	x8, [sp, #0xa0]
10004e078: f8680048    	ldaddl	x8, x8, [x2]
10004e07c: f100051f    	cmp	x8, #0x1
10004e080: 54001f21    	b.ne	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e084: d50339bf    	dmb	ishld
10004e088: 910843e0    	add	x0, sp, #0x210
10004e08c: 97ff9ff5    	bl	0x100036060 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004e090: 140000f5    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e094: ad428780    	ldp	q0, q1, [x28, #0x50]
10004e098: ad058680    	stp	q0, q1, [x20, #0xb0]
10004e09c: f9408be8    	ldr	x8, [sp, #0x110]
10004e0a0: f9006a88    	str	x8, [x20, #0xd0]
10004e0a4: ad418381    	ldp	q1, q0, [x28, #0x30]
10004e0a8: ad048281    	stp	q1, q0, [x20, #0x90]
10004e0ac: 3944e288    	ldrb	w8, [x20, #0x138]
10004e0b0: 7100051f    	cmp	w8, #0x1
10004e0b4: 54000481    	b.ne	0x10004e144 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x534>
10004e0b8: 910683e8    	add	x8, sp, #0x1a0
10004e0bc: 91002108    	add	x8, x8, #0x8
10004e0c0: 91050280    	add	x0, x20, #0x140
10004e0c4: 97ffd36d    	bl	0x100042e78 <<alloc::vec::Vec<u8> as core::clone::Clone>::clone>
10004e0c8: 14000025    	b	0x10004e15c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x54c>
10004e0cc: 528000e8    	mov	w8, #0x7                ; =7
10004e0d0: d0000469    	adrp	x9, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
10004e0d4: 913f1d29    	add	x9, x9, #0xfc7
10004e0d8: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e0dc: 528003a8    	mov	w8, #0x1d               ; =29
10004e0e0: f9005be8    	str	x8, [sp, #0xb0]
10004e0e4: 17ffff77    	b	0x10004dec0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e0e8: f942aaa8    	ldr	x8, [x21, #0x550]
10004e0ec: 52800029    	mov	w9, #0x1                ; =1
10004e0f0: f8290108    	ldadd	x9, x8, [x8]
10004e0f4: b7f83748    	tbnz	x8, #0x3f, 0x10004e7dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbcc>
10004e0f8: f942aaa0    	ldr	x0, [x21, #0x550]
10004e0fc: f942e2a3    	ldr	x3, [x21, #0x5c0]
10004e100: 910843e8    	add	x8, sp, #0x210
10004e104: aa1603e1    	mov	x1, x22
10004e108: aa1703e2    	mov	x2, x23
10004e10c: 97ffb48e    	bl	0x10003b344 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::decode>
10004e110: f9410be8    	ldr	x8, [sp, #0x210]
10004e114: 3cc78360    	ldur	q0, [x27, #0x78]
10004e118: 3cc88361    	ldur	q1, [x27, #0x88]
10004e11c: ad080780    	stp	q0, q1, [x28, #0x100]
10004e120: 3cc98360    	ldur	q0, [x27, #0x98]
10004e124: 3d804b80    	str	q0, [x28, #0x120]
10004e128: f100091f    	cmp	x8, #0x2
10004e12c: 54002901    	b.ne	0x10004e64c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa3c>
10004e130: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e134: 3d802be0    	str	q0, [sp, #0xa0]
10004e138: 3dc04b80    	ldr	q0, [x28, #0x120]
10004e13c: ad008381    	stp	q1, q0, [x28, #0x10]
10004e140: 17ffff60    	b	0x10004dec0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e144: 52800018    	mov	w24, #0x0               ; =0
10004e148: 9104ea88    	add	x8, x20, #0x13a
10004e14c: 3dc00100    	ldr	q0, [x8]
10004e150: 3c802360    	stur	q0, [x27, #0x2]
10004e154: 3944e688    	ldrb	w8, [x20, #0x139]
10004e158: 390687e8    	strb	w8, [sp, #0x1a1]
10004e15c: 390683f8    	strb	w24, [sp, #0x1a0]
10004e160: f940be85    	ldr	x5, [x20, #0x178]
10004e164: 910843e8    	add	x8, sp, #0x210
10004e168: 911522a0    	add	x0, x21, #0x548
10004e16c: 910822a1    	add	x1, x21, #0x208
10004e170: 910683e2    	add	x2, sp, #0x1a0
10004e174: a9410fe4    	ldp	x4, x3, [sp, #0x10]
10004e178: 97ff1d7c    	bl	0x100015768 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::lookup_deferred::<raster::schema::encoded_key::EncodedKey>>
10004e17c: f9410bf8    	ldr	x24, [sp, #0x210]
10004e180: 3cc78360    	ldur	q0, [x27, #0x78]
10004e184: 3cc88361    	ldur	q1, [x27, #0x88]
10004e188: ad048780    	stp	q0, q1, [x28, #0x90]
10004e18c: 3cc98360    	ldur	q0, [x27, #0x98]
10004e190: 3d802f80    	str	q0, [x28, #0xb0]
10004e194: f1000b1f    	cmp	x24, #0x2
10004e198: 54ffe040    	b.eq	0x10004dda0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x190>
10004e19c: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e1a0: 3ccb8361    	ldur	q1, [x27, #0xb8]
10004e1a4: ad000760    	stp	q0, q1, [x27]
10004e1a8: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e1ac: 3d800b60    	str	q0, [x27, #0x20]
10004e1b0: 3ccd2360    	ldur	q0, [x27, #0xd2]
10004e1b4: 3c82a360    	stur	q0, [x27, #0x2a]
10004e1b8: 394a0be8    	ldrb	w8, [sp, #0x282]
10004e1bc: 394a0fe9    	ldrb	w9, [sp, #0x283]
10004e1c0: b94287ea    	ldr	w10, [sp, #0x284]
10004e1c4: b9001bea    	str	w10, [sp, #0x18]
10004e1c8: ad448780    	ldp	q0, q1, [x28, #0x90]
10004e1cc: ad020760    	stp	q0, q1, [x27, #0x40]
10004e1d0: 3dc02f80    	ldr	q0, [x28, #0xb0]
10004e1d4: 3d801b60    	str	q0, [x27, #0x60]
10004e1d8: 3946228a    	ldrb	w10, [x20, #0x188]
10004e1dc: 7100015f    	cmp	w10, #0x0
10004e1e0: 1a8913e9    	csel	w9, wzr, w9, ne
10004e1e4: 1a9f0508    	csinc	w8, w8, wzr, eq
10004e1e8: 2901a7e8    	stp	w8, w9, [sp, #0xc]
10004e1ec: f9400e88    	ldr	x8, [x20, #0x18]
10004e1f0: f100091f    	cmp	x8, #0x2
10004e1f4: 54000060    	b.eq	0x10004e200 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x5f0>
10004e1f8: aa1603e0    	mov	x0, x22
10004e1fc: 97fffc66    	bl	0x10004d394 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e200: f9000e98    	str	x24, [x20, #0x18]
10004e204: ad420760    	ldp	q0, q1, [x27, #0x40]
10004e208: ad010680    	stp	q0, q1, [x20, #0x20]
10004e20c: 3dc01b60    	ldr	q0, [x27, #0x60]
10004e210: ad400b61    	ldp	q1, q2, [x27]
10004e214: ad020680    	stp	q0, q1, [x20, #0x40]
10004e218: 3dc00b60    	ldr	q0, [x27, #0x20]
10004e21c: ad030282    	stp	q2, q0, [x20, #0x60]
10004e220: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004e224: 3c87a280    	stur	q0, [x20, #0x7a]
10004e228: 2941a3e9    	ldp	w9, w8, [sp, #0xc]
10004e22c: 39022a89    	strb	w9, [x20, #0x8a]
10004e230: 39022e88    	strb	w8, [x20, #0x8b]
10004e234: b9401be8    	ldr	w8, [sp, #0x18]
10004e238: b9008e88    	str	w8, [x20, #0x8c]
10004e23c: b9400288    	ldr	w8, [x20]
10004e240: 360029a8    	tbz	w8, #0x0, 0x10004e774 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb64>
10004e244: 910843e8    	add	x8, sp, #0x210
10004e248: 911522a1    	add	x1, x21, #0x548
10004e24c: 910822a2    	add	x2, x21, #0x208
10004e250: aa1603e0    	mov	x0, x22
10004e254: aa1703e3    	mov	x3, x23
10004e258: 97ffa2fb    	bl	0x100036e44 <<raster::log::lookup::LogLookup>::step::<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>
10004e25c: f9410be8    	ldr	x8, [sp, #0x210]
10004e260: f9410fe2    	ldr	x2, [sp, #0x218]
10004e264: ad440760    	ldp	q0, q1, [x27, #0x80]
10004e268: ad078760    	stp	q0, q1, [x27, #0xf0]
10004e26c: f94123e9    	ldr	x9, [sp, #0x240]
10004e270: f81603a9    	stur	x9, [x29, #-0xa0]
10004e274: b100051f    	cmn	x8, #0x1
10004e278: 54000740    	b.eq	0x10004e360 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x750>
10004e27c: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e280: 3c8b8380    	stur	q0, [x28, #0xb8]
10004e284: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e288: 3c8c8380    	stur	q0, [x28, #0xc8]
10004e28c: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e290: 3c8d8380    	stur	q0, [x28, #0xd8]
10004e294: f9413fe9    	ldr	x9, [sp, #0x278]
10004e298: ad478760    	ldp	q0, q1, [x27, #0xf0]
10004e29c: f85603aa    	ldur	x10, [x29, #-0xa0]
10004e2a0: f900c7e9    	str	x9, [sp, #0x188]
10004e2a4: f900abea    	str	x10, [sp, #0x150]
10004e2a8: d1000909    	sub	x9, x8, #0x2
10004e2ac: f100051f    	cmp	x8, #0x1
10004e2b0: 9a9f8529    	csinc	x9, x9, xzr, hi
10004e2b4: ad048780    	stp	q0, q1, [x28, #0x90]
10004e2b8: f100093f    	cmp	x9, #0x2
10004e2bc: 540005ec    	b.gt	0x10004e378 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x768>
10004e2c0: b40007a9    	cbz	x9, 0x10004e3b4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7a4>
10004e2c4: f100053f    	cmp	x9, #0x1
10004e2c8: 540007e1    	b.ne	0x10004e3c4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7b4>
10004e2cc: f9010be8    	str	x8, [sp, #0x210]
10004e2d0: f9010fe2    	str	x2, [sp, #0x218]
10004e2d4: ad458780    	ldp	q0, q1, [x28, #0xb0]
10004e2d8: ad050760    	stp	q0, q1, [x27, #0xa0]
10004e2dc: ad468780    	ldp	q0, q1, [x28, #0xd0]
10004e2e0: ad060760    	stp	q0, q1, [x27, #0xc0]
10004e2e4: ad448780    	ldp	q0, q1, [x28, #0x90]
10004e2e8: ad040760    	stp	q0, q1, [x27, #0x80]
10004e2ec: f9404a88    	ldr	x8, [x20, #0x90]
10004e2f0: f100091f    	cmp	x8, #0x2
10004e2f4: 540024e0    	b.eq	0x10004e790 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb80>
10004e2f8: f940ca81    	ldr	x1, [x20, #0x190]
10004e2fc: f9006be8    	str	x8, [sp, #0xd0]
10004e300: 3cc98280    	ldur	q0, [x20, #0x98]
10004e304: 3c838380    	stur	q0, [x28, #0x38]
10004e308: 3cca8280    	ldur	q0, [x20, #0xa8]
10004e30c: 3c848380    	stur	q0, [x28, #0x48]
10004e310: 3ccb8280    	ldur	q0, [x20, #0xb8]
10004e314: 3c858380    	stur	q0, [x28, #0x58]
10004e318: 3ccc8280    	ldur	q0, [x20, #0xc8]
10004e31c: 3c868380    	stur	q0, [x28, #0x68]
10004e320: f9400e88    	ldr	x8, [x20, #0x18]
10004e324: f100091f    	cmp	x8, #0x2
10004e328: 54002400    	b.eq	0x10004e7a8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb98>
10004e32c: d10243a8    	sub	x8, x29, #0x90
10004e330: 910202a0    	add	x0, x21, #0x80
10004e334: 910343e2    	add	x2, sp, #0xd0
10004e338: aa1603e3    	mov	x3, x22
10004e33c: 97fefa92    	bl	0x10000cd84 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::populate_cache>
10004e340: f85703a8    	ldur	x8, [x29, #-0x90]
10004e344: b100051f    	cmn	x8, #0x1
10004e348: 540006c0    	b.eq	0x10004e420 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x810>
10004e34c: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e350: 3d802be0    	str	q0, [sp, #0xa0]
10004e354: 3dc05360    	ldr	q0, [x27, #0x140]
10004e358: ad008381    	stp	q1, q0, [x28, #0x10]
10004e35c: 14000040    	b	0x10004e45c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x84c>
10004e360: ad478760    	ldp	q0, q1, [x27, #0xf0]
10004e364: ad000720    	stp	q0, q1, [x25]
10004e368: f85603a8    	ldur	x8, [x29, #-0xa0]
10004e36c: f9001328    	str	x8, [x25, #0x20]
10004e370: f90053e2    	str	x2, [sp, #0xa0]
10004e374: 1400003c    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e378: d1001528    	sub	x8, x9, #0x5
10004e37c: f100091f    	cmp	x8, #0x2
10004e380: 54000082    	b.hs	0x10004e390 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x780>
10004e384: 52801fe8    	mov	w8, #0xff               ; =255
10004e388: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e38c: 14000007    	b	0x10004e3a8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x798>
10004e390: f1000d3f    	cmp	x9, #0x3
10004e394: 54000261    	b.ne	0x10004e3e0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7d0>
10004e398: 39476288    	ldrb	w8, [x20, #0x1d8]
10004e39c: 11000508    	add	w8, w8, #0x1
10004e3a0: 3902a3e8    	strb	w8, [sp, #0xa8]
10004e3a4: 3902a7ff    	strb	wzr, [sp, #0xa9]
10004e3a8: 92800008    	mov	x8, #-0x1               ; =-1
10004e3ac: f90053e8    	str	x8, [sp, #0xa0]
10004e3b0: 1400002d    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e3b4: 910283e0    	add	x0, sp, #0xa0
10004e3b8: aa1403e1    	mov	x1, x20
10004e3bc: 97fffd90    	bl	0x10004d9fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
10004e3c0: 14000029    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e3c4: 528000e8    	mov	w8, #0x7                ; =7
10004e3c8: f0000469    	adrp	x9, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x5c>
10004e3cc: 9100ad29    	add	x9, x9, #0x2b
10004e3d0: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e3d4: 52800448    	mov	w8, #0x22               ; =34
10004e3d8: f9005be8    	str	x8, [sp, #0xb0]
10004e3dc: 14000022    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e3e0: f940ca81    	ldr	x1, [x20, #0x190]
10004e3e4: 910843e8    	add	x8, sp, #0x210
10004e3e8: 910202a0    	add	x0, x21, #0x80
10004e3ec: 94005544    	bl	0x1000638fc <<raster::index::growth::MemIndex>::prepare>
10004e3f0: f9410be8    	ldr	x8, [sp, #0x210]
10004e3f4: 3cc78360    	ldur	q0, [x27, #0x78]
10004e3f8: 3cc88361    	ldur	q1, [x27, #0x88]
10004e3fc: ad090760    	stp	q0, q1, [x27, #0x120]
10004e400: 3cc98360    	ldur	q0, [x27, #0x98]
10004e404: 3d805360    	str	q0, [x27, #0x140]
10004e408: f100091f    	cmp	x8, #0x2
10004e40c: 54000a21    	b.ne	0x10004e550 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x940>
10004e410: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e414: 3d802be0    	str	q0, [sp, #0xa0]
10004e418: 3dc05360    	ldr	q0, [x27, #0x140]
10004e41c: 17fffe64    	b	0x10004ddac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x19c>
10004e420: 910343e8    	add	x8, sp, #0xd0
10004e424: 910843e0    	add	x0, sp, #0x210
10004e428: 91002281    	add	x1, x20, #0x8
10004e42c: 97ffaed9    	bl	0x100039f90 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#2}>>
10004e430: a94d23ea    	ldp	x10, x8, [sp, #0xd0]
10004e434: f94073e9    	ldr	x9, [sp, #0xe0]
10004e438: 3cc48380    	ldur	q0, [x28, #0x48]
10004e43c: 3cc58381    	ldur	q1, [x28, #0x58]
10004e440: ad090760    	stp	q0, q1, [x27, #0x120]
10004e444: f100055f    	cmp	x10, #0x1
10004e448: 54000ba1    	b.ne	0x10004e5bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9ac>
10004e44c: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e450: f94013ea    	ldr	x10, [sp, #0x20]
10004e454: ad000540    	stp	q0, q1, [x10]
10004e458: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10004e45c: 910843e0    	add	x0, sp, #0x210
10004e460: 97fffb1c    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e464: a94a5be8    	ldp	x8, x22, [sp, #0xa0]
10004e468: ad408780    	ldp	q0, q1, [x28, #0x10]
10004e46c: a903dbe8    	stp	x8, x22, [sp, #0x38]
10004e470: 3c8583e1    	stur	q1, [sp, #0x58]
10004e474: 3c8483e0    	stur	q0, [sp, #0x48]
10004e478: b100091f    	cmn	x8, #0x2
10004e47c: 54000200    	b.eq	0x10004e4bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8ac>
10004e480: b100051f    	cmn	x8, #0x1
10004e484: 54000501    	b.ne	0x10004e524 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x914>
10004e488: 52801fe8    	mov	w8, #0xff               ; =255
10004e48c: 6a36011f    	bics	wzr, w8, w22
10004e490: 54000120    	b.eq	0x10004e4b4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8a4>
10004e494: f84413e8    	ldur	x8, [sp, #0x41]
10004e498: f8079368    	stur	x8, [x27, #0x79]
10004e49c: f94027e8    	ldr	x8, [sp, #0x48]
10004e4a0: f90113e8    	str	x8, [sp, #0x220]
10004e4a4: 390863f6    	strb	w22, [sp, #0x218]
10004e4a8: 92800008    	mov	x8, #-0x1               ; =-1
10004e4ac: f9010be8    	str	x8, [sp, #0x210]
10004e4b0: 17fffe05    	b	0x10004dcc4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb4>
10004e4b4: 52800268    	mov	w8, #0x13               ; =19
10004e4b8: 17fffe08    	b	0x10004dcd8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc8>
10004e4bc: 9e660017    	fmov	x23, d0
10004e4c0: 52800028    	mov	w8, #0x1                ; =1
10004e4c4: 089fff48    	stlrb	w8, [x26]
10004e4c8: f0000468    	adrp	x8, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x5c>
10004e4cc: 91013508    	add	x8, x8, #0x4d
10004e4d0: 528000e9    	mov	w9, #0x7                ; =7
10004e4d4: a906a3e9    	stp	x9, x8, [sp, #0x68]
10004e4d8: 52800268    	mov	w8, #0x13               ; =19
10004e4dc: f9003fe8    	str	x8, [sp, #0x78]
10004e4e0: 390263ff    	strb	wzr, [sp, #0x98]
10004e4e4: 9101a3e2    	add	x2, sp, #0x68
10004e4e8: aa1403e0    	mov	x0, x20
10004e4ec: aa1503e1    	mov	x1, x21
10004e4f0: 9400012e    	bl	0x10004e9a8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004e4f4: 52800248    	mov	w8, #0x12               ; =18
10004e4f8: f9000268    	str	x8, [x19]
10004e4fc: f94002e8    	ldr	x8, [x23]
10004e500: b4000068    	cbz	x8, 0x10004e50c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8fc>
10004e504: aa1603e0    	mov	x0, x22
10004e508: d63f0100    	blr	x8
10004e50c: f94006e1    	ldr	x1, [x23, #0x8]
10004e510: b4ffbe61    	cbz	x1, 0x10004dcdc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcc>
10004e514: f9400ae2    	ldr	x2, [x23, #0x10]
10004e518: aa1603e0    	mov	x0, x22
10004e51c: 940003c4    	bl	0x10004f42c <__rustc::__rust_dealloc>
10004e520: 17fffdef    	b	0x10004dcdc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcc>
10004e524: 3cc503e0    	ldur	q0, [sp, #0x50]
10004e528: 3c888360    	stur	q0, [x27, #0x88]
10004e52c: f94033e9    	ldr	x9, [sp, #0x60]
10004e530: f84413ea    	ldur	x10, [sp, #0x41]
10004e534: f807936a    	stur	x10, [x27, #0x79]
10004e538: f94027ea    	ldr	x10, [sp, #0x48]
10004e53c: f9011fe9    	str	x9, [sp, #0x238]
10004e540: f90113ea    	str	x10, [sp, #0x220]
10004e544: f9010be8    	str	x8, [sp, #0x210]
10004e548: 390863f6    	strb	w22, [sp, #0x218]
10004e54c: 17fffddd    	b	0x10004dcc0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb0>
10004e550: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e554: 3c868380    	stur	q0, [x28, #0x68]
10004e558: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e55c: 3c838380    	stur	q0, [x28, #0x38]
10004e560: 3c848381    	stur	q1, [x28, #0x48]
10004e564: 3dc05360    	ldr	q0, [x27, #0x140]
10004e568: 3c858380    	stur	q0, [x28, #0x58]
10004e56c: f9006be8    	str	x8, [sp, #0xd0]
10004e570: aa1403f7    	mov	x23, x20
10004e574: f8490ee8    	ldr	x8, [x23, #0x90]!
10004e578: f100091f    	cmp	x8, #0x2
10004e57c: 540000e0    	b.eq	0x10004e598 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x988>
10004e580: 910343e1    	add	x1, sp, #0xd0
10004e584: aa1703e0    	mov	x0, x23
10004e588: 940002fd    	bl	0x10004f17c <<raster::index::EntrySnapshot as core::cmp::PartialEq>::eq>
10004e58c: 36000060    	tbz	w0, #0x0, 0x10004e598 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x988>
10004e590: 52800028    	mov	w8, #0x1                ; =1
10004e594: 17ffff7d    	b	0x10004e388 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x778>
10004e598: f94002c8    	ldr	x8, [x22]
10004e59c: f100091f    	cmp	x8, #0x2
10004e5a0: 54000060    	b.eq	0x10004e5ac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x99c>
10004e5a4: aa1603e0    	mov	x0, x22
10004e5a8: 97fffb7b    	bl	0x10004d394 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e5ac: 52800048    	mov	w8, #0x2                ; =2
10004e5b0: f90002c8    	str	x8, [x22]
10004e5b4: f90002e8    	str	x8, [x23]
10004e5b8: 17ffff73    	b	0x10004e384 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x774>
10004e5bc: b100051f    	cmn	x8, #0x1
10004e5c0: 54000380    	b.eq	0x10004e630 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa20>
10004e5c4: ad490760    	ldp	q0, q1, [x27, #0x120]
10004e5c8: f94013ea    	ldr	x10, [sp, #0x20]
10004e5cc: ad000540    	stp	q0, q1, [x10]
10004e5d0: 1400001a    	b	0x10004e638 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa28>
10004e5d4: 910843e8    	add	x8, sp, #0x210
10004e5d8: 91002281    	add	x1, x20, #0x8
10004e5dc: 97ffaeed    	bl	0x10003a190 <<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::try_read_live::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::invoke_read::{closure#1}>>
10004e5e0: b94213e9    	ldr	w9, [sp, #0x210]
10004e5e4: f9410fec    	ldr	x12, [sp, #0x218]
10004e5e8: f94113e8    	ldr	x8, [sp, #0x220]
10004e5ec: 3dc02760    	ldr	q0, [x27, #0x90]
10004e5f0: 3d802780    	str	q0, [x28, #0x90]
10004e5f4: f94117eb    	ldr	x11, [sp, #0x228]
10004e5f8: f94123ea    	ldr	x10, [sp, #0x240]
10004e5fc: f900a3ea    	str	x10, [sp, #0x140]
10004e600: 36000749    	tbz	w9, #0x0, 0x10004e6e8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xad8>
10004e604: 3dc02780    	ldr	q0, [x28, #0x90]
10004e608: 3d800360    	str	q0, [x27]
10004e60c: f940a3e9    	ldr	x9, [sp, #0x140]
10004e610: f900dbe9    	str	x9, [sp, #0x1b0]
10004e614: d348fd09    	lsr	x9, x8, #8
10004e618: d350fd0a    	lsr	x10, x8, #16
10004e61c: b100059f    	cmn	x12, #0x1
10004e620: 540007c1    	b.ne	0x10004e718 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb08>
10004e624: aa0803ec    	mov	x12, x8
10004e628: aa0b03e8    	mov	x8, x11
10004e62c: 17fffe57    	b	0x10004df88 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x378>
10004e630: 3902a3ff    	strb	wzr, [sp, #0xa8]
10004e634: f94013f9    	ldr	x25, [sp, #0x20]
10004e638: f9000329    	str	x9, [x25]
10004e63c: f90053e8    	str	x8, [sp, #0xa0]
10004e640: 910843e0    	add	x0, sp, #0x210
10004e644: 97fffaa3    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e648: 17ffff87    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e64c: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e650: 3c8c8380    	stur	q0, [x28, #0xc8]
10004e654: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e658: 3c8d8380    	stur	q0, [x28, #0xd8]
10004e65c: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e660: 3c8e8380    	stur	q0, [x28, #0xe8]
10004e664: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e668: 3c898380    	stur	q0, [x28, #0x98]
10004e66c: f9413fe9    	ldr	x9, [sp, #0x278]
10004e670: 3c8a8381    	stur	q1, [x28, #0xa8]
10004e674: 3dc04b80    	ldr	q0, [x28, #0x120]
10004e678: 3c8b8380    	stur	q0, [x28, #0xb8]
10004e67c: f900cfe9    	str	x9, [sp, #0x198]
10004e680: f9009be8    	str	x8, [sp, #0x130]
10004e684: 910843e8    	add	x8, sp, #0x210
10004e688: 9104c3e0    	add	x0, sp, #0x130
10004e68c: aa1403e1    	mov	x1, x20
10004e690: 97ffadb8    	bl	0x100039d70 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#0}>>
10004e694: f9410bea    	ldr	x10, [sp, #0x210]
10004e698: f9410fe9    	ldr	x9, [sp, #0x218]
10004e69c: f94113e8    	ldr	x8, [sp, #0x220]
10004e6a0: 3cc88360    	ldur	q0, [x27, #0x88]
10004e6a4: 3cc98361    	ldur	q1, [x27, #0x98]
10004e6a8: ad080780    	stp	q0, q1, [x28, #0x100]
10004e6ac: f100055f    	cmp	x10, #0x1
10004e6b0: 54000060    	b.eq	0x10004e6bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xaac>
10004e6b4: b100053f    	cmn	x9, #0x1
10004e6b8: 54000540    	b.eq	0x10004e760 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb50>
10004e6bc: ad480780    	ldp	q0, q1, [x28, #0x100]
10004e6c0: f94013ea    	ldr	x10, [sp, #0x20]
10004e6c4: ad000540    	stp	q0, q1, [x10]
10004e6c8: a90a23e9    	stp	x9, x8, [sp, #0xa0]
10004e6cc: 9104c3e0    	add	x0, sp, #0x130
10004e6d0: 97fffa80    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e6d4: 17fffdfb    	b	0x10004dec0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b0>
10004e6d8: 910283e0    	add	x0, sp, #0xa0
10004e6dc: aa1403e1    	mov	x1, x20
10004e6e0: 97fffcc7    	bl	0x10004d9fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
10004e6e4: 17ffff60    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e6e8: b1000d9f    	cmn	x12, #0x3
10004e6ec: 54000320    	b.eq	0x10004e750 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb40>
10004e6f0: b100059f    	cmn	x12, #0x1
10004e6f4: 54000260    	b.eq	0x10004e740 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb30>
10004e6f8: b100099f    	cmn	x12, #0x2
10004e6fc: 54ffc400    	b.eq	0x10004df7c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x36c>
10004e700: 3dc02780    	ldr	q0, [x28, #0x90]
10004e704: 3d800360    	str	q0, [x27]
10004e708: f940a3e9    	ldr	x9, [sp, #0x140]
10004e70c: f900dbe9    	str	x9, [sp, #0x1b0]
10004e710: d348fd09    	lsr	x9, x8, #8
10004e714: d350fd0a    	lsr	x10, x8, #16
10004e718: d370bd4a    	lsl	x10, x10, #16
10004e71c: b3781d2a    	bfi	x10, x9, #8, #8
10004e720: 3dc00360    	ldr	q0, [x27]
10004e724: 3c818380    	stur	q0, [x28, #0x18]
10004e728: f940dbe9    	ldr	x9, [sp, #0x1b0]
10004e72c: b3401d0a    	bfxil	x10, x8, #0, #8
10004e730: a90a2bec    	stp	x12, x10, [sp, #0xa0]
10004e734: f90067e9    	str	x9, [sp, #0xc8]
10004e738: f9005beb    	str	x11, [sp, #0xb0]
10004e73c: 17ffff4a    	b	0x10004e464 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x854>
10004e740: d280000a    	mov	x10, #0x0               ; =0
10004e744: d2800009    	mov	x9, #0x0                ; =0
10004e748: 5280000c    	mov	w12, #0x0               ; =0
10004e74c: 17fffe0f    	b	0x10004df88 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x378>
10004e750: d280000a    	mov	x10, #0x0               ; =0
10004e754: d2800009    	mov	x9, #0x0                ; =0
10004e758: 52801fec    	mov	w12, #0xff              ; =255
10004e75c: 17fffe0b    	b	0x10004df88 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x378>
10004e760: 3902a3ff    	strb	wzr, [sp, #0xa8]
10004e764: f9005be8    	str	x8, [sp, #0xb0]
10004e768: 92800008    	mov	x8, #-0x1               ; =-1
10004e76c: f90053e8    	str	x8, [sp, #0xa0]
10004e770: 17ffffd7    	b	0x10004e6cc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xabc>
10004e774: d0000460    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
10004e778: 913f9000    	add	x0, x0, #0xfe4
10004e77c: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e780: 912cc042    	add	x2, x2, #0xb30
10004e784: 528004c1    	mov	w1, #0x26               ; =38
10004e788: 9401fda0    	bl	0x1000cde08 <core::option::expect_failed>
10004e78c: 14000014    	b	0x10004e7dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbcc>
10004e790: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e794: 912d2042    	add	x2, x2, #0xb48
10004e798: 52800281    	mov	w1, #0x14               ; =20
10004e79c: f0000460    	adrp	x0, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x5c>
10004e7a0: 91005c00    	add	x0, x0, #0x17
10004e7a4: 14000006    	b	0x10004e7bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbac>
10004e7a8: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7ac: 912d8042    	add	x2, x2, #0xb60
10004e7b0: 528001a1    	mov	w1, #0xd                ; =13
10004e7b4: f0000460    	adrp	x0, 0x1000dd000 <_anon.21ccce44678a13607c575a46d00d29e9.7+0x5c>
10004e7b8: 91002800    	add	x0, x0, #0xa
10004e7bc: 9401fd93    	bl	0x1000cde08 <core::option::expect_failed>
10004e7c0: 14000007    	b	0x10004e7dc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbcc>
10004e7c4: d0000460    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
10004e7c8: 913f9000    	add	x0, x0, #0xfe4
10004e7cc: f0000602    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10004e7d0: 912c6042    	add	x2, x2, #0xb18
10004e7d4: 528004c1    	mov	w1, #0x26               ; =38
10004e7d8: 9401fd8c    	bl	0x1000cde08 <core::option::expect_failed>
10004e7dc: d4200020    	brk	#0x1
10004e7e0: 1400001b    	b	0x10004e84c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc3c>
10004e7e4: aa0003f7    	mov	x23, x0
10004e7e8: f9000e98    	str	x24, [x20, #0x18]
10004e7ec: ad420760    	ldp	q0, q1, [x27, #0x40]
10004e7f0: ad010680    	stp	q0, q1, [x20, #0x20]
10004e7f4: 3dc01b60    	ldr	q0, [x27, #0x60]
10004e7f8: ad400b61    	ldp	q1, q2, [x27]
10004e7fc: ad020680    	stp	q0, q1, [x20, #0x40]
10004e800: 3dc00b60    	ldr	q0, [x27, #0x20]
10004e804: ad030282    	stp	q2, q0, [x20, #0x60]
10004e808: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004e80c: 3c87a280    	stur	q0, [x20, #0x7a]
10004e810: 2941a3e9    	ldp	w9, w8, [sp, #0xc]
10004e814: 39022a89    	strb	w9, [x20, #0x8a]
10004e818: 39022e88    	strb	w8, [x20, #0x8b]
10004e81c: 52800038    	mov	w24, #0x1               ; =1
10004e820: b9401be8    	ldr	w8, [sp, #0x18]
10004e824: b9008e88    	str	w8, [x20, #0x8c]
10004e828: 14000025    	b	0x10004e8bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcac>
10004e82c: aa0003f7    	mov	x23, x0
10004e830: 9104c3e0    	add	x0, sp, #0x130
10004e834: 97fffa27    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e838: 14000011    	b	0x10004e87c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc6c>
10004e83c: aa0003f7    	mov	x23, x0
10004e840: 52800048    	mov	w8, #0x2                ; =2
10004e844: f90002c8    	str	x8, [x22]
10004e848: 1400002f    	b	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e84c: aa0003f7    	mov	x23, x0
10004e850: 52800038    	mov	w24, #0x1               ; =1
10004e854: 1400001a    	b	0x10004e8bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcac>
10004e858: aa0003f3    	mov	x19, x0
10004e85c: f94006e1    	ldr	x1, [x23, #0x8]
10004e860: b4000261    	cbz	x1, 0x10004e8ac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc9c>
10004e864: f9400ae2    	ldr	x2, [x23, #0x10]
10004e868: aa1603e0    	mov	x0, x22
10004e86c: 940002f0    	bl	0x10004f42c <__rustc::__rust_dealloc>
10004e870: aa1303e0    	mov	x0, x19
10004e874: 9401fe73    	bl	0x1000ce240 <dyld_stub_binder+0x1000ce240>
10004e878: aa0003f7    	mov	x23, x0
10004e87c: f85703a8    	ldur	x8, [x29, #-0x90]
10004e880: 92800009    	mov	x9, #-0x1               ; =-1
10004e884: f8690108    	ldaddl	x9, x8, [x8]
10004e888: f100051f    	cmp	x8, #0x1
10004e88c: 540003c1    	b.ne	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e890: d50339bf    	dmb	ishld
10004e894: d10243a0    	sub	x0, x29, #0x90
10004e898: 9400be58    	bl	0x10007e1f8 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e89c: 1400001a    	b	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8a0: aa0003f3    	mov	x19, x0
10004e8a4: 9100e3e0    	add	x0, sp, #0x38
10004e8a8: 97fff998    	bl	0x10004cf08 <core::ptr::drop_glue::<core::result::Result<core::result::Result<core::option::Option<raster::api::completion::Outcome<u64>>, raster::types::error::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
10004e8ac: aa1303e0    	mov	x0, x19
10004e8b0: 9401fe64    	bl	0x1000ce240 <dyld_stub_binder+0x1000ce240>
10004e8b4: 9401fd82    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
10004e8b8: aa0003f7    	mov	x23, x0
10004e8bc: 34000258    	cbz	w24, 0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8c0: f94097e8    	ldr	x8, [sp, #0x128]
10004e8c4: b4000208    	cbz	x8, 0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8c8: 92800009    	mov	x9, #-0x1               ; =-1
10004e8cc: f8690108    	ldaddl	x9, x8, [x8]
10004e8d0: f100051f    	cmp	x8, #0x1
10004e8d4: 54000181    	b.ne	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8d8: 910343e8    	add	x8, sp, #0xd0
10004e8dc: d50339bf    	dmb	ishld
10004e8e0: 91016100    	add	x0, x8, #0x58
10004e8e4: 9400be45    	bl	0x10007e1f8 <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e8e8: 14000007    	b	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8ec: aa0003f7    	mov	x23, x0
10004e8f0: 910843e0    	add	x0, sp, #0x210
10004e8f4: 97fff9f7    	bl	0x10004d0d0 <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e8f8: 14000003    	b	0x10004e904 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
10004e8fc: 9401fd70    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
10004e900: aa0003f7    	mov	x23, x0
10004e904: aa1703e0    	mov	x0, x23
10004e908: 9401fc40    	bl	0x1000cda08 <std::panicking::catch_unwind::cleanup>
10004e90c: aa0003f6    	mov	x22, x0
10004e910: aa0103f7    	mov	x23, x1
10004e914: a90407e0    	stp	x0, x1, [sp, #0x40]
10004e918: 92800028    	mov	x8, #-0x2               ; =-2
10004e91c: f9001fe8    	str	x8, [sp, #0x38]
10004e920: 17fffee8    	b	0x10004e4c0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8b0>
10004e924: 9401fdb5    	bl	0x1000cdff8 <core::panicking::panic_cannot_unwind>

