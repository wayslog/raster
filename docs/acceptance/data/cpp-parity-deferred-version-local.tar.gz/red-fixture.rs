use super::*;
use crate::{
    RasterKV, Submission,
    api::{Outcome, operation::*},
    schema::{KeyCodec, ValueRead, ValueUpdate, builtin::{AtomicU64Value, SchemaPair, U64Key}},
};
use std::{sync::mpsc, time::{Duration, Instant}};
type Schema = SchemaPair<U64Key, AtomicU64Value>;
struct Request(u64);
impl Keyed<Schema> for Request {
    fn key(&self) -> &u64 { &1 }
}
impl ReadOperation<Schema> for Request {
    type Output = u64;
    fn read(&mut self, value: ValueRead<'_, Schema>) -> Result<u64, Error> { Ok(*value.view()) }
}
impl UpsertOperation<Schema> for Request {
    type Output = u64;
    fn replacement(&mut self) -> Result<(u64,u64), Error> { Ok((self.0,self.0)) }
    fn update_in_place(&mut self, mut value: ValueUpdate<'_, Schema>) -> Result<UpdateDecision<u64>, Error> {
        value.view_mut().store(self.0, Ordering::SeqCst);
        Ok(UpdateDecision::Updated(self.0))
    }
}
impl RmwOperation<Schema> for Request {
    type Output = u64;
    fn initial(&mut self) -> Result<(u64,u64), Error> { Ok((self.0,self.0)) }
    fn copy_update(&mut self, value: ValueRead<'_, Schema>) -> Result<(u64,u64), Error> {
        let next = value.view().wrapping_add(self.0); Ok((next,next))
    }
    fn update_in_place(&mut self, mut value: ValueUpdate<'_, Schema>) -> Result<UpdateDecision<u64>, Error> {
        Ok(UpdateDecision::Updated(value.view_mut().fetch_add(self.0, Ordering::SeqCst).wrapping_add(self.0)))
    }
}
impl DeleteOperation<Schema> for Request {
    type Output = u64;
    fn complete(self, _: DeleteOutcome) -> u64 { 1 }
}
fn deadline() -> Deadline { Deadline(Instant::now()+Duration::from_secs(5)) }

#[test]
fn resident_operations_do_not_wait_for_an_empty_version_registry() {
    let store = RasterKV::builder(SchemaPair::new(U64Key, AtomicU64Value))
        .device(Box::new(crate::device::null::NullDeviceFactory)).create().unwrap();
    let mut owner = store.start_session(Default::default()).unwrap();
    assert!(matches!(owner.upsert(Serial(0),Request(7)), Ok(Submission::Ready(Ok(Outcome::Success(7))))));
    let result = std::thread::scope(|scope| {
        let (ready_tx,ready_rx) = mpsc::sync_channel(1);
        let (start_tx,start_rx) = mpsc::sync_channel(1);
        let (result_tx,result_rx) = mpsc::sync_channel(1);
        let store = &store;
        let worker = scope.spawn(move || {
            let mut session=store.start_session(Default::default()).unwrap();
            ready_tx.send(()).unwrap();start_rx.recv().unwrap();
            let read=matches!(session.read(Serial(1),Request(0),Default::default()),Ok(Submission::Ready(Ok(Outcome::Success(7)))));
            let put=matches!(session.upsert(Serial(2),Request(11)),Ok(Submission::Ready(Ok(Outcome::Success(11)))));
            let rmw=matches!(session.rmw(Serial(3),Request(2),Default::default()),Ok(Submission::Ready(Ok(Outcome::Success(13)))));
            let delete=matches!(session.delete(Serial(4),Request(0),Default::default()),Ok(Submission::Ready(Ok(Outcome::Success(1)))));
            result_tx.send((read,put,rmw,delete,session.last_accepted())).unwrap();
            session.close(deadline()).unwrap();
        });
        ready_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        let registry=store.inner.version_permits.shard(U64Key.hash(&1)).active.lock().unwrap();
        assert!(registry.is_empty());
        start_tx.send(()).unwrap();
        let early=result_rx.recv_timeout(Duration::from_secs(2));
        // Release the deliberate stall before checking late output or joining.
        drop(registry);
        let completed=match early { Ok(result)=>result,Err(_)=>result_rx.recv_timeout(Duration::from_secs(5)).unwrap() };
        worker.join().unwrap();
        assert_eq!(completed,(true,true,true,true,Some(Serial(4))));
        early
    });
    assert!(matches!(owner.read(Serial(1),Request(0),Default::default()),Ok(Submission::Ready(Ok(Outcome::NotFound)))));
    owner.close(deadline()).unwrap();store.shutdown(deadline()).unwrap();
    assert_eq!(result,Ok((true,true,true,true,Some(Serial(4)))));
}
