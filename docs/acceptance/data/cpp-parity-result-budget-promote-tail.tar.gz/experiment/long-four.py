"""Investigate the local four-thread failure without changing acceptance gates."""
from pathlib import Path
import hashlib,json,platform,subprocess,sys
sys.path.insert(0,"tools/performance")
from focused_compare import LABELS,ORDERS,summarize
from cpu_profile import validate_output
root=Path("target/parity-profile/result-budget-promote-tail")
out=root/"long-four"
out.mkdir(exist_ok=False)
base=Path("target/parity-profile/upsert-flat-result/candidate-bins/parity")
bins={"baseline":base,"control":base,"candidate":root/"candidate-bins/parity"}
count=20_000_000
parts=["upsert","worker-hot","4"]
per_worker=count//4
samples=4*((per_worker//4096)*64+sum((i&63)==((i//64)&63) for i in range(per_worker%4096)))
env={"scope":"Unpinned local four-thread diagnosis, not full acceptance","case":"/".join(parts),"count":count,"samples":samples,"platform":platform.platform(),"orders":ORDERS,"binary_sha256":{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in bins.items()}}
(out/"environment.json").write_text(json.dumps(env,indent=2)+"\n")
entries=[]
for index,order in [(-1,LABELS),*enumerate(ORDERS)]:
 for name in order:
  prefix=out/f"round-{index}-{name}"
  cmd=[str(bins[name]),*parts,str(count),"64"]
  prefix.with_suffix(".command.json").write_text(json.dumps(cmd)+"\n")
  run=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
  prefix.with_suffix(".stdout").write_text(run.stdout)
  prefix.with_suffix(".stderr").write_text(run.stderr)
  assert run.returncode==0
  row=validate_output(run.stdout,"rust","/".join(parts),count)
  assert row["samples"]==samples
  print(index,name,row["elapsed_ns"],flush=True)
  if index>=0:
   entries.append({"round":index,"name":name,"result":row})
   (out/"results.json").write_text(json.dumps(entries,indent=2)+"\n")
result=summarize(entries)
(out/"comparison.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result["comparisons"]),flush=True)
sys.exit(0 if result["passed"] else 1)
