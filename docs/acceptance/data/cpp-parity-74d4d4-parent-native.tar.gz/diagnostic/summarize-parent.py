"""Validate the one-case parent diagnostic without weakening the full 18-case gate."""
from pathlib import Path
import json,subprocess
root=Path(__file__).parent
case='upsert/shared-hot/1'
head='535fdc53da506fa6e8f73f94a5b509399e119024'
run=json.loads(subprocess.check_output(['gh','run','view','34824159780','--json','databaseId,headSha,status,conclusion,jobs'],text=True))
assert run['headSha']==head and run['status']=='completed'
(root/'run.json').write_text(json.dumps(run,indent=2)+'\n')
previous=root.parent/'74d4d4-native'
assert (root/'native-code/candidate-source.sha256').read_bytes()==(previous/'native-code/candidate-source.sha256').read_bytes()
meta=json.loads((root/'memory/environment.json').read_text())
assert meta['binary_sha256']==json.loads((previous/'memory/environment.json').read_text())['binary_sha256']
result={'scope':'One shared-hot Upsert case against direct parent525e130; original full primary69 and retained29 failures remain in force.','head':head,'runtime':'74d4d4dc5093337173ddf7c318681a8a87a725d3','source_and_timed_binaries_match_previous_full_run':True,'binary_sha256':meta['binary_sha256']}
for name in ['memory','rust-baseline','rust-baseline-control','rust-baseline-anchor']:
 rows=json.loads((root/name/'comparison.json').read_text());assert len(rows)==1 and rows[0]['case']==case
 row=rows[0];minimum=.9 if name=='memory' else .98
 assert row['passed']==(row['throughput_ratio']>=minimum and row['p99_ratio']<=1.1)
 result[name]={k:row[k] for k in ['case','throughput_ratio','p99_ratio','passed']}
scans=json.loads((root/'resident-scans/comparison.json').read_text());assert len(scans)==2
for row in scans:assert row['passed']==(row['append_throughput_ratio']>=.98 and row['scan_throughput_ratio']>=.98 and row['p99_ratio']<=1.1)
result['scans']=[{k:v for k,v in row.items() if k!='rows'} for row in scans]
result['variable']=json.loads((root/'variable-repeat/comparison.json').read_text())['comparisons']
for row in result['variable'].values():assert row['passed']==(row['throughput_ratio']>=.98 and row['p99_ratio']<=1.1)
rows=json.loads((root/'lifecycles/comparison.json').read_text());assert len(rows)==3
result['strict_lifecycles']=[{k:row[k] for k in ['case','throughput_ratio','p99_ratio','control_throughput_ratio','control_p99_ratio']} | {'candidate_passed':row['throughput_ratio']>=.98 and row['p99_ratio']<=1.10,'control_passed':row['control_throughput_ratio']>=.98 and row['control_p99_ratio']<=1.10} for row in rows]
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
