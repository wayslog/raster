"""Diagnostic only: keep executables and business inputs fixed; vary argv[0]."""
import hashlib,json,statistics,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path('tools/performance').resolve()))
from cpu_profile import validate_output
root=Path(__file__).parent
output=root/'argv0-diagnostic'
output.mkdir(exist_ok=False)
binaries={name:(root/(name+'-bins')/'parity').resolve() for name in ('baseline','candidate')}
roles={'baseline-original':('baseline',None),'candidate-original':('candidate',None),'baseline-fixed':('baseline','parity'),'candidate-fixed':('candidate','parity')}
meta={'diagnostic_only':True,'variable':'argv[0]; executable, workload and validation unchanged','count':2000000,'rounds':8,'binary_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in binaries.items()},'argv0_lengths':{k:len(a or str(binaries[b])) for k,(b,a) in roles.items()}}
(output/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
orders=[list(roles),list(reversed(roles)),['baseline-fixed','candidate-fixed','baseline-original','candidate-original'],['candidate-original','baseline-original','candidate-fixed','baseline-fixed']]
results=[]
for case in ['upsert/worker-hot/4','rmw/worker-hot/4','read/uniform/4']:
    rows={r:[] for r in roles}
    for i in range(-1,8):
        for role in orders[i%len(orders)]:
            binary,argv0=roles[role]
            path=binaries[binary]
            operation,distribution,threads=case.split('/')
            command=[argv0 or str(path),operation,distribution,threads,'2000000','64']
            run=subprocess.run(command,executable=str(path),capture_output=True,text=True,timeout=180)
            prefix=case.replace('/','-')+f'-{i}-{role}'
            (output/(prefix+'.stdout')).write_text(run.stdout)
            (output/(prefix+'.stderr')).write_text(run.stderr)
            if run.returncode: raise RuntimeError((prefix,run.returncode))
            row=validate_output(run.stdout,'rust',case,2000000)
            if i>=0: rows[role].append(row)
    pairs={}
    for label,candidate,baseline in [('original','candidate-original','baseline-original'),('fixed','candidate-fixed','baseline-fixed'),('baseline-argv0','baseline-fixed','baseline-original'),('candidate-argv0','candidate-fixed','candidate-original')]:
        throughput=statistics.median(r['elapsed_ns'] for r in rows[baseline])/statistics.median(r['elapsed_ns'] for r in rows[candidate])
        p99=statistics.median(r['p99_ns'] for r in rows[candidate])/statistics.median(r['p99_ns'] for r in rows[baseline])
        pairs[label]={'throughput_ratio':throughput,'p99_ratio':p99,'passed':throughput>=.98 and p99<=1.10}
    results.append({'case':case,'pairs':pairs,'rows':rows})
    (output/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
    print(case,json.dumps(pairs),flush=True)
