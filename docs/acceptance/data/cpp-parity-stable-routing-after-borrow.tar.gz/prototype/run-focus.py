import json, subprocess, sys, time
from pathlib import Path
root=Path(__file__).parent
cases=['read/uniform/1','read/uniform/4','read/worker-hot/4','read/shared-hot/4','upsert/uniform/1','upsert/uniform/4','upsert/worker-hot/4','rmw/worker-hot/4']
results=[]
for case in cases+['control/read/uniform/4']:
    control=case.startswith('control/')
    selected=case.removeprefix('control/')
    output=root/'focus'/case.replace('/','-')
    command=[sys.executable,'tools/performance/compare.py','--rust',str(root/('baseline-bins' if control else 'candidate-bins')/'parity'),'--baseline-rust',str(root/'baseline-bins'/'parity'),'--case',selected,'--output',str(output),'--min-throughput','.98','--max-p99','1.10']
    run=subprocess.run(command,capture_output=True,text=True)
    print(run.stdout,flush=True)
    results.append({'case':case,'command':command,'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
    (root/'focus-runs.json').write_text(json.dumps(results,indent=2)+'\n')
    if not (output/'comparison.json').exists():
        print(run.stderr,flush=True)
        raise SystemExit(run.returncode or 1)
print('Focus complete; results include failed gates without stopping later cases.',flush=True)
