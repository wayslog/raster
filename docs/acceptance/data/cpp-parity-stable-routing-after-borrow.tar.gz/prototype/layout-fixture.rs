
#[cfg(test)]
mod layout_diagnostic {
    #[test]
    fn inspect_operation_gate_layout() {
        use crate::schema::{KeyCodec, builtin::{AtomicU64Value, SchemaPair, U64Key}};
        type Schema = SchemaPair<U64Key, AtomicU64Value>;
        let mut config = crate::config::Config::default();
        config.log.page_bytes = 4096;
        config.log.memory_pages = 4;
        let store = crate::RasterKV::builder(SchemaPair::new(U64Key, AtomicU64Value))
            .config(config)
            .device(Box::new(crate::device::null::NullDeviceFactory))
            .create().unwrap();
        let engine = &*store.inner;
        println!("[DEBUG-layout] engine_size={} engine_align={} engine_mod_128={} index_offset={}",
            size_of::<super::Engine<Schema>>(), align_of::<super::Engine<Schema>>(),
            engine as *const _ as usize % 128, std::mem::offset_of!(super::Engine<Schema>, index));
        let base = &engine.operations[0] as *const _ as usize;
        println!("[DEBUG-layout] gate_size={} gate_base_mod_128={}", size_of_val(&engine.operations[0]), base % 128);
        for key in [0, 256, 512, 768] {
            let hash = U64Key.hash(&key);
            let slot = hash.0 as usize % engine.operations.len();
            let address = &engine.operations[slot] as *const _ as usize;
            println!("[DEBUG-layout] key={key} slot={slot} relative_address={} relative_line_64={} relative_line_128={}",
                address-base, address/64-base/64, address/128-base/128);
        }
    }
}
