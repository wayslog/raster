from pathlib import Path
import json,subprocess
root=Path(__file__).parent
manifest=json.loads((root/'manifest.json').read_text())
paths=set(manifest['source_sha256'])|{'src/engine/mod.rs'}
original={n:Path(n).read_bytes() for n in paths}
fixture=(root/'layout-fixture.rs').read_text()
try:
    for variant in ['candidate','parent']:
        for name,raw in original.items():
            if variant=='parent':
                previous=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
                if previous.returncode==0: raw=previous.stdout
            Path(name).write_bytes(raw)
        p=Path('src/engine/mod.rs');p.write_text(p.read_text()+fixture)
        p=Path('src/index/growth.rs');text=p.read_text()
        fields=['state','metrics']+(['epoch_owner','stable'] if variant=='candidate' else [])
        index_fixture='\n#[cfg(test)]\nmod index_layout_diagnostic {\n #[test] fn inspect_index_layout() {\n'
        index_fixture+='println!("[DEBUG-layout] index_size={} index_align={}", size_of::<super::MemIndex>(), align_of::<super::MemIndex>());\n'
        for field in fields:
            index_fixture+='println!("[DEBUG-layout] index_'+field+'_offset={}", std::mem::offset_of!(super::MemIndex, '+field+'));\n'
        index_fixture+='}}\n'
        p.write_text(text+index_fixture)
        r=subprocess.run(['cargo','test','--locked','--lib','layout_diagnostic','--','--nocapture'],capture_output=True,text=True)
        log=(r.stdout+r.stderr).replace(str(Path.cwd()),'worktree').replace(str(Path.home()),'user_directory')
        (root/(variant+'-layout.log')).write_text(log)
        print(variant, r.returncode, '\n'.join(line for line in log.splitlines() if '[DEBUG-layout]' in line),flush=True)
        if r.returncode: raise RuntimeError(log[-2000:])
finally:
    for name,raw in original.items():Path(name).write_bytes(raw)
