use std::{alloc::{GlobalAlloc, Layout, System}, collections::BTreeMap, sync::atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed}};
struct Tracking;
static ENABLED: AtomicBool = AtomicBool::new(false);
static ALLOC: AtomicUsize = AtomicUsize::new(0);
static FREE: AtomicUsize = AtomicUsize::new(0);
unsafe impl GlobalAlloc for Tracking {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        if ENABLED.load(Relaxed) { ALLOC.fetch_add(1, Relaxed); }
        unsafe { System.alloc(layout) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        if ENABLED.load(Relaxed) { FREE.fetch_add(1, Relaxed); }
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[global_allocator] static ALLOCATOR: Tracking = Tracking;
fn main() {
    let mut active = BTreeMap::new();
    active.insert((7_u64, 0_u64), 1_usize);
    active.remove(&(7, 0));
    ENABLED.store(true, Relaxed);
    for n in 0..200_000 {
        let key = std::hint::black_box((n % 64, 0));
        let count = active.get(&key).copied().unwrap_or(0) + 1;
        active.insert(key, count);
        std::hint::black_box(&active);
        active.remove(&key);
    }
    ENABLED.store(false, Relaxed);
    println!("operations=200000 allocations={} frees={}", ALLOC.load(Relaxed), FREE.load(Relaxed));
    assert!(active.is_empty());
}
