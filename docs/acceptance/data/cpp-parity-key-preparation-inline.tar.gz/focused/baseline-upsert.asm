0000000100005f88 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>>:
100005f88: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100005f8c: a90167fa    	stp	x26, x25, [sp, #0x10]
100005f90: a9025ff8    	stp	x24, x23, [sp, #0x20]
100005f94: a90357f6    	stp	x22, x21, [sp, #0x30]
100005f98: a9044ff4    	stp	x20, x19, [sp, #0x40]
100005f9c: a9057bfd    	stp	x29, x30, [sp, #0x50]
100005fa0: 910143fd    	add	x29, sp, #0x50
100005fa4: d11383ff    	sub	sp, sp, #0x4e0
100005fa8: f90003ff    	str	xzr, [sp]
100005fac: aa0403f9    	mov	x25, x4
100005fb0: aa0303fa    	mov	x26, x3
100005fb4: aa0203fc    	mov	x28, x2
100005fb8: aa0103f8    	mov	x24, x1
100005fbc: aa0803f7    	mov	x23, x8
100005fc0: a90513e3    	stp	x3, x4, [sp, #0x50]
100005fc4: a9061be5    	stp	x5, x6, [sp, #0x60]
100005fc8: 910e83f4    	add	x20, sp, #0x3a0
100005fcc: f9400016    	ldr	x22, [x0]
100005fd0: 910e83e8    	add	x8, sp, #0x3a0
100005fd4: 910202c0    	add	x0, x22, #0x80
100005fd8: 94001d91    	bl	0x10000d61c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
100005fdc: f941d3e8    	ldr	x8, [sp, #0x3a0]
100005fe0: b100051f    	cmn	x8, #0x1
100005fe4: 540001a0    	b.eq	0x100006018 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x90>
100005fe8: 394ea3e9    	ldrb	w9, [sp, #0x3a8]
100005fec: 3cc09280    	ldur	q0, [x20, #0x9]
100005ff0: 3c8112e0    	stur	q0, [x23, #0x11]
100005ff4: 3cc19280    	ldur	q0, [x20, #0x19]
100005ff8: 3c8212e0    	stur	q0, [x23, #0x21]
100005ffc: f941e7ea    	ldr	x10, [sp, #0x3c8]
100006000: 390042e9    	strb	w9, [x23, #0x10]
100006004: a9036aea    	stp	x10, x26, [x23, #0x30]
100006008: f90022f9    	str	x25, [x23, #0x40]
10000600c: 52800029    	mov	w9, #0x1                ; =1
100006010: a90022e9    	stp	x9, x8, [x23]
100006014: 1400006c    	b	0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
100006018: 910e83e0    	add	x0, sp, #0x3a0
10000601c: 910202c1    	add	x1, x22, #0x80
100006020: 910143e4    	add	x4, sp, #0x50
100006024: aa1803e2    	mov	x2, x24
100006028: aa1c03e3    	mov	x3, x28
10000602c: 97fffb45    	bl	0x100004d40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>>
100006030: f941d3e8    	ldr	x8, [sp, #0x3a0]
100006034: b100051f    	cmn	x8, #0x1
100006038: 54000140    	b.eq	0x100006060 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xd8>
10000603c: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
100006040: 3c8082e0    	stur	q0, [x23, #0x8]
100006044: 3c8182e1    	stur	q1, [x23, #0x18]
100006048: 3dc0f3e0    	ldr	q0, [sp, #0x3c0]
10000604c: 3c8282e0    	stur	q0, [x23, #0x28]
100006050: a903e6fa    	stp	x26, x25, [x23, #0x38]
100006054: 52800028    	mov	w8, #0x1                ; =1
100006058: f90002e8    	str	x8, [x23]
10000605c: 1400005a    	b	0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
100006060: f941d7fb    	ldr	x27, [sp, #0x3a8]
100006064: 394ec3e8    	ldrb	w8, [sp, #0x3b0]
100006068: b90047e8    	str	w8, [sp, #0x44]
10000606c: b8411288    	ldur	w8, [x20, #0x11]
100006070: b90073e8    	str	w8, [sp, #0x70]
100006074: b943b7e8    	ldr	w8, [sp, #0x3b4]
100006078: b80733e8    	stur	w8, [sp, #0x73]
10000607c: f941dfe8    	ldr	x8, [sp, #0x3b8]
100006080: f90027e8    	str	x8, [sp, #0x48]
100006084: f941e3e8    	ldr	x8, [sp, #0x3c0]
100006088: f9001fe8    	str	x8, [sp, #0x38]
10000608c: f94072c8    	ldr	x8, [x22, #0xe0]
100006090: b4003f68    	cbz	x8, 0x10000687c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8f4>
100006094: f941e7f5    	ldr	x21, [sp, #0x3c8]
100006098: f9406ec9    	ldr	x9, [x22, #0xd8]
10000609c: 9ac80b6a    	udiv	x10, x27, x8
1000060a0: 9b08ed48    	msub	x8, x10, x8, x27
1000060a4: 8b081121    	add	x1, x9, x8, lsl #4
1000060a8: 910e83e0    	add	x0, sp, #0x3a0
1000060ac: 94003c1e    	bl	0x100015124 <raster::engine::operation_gate::try_lock>
1000060b0: b943a3e8    	ldr	w8, [sp, #0x3a0]
1000060b4: 36000248    	tbz	w8, #0x0, 0x1000060fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x174>
1000060b8: a903e6fa    	stp	x26, x25, [x23, #0x38]
1000060bc: 900006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
1000060c0: 3dc10900    	ldr	q0, [x8, #0x420]
1000060c4: 3d8002e0    	str	q0, [x23]
1000060c8: 394ec3e8    	ldrb	w8, [sp, #0x3b0]
1000060cc: 7100091f    	cmp	w8, #0x2
1000060d0: 540006c0    	b.eq	0x1000061a8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x220>
1000060d4: f941d7f3    	ldr	x19, [sp, #0x3a8]
1000060d8: 370000c8    	tbnz	w8, #0x0, 0x1000060f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x168>
1000060dc: d0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
1000060e0: 91394108    	add	x8, x8, #0xe50
1000060e4: f9400108    	ldr	x8, [x8]
1000060e8: f240f91f    	tst	x8, #0x7fffffffffffffff
1000060ec: 54003b01    	b.ne	0x10000684c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8c4>
1000060f0: f9400260    	ldr	x0, [x19]
1000060f4: 94027921    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1000060f8: 1400002c    	b	0x1000061a8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x220>
1000060fc: f941d7e8    	ldr	x8, [sp, #0x3a8]
100006100: f9001be8    	str	x8, [sp, #0x30]
100006104: 394ec3e8    	ldrb	w8, [sp, #0x3b0]
100006108: b9002fe8    	str	w8, [sp, #0x2c]
10000610c: 52800033    	mov	w19, #0x1               ; =1
100006110: aa1803e0    	mov	x0, x24
100006114: 94015ada    	bl	0x10005cc7c <<raster::engine::pending::SessionRuntime>::pending>
100006118: f940fac8    	ldr	x8, [x22, #0x1f0]
10000611c: eb08001f    	cmp	x0, x8
100006120: 54000282    	b.hs	0x100006170 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x1e8>
100006124: f940fec1    	ldr	x1, [x22, #0x1f8]
100006128: 52800033    	mov	w19, #0x1               ; =1
10000612c: 910e83e8    	add	x8, sp, #0x3a0
100006130: aa1803e0    	mov	x0, x24
100006134: 9401596f    	bl	0x10005c6f0 <<raster::engine::pending::SessionRuntime>::reserve_result>
100006138: f941d3e8    	ldr	x8, [sp, #0x3a0]
10000613c: b100051f    	cmn	x8, #0x1
100006140: 54000520    	b.eq	0x1000061e4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x25c>
100006144: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
100006148: 3c8082e0    	stur	q0, [x23, #0x8]
10000614c: 3c8182e1    	stur	q1, [x23, #0x18]
100006150: 3dc0f3e0    	ldr	q0, [sp, #0x3c0]
100006154: 3c8282e0    	stur	q0, [x23, #0x28]
100006158: a903e6fa    	stp	x26, x25, [x23, #0x38]
10000615c: 52800028    	mov	w8, #0x1                ; =1
100006160: f90002e8    	str	x8, [x23]
100006164: b9402fe8    	ldr	w8, [sp, #0x2c]
100006168: 36000108    	tbz	w8, #0x0, 0x100006188 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x200>
10000616c: 1400000c    	b	0x10000619c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x214>
100006170: a903e6fa    	stp	x26, x25, [x23, #0x38]
100006174: 900006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
100006178: 3dc10900    	ldr	q0, [x8, #0x420]
10000617c: 3d8002e0    	str	q0, [x23]
100006180: b9402fe8    	ldr	w8, [sp, #0x2c]
100006184: 370000c8    	tbnz	w8, #0x0, 0x10000619c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x214>
100006188: d0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
10000618c: 91394108    	add	x8, x8, #0xe50
100006190: f9400108    	ldr	x8, [x8]
100006194: f240f91f    	tst	x8, #0x7fffffffffffffff
100006198: 540034e1    	b.ne	0x100006834 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8ac>
10000619c: f9401be8    	ldr	x8, [sp, #0x30]
1000061a0: f9400100    	ldr	x0, [x8]
1000061a4: 940278f5    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1000061a8: f94027e1    	ldr	x1, [sp, #0x48]
1000061ac: b94047e8    	ldr	w8, [sp, #0x44]
1000061b0: 340000a8    	cbz	w8, 0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
1000061b4: b4000081    	cbz	x1, 0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
1000061b8: f9401fe0    	ldr	x0, [sp, #0x38]
1000061bc: 52800022    	mov	w2, #0x1                ; =1
1000061c0: 9401249b    	bl	0x10004f42c <__rustc::__rust_dealloc>
1000061c4: 911383ff    	add	sp, sp, #0x4e0
1000061c8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000061cc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000061d0: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000061d4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000061d8: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000061dc: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000061e0: d65f03c0    	ret
1000061e4: f941d7e8    	ldr	x8, [sp, #0x3a8]
1000061e8: f9003fe8    	str	x8, [sp, #0x78]
1000061ec: 910e83e0    	add	x0, sp, #0x3a0
1000061f0: 910202c1    	add	x1, x22, #0x80
1000061f4: aa1803e2    	mov	x2, x24
1000061f8: 940016f7    	bl	0x10000bdd4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
1000061fc: 394f47e8    	ldrb	w8, [sp, #0x3d1]
100006200: 7100091f    	cmp	w8, #0x2
100006204: 540001e1    	b.ne	0x100006240 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x2b8>
100006208: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
10000620c: 3c8082e0    	stur	q0, [x23, #0x8]
100006210: 3c8182e1    	stur	q1, [x23, #0x18]
100006214: 3dc0f3e0    	ldr	q0, [sp, #0x3c0]
100006218: 3c8282e0    	stur	q0, [x23, #0x28]
10000621c: a903e6fa    	stp	x26, x25, [x23, #0x38]
100006220: 52800033    	mov	w19, #0x1               ; =1
100006224: f90002f3    	str	x19, [x23]
100006228: f9403fe8    	ldr	x8, [sp, #0x78]
10000622c: f9400109    	ldr	x9, [x8]
100006230: f1000529    	subs	x9, x9, #0x1
100006234: f9000109    	str	x9, [x8]
100006238: 540009e1    	b.ne	0x100006374 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3ec>
10000623c: 1400004c    	b	0x10000636c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3e4>
100006240: ad5d83e1    	ldp	q1, q0, [sp, #0x3b0]
100006244: ad0483e1    	stp	q1, q0, [sp, #0x90]
100006248: 3dc0ebe0    	ldr	q0, [sp, #0x3a0]
10000624c: 3d8023e0    	str	q0, [sp, #0x80]
100006250: f941ebe8    	ldr	x8, [sp, #0x3d0]
100006254: f9005be8    	str	x8, [sp, #0xb0]
100006258: ad0607e0    	stp	q0, q1, [sp, #0xc0]
10000625c: a94a23f3    	ldp	x19, x8, [sp, #0xa0]
100006260: f9000be8    	str	x8, [sp, #0x10]
100006264: f9400b02    	ldr	x2, [x24, #0x10]
100006268: 910403e8    	add	x8, sp, #0x100
10000626c: 910d02c0    	add	x0, x22, #0x340
100006270: aa1b03e1    	mov	x1, x27
100006274: 9401629e    	bl	0x10005ecec <<raster::engine::version_permit::VersionPermits>::reserve_initial>
100006278: f94083e8    	ldr	x8, [sp, #0x100]
10000627c: b100051f    	cmn	x8, #0x1
100006280: 54000280    	b.eq	0x1000062d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x348>
100006284: f94186c9    	ldr	x9, [x22, #0x308]
100006288: 910e83e8    	add	x8, sp, #0x3a0
10000628c: 91004120    	add	x0, x9, #0x10
100006290: 910203e1    	add	x1, sp, #0x80
100006294: 94022f2c    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
100006298: f941d3e8    	ldr	x8, [sp, #0x3a0]
10000629c: b100051f    	cmn	x8, #0x1
1000062a0: 54000060    	b.eq	0x1000062ac <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x324>
1000062a4: 910e83e0    	add	x0, sp, #0x3a0
1000062a8: 94001126    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
1000062ac: ad4807e0    	ldp	q0, q1, [sp, #0x100]
1000062b0: 3c8082e0    	stur	q0, [x23, #0x8]
1000062b4: 3c8182e1    	stur	q1, [x23, #0x18]
1000062b8: 3dc04be0    	ldr	q0, [sp, #0x120]
1000062bc: 3c8282e0    	stur	q0, [x23, #0x28]
1000062c0: a903e6fa    	stp	x26, x25, [x23, #0x38]
1000062c4: 52800028    	mov	w8, #0x1                ; =1
1000062c8: f90002e8    	str	x8, [x23]
1000062cc: 14000022    	b	0x100006354 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3cc>
1000062d0: f90007f3    	str	x19, [sp, #0x8]
1000062d4: 910403f3    	add	x19, sp, #0x100
1000062d8: 3cc08260    	ldur	q0, [x19, #0x8]
1000062dc: 3cc18261    	ldur	q1, [x19, #0x18]
1000062e0: ad0707e0    	stp	q0, q1, [sp, #0xe0]
1000062e4: 9104c3e0    	add	x0, sp, #0x130
1000062e8: 910202c1    	add	x1, x22, #0x80
1000062ec: aa1803e2    	mov	x2, x24
1000062f0: aa1c03e3    	mov	x3, x28
1000062f4: 94001701    	bl	0x10000bef8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
1000062f8: f9409be8    	ldr	x8, [sp, #0x130]
1000062fc: b100051f    	cmn	x8, #0x1
100006300: 540004a0    	b.eq	0x100006394 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x40c>
100006304: f94186c9    	ldr	x9, [x22, #0x308]
100006308: 910e83e8    	add	x8, sp, #0x3a0
10000630c: 91004120    	add	x0, x9, #0x10
100006310: 910203e1    	add	x1, sp, #0x80
100006314: 94022f0c    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
100006318: f941d3e8    	ldr	x8, [sp, #0x3a0]
10000631c: b100051f    	cmn	x8, #0x1
100006320: 54000060    	b.eq	0x10000632c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3a4>
100006324: 910e83e0    	add	x0, sp, #0x3a0
100006328: 94001106    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
10000632c: ad4987e0    	ldp	q0, q1, [sp, #0x130]
100006330: 3c8082e0    	stur	q0, [x23, #0x8]
100006334: 3c8182e1    	stur	q1, [x23, #0x18]
100006338: 3dc057e0    	ldr	q0, [sp, #0x150]
10000633c: 3c8282e0    	stur	q0, [x23, #0x28]
100006340: a903e6fa    	stp	x26, x25, [x23, #0x38]
100006344: 52800028    	mov	w8, #0x1                ; =1
100006348: f90002e8    	str	x8, [x23]
10000634c: 910383e0    	add	x0, sp, #0xe0
100006350: 94000852    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100006354: 52800033    	mov	w19, #0x1               ; =1
100006358: f9403fe8    	ldr	x8, [sp, #0x78]
10000635c: f9400109    	ldr	x9, [x8]
100006360: f1000529    	subs	x9, x9, #0x1
100006364: f9000109    	str	x9, [x8]
100006368: 54000061    	b.ne	0x100006374 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3ec>
10000636c: 9101e3e0    	add	x0, sp, #0x78
100006370: 9401d8da    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100006374: f9401be0    	ldr	x0, [sp, #0x30]
100006378: b9402fe1    	ldr	w1, [sp, #0x2c]
10000637c: 94000e3b    	bl	0x100009c68 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100006380: f94027e1    	ldr	x1, [sp, #0x48]
100006384: 34fff213    	cbz	w19, 0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
100006388: b94047e8    	ldr	w8, [sp, #0x44]
10000638c: 35fff148    	cbnz	w8, 0x1000061b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x22c>
100006390: 17ffff8d    	b	0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
100006394: 910e83e8    	add	x8, sp, #0x3a0
100006398: 91034300    	add	x0, x24, #0xd0
10000639c: 52800021    	mov	w1, #0x1                ; =1
1000063a0: 940235b5    	bl	0x100093a74 <<raster::engine::metrics::Tracker>::accept>
1000063a4: 52800028    	mov	w8, #0x1                ; =1
1000063a8: f82802c8    	ldadd	x8, x8, [x22]
1000063ac: b7f82a28    	tbnz	x8, #0x3f, 0x1000068f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
1000063b0: b94047e8    	ldr	w8, [sp, #0x44]
1000063b4: 390783e8    	strb	w8, [sp, #0x1e0]
1000063b8: b94073e8    	ldr	w8, [sp, #0x70]
1000063bc: b80e1268    	stur	w8, [x19, #0xe1]
1000063c0: b84733e8    	ldur	w8, [sp, #0x73]
1000063c4: b901e7e8    	str	w8, [sp, #0x1e4]
1000063c8: f94027e9    	ldr	x9, [sp, #0x48]
1000063cc: f9401fe8    	ldr	x8, [sp, #0x38]
1000063d0: a91ea3e9    	stp	x9, x8, [sp, #0x1e8]
1000063d4: f900fff5    	str	x21, [sp, #0x1f8]
1000063d8: 910583e9    	add	x9, sp, #0x160
1000063dc: ad4407e0    	ldp	q0, q1, [sp, #0x80]
1000063e0: ad1007e0    	stp	q0, q1, [sp, #0x200]
1000063e4: 3dc02be0    	ldr	q0, [sp, #0xa0]
1000063e8: 3d808be0    	str	q0, [sp, #0x220]
1000063ec: f9405be8    	ldr	x8, [sp, #0xb0]
1000063f0: 910583f5    	add	x21, sp, #0x160
1000063f4: 91042129    	add	x9, x9, #0x108
1000063f8: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
1000063fc: ad000520    	stp	q0, q1, [x9]
100006400: f9400b09    	ldr	x9, [x24, #0x10]
100006404: f9011be8    	str	x8, [sp, #0x230]
100006408: f9011ff6    	str	x22, [sp, #0x238]
10000640c: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
100006410: 3c8b8260    	stur	q0, [x19, #0xb8]
100006414: 3c8c8261    	stur	q1, [x19, #0xc8]
100006418: f941e3e8    	ldr	x8, [sp, #0x3c0]
10000641c: f900efe8    	str	x8, [sp, #0x1d8]
100006420: 52800033    	mov	w19, #0x1               ; =1
100006424: a9166bf3    	stp	x19, x26, [sp, #0x160]
100006428: 52800048    	mov	w8, #0x2                ; =2
10000642c: a91723f9    	stp	x25, x8, [sp, #0x170]
100006430: 390a23ff    	strb	wzr, [sp, #0x288]
100006434: f90123fb    	str	x27, [sp, #0x240]
100006438: f90127ff    	str	xzr, [sp, #0x248]
10000643c: f9012ffc    	str	x28, [sp, #0x258]
100006440: f90133e9    	str	x9, [sp, #0x260]
100006444: 92800008    	mov	x8, #-0x1               ; =-1
100006448: f9014be8    	str	x8, [sp, #0x290]
10000644c: 910583e0    	add	x0, sp, #0x160
100006450: 910183e1    	add	x1, sp, #0x60
100006454: 910a43e2    	add	x2, sp, #0x290
100006458: 94005dc1    	bl	0x10001db5c <<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked>
10000645c: 910a43f9    	add	x25, sp, #0x290
100006460: b4000740    	cbz	x0, 0x100006548 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x5c0>
100006464: f100041f    	cmp	x0, #0x1
100006468: 54000921    	b.ne	0x10000658c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x604>
10000646c: 52800033    	mov	w19, #0x1               ; =1
100006470: f94133e2    	ldr	x2, [sp, #0x260]
100006474: 910c03e8    	add	x8, sp, #0x300
100006478: 910d02c0    	add	x0, x22, #0x340
10000647c: 910422a3    	add	x3, x21, #0x108
100006480: aa1b03e1    	mov	x1, x27
100006484: 94016394    	bl	0x10005f2d4 <<raster::engine::version_permit::VersionPermits>::activate>
100006488: f94183e8    	ldr	x8, [sp, #0x300]
10000648c: b100051f    	cmn	x8, #0x1
100006490: 54000141    	b.ne	0x1000064b8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x530>
100006494: f94186c9    	ldr	x9, [x22, #0x308]
100006498: 52800033    	mov	w19, #0x1               ; =1
10000649c: 910c03e8    	add	x8, sp, #0x300
1000064a0: 91004120    	add	x0, x9, #0x10
1000064a4: 910282a1    	add	x1, x21, #0xa0
1000064a8: 94022f16    	bl	0x100092100 <<raster::engine::io_hub::CompletionHub>::activate_operation>
1000064ac: f94183e8    	ldr	x8, [sp, #0x300]
1000064b0: b100051f    	cmn	x8, #0x1
1000064b4: 540014e0    	b.eq	0x100006750 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x7c8>
1000064b8: ad5807e0    	ldp	q0, q1, [sp, #0x300]
1000064bc: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
1000064c0: 3dc0cbe0    	ldr	q0, [sp, #0x320]
1000064c4: 3d80f3e0    	str	q0, [sp, #0x3c0]
1000064c8: 394a23e8    	ldrb	w8, [sp, #0x288]
1000064cc: 390f43e8    	strb	w8, [sp, #0x3d0]
1000064d0: b94163e8    	ldr	w8, [sp, #0x160]
1000064d4: f900b3ff    	str	xzr, [sp, #0x160]
1000064d8: 36001f28    	tbz	w8, #0x0, 0x1000068bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x934>
1000064dc: 52800048    	mov	w8, #0x2                ; =2
1000064e0: f900bfe8    	str	x8, [sp, #0x178]
1000064e4: f941d3f3    	ldr	x19, [sp, #0x3a0]
1000064e8: 3cc08280    	ldur	q0, [x20, #0x8]
1000064ec: 3cc18281    	ldur	q1, [x20, #0x18]
1000064f0: ad1987e0    	stp	q0, q1, [sp, #0x330]
1000064f4: 3cc28280    	ldur	q0, [x20, #0x28]
1000064f8: 3d80d7e0    	str	q0, [sp, #0x350]
1000064fc: b1000a7f    	cmn	x19, #0x2
100006500: 54001ea0    	b.eq	0x1000068d4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x94c>
100006504: f901b3f3    	str	x19, [sp, #0x360]
100006508: ad5987e0    	ldp	q0, q1, [sp, #0x330]
10000650c: 3c8d8320    	stur	q0, [x25, #0xd8]
100006510: 3c8e8321    	stur	q1, [x25, #0xe8]
100006514: 3dc0d7e0    	ldr	q0, [sp, #0x350]
100006518: 3c8f8320    	stur	q0, [x25, #0xf8]
10000651c: 3948c3e8    	ldrb	w8, [sp, #0x230]
100006520: 7100051f    	cmp	w8, #0x1
100006524: 54000d41    	b.ne	0x1000066cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x744>
100006528: 910583f5    	add	x21, sp, #0x160
10000652c: ad4506a0    	ldp	q0, q1, [x21, #0xa0]
100006530: 3c808280    	stur	q0, [x20, #0x8]
100006534: 3c818281    	stur	q1, [x20, #0x18]
100006538: 3ccc02a0    	ldur	q0, [x21, #0xc0]
10000653c: 3c828280    	stur	q0, [x20, #0x28]
100006540: 52800028    	mov	w8, #0x1                ; =1
100006544: 14000064    	b	0x1000066d4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x74c>
100006548: 390b43ff    	strb	wzr, [sp, #0x2d0]
10000654c: f9016fe1    	str	x1, [sp, #0x2d8]
100006550: f940b3e8    	ldr	x8, [sp, #0x160]
100006554: f900b3ff    	str	xzr, [sp, #0x160]
100006558: f100051f    	cmp	x8, #0x1
10000655c: 54001981    	b.ne	0x10000688c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x904>
100006560: 910b23e8    	add	x8, sp, #0x2c8
100006564: 52800049    	mov	w9, #0x2                ; =2
100006568: f900bfe9    	str	x9, [sp, #0x178]
10000656c: 3cc08100    	ldur	q0, [x8, #0x8]
100006570: 3cc18101    	ldur	q1, [x8, #0x18]
100006574: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
100006578: 3cc28100    	ldur	q0, [x8, #0x28]
10000657c: 3d80f3e0    	str	q0, [sp, #0x3c0]
100006580: 52800033    	mov	w19, #0x1               ; =1
100006584: 92800015    	mov	x21, #-0x1              ; =-1
100006588: 14000019    	b	0x1000065ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x664>
10000658c: f9414bf5    	ldr	x21, [sp, #0x290]
100006590: b10006bf    	cmn	x21, #0x1
100006594: 54001660    	b.eq	0x100006860 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8d8>
100006598: 3cc08320    	ldur	q0, [x25, #0x8]
10000659c: 3cc18321    	ldur	q1, [x25, #0x18]
1000065a0: ad020720    	stp	q0, q1, [x25, #0x40]
1000065a4: 3cc28320    	ldur	q0, [x25, #0x28]
1000065a8: 3c860320    	stur	q0, [x25, #0x60]
1000065ac: f90167f5    	str	x21, [sp, #0x2c8]
1000065b0: b94163e8    	ldr	w8, [sp, #0x160]
1000065b4: f900b3ff    	str	xzr, [sp, #0x160]
1000065b8: 360016e8    	tbz	w8, #0x0, 0x100006894 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x90c>
1000065bc: 52800013    	mov	w19, #0x0               ; =0
1000065c0: 5280001a    	mov	w26, #0x0               ; =0
1000065c4: 910a43e8    	add	x8, sp, #0x290
1000065c8: 52800049    	mov	w9, #0x2                ; =2
1000065cc: f900bfe9    	str	x9, [sp, #0x178]
1000065d0: 3cc08100    	ldur	q0, [x8, #0x8]
1000065d4: 3cc18101    	ldur	q1, [x8, #0x18]
1000065d8: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
1000065dc: 3cc28100    	ldur	q0, [x8, #0x28]
1000065e0: 3d80f3e0    	str	q0, [sp, #0x3c0]
1000065e4: b1000abf    	cmn	x21, #0x2
1000065e8: 540015c0    	b.eq	0x1000068a0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x918>
1000065ec: f901b3f5    	str	x21, [sp, #0x360]
1000065f0: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
1000065f4: 3c8d8320    	stur	q0, [x25, #0xd8]
1000065f8: 3c8e8321    	stur	q1, [x25, #0xe8]
1000065fc: 3dc0f3e0    	ldr	q0, [sp, #0x3c0]
100006600: 3c8f8320    	stur	q0, [x25, #0xf8]
100006604: 3948c3e8    	ldrb	w8, [sp, #0x230]
100006608: 7100051f    	cmp	w8, #0x1
10000660c: 54000121    	b.ne	0x100006630 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x6a8>
100006610: 910583f9    	add	x25, sp, #0x160
100006614: ad450720    	ldp	q0, q1, [x25, #0xa0]
100006618: 3c808280    	stur	q0, [x20, #0x8]
10000661c: 3c818281    	stur	q1, [x20, #0x18]
100006620: 3ccc0320    	ldur	q0, [x25, #0xc0]
100006624: 3c828280    	stur	q0, [x20, #0x28]
100006628: 52800028    	mov	w8, #0x1                ; =1
10000662c: 14000003    	b	0x100006638 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x6b0>
100006630: d2800008    	mov	x8, #0x0                ; =0
100006634: 910583f9    	add	x25, sp, #0x160
100006638: f901d3e8    	str	x8, [sp, #0x3a0]
10000663c: 910202c0    	add	x0, x22, #0x80
100006640: 91016321    	add	x1, x25, #0x58
100006644: 910e83e2    	add	x2, sp, #0x3a0
100006648: 910d83e3    	add	x3, sp, #0x360
10000664c: 94000219    	bl	0x100006eb0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::record_ready::<u64>>
100006650: 910202c0    	add	x0, x22, #0x80
100006654: 91028322    	add	x2, x25, #0xa0
100006658: aa1803e1    	mov	x1, x24
10000665c: 940015ad    	bl	0x10000bd10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
100006660: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
100006664: ad0086e0    	stp	q0, q1, [x23, #0x10]
100006668: 3dc0e3e0    	ldr	q0, [sp, #0x380]
10000666c: 3d800ee0    	str	q0, [x23, #0x30]
100006670: f941cbe8    	ldr	x8, [sp, #0x390]
100006674: f90022e8    	str	x8, [x23, #0x40]
100006678: a9007eff    	stp	xzr, xzr, [x23]
10000667c: f9414be8    	ldr	x8, [sp, #0x290]
100006680: b100051f    	cmn	x8, #0x1
100006684: 1a9303e8    	csel	w8, wzr, w19, eq
100006688: 36000068    	tbz	w8, #0x0, 0x100006694 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x70c>
10000668c: 910a43e0    	add	x0, sp, #0x290
100006690: 9400102c    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100006694: 910583e0    	add	x0, sp, #0x160
100006698: 94000c97    	bl	0x1000098f4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
10000669c: f9403fe8    	ldr	x8, [sp, #0x78]
1000066a0: f9400109    	ldr	x9, [x8]
1000066a4: f1000529    	subs	x9, x9, #0x1
1000066a8: f9000109    	str	x9, [x8]
1000066ac: 54000081    	b.ne	0x1000066bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x734>
1000066b0: 52800013    	mov	w19, #0x0               ; =0
1000066b4: 9101e3e0    	add	x0, sp, #0x78
1000066b8: 9401d808    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
1000066bc: f9401be0    	ldr	x0, [sp, #0x30]
1000066c0: b9402fe1    	ldr	w1, [sp, #0x2c]
1000066c4: 94000d69    	bl	0x100009c68 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
1000066c8: 17fffebf    	b	0x1000061c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x23c>
1000066cc: d2800008    	mov	x8, #0x0                ; =0
1000066d0: 910583f5    	add	x21, sp, #0x160
1000066d4: f901d3e8    	str	x8, [sp, #0x3a0]
1000066d8: 910202c0    	add	x0, x22, #0x80
1000066dc: 910162a1    	add	x1, x21, #0x58
1000066e0: 910e83e2    	add	x2, sp, #0x3a0
1000066e4: 910d83e3    	add	x3, sp, #0x360
1000066e8: 940001f2    	bl	0x100006eb0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::record_ready::<u64>>
1000066ec: 910202c0    	add	x0, x22, #0x80
1000066f0: 910282a2    	add	x2, x21, #0xa0
1000066f4: aa1803e1    	mov	x1, x24
1000066f8: 94001586    	bl	0x10000bd10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
1000066fc: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
100006700: ad0086e0    	stp	q0, q1, [x23, #0x10]
100006704: 3dc0e3e0    	ldr	q0, [sp, #0x380]
100006708: 3d800ee0    	str	q0, [x23, #0x30]
10000670c: f941cbe8    	ldr	x8, [sp, #0x390]
100006710: f90022e8    	str	x8, [x23, #0x40]
100006714: a9007eff    	stp	xzr, xzr, [x23]
100006718: f9414be8    	ldr	x8, [sp, #0x290]
10000671c: b100051f    	cmn	x8, #0x1
100006720: 54000060    	b.eq	0x10000672c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x7a4>
100006724: 910a43e0    	add	x0, sp, #0x290
100006728: 94001006    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
10000672c: 910583e0    	add	x0, sp, #0x160
100006730: 94000c71    	bl	0x1000098f4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100006734: 52800013    	mov	w19, #0x0               ; =0
100006738: f9403fe8    	ldr	x8, [sp, #0x78]
10000673c: f9400109    	ldr	x9, [x8]
100006740: f1000529    	subs	x9, x9, #0x1
100006744: f9000109    	str	x9, [x8]
100006748: 54ffe161    	b.ne	0x100006374 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3ec>
10000674c: 17ffff08    	b	0x10000636c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3e4>
100006750: f9403fe1    	ldr	x1, [sp, #0x78]
100006754: ad4607e0    	ldp	q0, q1, [sp, #0xc0]
100006758: ad1b07e0    	stp	q0, q1, [sp, #0x360]
10000675c: a940a3e9    	ldp	x9, x8, [sp, #0x8]
100006760: f901c3e9    	str	x9, [sp, #0x380]
100006764: f901c7e8    	str	x8, [sp, #0x388]
100006768: 52800013    	mov	w19, #0x0               ; =0
10000676c: 910e83e8    	add	x8, sp, #0x3a0
100006770: 910d83e0    	add	x0, sp, #0x360
100006774: 940087ee    	bl	0x10002872c <<raster::api::completion::Ticket<u64>>::pair_bounded>
100006778: 910583f3    	add	x19, sp, #0x160
10000677c: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
100006780: ad1b07e0    	stp	q0, q1, [sp, #0x360]
100006784: ad5e07e0    	ldp	q0, q1, [sp, #0x3c0]
100006788: ad1c07e0    	stp	q0, q1, [sp, #0x380]
10000678c: 3dc0fbe0    	ldr	q0, [sp, #0x3e0]
100006790: 3d8007e0    	str	q0, [sp, #0x10]
100006794: 9103a2a0    	add	x0, x21, #0xe8
100006798: 94000491    	bl	0x1000079dc <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
10000679c: 3dc007e0    	ldr	q0, [sp, #0x10]
1000067a0: 3c8e8260    	stur	q0, [x19, #0xe8]
1000067a4: 52800034    	mov	w20, #0x1               ; =1
1000067a8: 910162a0    	add	x0, x21, #0x58
1000067ac: 940235ed    	bl	0x100093f60 <<raster::engine::metrics::Monitor>::pending>
1000067b0: 910e83e0    	add	x0, sp, #0x3a0
1000067b4: 910583e1    	add	x1, sp, #0x160
1000067b8: 52802602    	mov	w2, #0x130              ; =304
1000067bc: 94031ef8    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
1000067c0: 52802600    	mov	w0, #0x130              ; =304
1000067c4: 94003a49    	bl	0x1000150e8 <alloc::boxed::box_new_uninit>
1000067c8: aa0003f9    	mov	x25, x0
1000067cc: 910e83e1    	add	x1, sp, #0x3a0
1000067d0: 52802602    	mov	w2, #0x130              ; =304
1000067d4: 94031ef2    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
1000067d8: 52800014    	mov	w20, #0x0               ; =0
1000067dc: d0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
1000067e0: 910b8063    	add	x3, x3, #0x2e0
1000067e4: 91006300    	add	x0, x24, #0x18
1000067e8: f94007e1    	ldr	x1, [sp, #0x8]
1000067ec: aa1903e2    	mov	x2, x25
1000067f0: 9400c76f    	bl	0x1000385ac <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
1000067f4: 52800014    	mov	w20, #0x0               ; =0
1000067f8: 94000428    	bl	0x100007898 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
1000067fc: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
100006800: 3c8082e0    	stur	q0, [x23, #0x8]
100006804: 3c8182e1    	stur	q1, [x23, #0x18]
100006808: ad5c07e0    	ldp	q0, q1, [sp, #0x380]
10000680c: 3c8282e0    	stur	q0, [x23, #0x28]
100006810: 3c8382e1    	stur	q1, [x23, #0x38]
100006814: f90002ff    	str	xzr, [x23]
100006818: f9414be8    	ldr	x8, [sp, #0x290]
10000681c: b100051f    	cmn	x8, #0x1
100006820: 54000060    	b.eq	0x10000682c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8a4>
100006824: 910a43e0    	add	x0, sp, #0x290
100006828: 94000fc6    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
10000682c: 52800013    	mov	w19, #0x0               ; =0
100006830: 17fffed1    	b	0x100006374 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3ec>
100006834: 94031c2d    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
100006838: 3707cb20    	tbnz	w0, #0x0, 0x10000619c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x214>
10000683c: 52800028    	mov	w8, #0x1                ; =1
100006840: f9401be9    	ldr	x9, [sp, #0x30]
100006844: 39002128    	strb	w8, [x9, #0x8]
100006848: 17fffe55    	b	0x10000619c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x214>
10000684c: 94031c27    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
100006850: 3707c500    	tbnz	w0, #0x0, 0x1000060f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x168>
100006854: 52800028    	mov	w8, #0x1                ; =1
100006858: 39002268    	strb	w8, [x19, #0x8]
10000685c: 17fffe25    	b	0x1000060f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x168>
100006860: 900006a0    	adrp	x0, 0x1000da000 <GCC_except_table9+0x10>
100006864: 9115f000    	add	x0, x0, #0x57c
100006868: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
10000686c: 910ca042    	add	x2, x2, #0x328
100006870: 528003a1    	mov	w1, #0x1d               ; =29
100006874: 94031d65    	bl	0x1000cde08 <core::option::expect_failed>
100006878: 1400001e    	b	0x1000068f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
10000687c: d0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
100006880: 910ac000    	add	x0, x0, #0x2b0
100006884: 94031e2e    	bl	0x1000ce13c <core::panicking::panic_const::panic_const_rem_by_zero>
100006888: 1400001a    	b	0x1000068f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
10000688c: 5280003a    	mov	w26, #0x1               ; =1
100006890: 14000004    	b	0x1000068a0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x918>
100006894: 910b23e0    	add	x0, sp, #0x2c8
100006898: 94005c4f    	bl	0x10001d9d4 <core::ptr::drop_glue::<raster::types::error::Error>>
10000689c: 5280001a    	mov	w26, #0x0               ; =0
1000068a0: 900006a0    	adrp	x0, 0x1000da000 <GCC_except_table9+0x10>
1000068a4: 91166400    	add	x0, x0, #0x599
1000068a8: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
1000068ac: 910d0042    	add	x2, x2, #0x340
1000068b0: 528005a1    	mov	w1, #0x2d               ; =45
1000068b4: 94031d55    	bl	0x1000cde08 <core::option::expect_failed>
1000068b8: 1400000e    	b	0x1000068f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
1000068bc: f941d3e8    	ldr	x8, [sp, #0x3a0]
1000068c0: b100051f    	cmn	x8, #0x1
1000068c4: 54000080    	b.eq	0x1000068d4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x94c>
1000068c8: 52800033    	mov	w19, #0x1               ; =1
1000068cc: 910e83e0    	add	x0, sp, #0x3a0
1000068d0: 94005c41    	bl	0x10001d9d4 <core::ptr::drop_glue::<raster::types::error::Error>>
1000068d4: 52800033    	mov	w19, #0x1               ; =1
1000068d8: 900006a0    	adrp	x0, 0x1000da000 <GCC_except_table9+0x10>
1000068dc: 91154800    	add	x0, x0, #0x552
1000068e0: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
1000068e4: 910b2042    	add	x2, x2, #0x2c8
1000068e8: 52800541    	mov	w1, #0x2a               ; =42
1000068ec: 94031d47    	bl	0x1000cde08 <core::option::expect_failed>
1000068f0: d4200020    	brk	#0x1
1000068f4: aa0003f7    	mov	x23, x0
1000068f8: 52800013    	mov	w19, #0x0               ; =0
1000068fc: 14000056    	b	0x100006a54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xacc>
100006900: aa0003f7    	mov	x23, x0
100006904: 910e83e0    	add	x0, sp, #0x3a0
100006908: 94000bfb    	bl	0x1000098f4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
10000690c: 52800014    	mov	w20, #0x0               ; =0
100006910: 14000008    	b	0x100006930 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9a8>
100006914: 94031d6a    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
100006918: aa0003f7    	mov	x23, x0
10000691c: 3dc007e0    	ldr	q0, [sp, #0x10]
100006920: 3c8e8260    	stur	q0, [x19, #0xe8]
100006924: 52800034    	mov	w20, #0x1               ; =1
100006928: 14000002    	b	0x100006930 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9a8>
10000692c: aa0003f7    	mov	x23, x0
100006930: 910d83e0    	add	x0, sp, #0x360
100006934: 940009a0    	bl	0x100008fb4 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
100006938: 52800015    	mov	w21, #0x0               ; =0
10000693c: 1400001e    	b	0x1000069b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa2c>
100006940: 14000038    	b	0x100006a20 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa98>
100006944: aa0003f7    	mov	x23, x0
100006948: b100067f    	cmn	x19, #0x1
10000694c: 54000060    	b.eq	0x100006958 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9d0>
100006950: 910d83e0    	add	x0, sp, #0x360
100006954: 94000f7b    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100006958: 52800035    	mov	w21, #0x1               ; =1
10000695c: 14000015    	b	0x1000069b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa28>
100006960: aa0003f7    	mov	x23, x0
100006964: 52800035    	mov	w21, #0x1               ; =1
100006968: 52800034    	mov	w20, #0x1               ; =1
10000696c: 3700025a    	tbnz	w26, #0x0, 0x1000069b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa2c>
100006970: 1400002e    	b	0x100006a28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaa0>
100006974: 1400002b    	b	0x100006a20 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa98>
100006978: aa0003f7    	mov	x23, x0
10000697c: b10006bf    	cmn	x21, #0x1
100006980: 54000060    	b.eq	0x10000698c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa04>
100006984: 910d83e0    	add	x0, sp, #0x360
100006988: 94000f6e    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
10000698c: 52800035    	mov	w21, #0x1               ; =1
100006990: 52800034    	mov	w20, #0x1               ; =1
100006994: 37000113    	tbnz	w19, #0x0, 0x1000069b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa2c>
100006998: 14000024    	b	0x100006a28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaa0>
10000699c: aa0003f7    	mov	x23, x0
1000069a0: 52800013    	mov	w19, #0x0               ; =0
1000069a4: 14000025    	b	0x100006a38 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xab0>
1000069a8: aa1303f5    	mov	x21, x19
1000069ac: aa0003f7    	mov	x23, x0
1000069b0: 52800034    	mov	w20, #0x1               ; =1
1000069b4: f9414be8    	ldr	x8, [sp, #0x290]
1000069b8: b100051f    	cmn	x8, #0x1
1000069bc: 54000060    	b.eq	0x1000069c8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa40>
1000069c0: 910a43e0    	add	x0, sp, #0x290
1000069c4: 94000f5f    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
1000069c8: 37000314    	tbnz	w20, #0x0, 0x100006a28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaa0>
1000069cc: 14000019    	b	0x100006a30 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaa8>
1000069d0: aa0003f7    	mov	x23, x0
1000069d4: 9104c3e0    	add	x0, sp, #0x130
1000069d8: 94000f5a    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
1000069dc: 14000002    	b	0x1000069e4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa5c>
1000069e0: aa0003f7    	mov	x23, x0
1000069e4: 910383e0    	add	x0, sp, #0xe0
1000069e8: 940006ac    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
1000069ec: 14000009    	b	0x100006a10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa88>
1000069f0: aa0003f7    	mov	x23, x0
1000069f4: 910403e0    	add	x0, sp, #0x100
1000069f8: 94000f52    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
1000069fc: 14000005    	b	0x100006a10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa88>
100006a00: aa0003f7    	mov	x23, x0
100006a04: 37000373    	tbnz	w19, #0x0, 0x100006a70 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xae8>
100006a08: 14000022    	b	0x100006a90 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xb08>
100006a0c: aa0003f7    	mov	x23, x0
100006a10: 52800033    	mov	w19, #0x1               ; =1
100006a14: 14000009    	b	0x100006a38 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xab0>
100006a18: aa0003f7    	mov	x23, x0
100006a1c: 1400000e    	b	0x100006a54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xacc>
100006a20: aa0003f7    	mov	x23, x0
100006a24: 52800035    	mov	w21, #0x1               ; =1
100006a28: 910583e0    	add	x0, sp, #0x160
100006a2c: 94000bb2    	bl	0x1000098f4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100006a30: 52800013    	mov	w19, #0x0               ; =0
100006a34: 36000115    	tbz	w21, #0x0, 0x100006a54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xacc>
100006a38: f9403fe8    	ldr	x8, [sp, #0x78]
100006a3c: f9400109    	ldr	x9, [x8]
100006a40: f1000529    	subs	x9, x9, #0x1
100006a44: f9000109    	str	x9, [x8]
100006a48: 54000061    	b.ne	0x100006a54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xacc>
100006a4c: 9101e3e0    	add	x0, sp, #0x78
100006a50: 9401d722    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100006a54: f9401be0    	ldr	x0, [sp, #0x30]
100006a58: b9402fe1    	ldr	w1, [sp, #0x2c]
100006a5c: 94000c83    	bl	0x100009c68 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100006a60: 37000093    	tbnz	w19, #0x0, 0x100006a70 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xae8>
100006a64: 1400000b    	b	0x100006a90 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xb08>
100006a68: 94031d15    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
100006a6c: aa0003f7    	mov	x23, x0
100006a70: b94047e8    	ldr	w8, [sp, #0x44]
100006a74: 340000e8    	cbz	w8, 0x100006a90 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xb08>
100006a78: f94027e8    	ldr	x8, [sp, #0x48]
100006a7c: b40000a8    	cbz	x8, 0x100006a90 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xb08>
100006a80: f9401fe0    	ldr	x0, [sp, #0x38]
100006a84: f94027e1    	ldr	x1, [sp, #0x48]
100006a88: 52800022    	mov	w2, #0x1                ; =1
100006a8c: 94012268    	bl	0x10004f42c <__rustc::__rust_dealloc>
100006a90: aa1703e0    	mov	x0, x23
100006a94: 94031deb    	bl	0x1000ce240 <dyld_stub_binder+0x1000ce240>

