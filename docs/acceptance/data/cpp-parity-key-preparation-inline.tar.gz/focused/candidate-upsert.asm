0000000100005e3c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>>:
100005e3c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100005e40: a90167fa    	stp	x26, x25, [sp, #0x10]
100005e44: a9025ff8    	stp	x24, x23, [sp, #0x20]
100005e48: a90357f6    	stp	x22, x21, [sp, #0x30]
100005e4c: a9044ff4    	stp	x20, x19, [sp, #0x40]
100005e50: a9057bfd    	stp	x29, x30, [sp, #0x50]
100005e54: 910143fd    	add	x29, sp, #0x50
100005e58: d11283ff    	sub	sp, sp, #0x4a0
100005e5c: f90003ff    	str	xzr, [sp]
100005e60: aa0403f7    	mov	x23, x4
100005e64: aa0303f8    	mov	x24, x3
100005e68: aa0203fa    	mov	x26, x2
100005e6c: aa0103f6    	mov	x22, x1
100005e70: aa0803f5    	mov	x21, x8
100005e74: a9029be5    	stp	x5, x6, [sp, #0x28]
100005e78: f940001c    	ldr	x28, [x0]
100005e7c: 910d83f9    	add	x25, sp, #0x360
100005e80: 910d83e8    	add	x8, sp, #0x360
100005e84: 91020380    	add	x0, x28, #0x80
100005e88: 94001d55    	bl	0x10000d3dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
100005e8c: f941b3e8    	ldr	x8, [sp, #0x360]
100005e90: b100051f    	cmn	x8, #0x1
100005e94: 540001a0    	b.eq	0x100005ec8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8c>
100005e98: 394da3e9    	ldrb	w9, [sp, #0x368]
100005e9c: 3cc09320    	ldur	q0, [x25, #0x9]
100005ea0: 3c8112a0    	stur	q0, [x21, #0x11]
100005ea4: 3cc19320    	ldur	q0, [x25, #0x19]
100005ea8: 3c8212a0    	stur	q0, [x21, #0x21]
100005eac: f941c7ea    	ldr	x10, [sp, #0x388]
100005eb0: 390042a9    	strb	w9, [x21, #0x10]
100005eb4: a90362aa    	stp	x10, x24, [x21, #0x30]
100005eb8: f90022b7    	str	x23, [x21, #0x40]
100005ebc: 52800029    	mov	w9, #0x1                ; =1
100005ec0: a90022a9    	stp	x9, x8, [x21]
100005ec4: 14000010    	b	0x100005f04 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xc8>
100005ec8: 3943a2c8    	ldrb	w8, [x22, #0xe8]
100005ecc: 370000a8    	tbnz	w8, #0x0, 0x100005ee0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa4>
100005ed0: 52838508    	mov	w8, #0x1c28             ; =7208
100005ed4: 8b080388    	add	x8, x28, x8
100005ed8: 08dffd08    	ldarb	w8, [x8]
100005edc: 34000248    	cbz	w8, 0x100005f24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xe8>
100005ee0: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005ee4: 91041d08    	add	x8, x8, #0x107
100005ee8: 528003e9    	mov	w9, #0x1f               ; =31
100005eec: a90126a8    	stp	x8, x9, [x21, #0x10]
100005ef0: f90016bf    	str	xzr, [x21, #0x28]
100005ef4: a903deb8    	stp	x24, x23, [x21, #0x38]
100005ef8: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005efc: 3dc01900    	ldr	q0, [x8, #0x60]
100005f00: 3d8002a0    	str	q0, [x21]
100005f04: 911283ff    	add	sp, sp, #0x4a0
100005f08: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100005f0c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100005f10: a94357f6    	ldp	x22, x21, [sp, #0x30]
100005f14: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100005f18: a94167fa    	ldp	x26, x25, [sp, #0x10]
100005f1c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100005f20: d65f03c0    	ret
100005f24: f94002c8    	ldr	x8, [x22]
100005f28: f100051f    	cmp	x8, #0x1
100005f2c: 54000101    	b.ne	0x100005f4c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x110>
100005f30: f94006c8    	ldr	x8, [x22, #0x8]
100005f34: eb08035f    	cmp	x26, x8
100005f38: 540000a8    	b.hi	0x100005f4c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x110>
100005f3c: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005f40: 91038108    	add	x8, x8, #0xe0
100005f44: 528004e9    	mov	w9, #0x27               ; =39
100005f48: 17ffffe9    	b	0x100005eec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xb0>
100005f4c: f9407388    	ldr	x8, [x28, #0xe0]
100005f50: b4003ee8    	cbz	x8, 0x10000672c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8f0>
100005f54: 92401f09    	and	x9, x24, #0xff
100005f58: d28464aa    	mov	x10, #0x2325            ; =8997
100005f5c: f2b0844a    	movk	x10, #0x8422, lsl #16
100005f60: f2d39c8a    	movk	x10, #0x9ce4, lsl #32
100005f64: f2f97e4a    	movk	x10, #0xcbf2, lsl #48
100005f68: ca0a0129    	eor	x9, x9, x10
100005f6c: d280366a    	mov	x10, #0x1b3             ; =435
100005f70: f2c0200a    	movk	x10, #0x100, lsl #32
100005f74: 9b0a7d29    	mul	x9, x9, x10
100005f78: d3483f0b    	ubfx	x11, x24, #8, #8
100005f7c: ca0b0129    	eor	x9, x9, x11
100005f80: 9b0a7d29    	mul	x9, x9, x10
100005f84: d3505f0b    	ubfx	x11, x24, #16, #8
100005f88: ca0b0129    	eor	x9, x9, x11
100005f8c: 9b0a7d29    	mul	x9, x9, x10
100005f90: 53187f0b    	lsr	w11, w24, #24
100005f94: ca0b0129    	eor	x9, x9, x11
100005f98: 9b0a7d29    	mul	x9, x9, x10
100005f9c: d3609f0b    	ubfx	x11, x24, #32, #8
100005fa0: ca0b0129    	eor	x9, x9, x11
100005fa4: 9b0a7d29    	mul	x9, x9, x10
100005fa8: d368bf0b    	ubfx	x11, x24, #40, #8
100005fac: ca0b0129    	eor	x9, x9, x11
100005fb0: 9b0a7d29    	mul	x9, x9, x10
100005fb4: d370df0b    	ubfx	x11, x24, #48, #8
100005fb8: ca0b0129    	eor	x9, x9, x11
100005fbc: 9b0a7d29    	mul	x9, x9, x10
100005fc0: ca58e129    	eor	x9, x9, x24, lsr #56
100005fc4: 9b0a7d3b    	mul	x27, x9, x10
100005fc8: f9406f89    	ldr	x9, [x28, #0xd8]
100005fcc: 9ac80b6a    	udiv	x10, x27, x8
100005fd0: 9b08ed48    	msub	x8, x10, x8, x27
100005fd4: 8b081121    	add	x1, x9, x8, lsl #4
100005fd8: 910d83e0    	add	x0, sp, #0x360
100005fdc: 94003bc2    	bl	0x100014ee4 <raster::engine::operation_gate::try_lock>
100005fe0: b94363e8    	ldr	w8, [sp, #0x360]
100005fe4: 36000248    	tbz	w8, #0x0, 0x10000602c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x1f0>
100005fe8: a903deb8    	stp	x24, x23, [x21, #0x38]
100005fec: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005ff0: 3dc01500    	ldr	q0, [x8, #0x50]
100005ff4: 3d8002a0    	str	q0, [x21]
100005ff8: 394dc3e8    	ldrb	w8, [sp, #0x370]
100005ffc: 7100091f    	cmp	w8, #0x2
100006000: 54fff820    	b.eq	0x100005f04 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xc8>
100006004: f941b7f3    	ldr	x19, [sp, #0x368]
100006008: 370000c8    	tbnz	w8, #0x0, 0x100006020 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x1e4>
10000600c: d0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100006010: 91394108    	add	x8, x8, #0xe50
100006014: f9400108    	ldr	x8, [x8]
100006018: f240f91f    	tst	x8, #0x7fffffffffffffff
10000601c: 54003701    	b.ne	0x1000066fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8c0>
100006020: f9400260    	ldr	x0, [x19]
100006024: 9402787a    	bl	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100006028: 17ffffb7    	b	0x100005f04 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xc8>
10000602c: f941b7f3    	ldr	x19, [sp, #0x368]
100006030: 394dc3f4    	ldrb	w20, [sp, #0x370]
100006034: aa1603e0    	mov	x0, x22
100006038: 94015a8d    	bl	0x10005ca6c <<raster::engine::pending::SessionRuntime>::pending>
10000603c: f940fb88    	ldr	x8, [x28, #0x1f0]
100006040: eb08001f    	cmp	x0, x8
100006044: 54000222    	b.hs	0x100006088 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x24c>
100006048: f940ff81    	ldr	x1, [x28, #0x1f8]
10000604c: 910d83e8    	add	x8, sp, #0x360
100006050: aa1603e0    	mov	x0, x22
100006054: 94015923    	bl	0x10005c4e0 <<raster::engine::pending::SessionRuntime>::reserve_result>
100006058: f941b3e8    	ldr	x8, [sp, #0x360]
10000605c: b100051f    	cmn	x8, #0x1
100006060: 540003a0    	b.eq	0x1000060d4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x298>
100006064: ad400720    	ldp	q0, q1, [x25]
100006068: 3c8082a0    	stur	q0, [x21, #0x8]
10000606c: 3c8182a1    	stur	q1, [x21, #0x18]
100006070: 3dc00b20    	ldr	q0, [x25, #0x20]
100006074: 3c8282a0    	stur	q0, [x21, #0x28]
100006078: a903deb8    	stp	x24, x23, [x21, #0x38]
10000607c: 52800028    	mov	w8, #0x1                ; =1
100006080: f90002a8    	str	x8, [x21]
100006084: 14000005    	b	0x100006098 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x25c>
100006088: a903deb8    	stp	x24, x23, [x21, #0x38]
10000608c: 900006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100006090: 3dc01500    	ldr	q0, [x8, #0x50]
100006094: 3d8002a0    	str	q0, [x21]
100006098: 370000d4    	tbnz	w20, #0x0, 0x1000060b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x274>
10000609c: d0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
1000060a0: 91394108    	add	x8, x8, #0xe50
1000060a4: f9400108    	ldr	x8, [x8]
1000060a8: f240f91f    	tst	x8, #0x7fffffffffffffff
1000060ac: 540031e1    	b.ne	0x1000066e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8ac>
1000060b0: f9400260    	ldr	x0, [x19]
1000060b4: 911283ff    	add	sp, sp, #0x4a0
1000060b8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000060bc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000060c0: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000060c4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000060c8: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000060cc: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000060d0: 1402784f    	b	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1000060d4: f941b7e8    	ldr	x8, [sp, #0x368]
1000060d8: f9001fe8    	str	x8, [sp, #0x38]
1000060dc: 910d83e0    	add	x0, sp, #0x360
1000060e0: 91020381    	add	x1, x28, #0x80
1000060e4: aa1603e2    	mov	x2, x22
1000060e8: 940016ab    	bl	0x10000bb94 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
1000060ec: 394e47e8    	ldrb	w8, [sp, #0x391]
1000060f0: 7100091f    	cmp	w8, #0x2
1000060f4: 540000c1    	b.ne	0x10000610c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x2d0>
1000060f8: ad400720    	ldp	q0, q1, [x25]
1000060fc: 3c8082a0    	stur	q0, [x21, #0x8]
100006100: 3c8182a1    	stur	q1, [x21, #0x18]
100006104: 3dc00b20    	ldr	q0, [x25, #0x20]
100006108: 14000023    	b	0x100006194 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x358>
10000610c: ad408321    	ldp	q1, q0, [x25, #0x10]
100006110: ad0283e1    	stp	q1, q0, [sp, #0x50]
100006114: 3dc00320    	ldr	q0, [x25]
100006118: 3d8013e0    	str	q0, [sp, #0x40]
10000611c: f941cbe8    	ldr	x8, [sp, #0x390]
100006120: f9003be8    	str	x8, [sp, #0x70]
100006124: ad0407e0    	stp	q0, q1, [sp, #0x80]
100006128: a94623e9    	ldp	x9, x8, [sp, #0x60]
10000612c: f90013e9    	str	x9, [sp, #0x20]
100006130: f9000be8    	str	x8, [sp, #0x10]
100006134: f9400ac2    	ldr	x2, [x22, #0x10]
100006138: 910303e8    	add	x8, sp, #0xc0
10000613c: 910d0380    	add	x0, x28, #0x340
100006140: aa1b03e1    	mov	x1, x27
100006144: 94016266    	bl	0x10005eadc <<raster::engine::version_permit::VersionPermits>::reserve_initial>
100006148: 910283e9    	add	x9, sp, #0xa0
10000614c: f94063e8    	ldr	x8, [sp, #0xc0]
100006150: b100051f    	cmn	x8, #0x1
100006154: 540003e0    	b.eq	0x1000061d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x394>
100006158: f9418789    	ldr	x9, [x28, #0x308]
10000615c: 910d83e8    	add	x8, sp, #0x360
100006160: 91004120    	add	x0, x9, #0x10
100006164: 910103e1    	add	x1, sp, #0x40
100006168: 94022e9c    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
10000616c: f941b3e8    	ldr	x8, [sp, #0x360]
100006170: b100051f    	cmn	x8, #0x1
100006174: 54000060    	b.eq	0x100006180 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x344>
100006178: 910d83e0    	add	x0, sp, #0x360
10000617c: 940010e1    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006180: 910283e8    	add	x8, sp, #0xa0
100006184: ad410500    	ldp	q0, q1, [x8, #0x20]
100006188: 3c8082a0    	stur	q0, [x21, #0x8]
10000618c: 3c8182a1    	stur	q1, [x21, #0x18]
100006190: 3dc01100    	ldr	q0, [x8, #0x40]
100006194: 3c8282a0    	stur	q0, [x21, #0x28]
100006198: a903deb8    	stp	x24, x23, [x21, #0x38]
10000619c: 52800028    	mov	w8, #0x1                ; =1
1000061a0: f90002a8    	str	x8, [x21]
1000061a4: f9401fe8    	ldr	x8, [sp, #0x38]
1000061a8: f9400109    	ldr	x9, [x8]
1000061ac: f1000529    	subs	x9, x9, #0x1
1000061b0: f9000109    	str	x9, [x8]
1000061b4: 54000061    	b.ne	0x1000061c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x384>
1000061b8: 9100e3e0    	add	x0, sp, #0x38
1000061bc: 9401cb45    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
1000061c0: aa1303e0    	mov	x0, x19
1000061c4: aa1403e1    	mov	x1, x20
1000061c8: 94000e18    	bl	0x100009a28 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
1000061cc: 17ffff4e    	b	0x100005f04 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xc8>
1000061d0: 3cc28120    	ldur	q0, [x9, #0x28]
1000061d4: 3d802be0    	str	q0, [sp, #0xa0]
1000061d8: 3cc38120    	ldur	q0, [x9, #0x38]
1000061dc: 3d800520    	str	q0, [x9, #0x10]
1000061e0: 9103c3e0    	add	x0, sp, #0xf0
1000061e4: 91020381    	add	x1, x28, #0x80
1000061e8: aa1603e2    	mov	x2, x22
1000061ec: aa1a03e3    	mov	x3, x26
1000061f0: 940016b2    	bl	0x10000bcb8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
1000061f4: f9407be8    	ldr	x8, [sp, #0xf0]
1000061f8: b100051f    	cmn	x8, #0x1
1000061fc: 540002e0    	b.eq	0x100006258 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x41c>
100006200: f9418789    	ldr	x9, [x28, #0x308]
100006204: 910d83e8    	add	x8, sp, #0x360
100006208: 91004120    	add	x0, x9, #0x10
10000620c: 910103e1    	add	x1, sp, #0x40
100006210: 94022e72    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
100006214: f941b3e8    	ldr	x8, [sp, #0x360]
100006218: b100051f    	cmn	x8, #0x1
10000621c: 54000060    	b.eq	0x100006228 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x3ec>
100006220: 910d83e0    	add	x0, sp, #0x360
100006224: 940010b7    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006228: 910283e8    	add	x8, sp, #0xa0
10000622c: ad428500    	ldp	q0, q1, [x8, #0x50]
100006230: 3c8082a0    	stur	q0, [x21, #0x8]
100006234: 3c8182a1    	stur	q1, [x21, #0x18]
100006238: 3dc01d00    	ldr	q0, [x8, #0x70]
10000623c: 3c8282a0    	stur	q0, [x21, #0x28]
100006240: a903deb8    	stp	x24, x23, [x21, #0x38]
100006244: 52800028    	mov	w8, #0x1                ; =1
100006248: f90002a8    	str	x8, [x21]
10000624c: 910283e0    	add	x0, sp, #0xa0
100006250: 9400082c    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100006254: 17ffffd4    	b	0x1000061a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x368>
100006258: 910d83e8    	add	x8, sp, #0x360
10000625c: 910342c0    	add	x0, x22, #0xd0
100006260: 52800021    	mov	w1, #0x1                ; =1
100006264: 94023529    	bl	0x100093708 <<raster::engine::metrics::Tracker>::accept>
100006268: 52800028    	mov	w8, #0x1                ; =1
10000626c: f8280388    	ldadd	x8, x8, [x28]
100006270: b7f829a8    	tbnz	x8, #0x3f, 0x1000067a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
100006274: 910483ea    	add	x10, sp, #0x120
100006278: 910483e8    	add	x8, sp, #0x120
10000627c: ad4207e0    	ldp	q0, q1, [sp, #0x40]
100006280: ad050540    	stp	q0, q1, [x10, #0xa0]
100006284: 3dc01be0    	ldr	q0, [sp, #0x60]
100006288: 3d803140    	str	q0, [x10, #0xc0]
10000628c: 91042108    	add	x8, x8, #0x108
100006290: 3dc02be0    	ldr	q0, [sp, #0xa0]
100006294: 910283e9    	add	x9, sp, #0xa0
100006298: 3dc00521    	ldr	q1, [x9, #0x10]
10000629c: ad000500    	stp	q0, q1, [x8]
1000062a0: ad400720    	ldp	q0, q1, [x25]
1000062a4: 3c858140    	stur	q0, [x10, #0x58]
1000062a8: d370ff08    	lsr	x8, x24, #48
1000062ac: 52810009    	mov	w9, #0x800              ; =2048
1000062b0: 790343e9    	strh	w9, [sp, #0x1a0]
1000062b4: b8082158    	stur	w24, [x10, #0x82]
1000062b8: d360ff09    	lsr	x9, x24, #32
1000062bc: 79034fe9    	strh	w9, [sp, #0x1a6]
1000062c0: a91affe8    	stp	x8, xzr, [sp, #0x1a8]
1000062c4: f9403be8    	ldr	x8, [sp, #0x70]
1000062c8: f9400ac9    	ldr	x9, [x22, #0x10]
1000062cc: a91f73e8    	stp	x8, x28, [sp, #0x1f0]
1000062d0: 3c868141    	stur	q1, [x10, #0x68]
1000062d4: f941c3e8    	ldr	x8, [sp, #0x380]
1000062d8: f900cfe8    	str	x8, [sp, #0x198]
1000062dc: 5280002a    	mov	w10, #0x1               ; =1
1000062e0: 52800028    	mov	w8, #0x1                ; =1
1000062e4: f90007e8    	str	x8, [sp, #0x8]
1000062e8: a91263ea    	stp	x10, x24, [sp, #0x120]
1000062ec: 52800048    	mov	w8, #0x2                ; =2
1000062f0: a91323f7    	stp	x23, x8, [sp, #0x130]
1000062f4: 390923ff    	strb	wzr, [sp, #0x248]
1000062f8: f90103fb    	str	x27, [sp, #0x200]
1000062fc: f90107ff    	str	xzr, [sp, #0x208]
100006300: f9010ffa    	str	x26, [sp, #0x218]
100006304: f90113e9    	str	x9, [sp, #0x220]
100006308: 92800008    	mov	x8, #-0x1               ; =-1
10000630c: f9012be8    	str	x8, [sp, #0x250]
100006310: 910483e0    	add	x0, sp, #0x120
100006314: 9100a3e1    	add	x1, sp, #0x28
100006318: 910943e2    	add	x2, sp, #0x250
10000631c: 94005d80    	bl	0x10001d91c <<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked>
100006320: 910943f8    	add	x24, sp, #0x250
100006324: b40007c0    	cbz	x0, 0x10000641c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x5e0>
100006328: f100041f    	cmp	x0, #0x1
10000632c: 540009a1    	b.ne	0x100006460 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x624>
100006330: 52800028    	mov	w8, #0x1                ; =1
100006334: f90007e8    	str	x8, [sp, #0x8]
100006338: f94113e2    	ldr	x2, [sp, #0x220]
10000633c: 910b03e8    	add	x8, sp, #0x2c0
100006340: 910d0380    	add	x0, x28, #0x340
100006344: 910483e9    	add	x9, sp, #0x120
100006348: 91042123    	add	x3, x9, #0x108
10000634c: aa1b03e1    	mov	x1, x27
100006350: 9401635d    	bl	0x10005f0c4 <<raster::engine::version_permit::VersionPermits>::activate>
100006354: f94163e8    	ldr	x8, [sp, #0x2c0]
100006358: b100051f    	cmn	x8, #0x1
10000635c: 54000181    	b.ne	0x10000638c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x550>
100006360: f9418789    	ldr	x9, [x28, #0x308]
100006364: 52800028    	mov	w8, #0x1                ; =1
100006368: f90007e8    	str	x8, [sp, #0x8]
10000636c: 910b03e8    	add	x8, sp, #0x2c0
100006370: 91004120    	add	x0, x9, #0x10
100006374: 910483e9    	add	x9, sp, #0x120
100006378: 91028121    	add	x1, x9, #0xa0
10000637c: 94022e86    	bl	0x100091d94 <<raster::engine::io_hub::CompletionHub>::activate_operation>
100006380: f94163e8    	ldr	x8, [sp, #0x2c0]
100006384: b100051f    	cmn	x8, #0x1
100006388: 540013a0    	b.eq	0x1000065fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x7c0>
10000638c: ad438700    	ldp	q0, q1, [x24, #0x70]
100006390: ad000720    	stp	q0, q1, [x25]
100006394: 3dc02700    	ldr	q0, [x24, #0x90]
100006398: 3d800b20    	str	q0, [x25, #0x20]
10000639c: 394923e8    	ldrb	w8, [sp, #0x248]
1000063a0: 390e43e8    	strb	w8, [sp, #0x390]
1000063a4: b94123e8    	ldr	w8, [sp, #0x120]
1000063a8: f90093ff    	str	xzr, [sp, #0x120]
1000063ac: 36001de8    	tbz	w8, #0x0, 0x100006768 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x92c>
1000063b0: 52800048    	mov	w8, #0x2                ; =2
1000063b4: f9009fe8    	str	x8, [sp, #0x138]
1000063b8: f941b3f7    	ldr	x23, [sp, #0x360]
1000063bc: 3cc08320    	ldur	q0, [x25, #0x8]
1000063c0: 3cc18321    	ldur	q1, [x25, #0x18]
1000063c4: ad050700    	stp	q0, q1, [x24, #0xa0]
1000063c8: 3cc28320    	ldur	q0, [x25, #0x28]
1000063cc: 3d803300    	str	q0, [x24, #0xc0]
1000063d0: b1000aff    	cmn	x23, #0x2
1000063d4: 54001d80    	b.eq	0x100006784 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x948>
1000063d8: f90193f7    	str	x23, [sp, #0x320]
1000063dc: ad450700    	ldp	q0, q1, [x24, #0xa0]
1000063e0: 3c8d8300    	stur	q0, [x24, #0xd8]
1000063e4: 3c8e8301    	stur	q1, [x24, #0xe8]
1000063e8: 3dc03300    	ldr	q0, [x24, #0xc0]
1000063ec: 3c8f8300    	stur	q0, [x24, #0xf8]
1000063f0: 3947c3e8    	ldrb	w8, [sp, #0x1f0]
1000063f4: 7100051f    	cmp	w8, #0x1
1000063f8: 54000cc1    	b.ne	0x100006590 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x754>
1000063fc: 910483e8    	add	x8, sp, #0x120
100006400: ad450500    	ldp	q0, q1, [x8, #0xa0]
100006404: 3c808320    	stur	q0, [x25, #0x8]
100006408: 3c818321    	stur	q1, [x25, #0x18]
10000640c: 3ccc0100    	ldur	q0, [x8, #0xc0]
100006410: 3c828320    	stur	q0, [x25, #0x28]
100006414: 52800028    	mov	w8, #0x1                ; =1
100006418: 1400005f    	b	0x100006594 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x758>
10000641c: 390a43ff    	strb	wzr, [sp, #0x290]
100006420: f9014fe1    	str	x1, [sp, #0x298]
100006424: f94093e8    	ldr	x8, [sp, #0x120]
100006428: f90093ff    	str	xzr, [sp, #0x120]
10000642c: f100051f    	cmp	x8, #0x1
100006430: 54001841    	b.ne	0x100006738 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8fc>
100006434: 910a23e8    	add	x8, sp, #0x288
100006438: 52800049    	mov	w9, #0x2                ; =2
10000643c: f9009fe9    	str	x9, [sp, #0x138]
100006440: 3cc08100    	ldur	q0, [x8, #0x8]
100006444: 3cc18101    	ldur	q1, [x8, #0x18]
100006448: ad000720    	stp	q0, q1, [x25]
10000644c: 3cc28100    	ldur	q0, [x8, #0x28]
100006450: 3d800b20    	str	q0, [x25, #0x20]
100006454: 52800037    	mov	w23, #0x1               ; =1
100006458: 9280001a    	mov	x26, #-0x1              ; =-1
10000645c: 14000019    	b	0x1000064c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x684>
100006460: f9412bfa    	ldr	x26, [sp, #0x250]
100006464: b100075f    	cmn	x26, #0x1
100006468: 54001540    	b.eq	0x100006710 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x8d4>
10000646c: 3cc08300    	ldur	q0, [x24, #0x8]
100006470: 3cc18301    	ldur	q1, [x24, #0x18]
100006474: ad020700    	stp	q0, q1, [x24, #0x40]
100006478: 3cc28300    	ldur	q0, [x24, #0x28]
10000647c: 3c860300    	stur	q0, [x24, #0x60]
100006480: f90147fa    	str	x26, [sp, #0x288]
100006484: b94123e8    	ldr	w8, [sp, #0x120]
100006488: f90093ff    	str	xzr, [sp, #0x120]
10000648c: 360015a8    	tbz	w8, #0x0, 0x100006740 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x904>
100006490: 52800017    	mov	w23, #0x0               ; =0
100006494: 5280001b    	mov	w27, #0x0               ; =0
100006498: 910943e8    	add	x8, sp, #0x250
10000649c: 52800049    	mov	w9, #0x2                ; =2
1000064a0: f9009fe9    	str	x9, [sp, #0x138]
1000064a4: 3cc08100    	ldur	q0, [x8, #0x8]
1000064a8: 3cc18101    	ldur	q1, [x8, #0x18]
1000064ac: ad000720    	stp	q0, q1, [x25]
1000064b0: 3cc28100    	ldur	q0, [x8, #0x28]
1000064b4: 3d800b20    	str	q0, [x25, #0x20]
1000064b8: b1000b5f    	cmn	x26, #0x2
1000064bc: 54001480    	b.eq	0x10000674c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x910>
1000064c0: f90193fa    	str	x26, [sp, #0x320]
1000064c4: ad400720    	ldp	q0, q1, [x25]
1000064c8: 3c8d8300    	stur	q0, [x24, #0xd8]
1000064cc: 3c8e8301    	stur	q1, [x24, #0xe8]
1000064d0: 3dc00b20    	ldr	q0, [x25, #0x20]
1000064d4: 3c8f8300    	stur	q0, [x24, #0xf8]
1000064d8: 3947c3e8    	ldrb	w8, [sp, #0x1f0]
1000064dc: 7100051f    	cmp	w8, #0x1
1000064e0: 54000121    	b.ne	0x100006504 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x6c8>
1000064e4: 910483fb    	add	x27, sp, #0x120
1000064e8: ad450760    	ldp	q0, q1, [x27, #0xa0]
1000064ec: 3c808320    	stur	q0, [x25, #0x8]
1000064f0: 3c818321    	stur	q1, [x25, #0x18]
1000064f4: 3ccc0360    	ldur	q0, [x27, #0xc0]
1000064f8: 3c828320    	stur	q0, [x25, #0x28]
1000064fc: 52800028    	mov	w8, #0x1                ; =1
100006500: 14000003    	b	0x10000650c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x6d0>
100006504: d2800008    	mov	x8, #0x0                ; =0
100006508: 910483fb    	add	x27, sp, #0x120
10000650c: f901b3e8    	str	x8, [sp, #0x360]
100006510: 91020380    	add	x0, x28, #0x80
100006514: 91016361    	add	x1, x27, #0x58
100006518: 910d83e2    	add	x2, sp, #0x360
10000651c: 910c83e3    	add	x3, sp, #0x320
100006520: 940001fe    	bl	0x100006d18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::record_ready::<u64>>
100006524: 91020380    	add	x0, x28, #0x80
100006528: 91028362    	add	x2, x27, #0xa0
10000652c: aa1603e1    	mov	x1, x22
100006530: 94001568    	bl	0x10000bad0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
100006534: ad468700    	ldp	q0, q1, [x24, #0xd0]
100006538: ad0086a0    	stp	q0, q1, [x21, #0x10]
10000653c: 3dc03f00    	ldr	q0, [x24, #0xf0]
100006540: 3d800ea0    	str	q0, [x21, #0x30]
100006544: f941abe8    	ldr	x8, [sp, #0x350]
100006548: f90022a8    	str	x8, [x21, #0x40]
10000654c: a9007ebf    	stp	xzr, xzr, [x21]
100006550: f9412be8    	ldr	x8, [sp, #0x250]
100006554: b100051f    	cmn	x8, #0x1
100006558: 1a9703e8    	csel	w8, wzr, w23, eq
10000655c: 36000068    	tbz	w8, #0x0, 0x100006568 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x72c>
100006560: 910943e0    	add	x0, sp, #0x250
100006564: 94000fe7    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006568: 910483e0    	add	x0, sp, #0x120
10000656c: 94000c52    	bl	0x1000096b4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100006570: f9401fe8    	ldr	x8, [sp, #0x38]
100006574: f9400109    	ldr	x9, [x8]
100006578: f1000529    	subs	x9, x9, #0x1
10000657c: f9000109    	str	x9, [x8]
100006580: 54ffe201    	b.ne	0x1000061c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x384>
100006584: 9100e3e0    	add	x0, sp, #0x38
100006588: 9401ca52    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
10000658c: 17ffff0d    	b	0x1000061c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x384>
100006590: d2800008    	mov	x8, #0x0                ; =0
100006594: f901b3e8    	str	x8, [sp, #0x360]
100006598: 91020380    	add	x0, x28, #0x80
10000659c: 910483f9    	add	x25, sp, #0x120
1000065a0: 91016321    	add	x1, x25, #0x58
1000065a4: 910d83e2    	add	x2, sp, #0x360
1000065a8: 910c83e3    	add	x3, sp, #0x320
1000065ac: 940001db    	bl	0x100006d18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::record_ready::<u64>>
1000065b0: 91020380    	add	x0, x28, #0x80
1000065b4: 91028322    	add	x2, x25, #0xa0
1000065b8: aa1603e1    	mov	x1, x22
1000065bc: 94001545    	bl	0x10000bad0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
1000065c0: ad468700    	ldp	q0, q1, [x24, #0xd0]
1000065c4: ad0086a0    	stp	q0, q1, [x21, #0x10]
1000065c8: 3dc03f00    	ldr	q0, [x24, #0xf0]
1000065cc: 3d800ea0    	str	q0, [x21, #0x30]
1000065d0: f941abe8    	ldr	x8, [sp, #0x350]
1000065d4: f90022a8    	str	x8, [x21, #0x40]
1000065d8: a9007ebf    	stp	xzr, xzr, [x21]
1000065dc: f9412be8    	ldr	x8, [sp, #0x250]
1000065e0: b100051f    	cmn	x8, #0x1
1000065e4: 54000060    	b.eq	0x1000065f0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x7b4>
1000065e8: 910943e0    	add	x0, sp, #0x250
1000065ec: 94000fc5    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000065f0: 910483e0    	add	x0, sp, #0x120
1000065f4: 94000c30    	bl	0x1000096b4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
1000065f8: 17fffeeb    	b	0x1000061a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x368>
1000065fc: f9401fe1    	ldr	x1, [sp, #0x38]
100006600: ad4407e0    	ldp	q0, q1, [sp, #0x80]
100006604: ad068700    	stp	q0, q1, [x24, #0xd0]
100006608: f94013e8    	ldr	x8, [sp, #0x20]
10000660c: f901a3e8    	str	x8, [sp, #0x340]
100006610: f9400be8    	ldr	x8, [sp, #0x10]
100006614: f901a7e8    	str	x8, [sp, #0x348]
100006618: f90007ff    	str	xzr, [sp, #0x8]
10000661c: 910d83e8    	add	x8, sp, #0x360
100006620: 910c83e0    	add	x0, sp, #0x320
100006624: 940087b2    	bl	0x1000284ec <<raster::api::completion::Ticket<u64>>::pair_bounded>
100006628: ad400720    	ldp	q0, q1, [x25]
10000662c: ad068700    	stp	q0, q1, [x24, #0xd0]
100006630: ad410720    	ldp	q0, q1, [x25, #0x20]
100006634: ad078700    	stp	q0, q1, [x24, #0xf0]
100006638: 3dc01320    	ldr	q0, [x25, #0x40]
10000663c: 3d8007e0    	str	q0, [sp, #0x10]
100006640: 910483e8    	add	x8, sp, #0x120
100006644: 9103a100    	add	x0, x8, #0xe8
100006648: 9400047f    	bl	0x100007844 <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
10000664c: 910483e8    	add	x8, sp, #0x120
100006650: 3dc007e0    	ldr	q0, [sp, #0x10]
100006654: 3c8e8100    	stur	q0, [x8, #0xe8]
100006658: 52800039    	mov	w25, #0x1               ; =1
10000665c: 910483e8    	add	x8, sp, #0x120
100006660: 91016100    	add	x0, x8, #0x58
100006664: 94023564    	bl	0x100093bf4 <<raster::engine::metrics::Monitor>::pending>
100006668: 910d83e0    	add	x0, sp, #0x360
10000666c: 910483e1    	add	x1, sp, #0x120
100006670: 52802602    	mov	w2, #0x130              ; =304
100006674: 94031e6f    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
100006678: 52802600    	mov	w0, #0x130              ; =304
10000667c: 94003a0b    	bl	0x100014ea8 <alloc::boxed::box_new_uninit>
100006680: aa0003f7    	mov	x23, x0
100006684: 910d83e1    	add	x1, sp, #0x360
100006688: 52802602    	mov	w2, #0x130              ; =304
10000668c: 94031e69    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
100006690: 52800019    	mov	w25, #0x0               ; =0
100006694: d0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
100006698: 910b8063    	add	x3, x3, #0x2e0
10000669c: 910062c0    	add	x0, x22, #0x18
1000066a0: f94013e1    	ldr	x1, [sp, #0x20]
1000066a4: aa1703e2    	mov	x2, x23
1000066a8: 9400c731    	bl	0x10003836c <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
1000066ac: 52800019    	mov	w25, #0x0               ; =0
1000066b0: 94000414    	bl	0x100007700 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
1000066b4: ad468700    	ldp	q0, q1, [x24, #0xd0]
1000066b8: 3c8082a0    	stur	q0, [x21, #0x8]
1000066bc: 3c8182a1    	stur	q1, [x21, #0x18]
1000066c0: ad478700    	ldp	q0, q1, [x24, #0xf0]
1000066c4: 3c8282a0    	stur	q0, [x21, #0x28]
1000066c8: 3c8382a1    	stur	q1, [x21, #0x38]
1000066cc: f90002bf    	str	xzr, [x21]
1000066d0: f9412be8    	ldr	x8, [sp, #0x250]
1000066d4: b100051f    	cmn	x8, #0x1
1000066d8: 54ffd740    	b.eq	0x1000061c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x384>
1000066dc: 910943e0    	add	x0, sp, #0x250
1000066e0: 94000f88    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000066e4: 17fffeb7    	b	0x1000061c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x384>
1000066e8: 94031ba5    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
1000066ec: 3707ce20    	tbnz	w0, #0x0, 0x1000060b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x274>
1000066f0: 52800028    	mov	w8, #0x1                ; =1
1000066f4: 39002268    	strb	w8, [x19, #0x8]
1000066f8: 17fffe6e    	b	0x1000060b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x274>
1000066fc: 94031ba0    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
100006700: 3707c900    	tbnz	w0, #0x0, 0x100006020 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x1e4>
100006704: 52800028    	mov	w8, #0x1                ; =1
100006708: 39002268    	strb	w8, [x19, #0x8]
10000670c: 17fffe45    	b	0x100006020 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x1e4>
100006710: 900006a0    	adrp	x0, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100006714: 91067400    	add	x0, x0, #0x19d
100006718: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
10000671c: 910ca042    	add	x2, x2, #0x328
100006720: 528003a1    	mov	w1, #0x1d               ; =29
100006724: 94031cde    	bl	0x1000cda9c <core::option::expect_failed>
100006728: 1400001f    	b	0x1000067a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
10000672c: d0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
100006730: 910ac000    	add	x0, x0, #0x2b0
100006734: 94031da7    	bl	0x1000cddd0 <core::panicking::panic_const::panic_const_rem_by_zero>
100006738: 5280003b    	mov	w27, #0x1               ; =1
10000673c: 14000004    	b	0x10000674c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x910>
100006740: 910a23e0    	add	x0, sp, #0x288
100006744: 94005c14    	bl	0x10001d794 <core::ptr::drop_glue::<raster::types::error::Error>>
100006748: 5280001b    	mov	w27, #0x0               ; =0
10000674c: 900006a0    	adrp	x0, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100006750: 9106e800    	add	x0, x0, #0x1ba
100006754: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100006758: 910d0042    	add	x2, x2, #0x340
10000675c: 528005a1    	mov	w1, #0x2d               ; =45
100006760: 94031ccf    	bl	0x1000cda9c <core::option::expect_failed>
100006764: 14000010    	b	0x1000067a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x968>
100006768: f941b3e8    	ldr	x8, [sp, #0x360]
10000676c: b100051f    	cmn	x8, #0x1
100006770: 540000a0    	b.eq	0x100006784 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x948>
100006774: 52800028    	mov	w8, #0x1                ; =1
100006778: f90007e8    	str	x8, [sp, #0x8]
10000677c: 910d83e0    	add	x0, sp, #0x360
100006780: 94005c05    	bl	0x10001d794 <core::ptr::drop_glue::<raster::types::error::Error>>
100006784: 52800028    	mov	w8, #0x1                ; =1
100006788: f90007e8    	str	x8, [sp, #0x8]
10000678c: 900006a0    	adrp	x0, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100006790: 9105cc00    	add	x0, x0, #0x173
100006794: d0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100006798: 910b2042    	add	x2, x2, #0x2c8
10000679c: 52800541    	mov	w1, #0x2a               ; =42
1000067a0: 94031cbf    	bl	0x1000cda9c <core::option::expect_failed>
1000067a4: d4200020    	brk	#0x1
1000067a8: 14000042    	b	0x1000068b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa74>
1000067ac: aa0003f5    	mov	x21, x0
1000067b0: 910d83e0    	add	x0, sp, #0x360
1000067b4: 94000bc0    	bl	0x1000096b4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
1000067b8: 52800019    	mov	w25, #0x0               ; =0
1000067bc: 14000009    	b	0x1000067e0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9a4>
1000067c0: 94031ce4    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>
1000067c4: aa0003f5    	mov	x21, x0
1000067c8: 910483e8    	add	x8, sp, #0x120
1000067cc: 3dc007e0    	ldr	q0, [sp, #0x10]
1000067d0: 3c8e8100    	stur	q0, [x8, #0xe8]
1000067d4: 52800039    	mov	w25, #0x1               ; =1
1000067d8: 14000002    	b	0x1000067e0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9a4>
1000067dc: aa0003f5    	mov	x21, x0
1000067e0: 910c83e0    	add	x0, sp, #0x320
1000067e4: 94000964    	bl	0x100008d74 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
1000067e8: 52800016    	mov	w22, #0x0               ; =0
1000067ec: 1400001c    	b	0x10000685c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa20>
1000067f0: 14000032    	b	0x1000068b8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa7c>
1000067f4: aa0003f5    	mov	x21, x0
1000067f8: b10006ff    	cmn	x23, #0x1
1000067fc: 54000060    	b.eq	0x100006808 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0x9cc>
100006800: 910c83e0    	add	x0, sp, #0x320
100006804: 94000f3f    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006808: 52800036    	mov	w22, #0x1               ; =1
10000680c: 14000013    	b	0x100006858 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa1c>
100006810: aa0003f5    	mov	x21, x0
100006814: 52800036    	mov	w22, #0x1               ; =1
100006818: 52800039    	mov	w25, #0x1               ; =1
10000681c: 3700021b    	tbnz	w27, #0x0, 0x10000685c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa20>
100006820: 14000028    	b	0x1000068c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa84>
100006824: 14000025    	b	0x1000068b8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa7c>
100006828: aa0003f5    	mov	x21, x0
10000682c: b100075f    	cmn	x26, #0x1
100006830: 54000060    	b.eq	0x10000683c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa00>
100006834: 910c83e0    	add	x0, sp, #0x320
100006838: 94000f32    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
10000683c: 52800036    	mov	w22, #0x1               ; =1
100006840: 52800039    	mov	w25, #0x1               ; =1
100006844: 370000d7    	tbnz	w23, #0x0, 0x10000685c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa20>
100006848: 1400001e    	b	0x1000068c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa84>
10000684c: 14000017    	b	0x1000068a8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa6c>
100006850: f94007f6    	ldr	x22, [sp, #0x8]
100006854: aa0003f5    	mov	x21, x0
100006858: 52800039    	mov	w25, #0x1               ; =1
10000685c: f9412be8    	ldr	x8, [sp, #0x250]
100006860: b100051f    	cmn	x8, #0x1
100006864: 54000060    	b.eq	0x100006870 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa34>
100006868: 910943e0    	add	x0, sp, #0x250
10000686c: 94000f25    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006870: 37000299    	tbnz	w25, #0x0, 0x1000068c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa84>
100006874: 14000015    	b	0x1000068c8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa8c>
100006878: aa0003f5    	mov	x21, x0
10000687c: 9103c3e0    	add	x0, sp, #0xf0
100006880: 94000f20    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100006884: 14000002    	b	0x10000688c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa50>
100006888: aa0003f5    	mov	x21, x0
10000688c: 910283e0    	add	x0, sp, #0xa0
100006890: 9400069c    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100006894: 1400000e    	b	0x1000068cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa90>
100006898: aa0003f5    	mov	x21, x0
10000689c: 910303e0    	add	x0, sp, #0xc0
1000068a0: 94000f18    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000068a4: 1400000a    	b	0x1000068cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa90>
1000068a8: aa0003f5    	mov	x21, x0
1000068ac: 14000008    	b	0x1000068cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xa90>
1000068b0: aa0003f5    	mov	x21, x0
1000068b4: 1400000d    	b	0x1000068e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaac>
1000068b8: aa0003f5    	mov	x21, x0
1000068bc: 52800036    	mov	w22, #0x1               ; =1
1000068c0: 910483e0    	add	x0, sp, #0x120
1000068c4: 94000b7c    	bl	0x1000096b4 <core::ptr::drop_glue::<raster::engine::upsert::UpsertTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
1000068c8: 36000116    	tbz	w22, #0x0, 0x1000068e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaac>
1000068cc: f9401fe8    	ldr	x8, [sp, #0x38]
1000068d0: f9400109    	ldr	x9, [x8]
1000068d4: f1000529    	subs	x9, x9, #0x1
1000068d8: f9000109    	str	x9, [x8]
1000068dc: 54000061    	b.ne	0x1000068e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::upsert::<parity::Request>+0xaac>
1000068e0: 9100e3e0    	add	x0, sp, #0x38
1000068e4: 9401c97b    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
1000068e8: aa1303e0    	mov	x0, x19
1000068ec: aa1403e1    	mov	x1, x20
1000068f0: 94000c4e    	bl	0x100009a28 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
1000068f4: aa1503e0    	mov	x0, x21
1000068f8: 94031d77    	bl	0x1000cded4 <dyld_stub_binder+0x1000cded4>
1000068fc: 94031c95    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>

