0000000100004f50 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>>:
100004f50: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100004f54: a90167fa    	stp	x26, x25, [sp, #0x10]
100004f58: a9025ff8    	stp	x24, x23, [sp, #0x20]
100004f5c: a90357f6    	stp	x22, x21, [sp, #0x30]
100004f60: a9044ff4    	stp	x20, x19, [sp, #0x40]
100004f64: a9057bfd    	stp	x29, x30, [sp, #0x50]
100004f68: 910143fd    	add	x29, sp, #0x50
100004f6c: d11dc3ff    	sub	sp, sp, #0x770
100004f70: f90003ff    	str	xzr, [sp]
100004f74: a9058fe7    	stp	x7, x3, [sp, #0x58]
100004f78: aa0603f6    	mov	x22, x6
100004f7c: aa0503f3    	mov	x19, x5
100004f80: aa0403fa    	mov	x26, x4
100004f84: aa0303fb    	mov	x27, x3
100004f88: aa0203f8    	mov	x24, x2
100004f8c: aa0103f5    	mov	x21, x1
100004f90: aa0003f9    	mov	x25, x0
100004f94: aa0803fc    	mov	x28, x8
100004f98: f90037e4    	str	x4, [sp, #0x68]
100004f9c: f9400017    	ldr	x23, [x0]
100004fa0: 9115e3f4    	add	x20, sp, #0x578
100004fa4: 9115e3e8    	add	x8, sp, #0x578
100004fa8: 910202e0    	add	x0, x23, #0x80
100004fac: 9400219c    	bl	0x10000d61c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
100004fb0: f942bfe8    	ldr	x8, [sp, #0x578]
100004fb4: b100051f    	cmn	x8, #0x1
100004fb8: 540001a0    	b.eq	0x100004fec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x9c>
100004fbc: 395603e9    	ldrb	w9, [sp, #0x580]
100004fc0: 3cc09280    	ldur	q0, [x20, #0x9]
100004fc4: 3c811380    	stur	q0, [x28, #0x11]
100004fc8: 3cc19280    	ldur	q0, [x20, #0x19]
100004fcc: 3c821380    	stur	q0, [x28, #0x21]
100004fd0: f942d3ea    	ldr	x10, [sp, #0x5a0]
100004fd4: 39004389    	strb	w9, [x28, #0x10]
100004fd8: a9036f8a    	stp	x10, x27, [x28, #0x30]
100004fdc: f900239a    	str	x26, [x28, #0x40]
100004fe0: 52800029    	mov	w9, #0x1                ; =1
100004fe4: a9002389    	stp	x9, x8, [x28]
100004fe8: 14000084    	b	0x1000051f8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a8>
100004fec: aa1c03f4    	mov	x20, x28
100004ff0: f9002bf6    	str	x22, [sp, #0x50]
100004ff4: 395607fc    	ldrb	w28, [sp, #0x581]
100004ff8: 9115e3e0    	add	x0, sp, #0x578
100004ffc: 910202e1    	add	x1, x23, #0x80
100005000: 910183e4    	add	x4, sp, #0x60
100005004: aa1503e2    	mov	x2, x21
100005008: aa1803e3    	mov	x3, x24
10000500c: 97ffff4d    	bl	0x100004d40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>>
100005010: f942bfe8    	ldr	x8, [sp, #0x578]
100005014: b100051f    	cmn	x8, #0x1
100005018: 54000160    	b.eq	0x100005044 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xf4>
10000501c: 9115e3e8    	add	x8, sp, #0x578
100005020: ad400500    	ldp	q0, q1, [x8]
100005024: 3c808280    	stur	q0, [x20, #0x8]
100005028: 3c818281    	stur	q1, [x20, #0x18]
10000502c: 3dc00900    	ldr	q0, [x8, #0x20]
100005030: 3c828280    	stur	q0, [x20, #0x28]
100005034: a903ea9b    	stp	x27, x26, [x20, #0x38]
100005038: 52800028    	mov	w8, #0x1                ; =1
10000503c: f9000288    	str	x8, [x20]
100005040: 1400006e    	b	0x1000051f8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a8>
100005044: f942c3eb    	ldr	x11, [sp, #0x580]
100005048: 395623e8    	ldrb	w8, [sp, #0x588]
10000504c: b90047e8    	str	w8, [sp, #0x44]
100005050: 9115e3f6    	add	x22, sp, #0x578
100005054: b84112c8    	ldur	w8, [x22, #0x11]
100005058: b90073e8    	str	w8, [sp, #0x70]
10000505c: b9458fe8    	ldr	w8, [sp, #0x58c]
100005060: b80733e8    	stur	w8, [sp, #0x73]
100005064: f942cbe8    	ldr	x8, [sp, #0x590]
100005068: f90027e8    	str	x8, [sp, #0x48]
10000506c: f942cfe8    	ldr	x8, [sp, #0x598]
100005070: a90357e8    	stp	x8, x21, [sp, #0x30]
100005074: f94072e8    	ldr	x8, [x23, #0xe0]
100005078: b4003348    	cbz	x8, 0x1000056e0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x790>
10000507c: f942d3e9    	ldr	x9, [sp, #0x5a0]
100005080: a90267e9    	stp	x9, x25, [sp, #0x20]
100005084: aa1703f5    	mov	x21, x23
100005088: f9406ee9    	ldr	x9, [x23, #0xd8]
10000508c: 9ac8096a    	udiv	x10, x11, x8
100005090: 9b08ad48    	msub	x8, x10, x8, x11
100005094: 8b081121    	add	x1, x9, x8, lsl #4
100005098: aa0b03f7    	mov	x23, x11
10000509c: 3600015c    	tbz	w28, #0x0, 0x1000050c4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x174>
1000050a0: 39402028    	ldrb	w8, [x1, #0x8]
1000050a4: aa1a03f9    	mov	x25, x26
1000050a8: 34000488    	cbz	w8, 0x100005138 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1e8>
1000050ac: a903e69b    	stp	x27, x25, [x20, #0x38]
1000050b0: b00006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
1000050b4: 3dc10900    	ldr	q0, [x8, #0x420]
1000050b8: 3d800280    	str	q0, [x20]
1000050bc: f94027fc    	ldr	x28, [sp, #0x48]
1000050c0: 14000047    	b	0x1000051dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x28c>
1000050c4: 9115e3e0    	add	x0, sp, #0x578
1000050c8: f94027fc    	ldr	x28, [sp, #0x48]
1000050cc: 94004016    	bl	0x100015124 <raster::engine::operation_gate::try_lock>
1000050d0: aa1a03f9    	mov	x25, x26
1000050d4: b9457be8    	ldr	w8, [sp, #0x578]
1000050d8: 36000248    	tbz	w8, #0x0, 0x100005120 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1d0>
1000050dc: a903e69b    	stp	x27, x25, [x20, #0x38]
1000050e0: b00006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
1000050e4: 3dc10900    	ldr	q0, [x8, #0x420]
1000050e8: 3d800280    	str	q0, [x20]
1000050ec: 395623e8    	ldrb	w8, [sp, #0x588]
1000050f0: 7100091f    	cmp	w8, #0x2
1000050f4: 54000740    	b.eq	0x1000051dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x28c>
1000050f8: f942c3f3    	ldr	x19, [sp, #0x580]
1000050fc: 370000c8    	tbnz	w8, #0x0, 0x100005114 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1c4>
100005100: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100005104: 91394108    	add	x8, x8, #0xe50
100005108: f9400108    	ldr	x8, [x8]
10000510c: f240f91f    	tst	x8, #0x7fffffffffffffff
100005110: 54002a01    	b.ne	0x100005650 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x700>
100005114: f9400260    	ldr	x0, [x19]
100005118: 94027d18    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
10000511c: 14000030    	b	0x1000051dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x28c>
100005120: f942c3e8    	ldr	x8, [sp, #0x580]
100005124: f9000be8    	str	x8, [sp, #0x10]
100005128: 395623e8    	ldrb	w8, [sp, #0x588]
10000512c: b9001fe8    	str	w8, [sp, #0x1c]
100005130: 9115e3f6    	add	x22, sp, #0x578
100005134: 14000004    	b	0x100005144 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1f4>
100005138: 52800048    	mov	w8, #0x2                ; =2
10000513c: b9001fe8    	str	w8, [sp, #0x1c]
100005140: f94027fc    	ldr	x28, [sp, #0x48]
100005144: 5280003a    	mov	w26, #0x1               ; =1
100005148: f9401fe0    	ldr	x0, [sp, #0x38]
10000514c: 94015ecc    	bl	0x10005cc7c <<raster::engine::pending::SessionRuntime>::pending>
100005150: f940faa8    	ldr	x8, [x21, #0x1f0]
100005154: eb08001f    	cmp	x0, x8
100005158: 54000222    	b.hs	0x10000519c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x24c>
10000515c: f940fea1    	ldr	x1, [x21, #0x1f8]
100005160: 9115e3e8    	add	x8, sp, #0x578
100005164: f9401fe0    	ldr	x0, [sp, #0x38]
100005168: 94015d62    	bl	0x10005c6f0 <<raster::engine::pending::SessionRuntime>::reserve_result>
10000516c: f942bfe8    	ldr	x8, [sp, #0x578]
100005170: b100051f    	cmn	x8, #0x1
100005174: 54000520    	b.eq	0x100005218 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2c8>
100005178: ad4006c0    	ldp	q0, q1, [x22]
10000517c: 3c808280    	stur	q0, [x20, #0x8]
100005180: 3c818281    	stur	q1, [x20, #0x18]
100005184: 3dc00ac0    	ldr	q0, [x22, #0x20]
100005188: 3c828280    	stur	q0, [x20, #0x28]
10000518c: a903e69b    	stp	x27, x25, [x20, #0x38]
100005190: 52800028    	mov	w8, #0x1                ; =1
100005194: f9000288    	str	x8, [x20]
100005198: 14000005    	b	0x1000051ac <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x25c>
10000519c: a903e69b    	stp	x27, x25, [x20, #0x38]
1000051a0: b00006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
1000051a4: 3dc10900    	ldr	q0, [x8, #0x420]
1000051a8: 3d800280    	str	q0, [x20]
1000051ac: b9401fe8    	ldr	w8, [sp, #0x1c]
1000051b0: 7100091f    	cmp	w8, #0x2
1000051b4: 54000140    	b.eq	0x1000051dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x28c>
1000051b8: 370000c8    	tbnz	w8, #0x0, 0x1000051d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x280>
1000051bc: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
1000051c0: 91394108    	add	x8, x8, #0xe50
1000051c4: f9400108    	ldr	x8, [x8]
1000051c8: f240f91f    	tst	x8, #0x7fffffffffffffff
1000051cc: 54002361    	b.ne	0x100005638 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x6e8>
1000051d0: f9400be8    	ldr	x8, [sp, #0x10]
1000051d4: f9400100    	ldr	x0, [x8]
1000051d8: 94027ce8    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1000051dc: b94047e8    	ldr	w8, [sp, #0x44]
1000051e0: 340000c8    	cbz	w8, 0x1000051f8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a8>
1000051e4: b40000bc    	cbz	x28, 0x1000051f8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a8>
1000051e8: f9401be0    	ldr	x0, [sp, #0x30]
1000051ec: aa1c03e1    	mov	x1, x28
1000051f0: 52800022    	mov	w2, #0x1                ; =1
1000051f4: 9401288e    	bl	0x10004f42c <__rustc::__rust_dealloc>
1000051f8: 911dc3ff    	add	sp, sp, #0x770
1000051fc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100005200: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100005204: a94357f6    	ldp	x22, x21, [sp, #0x30]
100005208: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10000520c: a94167fa    	ldp	x26, x25, [sp, #0x10]
100005210: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100005214: d65f03c0    	ret
100005218: f942c3e8    	ldr	x8, [sp, #0x580]
10000521c: f9003fe8    	str	x8, [sp, #0x78]
100005220: 9115e3e0    	add	x0, sp, #0x578
100005224: 910202a1    	add	x1, x21, #0x80
100005228: f9401fe2    	ldr	x2, [sp, #0x38]
10000522c: 94001aea    	bl	0x10000bdd4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
100005230: 3956a7e8    	ldrb	w8, [sp, #0x5a9]
100005234: 7100091f    	cmp	w8, #0x2
100005238: 54000061    	b.ne	0x100005244 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2f4>
10000523c: 9115e3e8    	add	x8, sp, #0x578
100005240: 1400001f    	b	0x1000052bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x36c>
100005244: 9115e3e8    	add	x8, sp, #0x578
100005248: ad408101    	ldp	q1, q0, [x8, #0x10]
10000524c: ad0483e1    	stp	q1, q0, [sp, #0x90]
100005250: 3dc00100    	ldr	q0, [x8]
100005254: 3d8023e0    	str	q0, [sp, #0x80]
100005258: f942d7e8    	ldr	x8, [sp, #0x5a8]
10000525c: f9005be8    	str	x8, [sp, #0xb0]
100005260: ad0607e0    	stp	q0, q1, [sp, #0xc0]
100005264: a94a6bf6    	ldp	x22, x26, [sp, #0xa0]
100005268: f9401fe8    	ldr	x8, [sp, #0x38]
10000526c: f9400902    	ldr	x2, [x8, #0x10]
100005270: 910423e8    	add	x8, sp, #0x108
100005274: 910d02a0    	add	x0, x21, #0x340
100005278: aa1703e1    	mov	x1, x23
10000527c: 9401669c    	bl	0x10005ecec <<raster::engine::version_permit::VersionPermits>::reserve_initial>
100005280: 910423e9    	add	x9, sp, #0x108
100005284: f94087e8    	ldr	x8, [sp, #0x108]
100005288: b100051f    	cmn	x8, #0x1
10000528c: 540003a0    	b.eq	0x100005300 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x3b0>
100005290: f94186a9    	ldr	x9, [x21, #0x308]
100005294: 9115e3e8    	add	x8, sp, #0x578
100005298: 91004120    	add	x0, x9, #0x10
10000529c: 910203e1    	add	x1, sp, #0x80
1000052a0: 94023329    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
1000052a4: f942bfe8    	ldr	x8, [sp, #0x578]
1000052a8: b100051f    	cmn	x8, #0x1
1000052ac: 54000060    	b.eq	0x1000052b8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x368>
1000052b0: 9115e3e0    	add	x0, sp, #0x578
1000052b4: 94001523    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
1000052b8: 910423e8    	add	x8, sp, #0x108
1000052bc: ad400500    	ldp	q0, q1, [x8]
1000052c0: 3c808280    	stur	q0, [x20, #0x8]
1000052c4: 3c818281    	stur	q1, [x20, #0x18]
1000052c8: 3dc00900    	ldr	q0, [x8, #0x20]
1000052cc: 3c828280    	stur	q0, [x20, #0x28]
1000052d0: a903e69b    	stp	x27, x25, [x20, #0x38]
1000052d4: 52800028    	mov	w8, #0x1                ; =1
1000052d8: f9000288    	str	x8, [x20]
1000052dc: f9403fe8    	ldr	x8, [sp, #0x78]
1000052e0: f9400109    	ldr	x9, [x8]
1000052e4: f1000529    	subs	x9, x9, #0x1
1000052e8: f9000109    	str	x9, [x8]
1000052ec: 54fff601    	b.ne	0x1000051ac <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x25c>
1000052f0: 5280003a    	mov	w26, #0x1               ; =1
1000052f4: 9101e3e0    	add	x0, sp, #0x78
1000052f8: 9401dcf8    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
1000052fc: 17ffffac    	b	0x1000051ac <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x25c>
100005300: 3cc08120    	ldur	q0, [x9, #0x8]
100005304: 3cc18121    	ldur	q1, [x9, #0x18]
100005308: ad0707e0    	stp	q0, q1, [sp, #0xe0]
10000530c: 9104e3e0    	add	x0, sp, #0x138
100005310: 910202a1    	add	x1, x21, #0x80
100005314: f9401fe2    	ldr	x2, [sp, #0x38]
100005318: aa1803e3    	mov	x3, x24
10000531c: 94001af7    	bl	0x10000bef8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
100005320: f9409fe8    	ldr	x8, [sp, #0x138]
100005324: b100051f    	cmn	x8, #0x1
100005328: 540002e0    	b.eq	0x100005384 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x434>
10000532c: f94186a9    	ldr	x9, [x21, #0x308]
100005330: 9115e3e8    	add	x8, sp, #0x578
100005334: 91004120    	add	x0, x9, #0x10
100005338: 910203e1    	add	x1, sp, #0x80
10000533c: 94023302    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
100005340: f942bfe8    	ldr	x8, [sp, #0x578]
100005344: b100051f    	cmn	x8, #0x1
100005348: 54000060    	b.eq	0x100005354 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x404>
10000534c: 9115e3e0    	add	x0, sp, #0x578
100005350: 940014fc    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005354: 910423e8    	add	x8, sp, #0x108
100005358: ad418500    	ldp	q0, q1, [x8, #0x30]
10000535c: 3c808280    	stur	q0, [x20, #0x8]
100005360: 3c818281    	stur	q1, [x20, #0x18]
100005364: 3dc01500    	ldr	q0, [x8, #0x50]
100005368: 3c828280    	stur	q0, [x20, #0x28]
10000536c: a903e69b    	stp	x27, x25, [x20, #0x38]
100005370: 52800028    	mov	w8, #0x1                ; =1
100005374: f9000288    	str	x8, [x20]
100005378: 910383e0    	add	x0, sp, #0xe0
10000537c: 94000c47    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005380: 17ffffd7    	b	0x1000052dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x38c>
100005384: 910e43e8    	add	x8, sp, #0x390
100005388: f9401fe9    	ldr	x9, [sp, #0x38]
10000538c: 91034120    	add	x0, x9, #0xd0
100005390: 52800001    	mov	w1, #0x0                ; =0
100005394: 940239b8    	bl	0x100093a74 <<raster::engine::metrics::Tracker>::accept>
100005398: f90007fa    	str	x26, [sp, #0x8]
10000539c: b94047e8    	ldr	w8, [sp, #0x44]
1000053a0: 390a83e8    	strb	w8, [sp, #0x2a0]
1000053a4: 9105a3fa    	add	x26, sp, #0x168
1000053a8: 9104e748    	add	x8, x26, #0x139
1000053ac: b94073e9    	ldr	w9, [sp, #0x70]
1000053b0: b9000109    	str	w9, [x8]
1000053b4: b84733e8    	ldur	w8, [sp, #0x73]
1000053b8: b902a7e8    	str	w8, [sp, #0x2a4]
1000053bc: f90157fc    	str	x28, [sp, #0x2a8]
1000053c0: f9401be8    	ldr	x8, [sp, #0x30]
1000053c4: f9015be8    	str	x8, [sp, #0x2b0]
1000053c8: 91056348    	add	x8, x26, #0x158
1000053cc: ad4407e0    	ldp	q0, q1, [sp, #0x80]
1000053d0: ad000500    	stp	q0, q1, [x8]
1000053d4: 3dc02be0    	ldr	q0, [sp, #0xa0]
1000053d8: 3d800900    	str	q0, [x8, #0x20]
1000053dc: f9405be8    	ldr	x8, [sp, #0xb0]
1000053e0: f94013e9    	ldr	x9, [sp, #0x20]
1000053e4: f9015fe9    	str	x9, [sp, #0x2b8]
1000053e8: f9017be8    	str	x8, [sp, #0x2f0]
1000053ec: f9401fe8    	ldr	x8, [sp, #0x38]
1000053f0: f9400908    	ldr	x8, [x8, #0x10]
1000053f4: 9106e349    	add	x9, x26, #0x1b8
1000053f8: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
1000053fc: ad000520    	stp	q0, q1, [x9]
100005400: f941dbe9    	ldr	x9, [sp, #0x3b0]
100005404: f902e7e9    	str	x9, [sp, #0x5c8]
100005408: ad5c83e1    	ldp	q1, q0, [sp, #0x390]
10000540c: 9115e3ec    	add	x12, sp, #0x578
100005410: ad018181    	stp	q1, q0, [x12, #0x30]
100005414: 5280003c    	mov	w28, #0x1               ; =1
100005418: a916effc    	stp	x28, x27, [sp, #0x168]
10000541c: 5280004a    	mov	w10, #0x2               ; =2
100005420: a917abf9    	stp	x25, x10, [sp, #0x178]
100005424: 9280002b    	mov	x11, #-0x2              ; =-2
100005428: f900ffea    	str	x10, [sp, #0x1f8]
10000542c: f90123eb    	str	x11, [sp, #0x240]
100005430: ad400983    	ldp	q3, q2, [x12]
100005434: 910423ea    	add	x10, sp, #0x108
100005438: ad0a0943    	stp	q3, q2, [x10, #0x140]
10000543c: f9014fe9    	str	x9, [sp, #0x298]
100005440: ad0b8141    	stp	q1, q0, [x10, #0x170]
100005444: 3dc00980    	ldr	q0, [x12, #0x20]
100005448: 3d805940    	str	q0, [x10, #0x160]
10000544c: f9017ff7    	str	x23, [sp, #0x2f8]
100005450: f90183ff    	str	xzr, [sp, #0x300]
100005454: f9018bf8    	str	x24, [sp, #0x310]
100005458: f9018fe8    	str	x8, [sp, #0x318]
10000545c: 390d03f3    	strb	w19, [sp, #0x340]
100005460: f94017e1    	ldr	x1, [sp, #0x28]
100005464: f901a7e1    	str	x1, [sp, #0x348]
100005468: 9115e3e8    	add	x8, sp, #0x578
10000546c: 9105a3e0    	add	x0, sp, #0x168
100005470: 52800802    	mov	w2, #0x40               ; =64
100005474: a94513e3    	ldp	x3, x4, [sp, #0x50]
100005478: 94012102    	bl	0x10004d880 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_initial>
10000547c: f942bfe8    	ldr	x8, [sp, #0x578]
100005480: f100491f    	cmp	x8, #0x12
100005484: 54000441    	b.ne	0x10000550c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x5bc>
100005488: f940b7e8    	ldr	x8, [sp, #0x168]
10000548c: f100091f    	cmp	x8, #0x2
100005490: 54000ea0    	b.eq	0x100005664 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x714>
100005494: 910202a0    	add	x0, x21, #0x80
100005498: 91056342    	add	x2, x26, #0x158
10000549c: f9401fe1    	ldr	x1, [sp, #0x38]
1000054a0: 94001a1c    	bl	0x10000bd10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
1000054a4: f940b7e8    	ldr	x8, [sp, #0x168]
1000054a8: f100091f    	cmp	x8, #0x2
1000054ac: 54000dc0    	b.eq	0x100005664 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x714>
1000054b0: f94123e8    	ldr	x8, [sp, #0x240]
1000054b4: 92800029    	mov	x9, #-0x2               ; =-2
1000054b8: f90123e9    	str	x9, [sp, #0x240]
1000054bc: b100091f    	cmn	x8, #0x2
1000054c0: 54001000    	b.eq	0x1000056c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x770>
1000054c4: ad470740    	ldp	q0, q1, [x26, #0xe0]
1000054c8: 3c818280    	stur	q0, [x20, #0x18]
1000054cc: 3c828281    	stur	q1, [x20, #0x28]
1000054d0: 3dc04340    	ldr	q0, [x26, #0x100]
1000054d4: 3c838280    	stur	q0, [x20, #0x38]
1000054d8: a900a29f    	stp	xzr, x8, [x20, #0x8]
1000054dc: f900029f    	str	xzr, [x20]
1000054e0: 9105a3e0    	add	x0, sp, #0x168
1000054e4: 94001099    	bl	0x100009748 <core::ptr::drop_glue::<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
1000054e8: f9403fe8    	ldr	x8, [sp, #0x78]
1000054ec: f9400109    	ldr	x9, [x8]
1000054f0: f1000529    	subs	x9, x9, #0x1
1000054f4: f9000109    	str	x9, [x8]
1000054f8: 54000981    	b.ne	0x100005628 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x6d8>
1000054fc: 5280001a    	mov	w26, #0x0               ; =0
100005500: 9101e3e0    	add	x0, sp, #0x78
100005504: 9401dc75    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100005508: 14000048    	b	0x100005628 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x6d8>
10000550c: 54000083    	b.lo	0x10000551c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x5cc>
100005510: 927f0d08    	and	x8, x8, #0x1e
100005514: f100491f    	cmp	x8, #0x12
100005518: 54000080    	b.eq	0x100005528 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x5d8>
10000551c: 5280003c    	mov	w28, #0x1               ; =1
100005520: 9115e3e0    	add	x0, sp, #0x578
100005524: 94001487    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005528: f9403fe1    	ldr	x1, [sp, #0x78]
10000552c: ad4607e0    	ldp	q0, q1, [sp, #0xc0]
100005530: ad1c87e0    	stp	q0, q1, [sp, #0x390]
100005534: f901dbf6    	str	x22, [sp, #0x3b0]
100005538: f94007e8    	ldr	x8, [sp, #0x8]
10000553c: f901dfe8    	str	x8, [sp, #0x3b8]
100005540: 5280001c    	mov	w28, #0x0               ; =0
100005544: 9115e3e8    	add	x8, sp, #0x578
100005548: 910e43e0    	add	x0, sp, #0x390
10000554c: 94008c78    	bl	0x10002872c <<raster::api::completion::Ticket<u64>>::pair_bounded>
100005550: 9115e3e8    	add	x8, sp, #0x578
100005554: ad400500    	ldp	q0, q1, [x8]
100005558: ad1a87e0    	stp	q0, q1, [sp, #0x350]
10000555c: ad410500    	ldp	q0, q1, [x8, #0x20]
100005560: ad1b87e0    	stp	q0, q1, [sp, #0x370]
100005564: f942dff5    	ldr	x21, [sp, #0x5b8]
100005568: f942e3f7    	ldr	x23, [sp, #0x5c0]
10000556c: f902bff5    	str	x21, [sp, #0x578]
100005570: f902c3f7    	str	x23, [sp, #0x580]
100005574: f940b7e8    	ldr	x8, [sp, #0x168]
100005578: f100091f    	cmp	x8, #0x2
10000557c: 54000840    	b.eq	0x100005684 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x734>
100005580: 91066340    	add	x0, x26, #0x198
100005584: 94000916    	bl	0x1000079dc <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
100005588: f90183f5    	str	x21, [sp, #0x300]
10000558c: f90187f7    	str	x23, [sp, #0x308]
100005590: f940b7e8    	ldr	x8, [sp, #0x168]
100005594: f100091f    	cmp	x8, #0x2
100005598: 54000840    	b.eq	0x1000056a0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x750>
10000559c: 9105a3e8    	add	x8, sp, #0x168
1000055a0: 52800035    	mov	w21, #0x1               ; =1
1000055a4: 91044100    	add	x0, x8, #0x110
1000055a8: 94023a6e    	bl	0x100093f60 <<raster::engine::metrics::Monitor>::pending>
1000055ac: 9115e3e0    	add	x0, sp, #0x578
1000055b0: 9105a3e1    	add	x1, sp, #0x168
1000055b4: 52803d02    	mov	w2, #0x1e8              ; =488
1000055b8: 94032379    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
1000055bc: 52800015    	mov	w21, #0x0               ; =0
1000055c0: 910e43e8    	add	x8, sp, #0x390
1000055c4: 9115e3e0    	add	x0, sp, #0x578
1000055c8: 940106d9    	bl	0x10004712c <<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>::into_owned>
1000055cc: 52803d00    	mov	w0, #0x1e8              ; =488
1000055d0: 94003ec6    	bl	0x1000150e8 <alloc::boxed::box_new_uninit>
1000055d4: aa0003f3    	mov	x19, x0
1000055d8: 910e43e1    	add	x1, sp, #0x390
1000055dc: 52803d02    	mov	w2, #0x1e8              ; =488
1000055e0: 9403236f    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
1000055e4: 52800015    	mov	w21, #0x0               ; =0
1000055e8: f0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
1000055ec: 9107c063    	add	x3, x3, #0x1f0
1000055f0: f9401fe8    	ldr	x8, [sp, #0x38]
1000055f4: 91006100    	add	x0, x8, #0x18
1000055f8: aa1603e1    	mov	x1, x22
1000055fc: aa1303e2    	mov	x2, x19
100005600: 9400cbeb    	bl	0x1000385ac <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
100005604: 52800015    	mov	w21, #0x0               ; =0
100005608: 940008a4    	bl	0x100007898 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
10000560c: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
100005610: 3c808280    	stur	q0, [x20, #0x8]
100005614: 3c818281    	stur	q1, [x20, #0x18]
100005618: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
10000561c: 3c828280    	stur	q0, [x20, #0x28]
100005620: 3c838281    	stur	q1, [x20, #0x38]
100005624: f900029f    	str	xzr, [x20]
100005628: f9400be0    	ldr	x0, [sp, #0x10]
10000562c: b9401fe1    	ldr	w1, [sp, #0x1c]
100005630: 94000910    	bl	0x100007a70 <core::ptr::drop_glue::<core::option::Option<std::sync::poison::mutex::MutexGuard<()>>>>
100005634: 17fffef1    	b	0x1000051f8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a8>
100005638: 940320ac    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
10000563c: 3707dca0    	tbnz	w0, #0x0, 0x1000051d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x280>
100005640: 52800028    	mov	w8, #0x1                ; =1
100005644: f9400be9    	ldr	x9, [sp, #0x10]
100005648: 39002128    	strb	w8, [x9, #0x8]
10000564c: 17fffee1    	b	0x1000051d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x280>
100005650: 940320a6    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
100005654: 3707d600    	tbnz	w0, #0x0, 0x100005114 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1c4>
100005658: 52800028    	mov	w8, #0x1                ; =1
10000565c: 39002268    	strb	w8, [x19, #0x8]
100005660: 17fffead    	b	0x100005114 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1c4>
100005664: 5280003c    	mov	w28, #0x1               ; =1
100005668: f00006a0    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
10000566c: 9128d800    	add	x0, x0, #0xa36
100005670: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
100005674: 911ce042    	add	x2, x2, #0x738
100005678: 52800441    	mov	w1, #0x22               ; =34
10000567c: 940321e3    	bl	0x1000cde08 <core::option::expect_failed>
100005680: 1400001b    	b	0x1000056ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x79c>
100005684: f00006a0    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
100005688: 9128d800    	add	x0, x0, #0xa36
10000568c: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
100005690: 911ce042    	add	x2, x2, #0x738
100005694: 52800441    	mov	w1, #0x22               ; =34
100005698: 940321dc    	bl	0x1000cde08 <core::option::expect_failed>
10000569c: 14000014    	b	0x1000056ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x79c>
1000056a0: 52800035    	mov	w21, #0x1               ; =1
1000056a4: f00006a0    	adrp	x0, 0x1000dc000 <_anon.3ef8275974b08a4cf6279f5e576259b9.31+0x198>
1000056a8: 9128d800    	add	x0, x0, #0xa36
1000056ac: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
1000056b0: 911ce042    	add	x2, x2, #0x738
1000056b4: 52800441    	mov	w1, #0x22               ; =34
1000056b8: 940321d4    	bl	0x1000cde08 <core::option::expect_failed>
1000056bc: 1400000c    	b	0x1000056ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x79c>
1000056c0: 5280003c    	mov	w28, #0x1               ; =1
1000056c4: b00006a0    	adrp	x0, 0x1000da000 <GCC_except_table9+0x10>
1000056c8: 91141400    	add	x0, x0, #0x505
1000056cc: f0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
1000056d0: 91076042    	add	x2, x2, #0x1d8
1000056d4: 528004e1    	mov	w1, #0x27               ; =39
1000056d8: 940321cc    	bl	0x1000cde08 <core::option::expect_failed>
1000056dc: 14000004    	b	0x1000056ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x79c>
1000056e0: f0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
1000056e4: 91070000    	add	x0, x0, #0x1c0
1000056e8: 94032295    	bl	0x1000ce13c <core::panicking::panic_const::panic_const_rem_by_zero>
1000056ec: d4200020    	brk	#0x1
1000056f0: aa0003f3    	mov	x19, x0
1000056f4: 5280001a    	mov	w26, #0x0               ; =0
1000056f8: 1400002f    	b	0x1000057b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x864>
1000056fc: aa0003f3    	mov	x19, x0
100005700: 910e43e0    	add	x0, sp, #0x390
100005704: 94001042    	bl	0x10000980c <core::ptr::drop_glue::<raster::engine::task::OwnedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
100005708: 52800015    	mov	w21, #0x0               ; =0
10000570c: 1400001d    	b	0x100005780 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x830>
100005710: 940321eb    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
100005714: aa0003f3    	mov	x19, x0
100005718: f90183f5    	str	x21, [sp, #0x300]
10000571c: f90187f7    	str	x23, [sp, #0x308]
100005720: 14000015    	b	0x100005774 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x824>
100005724: aa0003f3    	mov	x19, x0
100005728: 9104e3e0    	add	x0, sp, #0x138
10000572c: 94001405    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005730: 14000002    	b	0x100005738 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x7e8>
100005734: aa0003f3    	mov	x19, x0
100005738: 910383e0    	add	x0, sp, #0xe0
10000573c: 94000b57    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005740: 14000006    	b	0x100005758 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x808>
100005744: aa0003f3    	mov	x19, x0
100005748: 910423e0    	add	x0, sp, #0x108
10000574c: 940013fd    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005750: 14000002    	b	0x100005758 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x808>
100005754: aa0003f3    	mov	x19, x0
100005758: 5280003a    	mov	w26, #0x1               ; =1
10000575c: 14000016    	b	0x1000057b4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x864>
100005760: aa0003f3    	mov	x19, x0
100005764: 1400001b    	b	0x1000057d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x880>
100005768: aa0003f3    	mov	x19, x0
10000576c: 9115e3e0    	add	x0, sp, #0x578
100005770: 9400089b    	bl	0x1000079dc <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
100005774: 52800035    	mov	w21, #0x1               ; =1
100005778: 14000002    	b	0x100005780 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x830>
10000577c: aa0003f3    	mov	x19, x0
100005780: 910d43e0    	add	x0, sp, #0x350
100005784: 94000e0c    	bl	0x100008fb4 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
100005788: 5280001a    	mov	w26, #0x0               ; =0
10000578c: 5280001c    	mov	w28, #0x0               ; =0
100005790: 370000b5    	tbnz	w21, #0x0, 0x1000057a4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x854>
100005794: 1400000f    	b	0x1000057d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x880>
100005798: aa0003f3    	mov	x19, x0
10000579c: 14000011    	b	0x1000057e0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x890>
1000057a0: aa0003f3    	mov	x19, x0
1000057a4: 9105a3e0    	add	x0, sp, #0x168
1000057a8: 94000fe8    	bl	0x100009748 <core::ptr::drop_glue::<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
1000057ac: 5280001a    	mov	w26, #0x0               ; =0
1000057b0: 3600011c    	tbz	w28, #0x0, 0x1000057d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x880>
1000057b4: f9403fe8    	ldr	x8, [sp, #0x78]
1000057b8: f9400109    	ldr	x9, [x8]
1000057bc: f1000529    	subs	x9, x9, #0x1
1000057c0: f9000109    	str	x9, [x8]
1000057c4: 54000061    	b.ne	0x1000057d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x880>
1000057c8: 9101e3e0    	add	x0, sp, #0x78
1000057cc: 9401dbc3    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
1000057d0: f9400be0    	ldr	x0, [sp, #0x10]
1000057d4: b9401fe1    	ldr	w1, [sp, #0x1c]
1000057d8: 940008a6    	bl	0x100007a70 <core::ptr::drop_glue::<core::option::Option<std::sync::poison::mutex::MutexGuard<()>>>>
1000057dc: 3600013a    	tbz	w26, #0x0, 0x100005800 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8b0>
1000057e0: b94047e8    	ldr	w8, [sp, #0x44]
1000057e4: 340000e8    	cbz	w8, 0x100005800 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8b0>
1000057e8: f94027e8    	ldr	x8, [sp, #0x48]
1000057ec: b40000a8    	cbz	x8, 0x100005800 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8b0>
1000057f0: f9401be0    	ldr	x0, [sp, #0x30]
1000057f4: f94027e1    	ldr	x1, [sp, #0x48]
1000057f8: 52800022    	mov	w2, #0x1                ; =1
1000057fc: 9401270c    	bl	0x10004f42c <__rustc::__rust_dealloc>
100005800: aa1303e0    	mov	x0, x19
100005804: 9403228f    	bl	0x1000ce240 <dyld_stub_binder+0x1000ce240>
100005808: 940321ad    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>

