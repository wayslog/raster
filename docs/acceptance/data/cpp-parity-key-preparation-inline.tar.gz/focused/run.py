"""Compare key preparation with the exact frozen direct parent."""
from pathlib import Path
import json,subprocess
root=Path("target/parity-profile/key-preparation-inline")
base=Path("target/parity-profile/read-inline-access/candidate-bins")
candidate=root/"candidate-bins"
cases=[("read-uniform","read/uniform/1"),("upsert-uniform","upsert/uniform/1"),("rmw-uniform","rmw/uniform/1"),("upsert-shared","upsert/shared-hot/1"),("read-four","read/uniform/4"),("upsert-four","upsert/worker-hot/4"),("rmw-shared-four","rmw/shared-hot/4"),("read-shared-four","read/shared-hot/4"),("control-read","read/uniform/1"),("control-upsert","upsert/shared-hot/1"),("control-shared-four","read/shared-hot/4")]
commands=[]
for name,case in cases:
 binary=(base if name.startswith("control") else candidate)/"parity"
 commands.append((name,["python3","tools/performance/compare.py","--rust",str(binary),"--baseline-rust",str(base/"parity"),"--case",case,"--min-throughput","0.98","--max-p99","1.10"]))
commands += [("result-budget",["python3","tools/performance/compare_result_budget.py","--rust",str(candidate/"result_budget"),"--baseline-rust",str(base/"result_budget")]),("variable",["python3","tools/performance/compare_repeat.py","--candidate",str(candidate/"benchmark_probe"),"--baseline",str(base/"benchmark_probe")])]
runs=[]
for name,cmd in commands:
 cmd += ["--output",str(root/name)]
 print("START",name,flush=True)
 with (root/(name+".log")).open("w") as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 runs.append({"name":name,"command":cmd,"exit_code":p.returncode});(root/"runs.json").write_text(json.dumps(runs,indent=2)+"\n")
 assert (root/name/"comparison.json").exists(),name
 if name=="variable":print(json.loads((root/name/"comparison.json").read_text())["comparisons"],flush=True)
 else:print((root/(name+".log")).read_text(),flush=True)
