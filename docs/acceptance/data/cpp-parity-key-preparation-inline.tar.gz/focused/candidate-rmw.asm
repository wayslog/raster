000000010000565c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>>:
10000565c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100005660: a90167fa    	stp	x26, x25, [sp, #0x10]
100005664: a9025ff8    	stp	x24, x23, [sp, #0x20]
100005668: a90357f6    	stp	x22, x21, [sp, #0x30]
10000566c: a9044ff4    	stp	x20, x19, [sp, #0x40]
100005670: a9057bfd    	stp	x29, x30, [sp, #0x50]
100005674: 910143fd    	add	x29, sp, #0x50
100005678: d11543ff    	sub	sp, sp, #0x550
10000567c: f90003ff    	str	xzr, [sp]
100005680: aa0503fa    	mov	x26, x5
100005684: aa0403f7    	mov	x23, x4
100005688: aa0303f8    	mov	x24, x3
10000568c: aa0203f9    	mov	x25, x2
100005690: aa0103f6    	mov	x22, x1
100005694: aa0803f5    	mov	x21, x8
100005698: 910c43fb    	add	x27, sp, #0x310
10000569c: f9400013    	ldr	x19, [x0]
1000056a0: 910d63e8    	add	x8, sp, #0x358
1000056a4: 91020260    	add	x0, x19, #0x80
1000056a8: 94001f4d    	bl	0x10000d3dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
1000056ac: f941afe8    	ldr	x8, [sp, #0x358]
1000056b0: b100051f    	cmn	x8, #0x1
1000056b4: 540001a0    	b.eq	0x1000056e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x8c>
1000056b8: 394d83e9    	ldrb	w9, [sp, #0x360]
1000056bc: 3cc51360    	ldur	q0, [x27, #0x51]
1000056c0: 3c8112a0    	stur	q0, [x21, #0x11]
1000056c4: 3cc61360    	ldur	q0, [x27, #0x61]
1000056c8: 3c8212a0    	stur	q0, [x21, #0x21]
1000056cc: f941c3ea    	ldr	x10, [sp, #0x380]
1000056d0: 390042a9    	strb	w9, [x21, #0x10]
1000056d4: a90362aa    	stp	x10, x24, [x21, #0x30]
1000056d8: f90022b7    	str	x23, [x21, #0x40]
1000056dc: 52800029    	mov	w9, #0x1                ; =1
1000056e0: a90022a9    	stp	x9, x8, [x21]
1000056e4: 14000010    	b	0x100005724 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xc8>
1000056e8: 3943a2c8    	ldrb	w8, [x22, #0xe8]
1000056ec: 370000a8    	tbnz	w8, #0x0, 0x100005700 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xa4>
1000056f0: 52838508    	mov	w8, #0x1c28             ; =7208
1000056f4: 8b080268    	add	x8, x19, x8
1000056f8: 08dffd08    	ldarb	w8, [x8]
1000056fc: 34000248    	cbz	w8, 0x100005744 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xe8>
100005700: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005704: 91041d08    	add	x8, x8, #0x107
100005708: 528003e9    	mov	w9, #0x1f               ; =31
10000570c: a90126a8    	stp	x8, x9, [x21, #0x10]
100005710: f90016bf    	str	xzr, [x21, #0x28]
100005714: a903deb8    	stp	x24, x23, [x21, #0x38]
100005718: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
10000571c: 3dc01900    	ldr	q0, [x8, #0x60]
100005720: 3d8002a0    	str	q0, [x21]
100005724: 911543ff    	add	sp, sp, #0x550
100005728: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10000572c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100005730: a94357f6    	ldp	x22, x21, [sp, #0x30]
100005734: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100005738: a94167fa    	ldp	x26, x25, [sp, #0x10]
10000573c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100005740: d65f03c0    	ret
100005744: f94002c8    	ldr	x8, [x22]
100005748: f100051f    	cmp	x8, #0x1
10000574c: 54000101    	b.ne	0x10000576c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x110>
100005750: f94006c8    	ldr	x8, [x22, #0x8]
100005754: eb08033f    	cmp	x25, x8
100005758: 540000a8    	b.hi	0x10000576c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x110>
10000575c: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005760: 91038108    	add	x8, x8, #0xe0
100005764: 528004e9    	mov	w9, #0x27               ; =39
100005768: 17ffffe9    	b	0x10000570c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xb0>
10000576c: f9407268    	ldr	x8, [x19, #0xe0]
100005770: b4002f68    	cbz	x8, 0x100005d5c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x700>
100005774: 92401f09    	and	x9, x24, #0xff
100005778: d28464aa    	mov	x10, #0x2325            ; =8997
10000577c: f2b0844a    	movk	x10, #0x8422, lsl #16
100005780: f2d39c8a    	movk	x10, #0x9ce4, lsl #32
100005784: f2f97e4a    	movk	x10, #0xcbf2, lsl #48
100005788: ca0a0129    	eor	x9, x9, x10
10000578c: d280366a    	mov	x10, #0x1b3             ; =435
100005790: f2c0200a    	movk	x10, #0x100, lsl #32
100005794: 9b0a7d29    	mul	x9, x9, x10
100005798: d3483f0b    	ubfx	x11, x24, #8, #8
10000579c: ca0b0129    	eor	x9, x9, x11
1000057a0: 9b0a7d29    	mul	x9, x9, x10
1000057a4: d3505f0b    	ubfx	x11, x24, #16, #8
1000057a8: ca0b0129    	eor	x9, x9, x11
1000057ac: 9b0a7d29    	mul	x9, x9, x10
1000057b0: 53187f0b    	lsr	w11, w24, #24
1000057b4: ca0b0129    	eor	x9, x9, x11
1000057b8: 9b0a7d29    	mul	x9, x9, x10
1000057bc: d3609f0b    	ubfx	x11, x24, #32, #8
1000057c0: ca0b0129    	eor	x9, x9, x11
1000057c4: 9b0a7d29    	mul	x9, x9, x10
1000057c8: d368bf0b    	ubfx	x11, x24, #40, #8
1000057cc: ca0b0129    	eor	x9, x9, x11
1000057d0: 9b0a7d29    	mul	x9, x9, x10
1000057d4: d370df0b    	ubfx	x11, x24, #48, #8
1000057d8: ca0b0129    	eor	x9, x9, x11
1000057dc: 9b0a7d29    	mul	x9, x9, x10
1000057e0: ca58e129    	eor	x9, x9, x24, lsr #56
1000057e4: 9b0a7d3c    	mul	x28, x9, x10
1000057e8: f9406e69    	ldr	x9, [x19, #0xd8]
1000057ec: 9ac80b8a    	udiv	x10, x28, x8
1000057f0: 9b08f148    	msub	x8, x10, x8, x28
1000057f4: 8b081121    	add	x1, x9, x8, lsl #4
1000057f8: 910d63e0    	add	x0, sp, #0x358
1000057fc: 94003dba    	bl	0x100014ee4 <raster::engine::operation_gate::try_lock>
100005800: b9435be8    	ldr	w8, [sp, #0x358]
100005804: 36000248    	tbz	w8, #0x0, 0x10000584c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1f0>
100005808: a903deb8    	stp	x24, x23, [x21, #0x38]
10000580c: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005810: 3dc01500    	ldr	q0, [x8, #0x50]
100005814: 3d8002a0    	str	q0, [x21]
100005818: 394da3e8    	ldrb	w8, [sp, #0x368]
10000581c: 7100091f    	cmp	w8, #0x2
100005820: 54fff820    	b.eq	0x100005724 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xc8>
100005824: f941b3f3    	ldr	x19, [sp, #0x360]
100005828: 370000c8    	tbnz	w8, #0x0, 0x100005840 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1e4>
10000582c: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100005830: 91394108    	add	x8, x8, #0xe50
100005834: f9400108    	ldr	x8, [x8]
100005838: f240f91f    	tst	x8, #0x7fffffffffffffff
10000583c: 54002741    	b.ne	0x100005d24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6c8>
100005840: f9400260    	ldr	x0, [x19]
100005844: 94027a72    	bl	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100005848: 17ffffb7    	b	0x100005724 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xc8>
10000584c: f941b3f4    	ldr	x20, [sp, #0x360]
100005850: 394da3e8    	ldrb	w8, [sp, #0x368]
100005854: b90037e8    	str	w8, [sp, #0x34]
100005858: aa1603e0    	mov	x0, x22
10000585c: 94015c84    	bl	0x10005ca6c <<raster::engine::pending::SessionRuntime>::pending>
100005860: f940fa68    	ldr	x8, [x19, #0x1f0]
100005864: eb08001f    	cmp	x0, x8
100005868: 540002a2    	b.hs	0x1000058bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x260>
10000586c: f940fe61    	ldr	x1, [x19, #0x1f8]
100005870: 910d63e8    	add	x8, sp, #0x358
100005874: aa1603e0    	mov	x0, x22
100005878: 94015b1a    	bl	0x10005c4e0 <<raster::engine::pending::SessionRuntime>::reserve_result>
10000587c: f941afe8    	ldr	x8, [sp, #0x358]
100005880: b100051f    	cmn	x8, #0x1
100005884: 54000380    	b.eq	0x1000058f4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x298>
100005888: 910967e8    	add	x8, sp, #0x259
10000588c: 3ccff100    	ldur	q0, [x8, #0xff]
100005890: 9109a7e8    	add	x8, sp, #0x269
100005894: 3ccff101    	ldur	q1, [x8, #0xff]
100005898: 3c8082a0    	stur	q0, [x21, #0x8]
10000589c: 3c8182a1    	stur	q1, [x21, #0x18]
1000058a0: 9109e7e8    	add	x8, sp, #0x279
1000058a4: 3ccff100    	ldur	q0, [x8, #0xff]
1000058a8: 3c8282a0    	stur	q0, [x21, #0x28]
1000058ac: a903deb8    	stp	x24, x23, [x21, #0x38]
1000058b0: 52800028    	mov	w8, #0x1                ; =1
1000058b4: f90002a8    	str	x8, [x21]
1000058b8: 14000005    	b	0x1000058cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x270>
1000058bc: a903deb8    	stp	x24, x23, [x21, #0x38]
1000058c0: b00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
1000058c4: 3dc01500    	ldr	q0, [x8, #0x50]
1000058c8: 3d8002a0    	str	q0, [x21]
1000058cc: b94037e8    	ldr	w8, [sp, #0x34]
1000058d0: 370000c8    	tbnz	w8, #0x0, 0x1000058e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x28c>
1000058d4: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
1000058d8: 91394108    	add	x8, x8, #0xe50
1000058dc: f9400108    	ldr	x8, [x8]
1000058e0: f240f91f    	tst	x8, #0x7fffffffffffffff
1000058e4: 54002161    	b.ne	0x100005d10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6b4>
1000058e8: f9400280    	ldr	x0, [x20]
1000058ec: 94027a48    	bl	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
1000058f0: 17ffff8d    	b	0x100005724 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xc8>
1000058f4: f941b3e8    	ldr	x8, [sp, #0x360]
1000058f8: f9001fe8    	str	x8, [sp, #0x38]
1000058fc: 910d63e0    	add	x0, sp, #0x358
100005900: 91020261    	add	x1, x19, #0x80
100005904: aa1603e2    	mov	x2, x22
100005908: 940018a3    	bl	0x10000bb94 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
10000590c: 394e27e8    	ldrb	w8, [sp, #0x389]
100005910: 7100091f    	cmp	w8, #0x2
100005914: 54000141    	b.ne	0x10000593c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x2e0>
100005918: 910967e8    	add	x8, sp, #0x259
10000591c: 3ccff100    	ldur	q0, [x8, #0xff]
100005920: 9109a7e8    	add	x8, sp, #0x269
100005924: 3ccff101    	ldur	q1, [x8, #0xff]
100005928: 3c8082a0    	stur	q0, [x21, #0x8]
10000592c: 3c8182a1    	stur	q1, [x21, #0x18]
100005930: 9109e7e8    	add	x8, sp, #0x279
100005934: 3ccff100    	ldur	q0, [x8, #0xff]
100005938: 14000026    	b	0x1000059d0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x374>
10000593c: 9109e7e8    	add	x8, sp, #0x279
100005940: 3ccff102    	ldur	q2, [x8, #0xff]
100005944: 910967e8    	add	x8, sp, #0x259
100005948: 3ccff100    	ldur	q0, [x8, #0xff]
10000594c: 9109a7e8    	add	x8, sp, #0x269
100005950: 3ccff101    	ldur	q1, [x8, #0xff]
100005954: 3d8013e0    	str	q0, [sp, #0x40]
100005958: ad028be1    	stp	q1, q2, [sp, #0x50]
10000595c: f941c7e8    	ldr	x8, [sp, #0x388]
100005960: f9003be8    	str	x8, [sp, #0x70]
100005964: ad0407e0    	stp	q0, q1, [sp, #0x80]
100005968: a94623e9    	ldp	x9, x8, [sp, #0x60]
10000596c: f90017e9    	str	x9, [sp, #0x28]
100005970: f9000be8    	str	x8, [sp, #0x10]
100005974: f9400ac2    	ldr	x2, [x22, #0x10]
100005978: 910323e8    	add	x8, sp, #0xc8
10000597c: 910d0260    	add	x0, x19, #0x340
100005980: aa1c03e1    	mov	x1, x28
100005984: 94016456    	bl	0x10005eadc <<raster::engine::version_permit::VersionPermits>::reserve_initial>
100005988: f94067e8    	ldr	x8, [sp, #0xc8]
10000598c: b100051f    	cmn	x8, #0x1
100005990: 54000380    	b.eq	0x100005a00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x3a4>
100005994: f9418669    	ldr	x9, [x19, #0x308]
100005998: 910d63e8    	add	x8, sp, #0x358
10000599c: 91004120    	add	x0, x9, #0x10
1000059a0: 910103e1    	add	x1, sp, #0x40
1000059a4: 9402308d    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
1000059a8: f941afe8    	ldr	x8, [sp, #0x358]
1000059ac: b100051f    	cmn	x8, #0x1
1000059b0: 54000060    	b.eq	0x1000059bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x360>
1000059b4: 910d63e0    	add	x0, sp, #0x358
1000059b8: 940012d2    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000059bc: 3ccc83e0    	ldur	q0, [sp, #0xc8]
1000059c0: 3ccd83e1    	ldur	q1, [sp, #0xd8]
1000059c4: 3c8082a0    	stur	q0, [x21, #0x8]
1000059c8: 3c8182a1    	stur	q1, [x21, #0x18]
1000059cc: 3cce83e0    	ldur	q0, [sp, #0xe8]
1000059d0: 3c8282a0    	stur	q0, [x21, #0x28]
1000059d4: a903deb8    	stp	x24, x23, [x21, #0x38]
1000059d8: 52800028    	mov	w8, #0x1                ; =1
1000059dc: f90002a8    	str	x8, [x21]
1000059e0: f9401fe8    	ldr	x8, [sp, #0x38]
1000059e4: f9400109    	ldr	x9, [x8]
1000059e8: f1000529    	subs	x9, x9, #0x1
1000059ec: f9000109    	str	x9, [x8]
1000059f0: 54fff6e1    	b.ne	0x1000058cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x270>
1000059f4: 9100e3e0    	add	x0, sp, #0x38
1000059f8: 9401cd36    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
1000059fc: 17ffffb4    	b	0x1000058cc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x270>
100005a00: 910323e8    	add	x8, sp, #0xc8
100005a04: 3cc08100    	ldur	q0, [x8, #0x8]
100005a08: 3cc18101    	ldur	q1, [x8, #0x18]
100005a0c: ad0507e0    	stp	q0, q1, [sp, #0xa0]
100005a10: 9103e3e0    	add	x0, sp, #0xf8
100005a14: 91020261    	add	x1, x19, #0x80
100005a18: aa1603e2    	mov	x2, x22
100005a1c: aa1903e3    	mov	x3, x25
100005a20: 940018a6    	bl	0x10000bcb8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
100005a24: f9407fe8    	ldr	x8, [sp, #0xf8]
100005a28: b100051f    	cmn	x8, #0x1
100005a2c: 54000320    	b.eq	0x100005a90 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x434>
100005a30: f9418669    	ldr	x9, [x19, #0x308]
100005a34: 910d63e8    	add	x8, sp, #0x358
100005a38: 91004120    	add	x0, x9, #0x10
100005a3c: 910103e1    	add	x1, sp, #0x40
100005a40: 94023066    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
100005a44: f941afe8    	ldr	x8, [sp, #0x358]
100005a48: b100051f    	cmn	x8, #0x1
100005a4c: 54000060    	b.eq	0x100005a58 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x3fc>
100005a50: 910d63e0    	add	x0, sp, #0x358
100005a54: 940012ab    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005a58: 3ccf83e0    	ldur	q0, [sp, #0xf8]
100005a5c: 910027e8    	add	x8, sp, #0x9
100005a60: 3ccff101    	ldur	q1, [x8, #0xff]
100005a64: 3c8082a0    	stur	q0, [x21, #0x8]
100005a68: 3c8182a1    	stur	q1, [x21, #0x18]
100005a6c: 910067e8    	add	x8, sp, #0x19
100005a70: 3ccff100    	ldur	q0, [x8, #0xff]
100005a74: 3c8282a0    	stur	q0, [x21, #0x28]
100005a78: a903deb8    	stp	x24, x23, [x21, #0x38]
100005a7c: 52800028    	mov	w8, #0x1                ; =1
100005a80: f90002a8    	str	x8, [x21]
100005a84: 910283e0    	add	x0, sp, #0xa0
100005a88: 94000a1e    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005a8c: 17ffffd5    	b	0x1000059e0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x384>
100005a90: 910d63e8    	add	x8, sp, #0x358
100005a94: 910342c0    	add	x0, x22, #0xd0
100005a98: 52800041    	mov	w1, #0x2                ; =2
100005a9c: 9402371b    	bl	0x100093708 <<raster::engine::metrics::Tracker>::accept>
100005aa0: 52800028    	mov	w8, #0x1                ; =1
100005aa4: f8280268    	ldadd	x8, x8, [x19]
100005aa8: b7f81588    	tbnz	x8, #0x3f, 0x100005d58 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6fc>
100005aac: 52810008    	mov	w8, #0x800              ; =2048
100005ab0: 7904c3e8    	strh	w8, [sp, #0x260]
100005ab4: 9104a3ea    	add	x10, sp, #0x128
100005ab8: 9104e948    	add	x8, x10, #0x13a
100005abc: b9000118    	str	w24, [x8]
100005ac0: d370ff08    	lsr	x8, x24, #48
100005ac4: d360ff09    	lsr	x9, x24, #32
100005ac8: 7904cfe9    	strh	w9, [sp, #0x266]
100005acc: f90137e8    	str	x8, [sp, #0x268]
100005ad0: f9013bff    	str	xzr, [sp, #0x270]
100005ad4: 91056148    	add	x8, x10, #0x158
100005ad8: ad4207e0    	ldp	q0, q1, [sp, #0x40]
100005adc: ad000500    	stp	q0, q1, [x8]
100005ae0: 3dc01be0    	ldr	q0, [sp, #0x60]
100005ae4: 3d800900    	str	q0, [x8, #0x20]
100005ae8: f9403be8    	ldr	x8, [sp, #0x70]
100005aec: f9400ac9    	ldr	x9, [x22, #0x10]
100005af0: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
100005af4: 9107a7ea    	add	x10, sp, #0x1e9
100005af8: 3c8ff140    	stur	q0, [x10, #0xff]
100005afc: 9107e7ea    	add	x10, sp, #0x1f9
100005b00: 3c8ff141    	stur	q1, [x10, #0xff]
100005b04: f9015be8    	str	x8, [sp, #0x2b0]
100005b08: f9015ff3    	str	x19, [sp, #0x2b8]
100005b0c: 910967e8    	add	x8, sp, #0x259
100005b10: 3ccff100    	ldur	q0, [x8, #0xff]
100005b14: 9109a7e8    	add	x8, sp, #0x269
100005b18: 3ccff101    	ldur	q1, [x8, #0xff]
100005b1c: 9104e7e8    	add	x8, sp, #0x139
100005b20: 3c8ff100    	stur	q0, [x8, #0xff]
100005b24: 910527e8    	add	x8, sp, #0x149
100005b28: 3c8ff101    	stur	q1, [x8, #0xff]
100005b2c: f941bfe8    	ldr	x8, [sp, #0x378]
100005b30: f9012fe8    	str	x8, [sp, #0x258]
100005b34: 5280002a    	mov	w10, #0x1               ; =1
100005b38: 52800028    	mov	w8, #0x1                ; =1
100005b3c: f90007e8    	str	x8, [sp, #0x8]
100005b40: a912e3ea    	stp	x10, x24, [sp, #0x128]
100005b44: 52800048    	mov	w8, #0x2                ; =2
100005b48: a913a3f7    	stp	x23, x8, [sp, #0x138]
100005b4c: 9104a3f7    	add	x23, sp, #0x128
100005b50: 390c23fa    	strb	w26, [sp, #0x308]
100005b54: 910786e8    	add	x8, x23, #0x1e1
100005b58: 7900011f    	strh	wzr, [x8]
100005b5c: f90163fc    	str	x28, [sp, #0x2c0]
100005b60: f90167ff    	str	xzr, [sp, #0x2c8]
100005b64: 92800028    	mov	x8, #-0x2               ; =-2
100005b68: f90103e8    	str	x8, [sp, #0x200]
100005b6c: f9016ff9    	str	x25, [sp, #0x2d8]
100005b70: f90173e9    	str	x9, [sp, #0x2e0]
100005b74: 910d63e8    	add	x8, sp, #0x358
100005b78: 9104a3e0    	add	x0, sp, #0x128
100005b7c: 52800801    	mov	w1, #0x40               ; =64
100005b80: 9400dcfc    	bl	0x10003cf70 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_initial>
100005b84: f941afe8    	ldr	x8, [sp, #0x358]
100005b88: f100491f    	cmp	x8, #0x12
100005b8c: 54000361    	b.ne	0x100005bf8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x59c>
100005b90: 91020260    	add	x0, x19, #0x80
100005b94: 910562e2    	add	x2, x23, #0x158
100005b98: aa1603e1    	mov	x1, x22
100005b9c: 940017cd    	bl	0x10000bad0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
100005ba0: f94103e8    	ldr	x8, [sp, #0x200]
100005ba4: 92800029    	mov	x9, #-0x2               ; =-2
100005ba8: f90103e9    	str	x9, [sp, #0x200]
100005bac: b100091f    	cmn	x8, #0x2
100005bb0: 54000c40    	b.eq	0x100005d38 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6dc>
100005bb4: ad4706e0    	ldp	q0, q1, [x23, #0xe0]
100005bb8: 3c8182a0    	stur	q0, [x21, #0x18]
100005bbc: 3c8282a1    	stur	q1, [x21, #0x28]
100005bc0: 3dc042e0    	ldr	q0, [x23, #0x100]
100005bc4: 3c8382a0    	stur	q0, [x21, #0x38]
100005bc8: a900a2bf    	stp	xzr, x8, [x21, #0x8]
100005bcc: f90002bf    	str	xzr, [x21]
100005bd0: 9104a3e0    	add	x0, sp, #0x128
100005bd4: 94000d2a    	bl	0x10000907c <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005bd8: f9401fe8    	ldr	x8, [sp, #0x38]
100005bdc: f9400109    	ldr	x9, [x8]
100005be0: f1000529    	subs	x9, x9, #0x1
100005be4: f9000109    	str	x9, [x8]
100005be8: 540008c1    	b.ne	0x100005d00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6a4>
100005bec: 9100e3e0    	add	x0, sp, #0x38
100005bf0: 9401ccb8    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
100005bf4: 14000043    	b	0x100005d00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6a4>
100005bf8: 54000083    	b.lo	0x100005c08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x5ac>
100005bfc: 927f0d08    	and	x8, x8, #0x1e
100005c00: f100491f    	cmp	x8, #0x12
100005c04: 540000a0    	b.eq	0x100005c18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x5bc>
100005c08: 52800028    	mov	w8, #0x1                ; =1
100005c0c: f90007e8    	str	x8, [sp, #0x8]
100005c10: 910d63e0    	add	x0, sp, #0x358
100005c14: 9400123b    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005c18: f9401fe1    	ldr	x1, [sp, #0x38]
100005c1c: ad4407e0    	ldp	q0, q1, [sp, #0x80]
100005c20: ad000760    	stp	q0, q1, [x27]
100005c24: f94017e8    	ldr	x8, [sp, #0x28]
100005c28: f9019be8    	str	x8, [sp, #0x330]
100005c2c: f9400be8    	ldr	x8, [sp, #0x10]
100005c30: f9019fe8    	str	x8, [sp, #0x338]
100005c34: f90007ff    	str	xzr, [sp, #0x8]
100005c38: 910d63e8    	add	x8, sp, #0x358
100005c3c: 910c43e0    	add	x0, sp, #0x310
100005c40: 94008a2b    	bl	0x1000284ec <<raster::api::completion::Ticket<u64>>::pair_bounded>
100005c44: 910967e8    	add	x8, sp, #0x259
100005c48: 3ccff100    	ldur	q0, [x8, #0xff]
100005c4c: 9109a7e8    	add	x8, sp, #0x269
100005c50: 3ccff101    	ldur	q1, [x8, #0xff]
100005c54: ad000760    	stp	q0, q1, [x27]
100005c58: 9109e7e8    	add	x8, sp, #0x279
100005c5c: 3ccff100    	ldur	q0, [x8, #0xff]
100005c60: 910a27e8    	add	x8, sp, #0x289
100005c64: 3ccff101    	ldur	q1, [x8, #0xff]
100005c68: ad010760    	stp	q0, q1, [x27, #0x20]
100005c6c: 910a67e8    	add	x8, sp, #0x299
100005c70: 3ccff100    	ldur	q0, [x8, #0xff]
100005c74: 3d8007e0    	str	q0, [sp, #0x10]
100005c78: 910682e0    	add	x0, x23, #0x1a0
100005c7c: 940006f2    	bl	0x100007844 <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
100005c80: 3dc007e0    	ldr	q0, [sp, #0x10]
100005c84: 910727e8    	add	x8, sp, #0x1c9
100005c88: 3c8ff100    	stur	q0, [x8, #0xff]
100005c8c: 52800033    	mov	w19, #0x1               ; =1
100005c90: 910442e0    	add	x0, x23, #0x110
100005c94: 940237d8    	bl	0x100093bf4 <<raster::engine::metrics::Monitor>::pending>
100005c98: 910d63e0    	add	x0, sp, #0x358
100005c9c: 9104a3e1    	add	x1, sp, #0x128
100005ca0: 52803d02    	mov	w2, #0x1e8              ; =488
100005ca4: 940320e3    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
100005ca8: 52803d00    	mov	w0, #0x1e8              ; =488
100005cac: 94003c7f    	bl	0x100014ea8 <alloc::boxed::box_new_uninit>
100005cb0: aa0003f7    	mov	x23, x0
100005cb4: 910d63e1    	add	x1, sp, #0x358
100005cb8: 52803d02    	mov	w2, #0x1e8              ; =488
100005cbc: 940320dd    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
100005cc0: 52800013    	mov	w19, #0x0               ; =0
100005cc4: f0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
100005cc8: 9109a063    	add	x3, x3, #0x268
100005ccc: 910062c0    	add	x0, x22, #0x18
100005cd0: f94017e1    	ldr	x1, [sp, #0x28]
100005cd4: aa1703e2    	mov	x2, x23
100005cd8: 9400c9a5    	bl	0x10003836c <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
100005cdc: 52800013    	mov	w19, #0x0               ; =0
100005ce0: 94000688    	bl	0x100007700 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
100005ce4: ad400760    	ldp	q0, q1, [x27]
100005ce8: 3c8082a0    	stur	q0, [x21, #0x8]
100005cec: 3c8182a1    	stur	q1, [x21, #0x18]
100005cf0: ad410760    	ldp	q0, q1, [x27, #0x20]
100005cf4: 3c8282a0    	stur	q0, [x21, #0x28]
100005cf8: 3c8382a1    	stur	q1, [x21, #0x38]
100005cfc: f90002bf    	str	xzr, [x21]
100005d00: aa1403e0    	mov	x0, x20
100005d04: b94037e1    	ldr	w1, [sp, #0x34]
100005d08: 94000f48    	bl	0x100009a28 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100005d0c: 17fffe86    	b	0x100005724 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xc8>
100005d10: 94031e1b    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
100005d14: 3707dea0    	tbnz	w0, #0x0, 0x1000058e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x28c>
100005d18: 52800028    	mov	w8, #0x1                ; =1
100005d1c: 39002288    	strb	w8, [x20, #0x8]
100005d20: 17fffef2    	b	0x1000058e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x28c>
100005d24: 94031e16    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
100005d28: 3707d8c0    	tbnz	w0, #0x0, 0x100005840 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1e4>
100005d2c: 52800028    	mov	w8, #0x1                ; =1
100005d30: 39002268    	strb	w8, [x19, #0x8]
100005d34: 17fffec3    	b	0x100005840 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1e4>
100005d38: 52800028    	mov	w8, #0x1                ; =1
100005d3c: f90007e8    	str	x8, [sp, #0x8]
100005d40: b00006a0    	adrp	x0, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005d44: 91053400    	add	x0, x0, #0x14d
100005d48: f0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100005d4c: 91094042    	add	x2, x2, #0x250
100005d50: 528004c1    	mov	w1, #0x26               ; =38
100005d54: 94031f52    	bl	0x1000cda9c <core::option::expect_failed>
100005d58: d4200020    	brk	#0x1
100005d5c: f0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
100005d60: 9108e000    	add	x0, x0, #0x238
100005d64: 9403201b    	bl	0x1000cddd0 <core::panicking::panic_const::panic_const_rem_by_zero>
100005d68: 1400001f    	b	0x100005de4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x788>
100005d6c: aa0003f5    	mov	x21, x0
100005d70: 910d63e0    	add	x0, sp, #0x358
100005d74: 94000cc2    	bl	0x10000907c <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005d78: 52800013    	mov	w19, #0x0               ; =0
100005d7c: 14000009    	b	0x100005da0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x744>
100005d80: 94031f74    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>
100005d84: aa0003f5    	mov	x21, x0
100005d88: 3dc007e0    	ldr	q0, [sp, #0x10]
100005d8c: 910727e8    	add	x8, sp, #0x1c9
100005d90: 3c8ff100    	stur	q0, [x8, #0xff]
100005d94: 52800033    	mov	w19, #0x1               ; =1
100005d98: 14000002    	b	0x100005da0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x744>
100005d9c: aa0003f5    	mov	x21, x0
100005da0: 910c43e0    	add	x0, sp, #0x310
100005da4: 94000bf4    	bl	0x100008d74 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
100005da8: 360003f3    	tbz	w19, #0x0, 0x100005e24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7c8>
100005dac: 52800013    	mov	w19, #0x0               ; =0
100005db0: 14000013    	b	0x100005dfc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7a0>
100005db4: aa0003f5    	mov	x21, x0
100005db8: 9103e3e0    	add	x0, sp, #0xf8
100005dbc: 940011d1    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005dc0: 14000002    	b	0x100005dc8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x76c>
100005dc4: aa0003f5    	mov	x21, x0
100005dc8: 910283e0    	add	x0, sp, #0xa0
100005dcc: 9400094d    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005dd0: 1400000e    	b	0x100005e08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7ac>
100005dd4: aa0003f5    	mov	x21, x0
100005dd8: 910323e0    	add	x0, sp, #0xc8
100005ddc: 940011c9    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005de0: 1400000a    	b	0x100005e08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7ac>
100005de4: aa0003f5    	mov	x21, x0
100005de8: 14000008    	b	0x100005e08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7ac>
100005dec: aa0003f5    	mov	x21, x0
100005df0: 1400000d    	b	0x100005e24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7c8>
100005df4: f94007f3    	ldr	x19, [sp, #0x8]
100005df8: aa0003f5    	mov	x21, x0
100005dfc: 9104a3e0    	add	x0, sp, #0x128
100005e00: 94000c9f    	bl	0x10000907c <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005e04: 36000113    	tbz	w19, #0x0, 0x100005e24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7c8>
100005e08: f9401fe8    	ldr	x8, [sp, #0x38]
100005e0c: f9400109    	ldr	x9, [x8]
100005e10: f1000529    	subs	x9, x9, #0x1
100005e14: f9000109    	str	x9, [x8]
100005e18: 54000061    	b.ne	0x100005e24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x7c8>
100005e1c: 9100e3e0    	add	x0, sp, #0x38
100005e20: 9401cc2c    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
100005e24: aa1403e0    	mov	x0, x20
100005e28: b94037e1    	ldr	w1, [sp, #0x34]
100005e2c: 94000eff    	bl	0x100009a28 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100005e30: aa1503e0    	mov	x0, x21
100005e34: 94032028    	bl	0x1000cded4 <dyld_stub_binder+0x1000cded4>
100005e38: 94031f46    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>

