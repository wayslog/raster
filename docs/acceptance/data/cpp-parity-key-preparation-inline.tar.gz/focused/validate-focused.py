"""Revalidate focused measurements, source identity, and completed checks."""
from pathlib import Path
import hashlib,json,re,statistics,sys
sys.path.insert(0,'tools/performance')
from cpu_profile import validate_output
from compare_result_budget import validate_output as budget_output
from focused_compare import LABELS,ORDERS,summarize
from compare_repeat import validate as repeat_validate,KINDS
root=Path('target/parity-profile/key-preparation-inline')
base=Path('target/parity-profile/read-inline-access/candidate-bins')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert Path('src/schema/builtin.rs').read_bytes()==(root/'candidate-builtin.rs').read_bytes()
assert Path('src/schema/encoded_key.rs').read_bytes()==(root/'candidate-encoded_key.rs').read_bytes()
for name,digest in read(root/'binary-sha256.json').items():assert sha(root/'candidate-bins'/name)==digest
log=(root/'tests.log').read_text()
counts=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',log)
assert sum(map(int,counts))==550
assert not re.search(r'^error(?:\[[^]]+\])?:|^test result: FAILED',log,re.M)
for name in ['clippy','rustdoc']:
 text=(root/(name+'.log')).read_text();assert 'Finished ' in text and not re.search(r'^error(?:\[[^]]+\])?:',text,re.M)
ordinary=0
for run in read(root/'runs.json'):
 name=run['name']
 if name in ['result-budget','variable']:continue
 directory=root/name;env=read(directory/'environment.json');rows=read(directory/'comparison.json');assert len(rows)==1
 assert env['binary_sha256']['baseline']==sha(base/'parity')
 assert env['binary_sha256']['rust']==sha((base if name.startswith('control') else root/'candidate-bins')/'parity')
 row=rows[0];case=row['case'];threads=int(case.split('/')[-1]);n=env['count']//threads
 samples=threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
 for label in ['baseline','rust']:
  for index in range(-1,env['rounds']):
   prefix=directory/f"{case.replace('/','-')}-{index}-{label}"
   raw=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,env['count']);assert raw['samples']==samples
   assert not prefix.with_suffix('.stderr').read_text()
   if index>=0:assert raw==row['rows'][label][index]
   ordinary+=1
 med=lambda label,key:statistics.median(r[key] for r in row['rows'][label])
 t=med('baseline','elapsed_ns')/med('rust','elapsed_ns');p=med('rust','p99_ns')/med('baseline','p99_ns')
 assert row['throughput_ratio']==t and row['p99_ratio']==p and row['passed']==(t>=.98 and p<=1.1)
budget=0;directory=root/'result-budget';env=read(directory/'environment.json')
assert env['binary_sha256']['baseline']==env['binary_sha256']['control']==sha(base/'result_budget')
assert env['binary_sha256']['candidate']==sha(root/'candidate-bins/result_budget')
for retained in env['retained']:
 d=directory/f'retained-{retained}';entries=[]
 for index,order in [(-1,LABELS),*enumerate(ORDERS)]:
  for label in order:
   prefix=d/f'round-{index}-{label}'
   raw=budget_output(prefix.with_suffix('.stdout').read_text(),retained,env['count']);assert not prefix.with_suffix('.stderr').read_text()
   if index>=0:entries.append({'round':index,'name':label,'result':raw})
   budget+=1
 assert entries==read(d/'results.json')
 result=summarize(entries);result.update(scope='Retained-result Rust diagnostic, not complete C++ acceptance',retained=retained)
 assert result==read(d/'comparison.json')
directory=root/'variable';env=read(directory/'environment.json');pairs=read(directory/'pairs.json');assert len(pairs)==6
assert env['binary_sha256']['baseline']==env['binary_sha256']['control']==sha(base/'benchmark_probe')
assert env['binary_sha256']['candidate']==sha(root/'candidate-bins/benchmark_probe')
for number,pair in enumerate(pairs):
 assert pair['order']==env['orders'][number]
 for label in LABELS:assert repeat_validate(directory/f'pair{number}-{label}',env['repetitions'])==pair['samples'][label]
medians={label:{'elapsed_ns':statistics.median(p['samples'][label]['elapsed_ns'] for p in pairs),'overall_p99_ns':statistics.median(p['samples'][label]['overall_p99_ns'] for p in pairs),'engine_ns':[statistics.median(p['samples'][label]['engine_ns'][i] for p in pairs) for i in range(4)]} for label in LABELS}
result=read(directory/'comparison.json');assert medians==result['medians']
for label in ['candidate','control']:
 t=medians['baseline']['elapsed_ns']/medians[label]['elapsed_ns'];p=medians[label]['overall_p99_ns']/medians['baseline']['overall_p99_ns']
 assert result['comparisons'][label]=={'throughput_ratio':t,'p99_ratio':p,'passed':t>=.98 and p<=1.1,'operation_time_ratios':{kind:medians[label]['engine_ns'][i]/medians['baseline']['engine_ns'][i] for i,kind in enumerate(KINDS)}}
summary={'ordinary_outputs':ordinary,'result_budget_outputs':budget,'variable_processes':18,'variable_trajectories':18*env['repetitions'],'tests_passed':550,'clippy':'passed','strict_rustdoc':'passed','fmt':'passed in fresh follow-up check','source_and_binary_identity':'verified','status':'Measurements verified; failed and invalid-control gates retained. Full parity not established.'}
assert ordinary==110 and budget==63
(root/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
