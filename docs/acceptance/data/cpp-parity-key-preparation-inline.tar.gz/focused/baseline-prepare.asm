0000000100004d40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>>:
100004d40: d10443ff    	sub	sp, sp, #0x110
100004d44: a90c67fa    	stp	x26, x25, [sp, #0xc0]
100004d48: a90d5ff8    	stp	x24, x23, [sp, #0xd0]
100004d4c: a90e57f6    	stp	x22, x21, [sp, #0xe0]
100004d50: a90f4ff4    	stp	x20, x19, [sp, #0xf0]
100004d54: a9107bfd    	stp	x29, x30, [sp, #0x100]
100004d58: 910403fd    	add	x29, sp, #0x100
100004d5c: 3943a048    	ldrb	w8, [x2, #0xe8]
100004d60: 370000a8    	tbnz	w8, #0x0, 0x100004d74 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x34>
100004d64: 52837508    	mov	w8, #0x1ba8             ; =7080
100004d68: 8b080036    	add	x22, x1, x8
100004d6c: 08dffec8    	ldarb	w8, [x22]
100004d70: 340001c8    	cbz	w8, 0x100004da8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x68>
100004d74: 528000e8    	mov	w8, #0x7                ; =7
100004d78: d00006a9    	adrp	x9, 0x1000da000 <GCC_except_table9+0x10>
100004d7c: 91139929    	add	x9, x9, #0x4e6
100004d80: a9002408    	stp	x8, x9, [x0]
100004d84: 528003e8    	mov	w8, #0x1f               ; =31
100004d88: f9000808    	str	x8, [x0, #0x10]
100004d8c: a9507bfd    	ldp	x29, x30, [sp, #0x100]
100004d90: a94f4ff4    	ldp	x20, x19, [sp, #0xf0]
100004d94: a94e57f6    	ldp	x22, x21, [sp, #0xe0]
100004d98: a94d5ff8    	ldp	x24, x23, [sp, #0xd0]
100004d9c: a94c67fa    	ldp	x26, x25, [sp, #0xc0]
100004da0: 910443ff    	add	sp, sp, #0x110
100004da4: d65f03c0    	ret
100004da8: a9402448    	ldp	x8, x9, [x2]
100004dac: f100051f    	cmp	x8, #0x1
100004db0: fa490062    	ccmp	x3, x9, #0x2, eq
100004db4: 54000449    	b.ls	0x100004e3c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0xfc>
100004db8: aa0003f5    	mov	x21, x0
100004dbc: f9426039    	ldr	x25, [x1, #0x4c0]
100004dc0: 91004320    	add	x0, x25, #0x10
100004dc4: aa0403f4    	mov	x20, x4
100004dc8: aa0403e1    	mov	x1, x4
100004dcc: 9401fa50    	bl	0x10008370c <<raster::schema::builtin::U64Key as raster::schema::key::KeyCodec>::hash>
100004dd0: aa0003f3    	mov	x19, x0
100004dd4: d101c3a8    	sub	x8, x29, #0x70
100004dd8: 52800100    	mov	w0, #0x8                ; =8
100004ddc: 9401ffb0    	bl	0x100084c9c <<raster::schema::encoded_key::EncodedKey>::zeroed>
100004de0: a97963b7    	ldp	x23, x24, [x29, #-0x70]
100004de4: 3cda03a0    	ldur	q0, [x29, #-0x60]
100004de8: 3d801fe0    	str	q0, [sp, #0x70]
100004dec: f85b03a8    	ldur	x8, [x29, #-0x50]
100004df0: f90043e8    	str	x8, [sp, #0x80]
100004df4: b10006ff    	cmn	x23, #0x1
100004df8: 540002e0    	b.eq	0x100004e54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x114>
100004dfc: f85b83b4    	ldur	x20, [x29, #-0x48]
100004e00: 3dc01fe0    	ldr	q0, [sp, #0x70]
100004e04: 3d800fe0    	str	q0, [sp, #0x30]
100004e08: f94043e8    	ldr	x8, [sp, #0x80]
100004e0c: f90023e8    	str	x8, [sp, #0x40]
100004e10: aa1503e8    	mov	x8, x21
100004e14: f94023e9    	ldr	x9, [sp, #0x40]
100004e18: 3dc00fe0    	ldr	q0, [sp, #0x30]
100004e1c: 3d8007e0    	str	q0, [sp, #0x10]
100004e20: a90063f7    	stp	x23, x24, [sp]
100004e24: a90253e9    	stp	x9, x20, [sp, #0x20]
100004e28: 3dc003e1    	ldr	q1, [sp]
100004e2c: 3dc00be2    	ldr	q2, [sp, #0x20]
100004e30: ad000101    	stp	q1, q0, [x8]
100004e34: 3d800902    	str	q2, [x8, #0x20]
100004e38: 17ffffd5    	b	0x100004d8c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x4c>
100004e3c: 528000e8    	mov	w8, #0x7                ; =7
100004e40: d00006a9    	adrp	x9, 0x1000da000 <GCC_except_table9+0x10>
100004e44: 9112fd29    	add	x9, x9, #0x4bf
100004e48: a9002408    	stp	x8, x9, [x0]
100004e4c: 528004e8    	mov	w8, #0x27               ; =39
100004e50: 17ffffce    	b	0x100004d88 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x48>
100004e54: f9002bf8    	str	x24, [sp, #0x50]
100004e58: 3dc01fe0    	ldr	q0, [sp, #0x70]
100004e5c: 3c8583e0    	stur	q0, [sp, #0x58]
100004e60: f94043e8    	ldr	x8, [sp, #0x80]
100004e64: f90037e8    	str	x8, [sp, #0x68]
100004e68: 910143e0    	add	x0, sp, #0x50
100004e6c: 94020d4b    	bl	0x100088398 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::DerefMut>::deref_mut>
100004e70: aa0003e2    	mov	x2, x0
100004e74: aa0103e3    	mov	x3, x1
100004e78: d101c3a8    	sub	x8, x29, #0x70
100004e7c: 91004320    	add	x0, x25, #0x10
100004e80: aa1403e1    	mov	x1, x20
100004e84: 9401fa41    	bl	0x100083788 <<raster::schema::builtin::U64Key as raster::schema::key::KeyCodec>::encode>
100004e88: f85903b7    	ldur	x23, [x29, #-0x70]
100004e8c: b10006ff    	cmn	x23, #0x1
100004e90: aa1503e8    	mov	x8, x21
100004e94: 540001c0    	b.eq	0x100004ecc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x18c>
100004e98: f85983b8    	ldur	x24, [x29, #-0x68]
100004e9c: 3cda03a0    	ldur	q0, [x29, #-0x60]
100004ea0: 3d800fe0    	str	q0, [sp, #0x30]
100004ea4: a97b53a9    	ldp	x9, x20, [x29, #-0x50]
100004ea8: f90023e9    	str	x9, [sp, #0x40]
100004eac: 394143e9    	ldrb	w9, [sp, #0x50]
100004eb0: 34fffb29    	cbz	w9, 0x100004e14 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0xd4>
100004eb4: f9402fe1    	ldr	x1, [sp, #0x58]
100004eb8: b4fffae1    	cbz	x1, 0x100004e14 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0xd4>
100004ebc: f94033e0    	ldr	x0, [sp, #0x60]
100004ec0: 52800022    	mov	w2, #0x1                ; =1
100004ec4: 9401295a    	bl	0x10004f42c <__rustc::__rust_dealloc>
100004ec8: 17ffffd2    	b	0x100004e10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0xd0>
100004ecc: 3dc017e0    	ldr	q0, [sp, #0x50]
100004ed0: 3d800fe0    	str	q0, [sp, #0x30]
100004ed4: a94653e9    	ldp	x9, x20, [sp, #0x60]
100004ed8: f90023e9    	str	x9, [sp, #0x40]
100004edc: aa1303f8    	mov	x24, x19
100004ee0: 17ffffcd    	b	0x100004e14 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0xd4>
100004ee4: aa0003f3    	mov	x19, x0
100004ee8: 394143e8    	ldrb	w8, [sp, #0x50]
100004eec: 34000108    	cbz	w8, 0x100004f0c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x1cc>
100004ef0: f9402fe1    	ldr	x1, [sp, #0x58]
100004ef4: b40000c1    	cbz	x1, 0x100004f0c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x1cc>
100004ef8: f94033e0    	ldr	x0, [sp, #0x60]
100004efc: 52800022    	mov	w2, #0x1                ; =1
100004f00: 9401294b    	bl	0x10004f42c <__rustc::__rust_dealloc>
100004f04: 14000002    	b	0x100004f0c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x1cc>
100004f08: aa0003f3    	mov	x19, x0
100004f0c: aa1303e0    	mov	x0, x19
100004f10: 940322be    	bl	0x1000cda08 <std::panicking::catch_unwind::cleanup>
100004f14: a90087e0    	stp	x0, x1, [sp, #0x8]
100004f18: 92800028    	mov	x8, #-0x2               ; =-2
100004f1c: f90003e8    	str	x8, [sp]
100004f20: 52800028    	mov	w8, #0x1                ; =1
100004f24: 089ffec8    	stlrb	w8, [x22]
100004f28: 528000e8    	mov	w8, #0x7                ; =7
100004f2c: d00006a9    	adrp	x9, 0x1000da000 <GCC_except_table9+0x10>
100004f30: 91128129    	add	x9, x9, #0x4a0
100004f34: a90026a8    	stp	x8, x9, [x21]
100004f38: 528003e8    	mov	w8, #0x1f               ; =31
100004f3c: f9000aa8    	str	x8, [x21, #0x10]
100004f40: 910003e0    	mov	x0, sp
100004f44: 94000f1c    	bl	0x100008bb4 <core::ptr::drop_glue::<core::result::Result<core::result::Result<(raster::types::id::KeyHash, raster::schema::encoded_key::EncodedKey), raster::types::error::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
100004f48: 17ffff91    	b	0x100004d8c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x4c>
100004f4c: 9403242b    	bl	0x1000cdff8 <core::panicking::panic_cannot_unwind>

