0000000100004d40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>>:
100004d40: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100004d44: a90167fa    	stp	x26, x25, [sp, #0x10]
100004d48: a9025ff8    	stp	x24, x23, [sp, #0x20]
100004d4c: a90357f6    	stp	x22, x21, [sp, #0x30]
100004d50: a9044ff4    	stp	x20, x19, [sp, #0x40]
100004d54: a9057bfd    	stp	x29, x30, [sp, #0x50]
100004d58: 910143fd    	add	x29, sp, #0x50
100004d5c: d11cc3ff    	sub	sp, sp, #0x730
100004d60: f90003ff    	str	xzr, [sp]
100004d64: aa0703f9    	mov	x25, x7
100004d68: aa0603fa    	mov	x26, x6
100004d6c: aa0503fb    	mov	x27, x5
100004d70: aa0403f7    	mov	x23, x4
100004d74: aa0303f8    	mov	x24, x3
100004d78: aa0203f3    	mov	x19, x2
100004d7c: aa0103f6    	mov	x22, x1
100004d80: aa0003fc    	mov	x28, x0
100004d84: aa0803f5    	mov	x21, x8
100004d88: f9400014    	ldr	x20, [x0]
100004d8c: 9114e3e8    	add	x8, sp, #0x538
100004d90: 91020280    	add	x0, x20, #0x80
100004d94: 94002192    	bl	0x10000d3dc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
100004d98: f9429fe8    	ldr	x8, [sp, #0x538]
100004d9c: b100051f    	cmn	x8, #0x1
100004da0: 540001c0    	b.eq	0x100004dd8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x98>
100004da4: 9114e3e9    	add	x9, sp, #0x538
100004da8: 395503ea    	ldrb	w10, [sp, #0x540]
100004dac: 3cc09120    	ldur	q0, [x9, #0x9]
100004db0: 3c8112a0    	stur	q0, [x21, #0x11]
100004db4: 3cc19120    	ldur	q0, [x9, #0x19]
100004db8: 3c8212a0    	stur	q0, [x21, #0x21]
100004dbc: f942b3e9    	ldr	x9, [sp, #0x560]
100004dc0: 390042aa    	strb	w10, [x21, #0x10]
100004dc4: a90362a9    	stp	x9, x24, [x21, #0x30]
100004dc8: f90022b7    	str	x23, [x21, #0x40]
100004dcc: 52800029    	mov	w9, #0x1                ; =1
100004dd0: a90022a9    	stp	x9, x8, [x21]
100004dd4: 14000011    	b	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
100004dd8: 3943a2c8    	ldrb	w8, [x22, #0xe8]
100004ddc: 370000c8    	tbnz	w8, #0x0, 0x100004df4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xb4>
100004de0: 395507e8    	ldrb	w8, [sp, #0x541]
100004de4: 52838509    	mov	w9, #0x1c28             ; =7208
100004de8: 8b090289    	add	x9, x20, x9
100004dec: 08dffd29    	ldarb	w9, [x9]
100004df0: 34000249    	cbz	w9, 0x100004e38 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xf8>
100004df4: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004df8: 91041d08    	add	x8, x8, #0x107
100004dfc: 528003e9    	mov	w9, #0x1f               ; =31
100004e00: a90126a8    	stp	x8, x9, [x21, #0x10]
100004e04: f90016bf    	str	xzr, [x21, #0x28]
100004e08: a903deb8    	stp	x24, x23, [x21, #0x38]
100004e0c: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004e10: 3dc01900    	ldr	q0, [x8, #0x60]
100004e14: 3d8002a0    	str	q0, [x21]
100004e18: 911cc3ff    	add	sp, sp, #0x730
100004e1c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100004e20: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100004e24: a94357f6    	ldp	x22, x21, [sp, #0x30]
100004e28: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100004e2c: a94167fa    	ldp	x26, x25, [sp, #0x10]
100004e30: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100004e34: d65f03c0    	ret
100004e38: f94002c9    	ldr	x9, [x22]
100004e3c: f100053f    	cmp	x9, #0x1
100004e40: 54000101    	b.ne	0x100004e60 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x120>
100004e44: f94006c9    	ldr	x9, [x22, #0x8]
100004e48: eb09027f    	cmp	x19, x9
100004e4c: 540000a8    	b.hi	0x100004e60 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x120>
100004e50: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004e54: 91038108    	add	x8, x8, #0xe0
100004e58: 528004e9    	mov	w9, #0x27               ; =39
100004e5c: 17ffffe9    	b	0x100004e00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xc0>
100004e60: f9407289    	ldr	x9, [x20, #0xe0]
100004e64: b4003869    	cbz	x9, 0x100005570 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x830>
100004e68: 92401f0a    	and	x10, x24, #0xff
100004e6c: d28464ab    	mov	x11, #0x2325            ; =8997
100004e70: f2b0844b    	movk	x11, #0x8422, lsl #16
100004e74: f2d39c8b    	movk	x11, #0x9ce4, lsl #32
100004e78: f2f97e4b    	movk	x11, #0xcbf2, lsl #48
100004e7c: ca0b014a    	eor	x10, x10, x11
100004e80: d280366b    	mov	x11, #0x1b3             ; =435
100004e84: f2c0200b    	movk	x11, #0x100, lsl #32
100004e88: 9b0b7d4a    	mul	x10, x10, x11
100004e8c: d3483f0c    	ubfx	x12, x24, #8, #8
100004e90: ca0c014a    	eor	x10, x10, x12
100004e94: 9b0b7d4a    	mul	x10, x10, x11
100004e98: d3505f0c    	ubfx	x12, x24, #16, #8
100004e9c: ca0c014a    	eor	x10, x10, x12
100004ea0: 9b0b7d4a    	mul	x10, x10, x11
100004ea4: 53187f0c    	lsr	w12, w24, #24
100004ea8: ca0c014a    	eor	x10, x10, x12
100004eac: 9b0b7d4a    	mul	x10, x10, x11
100004eb0: d3609f0c    	ubfx	x12, x24, #32, #8
100004eb4: ca0c014a    	eor	x10, x10, x12
100004eb8: 9b0b7d4a    	mul	x10, x10, x11
100004ebc: d368bf0c    	ubfx	x12, x24, #40, #8
100004ec0: ca0c014a    	eor	x10, x10, x12
100004ec4: 9b0b7d4a    	mul	x10, x10, x11
100004ec8: d370df0c    	ubfx	x12, x24, #48, #8
100004ecc: ca0c014a    	eor	x10, x10, x12
100004ed0: 9b0b7d4a    	mul	x10, x10, x11
100004ed4: ca58e14a    	eor	x10, x10, x24, lsr #56
100004ed8: 9b0b7d4c    	mul	x12, x10, x11
100004edc: f9406e8a    	ldr	x10, [x20, #0xd8]
100004ee0: 9ac9098b    	udiv	x11, x12, x9
100004ee4: f9001bec    	str	x12, [sp, #0x30]
100004ee8: 9b09b169    	msub	x9, x11, x9, x12
100004eec: 8b091141    	add	x1, x10, x9, lsl #4
100004ef0: 360000e8    	tbz	w8, #0x0, 0x100004f0c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x1cc>
100004ef4: 39402028    	ldrb	w8, [x1, #0x8]
100004ef8: 340003e8    	cbz	w8, 0x100004f74 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x234>
100004efc: a903deb8    	stp	x24, x23, [x21, #0x38]
100004f00: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004f04: 3dc01500    	ldr	q0, [x8, #0x50]
100004f08: 17ffffc3    	b	0x100004e14 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd4>
100004f0c: 9114e3e0    	add	x0, sp, #0x538
100004f10: 94003ff5    	bl	0x100014ee4 <raster::engine::operation_gate::try_lock>
100004f14: b9453be8    	ldr	w8, [sp, #0x538]
100004f18: 36000248    	tbz	w8, #0x0, 0x100004f60 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x220>
100004f1c: a903deb8    	stp	x24, x23, [x21, #0x38]
100004f20: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004f24: 3dc01500    	ldr	q0, [x8, #0x50]
100004f28: 3d8002a0    	str	q0, [x21]
100004f2c: 395523e8    	ldrb	w8, [sp, #0x548]
100004f30: 7100091f    	cmp	w8, #0x2
100004f34: 54fff720    	b.eq	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
100004f38: f942a3f3    	ldr	x19, [sp, #0x540]
100004f3c: 370000c8    	tbnz	w8, #0x0, 0x100004f54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x214>
100004f40: 900008a8    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100004f44: 91394108    	add	x8, x8, #0xe50
100004f48: f9400108    	ldr	x8, [x8]
100004f4c: f240f91f    	tst	x8, #0x7fffffffffffffff
100004f50: 54002c41    	b.ne	0x1000054d8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x798>
100004f54: f9400260    	ldr	x0, [x19]
100004f58: 94027cad    	bl	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100004f5c: 17ffffaf    	b	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
100004f60: f942a3e8    	ldr	x8, [sp, #0x540]
100004f64: f90013e8    	str	x8, [sp, #0x20]
100004f68: 395523e8    	ldrb	w8, [sp, #0x548]
100004f6c: b9002fe8    	str	w8, [sp, #0x2c]
100004f70: 14000003    	b	0x100004f7c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x23c>
100004f74: 52800048    	mov	w8, #0x2                ; =2
100004f78: b9002fe8    	str	w8, [sp, #0x2c]
100004f7c: aa1603e0    	mov	x0, x22
100004f80: 94015ebb    	bl	0x10005ca6c <<raster::engine::pending::SessionRuntime>::pending>
100004f84: f940fa88    	ldr	x8, [x20, #0x1f0]
100004f88: eb08001f    	cmp	x0, x8
100004f8c: 540002a2    	b.hs	0x100004fe0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2a0>
100004f90: f940fe81    	ldr	x1, [x20, #0x1f8]
100004f94: 9114e3e8    	add	x8, sp, #0x538
100004f98: aa1603e0    	mov	x0, x22
100004f9c: 94015d51    	bl	0x10005c4e0 <<raster::engine::pending::SessionRuntime>::reserve_result>
100004fa0: f9429fe8    	ldr	x8, [sp, #0x538]
100004fa4: b100051f    	cmn	x8, #0x1
100004fa8: 540003e0    	b.eq	0x100005024 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2e4>
100004fac: 9110e7e8    	add	x8, sp, #0x439
100004fb0: 3ccff100    	ldur	q0, [x8, #0xff]
100004fb4: 911127e8    	add	x8, sp, #0x449
100004fb8: 3ccff101    	ldur	q1, [x8, #0xff]
100004fbc: 3c8082a0    	stur	q0, [x21, #0x8]
100004fc0: 3c8182a1    	stur	q1, [x21, #0x18]
100004fc4: 911167e8    	add	x8, sp, #0x459
100004fc8: 3ccff100    	ldur	q0, [x8, #0xff]
100004fcc: 3c8282a0    	stur	q0, [x21, #0x28]
100004fd0: a903deb8    	stp	x24, x23, [x21, #0x38]
100004fd4: 52800028    	mov	w8, #0x1                ; =1
100004fd8: f90002a8    	str	x8, [x21]
100004fdc: 14000005    	b	0x100004ff0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2b0>
100004fe0: a903deb8    	stp	x24, x23, [x21, #0x38]
100004fe4: d00006a8    	adrp	x8, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100004fe8: 3dc01500    	ldr	q0, [x8, #0x50]
100004fec: 3d8002a0    	str	q0, [x21]
100004ff0: b9402fe8    	ldr	w8, [sp, #0x2c]
100004ff4: 7100091f    	cmp	w8, #0x2
100004ff8: 54fff100    	b.eq	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
100004ffc: 370000c8    	tbnz	w8, #0x0, 0x100005014 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2d4>
100005000: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100005004: 91394108    	add	x8, x8, #0xe50
100005008: f9400108    	ldr	x8, [x8]
10000500c: f240f91f    	tst	x8, #0x7fffffffffffffff
100005010: 54002581    	b.ne	0x1000054c0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x780>
100005014: f94013e8    	ldr	x8, [sp, #0x20]
100005018: f9400100    	ldr	x0, [x8]
10000501c: 94027c7c    	bl	0x1000a420c <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100005020: 17ffff7e    	b	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
100005024: f942a3e8    	ldr	x8, [sp, #0x540]
100005028: f9001fe8    	str	x8, [sp, #0x38]
10000502c: 9114e3e0    	add	x0, sp, #0x538
100005030: 91020281    	add	x1, x20, #0x80
100005034: aa1603e2    	mov	x2, x22
100005038: 94001ad7    	bl	0x10000bb94 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
10000503c: 3955a7e8    	ldrb	w8, [sp, #0x569]
100005040: 7100091f    	cmp	w8, #0x2
100005044: 54000141    	b.ne	0x10000506c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x32c>
100005048: 9110e7e8    	add	x8, sp, #0x439
10000504c: 3ccff100    	ldur	q0, [x8, #0xff]
100005050: 911127e8    	add	x8, sp, #0x449
100005054: 3ccff101    	ldur	q1, [x8, #0xff]
100005058: 3c8082a0    	stur	q0, [x21, #0x8]
10000505c: 3c8182a1    	stur	q1, [x21, #0x18]
100005060: 911167e8    	add	x8, sp, #0x459
100005064: 3ccff100    	ldur	q0, [x8, #0xff]
100005068: 14000025    	b	0x1000050fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x3bc>
10000506c: 911167e8    	add	x8, sp, #0x459
100005070: 3ccff102    	ldur	q2, [x8, #0xff]
100005074: 9110e7e8    	add	x8, sp, #0x439
100005078: 3ccff100    	ldur	q0, [x8, #0xff]
10000507c: 911127e8    	add	x8, sp, #0x449
100005080: 3ccff101    	ldur	q1, [x8, #0xff]
100005084: 3d8013e0    	str	q0, [sp, #0x40]
100005088: ad028be1    	stp	q1, q2, [sp, #0x50]
10000508c: f942b7e8    	ldr	x8, [sp, #0x568]
100005090: f9003be8    	str	x8, [sp, #0x70]
100005094: ad0407e0    	stp	q0, q1, [sp, #0x80]
100005098: a94623e9    	ldp	x9, x8, [sp, #0x60]
10000509c: a90127e8    	stp	x8, x9, [sp, #0x10]
1000050a0: f9400ac2    	ldr	x2, [x22, #0x10]
1000050a4: 910323e8    	add	x8, sp, #0xc8
1000050a8: 910d0280    	add	x0, x20, #0x340
1000050ac: f9401be1    	ldr	x1, [sp, #0x30]
1000050b0: 9401668b    	bl	0x10005eadc <<raster::engine::version_permit::VersionPermits>::reserve_initial>
1000050b4: f94067e8    	ldr	x8, [sp, #0xc8]
1000050b8: b100051f    	cmn	x8, #0x1
1000050bc: 54000380    	b.eq	0x10000512c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x3ec>
1000050c0: f9418689    	ldr	x9, [x20, #0x308]
1000050c4: 9114e3e8    	add	x8, sp, #0x538
1000050c8: 91004120    	add	x0, x9, #0x10
1000050cc: 910103e1    	add	x1, sp, #0x40
1000050d0: 940232c2    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
1000050d4: f9429fe8    	ldr	x8, [sp, #0x538]
1000050d8: b100051f    	cmn	x8, #0x1
1000050dc: 54000060    	b.eq	0x1000050e8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x3a8>
1000050e0: 9114e3e0    	add	x0, sp, #0x538
1000050e4: 94001507    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000050e8: 3ccc83e0    	ldur	q0, [sp, #0xc8]
1000050ec: 3ccd83e1    	ldur	q1, [sp, #0xd8]
1000050f0: 3c8082a0    	stur	q0, [x21, #0x8]
1000050f4: 3c8182a1    	stur	q1, [x21, #0x18]
1000050f8: 3cce83e0    	ldur	q0, [sp, #0xe8]
1000050fc: 3c8282a0    	stur	q0, [x21, #0x28]
100005100: a903deb8    	stp	x24, x23, [x21, #0x38]
100005104: 52800028    	mov	w8, #0x1                ; =1
100005108: f90002a8    	str	x8, [x21]
10000510c: f9401fe8    	ldr	x8, [sp, #0x38]
100005110: f9400109    	ldr	x9, [x8]
100005114: f1000529    	subs	x9, x9, #0x1
100005118: f9000109    	str	x9, [x8]
10000511c: 54fff6a1    	b.ne	0x100004ff0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2b0>
100005120: 9100e3e0    	add	x0, sp, #0x38
100005124: 9401cf6b    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
100005128: 17ffffb2    	b	0x100004ff0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2b0>
10000512c: 910323e8    	add	x8, sp, #0xc8
100005130: 3cc08100    	ldur	q0, [x8, #0x8]
100005134: 3cc18101    	ldur	q1, [x8, #0x18]
100005138: ad0507e0    	stp	q0, q1, [sp, #0xa0]
10000513c: 9103e3e0    	add	x0, sp, #0xf8
100005140: 91020281    	add	x1, x20, #0x80
100005144: aa1603e2    	mov	x2, x22
100005148: aa1303e3    	mov	x3, x19
10000514c: 94001adb    	bl	0x10000bcb8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
100005150: f9407fe8    	ldr	x8, [sp, #0xf8]
100005154: b100051f    	cmn	x8, #0x1
100005158: 54000320    	b.eq	0x1000051bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x47c>
10000515c: f9418689    	ldr	x9, [x20, #0x308]
100005160: 9114e3e8    	add	x8, sp, #0x538
100005164: 91004120    	add	x0, x9, #0x10
100005168: 910103e1    	add	x1, sp, #0x40
10000516c: 9402329b    	bl	0x100091bd8 <<raster::engine::io_hub::CompletionHub>::release_operation>
100005170: f9429fe8    	ldr	x8, [sp, #0x538]
100005174: b100051f    	cmn	x8, #0x1
100005178: 54000060    	b.eq	0x100005184 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x444>
10000517c: 9114e3e0    	add	x0, sp, #0x538
100005180: 940014e0    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005184: 3ccf83e0    	ldur	q0, [sp, #0xf8]
100005188: 910027e8    	add	x8, sp, #0x9
10000518c: 3ccff101    	ldur	q1, [x8, #0xff]
100005190: 3c8082a0    	stur	q0, [x21, #0x8]
100005194: 3c8182a1    	stur	q1, [x21, #0x18]
100005198: 910067e8    	add	x8, sp, #0x19
10000519c: 3ccff100    	ldur	q0, [x8, #0xff]
1000051a0: 3c8282a0    	stur	q0, [x21, #0x28]
1000051a4: a903deb8    	stp	x24, x23, [x21, #0x38]
1000051a8: 52800028    	mov	w8, #0x1                ; =1
1000051ac: f90002a8    	str	x8, [x21]
1000051b0: 910283e0    	add	x0, sp, #0xa0
1000051b4: 94000c53    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
1000051b8: 17ffffd5    	b	0x10000510c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x3cc>
1000051bc: 910d43e8    	add	x8, sp, #0x350
1000051c0: 910342c0    	add	x0, x22, #0xd0
1000051c4: 52800001    	mov	w1, #0x0                ; =0
1000051c8: 94023950    	bl	0x100093708 <<raster::engine::metrics::Tracker>::accept>
1000051cc: 52810008    	mov	w8, #0x800              ; =2048
1000051d0: 7904c3e8    	strh	w8, [sp, #0x260]
1000051d4: 9104a3ea    	add	x10, sp, #0x128
1000051d8: 9104e948    	add	x8, x10, #0x13a
1000051dc: b9000118    	str	w24, [x8]
1000051e0: 910c43eb    	add	x11, sp, #0x310
1000051e4: d360ff08    	lsr	x8, x24, #32
1000051e8: 7904cfe8    	strh	w8, [sp, #0x266]
1000051ec: d370ff08    	lsr	x8, x24, #48
1000051f0: f90137e8    	str	x8, [sp, #0x268]
1000051f4: f9013bff    	str	xzr, [sp, #0x270]
1000051f8: 91056148    	add	x8, x10, #0x158
1000051fc: ad4207e0    	ldp	q0, q1, [sp, #0x40]
100005200: ad000500    	stp	q0, q1, [x8]
100005204: 3dc01be0    	ldr	q0, [sp, #0x60]
100005208: 3d800900    	str	q0, [x8, #0x20]
10000520c: f9403be8    	ldr	x8, [sp, #0x70]
100005210: f9400ac9    	ldr	x9, [x22, #0x10]
100005214: 9106e14a    	add	x10, x10, #0x1b8
100005218: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
10000521c: ad000540    	stp	q0, q1, [x10]
100005220: ad420560    	ldp	q0, q1, [x11, #0x40]
100005224: 9111a7ea    	add	x10, sp, #0x469
100005228: 3c8ff140    	stur	q0, [x10, #0xff]
10000522c: 9111e7ea    	add	x10, sp, #0x479
100005230: 3c8ff141    	stur	q1, [x10, #0xff]
100005234: f941bbea    	ldr	x10, [sp, #0x370]
100005238: f902c7ea    	str	x10, [sp, #0x588]
10000523c: 5280002c    	mov	w12, #0x1               ; =1
100005240: 5280002b    	mov	w11, #0x1               ; =1
100005244: f90007eb    	str	x11, [sp, #0x8]
100005248: a912e3ec    	stp	x12, x24, [sp, #0x128]
10000524c: 5280004b    	mov	w11, #0x2               ; =2
100005250: a913aff7    	stp	x23, x11, [sp, #0x138]
100005254: 9280002c    	mov	x12, #-0x2              ; =-2
100005258: f900dfeb    	str	x11, [sp, #0x1b8]
10000525c: f90103ec    	str	x12, [sp, #0x200]
100005260: f9012fea    	str	x10, [sp, #0x258]
100005264: 911167ea    	add	x10, sp, #0x459
100005268: 3ccff142    	ldur	q2, [x10, #0xff]
10000526c: 9104e7ea    	add	x10, sp, #0x139
100005270: 3c8ff140    	stur	q0, [x10, #0xff]
100005274: 9104a7ea    	add	x10, sp, #0x129
100005278: 3c8ff142    	stur	q2, [x10, #0xff]
10000527c: 910527ea    	add	x10, sp, #0x149
100005280: 3c8ff141    	stur	q1, [x10, #0xff]
100005284: 9110e7ea    	add	x10, sp, #0x439
100005288: 3ccff140    	ldur	q0, [x10, #0xff]
10000528c: 911127ea    	add	x10, sp, #0x449
100005290: 3ccff141    	ldur	q1, [x10, #0xff]
100005294: 910427ea    	add	x10, sp, #0x109
100005298: 3c8ff140    	stur	q0, [x10, #0xff]
10000529c: 910467ea    	add	x10, sp, #0x119
1000052a0: 3c8ff141    	stur	q1, [x10, #0xff]
1000052a4: f9015be8    	str	x8, [sp, #0x2b0]
1000052a8: f9401be8    	ldr	x8, [sp, #0x30]
1000052ac: f9015fe8    	str	x8, [sp, #0x2b8]
1000052b0: f90163ff    	str	xzr, [sp, #0x2c0]
1000052b4: f9016bf3    	str	x19, [sp, #0x2d0]
1000052b8: f9016fe9    	str	x9, [sp, #0x2d8]
1000052bc: 390c03fb    	strb	w27, [sp, #0x300]
1000052c0: f90187fc    	str	x28, [sp, #0x308]
1000052c4: 9114e3e8    	add	x8, sp, #0x538
1000052c8: 9104a3e0    	add	x0, sp, #0x128
1000052cc: aa1c03e1    	mov	x1, x28
1000052d0: 52800802    	mov	w2, #0x40               ; =64
1000052d4: aa1a03e3    	mov	x3, x26
1000052d8: aa1903e4    	mov	x4, x25
1000052dc: 940120e5    	bl	0x10004d670 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_initial>
1000052e0: f9429fe8    	ldr	x8, [sp, #0x538]
1000052e4: f100491f    	cmp	x8, #0x12
1000052e8: 54000441    	b.ne	0x100005370 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x630>
1000052ec: f94097e8    	ldr	x8, [sp, #0x128]
1000052f0: f100091f    	cmp	x8, #0x2
1000052f4: 9104a3f3    	add	x19, sp, #0x128
1000052f8: 54000fa0    	b.eq	0x1000054ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x7ac>
1000052fc: 91020280    	add	x0, x20, #0x80
100005300: 91056262    	add	x2, x19, #0x158
100005304: aa1603e1    	mov	x1, x22
100005308: 940019f2    	bl	0x10000bad0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
10000530c: f94097e8    	ldr	x8, [sp, #0x128]
100005310: f100091f    	cmp	x8, #0x2
100005314: 54000ec0    	b.eq	0x1000054ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x7ac>
100005318: f94103e8    	ldr	x8, [sp, #0x200]
10000531c: 92800029    	mov	x9, #-0x2               ; =-2
100005320: f90103e9    	str	x9, [sp, #0x200]
100005324: b100091f    	cmn	x8, #0x2
100005328: 54001120    	b.eq	0x10000554c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x80c>
10000532c: ad470660    	ldp	q0, q1, [x19, #0xe0]
100005330: 3c8182a0    	stur	q0, [x21, #0x18]
100005334: 3c8282a1    	stur	q1, [x21, #0x28]
100005338: 3dc04260    	ldr	q0, [x19, #0x100]
10000533c: 3c8382a0    	stur	q0, [x21, #0x38]
100005340: a900a2bf    	stp	xzr, x8, [x21, #0x8]
100005344: f90002bf    	str	xzr, [x21]
100005348: 9104a3e0    	add	x0, sp, #0x128
10000534c: 9400106f    	bl	0x100009508 <core::ptr::drop_glue::<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
100005350: f9401fe8    	ldr	x8, [sp, #0x38]
100005354: f9400109    	ldr	x9, [x8]
100005358: f1000529    	subs	x9, x9, #0x1
10000535c: f9000109    	str	x9, [x8]
100005360: 54000a81    	b.ne	0x1000054b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x770>
100005364: 9100e3e0    	add	x0, sp, #0x38
100005368: 9401ceda    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
10000536c: 14000051    	b	0x1000054b0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x770>
100005370: 54000083    	b.lo	0x100005380 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x640>
100005374: 927f0d08    	and	x8, x8, #0x1e
100005378: f100491f    	cmp	x8, #0x12
10000537c: 540000a0    	b.eq	0x100005390 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x650>
100005380: 52800028    	mov	w8, #0x1                ; =1
100005384: f90007e8    	str	x8, [sp, #0x8]
100005388: 9114e3e0    	add	x0, sp, #0x538
10000538c: 9400145d    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
100005390: f9401fe1    	ldr	x1, [sp, #0x38]
100005394: ad4407e0    	ldp	q0, q1, [sp, #0x80]
100005398: 910c43e8    	add	x8, sp, #0x310
10000539c: ad020500    	stp	q0, q1, [x8, #0x40]
1000053a0: a94127e8    	ldp	x8, x9, [sp, #0x10]
1000053a4: f901bbe9    	str	x9, [sp, #0x370]
1000053a8: f901bfe8    	str	x8, [sp, #0x378]
1000053ac: f90007ff    	str	xzr, [sp, #0x8]
1000053b0: 9114e3e8    	add	x8, sp, #0x538
1000053b4: 910d43e0    	add	x0, sp, #0x350
1000053b8: 94008c4d    	bl	0x1000284ec <<raster::api::completion::Ticket<u64>>::pair_bounded>
1000053bc: 9110e7e8    	add	x8, sp, #0x439
1000053c0: 3ccff100    	ldur	q0, [x8, #0xff]
1000053c4: 911127e8    	add	x8, sp, #0x449
1000053c8: 3ccff101    	ldur	q1, [x8, #0xff]
1000053cc: 910c43e8    	add	x8, sp, #0x310
1000053d0: ad000500    	stp	q0, q1, [x8]
1000053d4: 911167e9    	add	x9, sp, #0x459
1000053d8: 3ccff120    	ldur	q0, [x9, #0xff]
1000053dc: 9111a7e9    	add	x9, sp, #0x469
1000053e0: 3ccff121    	ldur	q1, [x9, #0xff]
1000053e4: ad010500    	stp	q0, q1, [x8, #0x20]
1000053e8: f942bff7    	ldr	x23, [sp, #0x578]
1000053ec: f942c3f4    	ldr	x20, [sp, #0x580]
1000053f0: f9029ff7    	str	x23, [sp, #0x538]
1000053f4: f902a3f4    	str	x20, [sp, #0x540]
1000053f8: f94097e8    	ldr	x8, [sp, #0x128]
1000053fc: f100091f    	cmp	x8, #0x2
100005400: 54000880    	b.eq	0x100005510 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x7d0>
100005404: 9104a3e8    	add	x8, sp, #0x128
100005408: 91066100    	add	x0, x8, #0x198
10000540c: 9400090e    	bl	0x100007844 <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
100005410: f90163f7    	str	x23, [sp, #0x2c0]
100005414: f90167f4    	str	x20, [sp, #0x2c8]
100005418: f94097e8    	ldr	x8, [sp, #0x128]
10000541c: f100091f    	cmp	x8, #0x2
100005420: 54000860    	b.eq	0x10000552c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x7ec>
100005424: 9104a3e8    	add	x8, sp, #0x128
100005428: 52800034    	mov	w20, #0x1               ; =1
10000542c: 91044100    	add	x0, x8, #0x110
100005430: 940239f1    	bl	0x100093bf4 <<raster::engine::metrics::Monitor>::pending>
100005434: 9114e3e0    	add	x0, sp, #0x538
100005438: 9104a3e1    	add	x1, sp, #0x128
10000543c: 52803d02    	mov	w2, #0x1e8              ; =488
100005440: 940322fc    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
100005444: 52800014    	mov	w20, #0x0               ; =0
100005448: 910d43e8    	add	x8, sp, #0x350
10000544c: 9114e3e0    	add	x0, sp, #0x538
100005450: 94011644    	bl	0x10004ad60 <<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>::into_owned>
100005454: 52803d00    	mov	w0, #0x1e8              ; =488
100005458: 94003e94    	bl	0x100014ea8 <alloc::boxed::box_new_uninit>
10000545c: aa0003f3    	mov	x19, x0
100005460: 910d43e1    	add	x1, sp, #0x350
100005464: 52803d02    	mov	w2, #0x1e8              ; =488
100005468: 940322f2    	bl	0x1000ce030 <dyld_stub_binder+0x1000ce030>
10000546c: 52800014    	mov	w20, #0x0               ; =0
100005470: f0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
100005474: 9107c063    	add	x3, x3, #0x1f0
100005478: 910062c0    	add	x0, x22, #0x18
10000547c: f9400fe1    	ldr	x1, [sp, #0x18]
100005480: aa1303e2    	mov	x2, x19
100005484: 9400cbba    	bl	0x10003836c <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
100005488: 52800014    	mov	w20, #0x0               ; =0
10000548c: 9400089d    	bl	0x100007700 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
100005490: 910c43e8    	add	x8, sp, #0x310
100005494: ad400500    	ldp	q0, q1, [x8]
100005498: 3c8082a0    	stur	q0, [x21, #0x8]
10000549c: 3c8182a1    	stur	q1, [x21, #0x18]
1000054a0: ad410500    	ldp	q0, q1, [x8, #0x20]
1000054a4: 3c8282a0    	stur	q0, [x21, #0x28]
1000054a8: 3c8382a1    	stur	q1, [x21, #0x38]
1000054ac: f90002bf    	str	xzr, [x21]
1000054b0: f94013e0    	ldr	x0, [sp, #0x20]
1000054b4: b9402fe1    	ldr	w1, [sp, #0x2c]
1000054b8: 94000908    	bl	0x1000078d8 <core::ptr::drop_glue::<core::option::Option<std::sync::poison::mutex::MutexGuard<()>>>>
1000054bc: 17fffe57    	b	0x100004e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0xd8>
1000054c0: 9403202f    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
1000054c4: 3707da80    	tbnz	w0, #0x0, 0x100005014 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2d4>
1000054c8: 52800028    	mov	w8, #0x1                ; =1
1000054cc: f94013e9    	ldr	x9, [sp, #0x20]
1000054d0: 39002128    	strb	w8, [x9, #0x8]
1000054d4: 17fffed0    	b	0x100005014 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x2d4>
1000054d8: 94032029    	bl	0x1000cd57c <std::panicking::panic_count::is_zero_slow_path>
1000054dc: 3707d3c0    	tbnz	w0, #0x0, 0x100004f54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x214>
1000054e0: 52800028    	mov	w8, #0x1                ; =1
1000054e4: 39002268    	strb	w8, [x19, #0x8]
1000054e8: 17fffe9b    	b	0x100004f54 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x214>
1000054ec: 52800028    	mov	w8, #0x1                ; =1
1000054f0: f90007e8    	str	x8, [sp, #0x8]
1000054f4: f00006a0    	adrp	x0, 0x1000dc000 <_anon.4047a57d598d2d67a1d7f75eed3af200.1+0x123>
1000054f8: 91269800    	add	x0, x0, #0x9a6
1000054fc: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
100005500: 91204042    	add	x2, x2, #0x810
100005504: 52800441    	mov	w1, #0x22               ; =34
100005508: 94032165    	bl	0x1000cda9c <core::option::expect_failed>
10000550c: 14000018    	b	0x10000556c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x82c>
100005510: f00006a0    	adrp	x0, 0x1000dc000 <_anon.4047a57d598d2d67a1d7f75eed3af200.1+0x123>
100005514: 91269800    	add	x0, x0, #0x9a6
100005518: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10000551c: 91204042    	add	x2, x2, #0x810
100005520: 52800441    	mov	w1, #0x22               ; =34
100005524: 9403215e    	bl	0x1000cda9c <core::option::expect_failed>
100005528: 14000011    	b	0x10000556c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x82c>
10000552c: 52800034    	mov	w20, #0x1               ; =1
100005530: f00006a0    	adrp	x0, 0x1000dc000 <_anon.4047a57d598d2d67a1d7f75eed3af200.1+0x123>
100005534: 91269800    	add	x0, x0, #0x9a6
100005538: 90000862    	adrp	x2, 0x100111000 <_anon.71176c66ba7a298ff31537c9f18ab707.18+0x50>
10000553c: 91204042    	add	x2, x2, #0x810
100005540: 52800441    	mov	w1, #0x22               ; =34
100005544: 94032156    	bl	0x1000cda9c <core::option::expect_failed>
100005548: 14000009    	b	0x10000556c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x82c>
10000554c: 52800028    	mov	w8, #0x1                ; =1
100005550: f90007e8    	str	x8, [sp, #0x8]
100005554: b00006a0    	adrp	x0, 0x1000da000 <_anon.789b1034ee6c725137bbedd4e1b0e77c.12+0x142>
100005558: 91049800    	add	x0, x0, #0x126
10000555c: f0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100005560: 91076042    	add	x2, x2, #0x1d8
100005564: 528004e1    	mov	w1, #0x27               ; =39
100005568: 9403214d    	bl	0x1000cda9c <core::option::expect_failed>
10000556c: d4200020    	brk	#0x1
100005570: f0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
100005574: 91070000    	add	x0, x0, #0x1c0
100005578: 94032216    	bl	0x1000cddd0 <core::panicking::panic_const::panic_const_rem_by_zero>
10000557c: 14000017    	b	0x1000055d8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x898>
100005580: aa0003f3    	mov	x19, x0
100005584: 910d43e0    	add	x0, sp, #0x350
100005588: 94001011    	bl	0x1000095cc <core::ptr::drop_glue::<raster::engine::task::OwnedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
10000558c: 52800014    	mov	w20, #0x0               ; =0
100005590: 1400001c    	b	0x100005600 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8c0>
100005594: 9403216f    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>
100005598: aa0003f3    	mov	x19, x0
10000559c: f90163f7    	str	x23, [sp, #0x2c0]
1000055a0: f90167f4    	str	x20, [sp, #0x2c8]
1000055a4: 14000014    	b	0x1000055f4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8b4>
1000055a8: aa0003f3    	mov	x19, x0
1000055ac: 9103e3e0    	add	x0, sp, #0xf8
1000055b0: 940013d4    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000055b4: 14000002    	b	0x1000055bc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x87c>
1000055b8: aa0003f3    	mov	x19, x0
1000055bc: 910283e0    	add	x0, sp, #0xa0
1000055c0: 94000b50    	bl	0x100008300 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
1000055c4: 14000019    	b	0x100005628 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8e8>
1000055c8: aa0003f3    	mov	x19, x0
1000055cc: 910323e0    	add	x0, sp, #0xc8
1000055d0: 940013cc    	bl	0x10000a500 <core::ptr::drop_glue::<raster::types::error::Error>>
1000055d4: 14000015    	b	0x100005628 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8e8>
1000055d8: aa0003f3    	mov	x19, x0
1000055dc: 14000013    	b	0x100005628 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8e8>
1000055e0: aa0003f3    	mov	x19, x0
1000055e4: 14000018    	b	0x100005644 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x904>
1000055e8: aa0003f3    	mov	x19, x0
1000055ec: 9114e3e0    	add	x0, sp, #0x538
1000055f0: 94000895    	bl	0x100007844 <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
1000055f4: 52800034    	mov	w20, #0x1               ; =1
1000055f8: 14000002    	b	0x100005600 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8c0>
1000055fc: aa0003f3    	mov	x19, x0
100005600: 910c43e0    	add	x0, sp, #0x310
100005604: 94000ddc    	bl	0x100008d74 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
100005608: 360001f4    	tbz	w20, #0x0, 0x100005644 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x904>
10000560c: 52800014    	mov	w20, #0x0               ; =0
100005610: 14000003    	b	0x10000561c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x8dc>
100005614: f94007f4    	ldr	x20, [sp, #0x8]
100005618: aa0003f3    	mov	x19, x0
10000561c: 9104a3e0    	add	x0, sp, #0x128
100005620: 94000fba    	bl	0x100009508 <core::ptr::drop_glue::<raster::engine::task::BorrowedTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>>
100005624: 36000114    	tbz	w20, #0x0, 0x100005644 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x904>
100005628: f9401fe8    	ldr	x8, [sp, #0x38]
10000562c: f9400109    	ldr	x9, [x8]
100005630: f1000529    	subs	x9, x9, #0x1
100005634: f9000109    	str	x9, [x8]
100005638: 54000061    	b.ne	0x100005644 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::read::<parity::Request>+0x904>
10000563c: 9100e3e0    	add	x0, sp, #0x38
100005640: 9401ce24    	bl	0x100078ed0 <<alloc::rc::Rc<()>>::drop_slow>
100005644: f94013e0    	ldr	x0, [sp, #0x20]
100005648: b9402fe1    	ldr	w1, [sp, #0x2c]
10000564c: 940008a3    	bl	0x1000078d8 <core::ptr::drop_glue::<core::option::Option<std::sync::poison::mutex::MutexGuard<()>>>>
100005650: aa1303e0    	mov	x0, x19
100005654: 94032220    	bl	0x1000cded4 <dyld_stub_binder+0x1000cded4>
100005658: 9403213e    	bl	0x1000cdb50 <core::panicking::panic_in_cleanup>

