000000000004ce10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>>:
   4ce10:	55                   	push   %rbp
   4ce11:	41 57                	push   %r15
   4ce13:	41 56                	push   %r14
   4ce15:	41 55                	push   %r13
   4ce17:	41 54                	push   %r12
   4ce19:	53                   	push   %rbx
   4ce1a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
   4ce21:	80 ba e8 00 00 00 00 	cmpb   $0x0,0xe8(%rdx)
   4ce28:	75 0b                	jne    4ce35 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x25>
   4ce2a:	0f b6 86 40 1b 00 00 	movzbl 0x1b40(%rsi),%eax
   4ce31:	84 c0                	test   %al,%al
   4ce33:	74 2c                	je     4ce61 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x51>
   4ce35:	48 c7 07 07 00 00 00 	movq   $0x7,(%rdi)
   4ce3c:	48 8d 05 5b ee fc ff 	lea    -0x311a5(%rip),%rax        # 1bc9e <anon.620d0679d47398e68dd3c6ba79837389.2.llvm.4227930560065955062+0xae>
   4ce43:	48 89 47 08          	mov    %rax,0x8(%rdi)
   4ce47:	48 c7 47 10 1f 00 00 	movq   $0x1f,0x10(%rdi)
   4ce4e:	00 
   4ce4f:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
   4ce56:	5b                   	pop    %rbx
   4ce57:	41 5c                	pop    %r12
   4ce59:	41 5d                	pop    %r13
   4ce5b:	41 5e                	pop    %r14
   4ce5d:	41 5f                	pop    %r15
   4ce5f:	5d                   	pop    %rbp
   4ce60:	c3                   	ret
   4ce61:	83 3a 01             	cmpl   $0x1,(%rdx)
   4ce64:	75 22                	jne    4ce88 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x78>
   4ce66:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   4ce6a:	77 1c                	ja     4ce88 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x78>
   4ce6c:	48 c7 07 07 00 00 00 	movq   $0x7,(%rdi)
   4ce73:	48 8d 05 fd ed fc ff 	lea    -0x31203(%rip),%rax        # 1bc77 <anon.620d0679d47398e68dd3c6ba79837389.2.llvm.4227930560065955062+0x87>
   4ce7a:	48 89 47 08          	mov    %rax,0x8(%rdi)
   4ce7e:	48 c7 47 10 27 00 00 	movq   $0x27,0x10(%rdi)
   4ce85:	00 
   4ce86:	eb c7                	jmp    4ce4f <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x3f>
   4ce88:	49 89 fc             	mov    %rdi,%r12
   4ce8b:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
   4ce92:	00 
   4ce93:	4c 8b b6 a8 04 00 00 	mov    0x4a8(%rsi),%r14
   4ce9a:	49 83 c6 10          	add    $0x10,%r14
   4ce9e:	4c 89 f7             	mov    %r14,%rdi
   4cea1:	4d 89 c7             	mov    %r8,%r15
   4cea4:	4c 89 c6             	mov    %r8,%rsi
   4cea7:	ff 15 e3 f1 0e 00    	call   *0xef1e3(%rip)        # 13c090 <_DYNAMIC+0x290>
   4cead:	49 89 c5             	mov    %rax,%r13
   4ceb0:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   4ceb7:	00 
   4ceb8:	be 08 00 00 00       	mov    $0x8,%esi
   4cebd:	ff 15 d5 f1 0e 00    	call   *0xef1d5(%rip)        # 13c098 <_DYNAMIC+0x298>
   4cec3:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   4ceca:	00 
   4cecb:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   4ced2:	00 
   4ced3:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
   4ceda:	00 
   4cedb:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   4cee0:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   4cee7:	00 
   4cee8:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   4ceef:	00 
   4cef0:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
   4cef4:	74 71                	je     4cf67 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x157>
   4cef6:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   4cefd:	00 
   4cefe:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   4cf03:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   4cf08:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4cf0f:	00 
   4cf10:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   4cf15:	4c 89 e0             	mov    %r12,%rax
   4cf18:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   4cf1d:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
   4cf22:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   4cf27:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   4cf2c:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   4cf31:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   4cf36:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   4cf3b:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   4cf40:	48 89 48 20          	mov    %rcx,0x20(%rax)
   4cf44:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   4cf49:	48 89 48 28          	mov    %rcx,0x28(%rax)
   4cf4d:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   4cf51:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cf56:	48 89 08             	mov    %rcx,(%rax)
   4cf59:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   4cf5e:	48 89 48 08          	mov    %rcx,0x8(%rax)
   4cf62:	e9 e8 fe ff ff       	jmp    4ce4f <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x3f>
   4cf67:	48 89 1c 24          	mov    %rbx,(%rsp)
   4cf6b:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   4cf70:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
   4cf75:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4cf7c:	00 
   4cf7d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   4cf82:	48 89 e7             	mov    %rsp,%rdi
   4cf85:	ff 15 15 f1 0e 00    	call   *0xef115(%rip)        # 13c0a0 <_DYNAMIC+0x2a0>
   4cf8b:	49 89 d0             	mov    %rdx,%r8
   4cf8e:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   4cf95:	00 
   4cf96:	4c 89 f6             	mov    %r14,%rsi
   4cf99:	4c 89 fa             	mov    %r15,%rdx
   4cf9c:	48 89 c1             	mov    %rax,%rcx
   4cf9f:	ff 15 03 f1 0e 00    	call   *0xef103(%rip)        # 13c0a8 <_DYNAMIC+0x2a8>
   4cfa5:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
   4cfac:	00 
   4cfad:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
   4cfb1:	4c 89 e0             	mov    %r12,%rax
   4cfb4:	74 57                	je     4d00d <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x1fd>
   4cfb6:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   4cfbd:	00 
   4cfbe:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
   4cfc5:	00 
   4cfc6:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   4cfcb:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
   4cfd2:	00 
   4cfd3:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   4cfd8:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   4cfdf:	00 
   4cfe0:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   4cfe4:	0f 84 2e ff ff ff    	je     4cf18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x108>
   4cfea:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   4cfef:	48 85 f6             	test   %rsi,%rsi
   4cff2:	0f 84 20 ff ff ff    	je     4cf18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x108>
   4cff8:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   4cffd:	ba 01 00 00 00       	mov    $0x1,%edx
   4d002:	ff 15 38 f0 0e 00    	call   *0xef038(%rip)        # 13c040 <_DYNAMIC+0x240>
   4d008:	e9 08 ff ff ff       	jmp    4cf15 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x105>
   4d00d:	0f 10 04 24          	movups (%rsp),%xmm0
   4d011:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   4d016:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   4d01b:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   4d020:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
   4d027:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
   4d02c:	4c 89 eb             	mov    %r13,%rbx
   4d02f:	e9 e4 fe ff ff       	jmp    4cf18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x108>
   4d034:	48 89 c3             	mov    %rax,%rbx
   4d037:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   4d03b:	74 1f                	je     4d05c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x24c>
   4d03d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   4d042:	48 85 f6             	test   %rsi,%rsi
   4d045:	74 15                	je     4d05c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x24c>
   4d047:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   4d04c:	ba 01 00 00 00       	mov    $0x1,%edx
   4d051:	ff 15 e9 ef 0e 00    	call   *0xeefe9(%rip)        # 13c040 <_DYNAMIC+0x240>
   4d057:	eb 03                	jmp    4d05c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x24c>
   4d059:	48 89 c3             	mov    %rax,%rbx
   4d05c:	48 89 df             	mov    %rbx,%rdi
   4d05f:	ff 15 4b f0 0e 00    	call   *0xef04b(%rip)        # 13c0b0 <_DYNAMIC+0x2b0>
   4d065:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   4d06a:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   4d06f:	48 c7 44 24 40 fe ff 	movq   $0xfffffffffffffffe,0x40(%rsp)
   4d076:	ff ff 
   4d078:	b1 01                	mov    $0x1,%cl
   4d07a:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   4d081:	00 
   4d082:	86 88 40 1b 00 00    	xchg   %cl,0x1b40(%rax)
   4d088:	49 c7 04 24 07 00 00 	movq   $0x7,(%r12)
   4d08f:	00 
   4d090:	48 8d 05 c1 eb fc ff 	lea    -0x3143f(%rip),%rax        # 1bc58 <anon.620d0679d47398e68dd3c6ba79837389.2.llvm.4227930560065955062+0x68>
   4d097:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   4d09c:	49 c7 44 24 10 1f 00 	movq   $0x1f,0x10(%r12)
   4d0a3:	00 00 
   4d0a5:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d0aa:	e8 41 49 00 00       	call   519f0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<(raster::types::id::KeyHash, raster::schema::encoded_key::EncodedKey), raster::types::error::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
   4d0af:	e9 9b fd ff ff       	jmp    4ce4f <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>+0x3f>
   4d0b4:	ff 15 fe ef 0e 00    	call   *0xeeffe(%rip)        # 13c0b8 <_DYNAMIC+0x2b8>
   4d0ba:	cc                   	int3
   4d0bb:	cc                   	int3
   4d0bc:	cc                   	int3
   4d0bd:	cc                   	int3
   4d0be:	cc                   	int3
   4d0bf:	cc                   	int3

