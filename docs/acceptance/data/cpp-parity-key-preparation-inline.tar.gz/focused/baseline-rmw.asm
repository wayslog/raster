000000010000580c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>>:
10000580c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100005810: a90167fa    	stp	x26, x25, [sp, #0x10]
100005814: a9025ff8    	stp	x24, x23, [sp, #0x20]
100005818: a90357f6    	stp	x22, x21, [sp, #0x30]
10000581c: a9044ff4    	stp	x20, x19, [sp, #0x40]
100005820: a9057bfd    	stp	x29, x30, [sp, #0x50]
100005824: 910143fd    	add	x29, sp, #0x50
100005828: d11603ff    	sub	sp, sp, #0x580
10000582c: f90003ff    	str	xzr, [sp]
100005830: aa0503fc    	mov	x28, x5
100005834: aa0403f9    	mov	x25, x4
100005838: aa0303fa    	mov	x26, x3
10000583c: aa0203fb    	mov	x27, x2
100005840: aa0103f8    	mov	x24, x1
100005844: aa0803f7    	mov	x23, x8
100005848: 910e23f4    	add	x20, sp, #0x388
10000584c: a90513e3    	stp	x3, x4, [sp, #0x50]
100005850: f9400016    	ldr	x22, [x0]
100005854: 910e23e8    	add	x8, sp, #0x388
100005858: 910202c0    	add	x0, x22, #0x80
10000585c: 94001f70    	bl	0x10000d61c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::observe_entry>
100005860: f941c7e8    	ldr	x8, [sp, #0x388]
100005864: b100051f    	cmn	x8, #0x1
100005868: 540001a0    	b.eq	0x10000589c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x90>
10000586c: 394e43e9    	ldrb	w9, [sp, #0x390]
100005870: 3cc09280    	ldur	q0, [x20, #0x9]
100005874: 3c8112e0    	stur	q0, [x23, #0x11]
100005878: 3cc19280    	ldur	q0, [x20, #0x19]
10000587c: 3c8212e0    	stur	q0, [x23, #0x21]
100005880: f941dbea    	ldr	x10, [sp, #0x3b0]
100005884: 390042e9    	strb	w9, [x23, #0x10]
100005888: a9036aea    	stp	x10, x26, [x23, #0x30]
10000588c: f90022f9    	str	x25, [x23, #0x40]
100005890: 52800029    	mov	w9, #0x1                ; =1
100005894: a90022e9    	stp	x9, x8, [x23]
100005898: 1400006a    	b	0x100005a40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x234>
10000589c: 910e23e0    	add	x0, sp, #0x388
1000058a0: 910202c1    	add	x1, x22, #0x80
1000058a4: 910143e4    	add	x4, sp, #0x50
1000058a8: aa1803e2    	mov	x2, x24
1000058ac: aa1b03e3    	mov	x3, x27
1000058b0: 97fffd24    	bl	0x100004d40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::prepare::<parity::Request>>
1000058b4: f941c7e8    	ldr	x8, [sp, #0x388]
1000058b8: b100051f    	cmn	x8, #0x1
1000058bc: 54000140    	b.eq	0x1000058e4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0xd8>
1000058c0: ad400680    	ldp	q0, q1, [x20]
1000058c4: 3c8082e0    	stur	q0, [x23, #0x8]
1000058c8: 3c8182e1    	stur	q1, [x23, #0x18]
1000058cc: 3dc00a80    	ldr	q0, [x20, #0x20]
1000058d0: 3c8282e0    	stur	q0, [x23, #0x28]
1000058d4: a903e6fa    	stp	x26, x25, [x23, #0x38]
1000058d8: 52800028    	mov	w8, #0x1                ; =1
1000058dc: f90002e8    	str	x8, [x23]
1000058e0: 14000058    	b	0x100005a40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x234>
1000058e4: f941cbf5    	ldr	x21, [sp, #0x390]
1000058e8: 394e63e8    	ldrb	w8, [sp, #0x398]
1000058ec: b90047e8    	str	w8, [sp, #0x44]
1000058f0: b8411288    	ldur	w8, [x20, #0x11]
1000058f4: b90063e8    	str	w8, [sp, #0x60]
1000058f8: b9439fe8    	ldr	w8, [sp, #0x39c]
1000058fc: b80633e8    	stur	w8, [sp, #0x63]
100005900: f941d3e8    	ldr	x8, [sp, #0x3a0]
100005904: f90027e8    	str	x8, [sp, #0x48]
100005908: f941d7e8    	ldr	x8, [sp, #0x3a8]
10000590c: f9001fe8    	str	x8, [sp, #0x38]
100005910: f94072c8    	ldr	x8, [x22, #0xe0]
100005914: b4002aa8    	cbz	x8, 0x100005e68 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x65c>
100005918: f941dbf3    	ldr	x19, [sp, #0x3b0]
10000591c: f9406ec9    	ldr	x9, [x22, #0xd8]
100005920: 9ac80aaa    	udiv	x10, x21, x8
100005924: 9b08d548    	msub	x8, x10, x8, x21
100005928: 8b081121    	add	x1, x9, x8, lsl #4
10000592c: 910e23e0    	add	x0, sp, #0x388
100005930: 94003dfd    	bl	0x100015124 <raster::engine::operation_gate::try_lock>
100005934: b9438be8    	ldr	w8, [sp, #0x388]
100005938: 36000248    	tbz	w8, #0x0, 0x100005980 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x174>
10000593c: a903e6fa    	stp	x26, x25, [x23, #0x38]
100005940: b00006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
100005944: 3dc10900    	ldr	q0, [x8, #0x420]
100005948: 3d8002e0    	str	q0, [x23]
10000594c: 394e63e8    	ldrb	w8, [sp, #0x398]
100005950: 7100091f    	cmp	w8, #0x2
100005954: 54000680    	b.eq	0x100005a24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x218>
100005958: f941cbf3    	ldr	x19, [sp, #0x390]
10000595c: 370000c8    	tbnz	w8, #0x0, 0x100005974 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x168>
100005960: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100005964: 91394108    	add	x8, x8, #0xe50
100005968: f9400108    	ldr	x8, [x8]
10000596c: f240f91f    	tst	x8, #0x7fffffffffffffff
100005970: 54002601    	b.ne	0x100005e30 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x624>
100005974: f9400260    	ldr	x0, [x19]
100005978: 94027b00    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
10000597c: 1400002a    	b	0x100005a24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x218>
100005980: f9000bf3    	str	x19, [sp, #0x10]
100005984: f941cbe8    	ldr	x8, [sp, #0x390]
100005988: f9001be8    	str	x8, [sp, #0x30]
10000598c: 394e63e8    	ldrb	w8, [sp, #0x398]
100005990: b9002fe8    	str	w8, [sp, #0x2c]
100005994: 52800033    	mov	w19, #0x1               ; =1
100005998: aa1803e0    	mov	x0, x24
10000599c: 94015cb8    	bl	0x10005cc7c <<raster::engine::pending::SessionRuntime>::pending>
1000059a0: f940fac8    	ldr	x8, [x22, #0x1f0]
1000059a4: eb08001f    	cmp	x0, x8
1000059a8: 54000222    	b.hs	0x1000059ec <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1e0>
1000059ac: f940fec1    	ldr	x1, [x22, #0x1f8]
1000059b0: 910e23e8    	add	x8, sp, #0x388
1000059b4: aa1803e0    	mov	x0, x24
1000059b8: 94015b4e    	bl	0x10005c6f0 <<raster::engine::pending::SessionRuntime>::reserve_result>
1000059bc: f941c7e8    	ldr	x8, [sp, #0x388]
1000059c0: b100051f    	cmn	x8, #0x1
1000059c4: 540004e0    	b.eq	0x100005a60 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x254>
1000059c8: ad400680    	ldp	q0, q1, [x20]
1000059cc: 3c8082e0    	stur	q0, [x23, #0x8]
1000059d0: 3c8182e1    	stur	q1, [x23, #0x18]
1000059d4: 3dc00a80    	ldr	q0, [x20, #0x20]
1000059d8: 3c8282e0    	stur	q0, [x23, #0x28]
1000059dc: a903e6fa    	stp	x26, x25, [x23, #0x38]
1000059e0: 52800028    	mov	w8, #0x1                ; =1
1000059e4: f90002e8    	str	x8, [x23]
1000059e8: 14000005    	b	0x1000059fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1f0>
1000059ec: a903e6fa    	stp	x26, x25, [x23, #0x38]
1000059f0: b00006a8    	adrp	x8, 0x1000da000 <GCC_except_table9+0x10>
1000059f4: 3dc10900    	ldr	q0, [x8, #0x420]
1000059f8: 3d8002e0    	str	q0, [x23]
1000059fc: b9402fe8    	ldr	w8, [sp, #0x2c]
100005a00: 370000c8    	tbnz	w8, #0x0, 0x100005a18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x20c>
100005a04: f0000888    	adrp	x8, 0x100118000 <dyld_stub_binder+0x100118000>
100005a08: 91394108    	add	x8, x8, #0xe50
100005a0c: f9400108    	ldr	x8, [x8]
100005a10: f240f91f    	tst	x8, #0x7fffffffffffffff
100005a14: 54002021    	b.ne	0x100005e18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x60c>
100005a18: f9401be8    	ldr	x8, [sp, #0x30]
100005a1c: f9400100    	ldr	x0, [x8]
100005a20: 94027ad6    	bl	0x1000a4578 <<std::sys::pal::unix::sync::mutex::Mutex>::unlock>
100005a24: f94027e1    	ldr	x1, [sp, #0x48]
100005a28: b94047e8    	ldr	w8, [sp, #0x44]
100005a2c: 340000a8    	cbz	w8, 0x100005a40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x234>
100005a30: b4000081    	cbz	x1, 0x100005a40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x234>
100005a34: f9401fe0    	ldr	x0, [sp, #0x38]
100005a38: 52800022    	mov	w2, #0x1                ; =1
100005a3c: 9401267c    	bl	0x10004f42c <__rustc::__rust_dealloc>
100005a40: 911603ff    	add	sp, sp, #0x580
100005a44: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100005a48: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100005a4c: a94357f6    	ldp	x22, x21, [sp, #0x30]
100005a50: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100005a54: a94167fa    	ldp	x26, x25, [sp, #0x10]
100005a58: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100005a5c: d65f03c0    	ret
100005a60: f941cbe8    	ldr	x8, [sp, #0x390]
100005a64: f90037e8    	str	x8, [sp, #0x68]
100005a68: 910e23e0    	add	x0, sp, #0x388
100005a6c: 910202c1    	add	x1, x22, #0x80
100005a70: aa1803e2    	mov	x2, x24
100005a74: 940018d8    	bl	0x10000bdd4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::reserve_operation>
100005a78: 394ee7e8    	ldrb	w8, [sp, #0x3b9]
100005a7c: 7100091f    	cmp	w8, #0x2
100005a80: 540000c1    	b.ne	0x100005a98 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x28c>
100005a84: ad400680    	ldp	q0, q1, [x20]
100005a88: 3c8082e0    	stur	q0, [x23, #0x8]
100005a8c: 3c8182e1    	stur	q1, [x23, #0x18]
100005a90: 3dc00a80    	ldr	q0, [x20, #0x20]
100005a94: 14000021    	b	0x100005b18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x30c>
100005a98: ad408281    	ldp	q1, q0, [x20, #0x10]
100005a9c: ad0403e1    	stp	q1, q0, [sp, #0x80]
100005aa0: 3dc00280    	ldr	q0, [x20]
100005aa4: 3d801fe0    	str	q0, [sp, #0x70]
100005aa8: f941dfe8    	ldr	x8, [sp, #0x3b8]
100005aac: f90053e8    	str	x8, [sp, #0xa0]
100005ab0: ad0587e0    	stp	q0, q1, [sp, #0xb0]
100005ab4: a94923e9    	ldp	x9, x8, [sp, #0x90]
100005ab8: a90027e8    	stp	x8, x9, [sp]
100005abc: f9400b02    	ldr	x2, [x24, #0x10]
100005ac0: 9103e3e8    	add	x8, sp, #0xf8
100005ac4: 910d02c0    	add	x0, x22, #0x340
100005ac8: aa1503e1    	mov	x1, x21
100005acc: 94016488    	bl	0x10005ecec <<raster::engine::version_permit::VersionPermits>::reserve_initial>
100005ad0: 9103e3f3    	add	x19, sp, #0xf8
100005ad4: f9407fe8    	ldr	x8, [sp, #0xf8]
100005ad8: b100051f    	cmn	x8, #0x1
100005adc: 54000380    	b.eq	0x100005b4c <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x340>
100005ae0: f94186c9    	ldr	x9, [x22, #0x308]
100005ae4: 910e23e8    	add	x8, sp, #0x388
100005ae8: 91004120    	add	x0, x9, #0x10
100005aec: 9101c3e1    	add	x1, sp, #0x70
100005af0: 94023115    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
100005af4: f941c7e8    	ldr	x8, [sp, #0x388]
100005af8: b100051f    	cmn	x8, #0x1
100005afc: 54000060    	b.eq	0x100005b08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x2fc>
100005b00: 910e23e0    	add	x0, sp, #0x388
100005b04: 9400130f    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005b08: ad400660    	ldp	q0, q1, [x19]
100005b0c: 3c8082e0    	stur	q0, [x23, #0x8]
100005b10: 3c8182e1    	stur	q1, [x23, #0x18]
100005b14: 3dc00a60    	ldr	q0, [x19, #0x20]
100005b18: 3c8282e0    	stur	q0, [x23, #0x28]
100005b1c: a903e6fa    	stp	x26, x25, [x23, #0x38]
100005b20: 52800028    	mov	w8, #0x1                ; =1
100005b24: f90002e8    	str	x8, [x23]
100005b28: f94037e8    	ldr	x8, [sp, #0x68]
100005b2c: f9400109    	ldr	x9, [x8]
100005b30: f1000529    	subs	x9, x9, #0x1
100005b34: f9000109    	str	x9, [x8]
100005b38: 54fff621    	b.ne	0x1000059fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1f0>
100005b3c: 52800033    	mov	w19, #0x1               ; =1
100005b40: 9101a3e0    	add	x0, sp, #0x68
100005b44: 9401dae5    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100005b48: 17ffffad    	b	0x1000059fc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x1f0>
100005b4c: 3cc08260    	ldur	q0, [x19, #0x8]
100005b50: 3cc18261    	ldur	q1, [x19, #0x18]
100005b54: ad0687e0    	stp	q0, q1, [sp, #0xd0]
100005b58: 9104a3e0    	add	x0, sp, #0x128
100005b5c: 910202c1    	add	x1, x22, #0x80
100005b60: aa1803e2    	mov	x2, x24
100005b64: aa1b03e3    	mov	x3, x27
100005b68: 940018e4    	bl	0x10000bef8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::admit>
100005b6c: f94097e8    	ldr	x8, [sp, #0x128]
100005b70: b100051f    	cmn	x8, #0x1
100005b74: 540002c0    	b.eq	0x100005bcc <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x3c0>
100005b78: f94186c9    	ldr	x9, [x22, #0x308]
100005b7c: 910e23e8    	add	x8, sp, #0x388
100005b80: 91004120    	add	x0, x9, #0x10
100005b84: 9101c3e1    	add	x1, sp, #0x70
100005b88: 940230ef    	bl	0x100091f44 <<raster::engine::io_hub::CompletionHub>::release_operation>
100005b8c: f941c7e8    	ldr	x8, [sp, #0x388]
100005b90: b100051f    	cmn	x8, #0x1
100005b94: 54000060    	b.eq	0x100005ba0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x394>
100005b98: 910e23e0    	add	x0, sp, #0x388
100005b9c: 940012e9    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005ba0: ad418660    	ldp	q0, q1, [x19, #0x30]
100005ba4: 3c8082e0    	stur	q0, [x23, #0x8]
100005ba8: 3c8182e1    	stur	q1, [x23, #0x18]
100005bac: 3dc01660    	ldr	q0, [x19, #0x50]
100005bb0: 3c8282e0    	stur	q0, [x23, #0x28]
100005bb4: a903e6fa    	stp	x26, x25, [x23, #0x38]
100005bb8: 52800028    	mov	w8, #0x1                ; =1
100005bbc: f90002e8    	str	x8, [x23]
100005bc0: 910343e0    	add	x0, sp, #0xd0
100005bc4: 94000a35    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005bc8: 17ffffd8    	b	0x100005b28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x31c>
100005bcc: 910e23e8    	add	x8, sp, #0x388
100005bd0: 91034300    	add	x0, x24, #0xd0
100005bd4: 52800041    	mov	w1, #0x2                ; =2
100005bd8: 940237a7    	bl	0x100093a74 <<raster::engine::metrics::Tracker>::accept>
100005bdc: 52800028    	mov	w8, #0x1                ; =1
100005be0: f82802c8    	ldadd	x8, x8, [x22]
100005be4: b7f81488    	tbnz	x8, #0x3f, 0x100005e74 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x668>
100005be8: b94047e8    	ldr	w8, [sp, #0x44]
100005bec: 390a43e8    	strb	w8, [sp, #0x290]
100005bf0: 910563ea    	add	x10, sp, #0x158
100005bf4: 9104e548    	add	x8, x10, #0x139
100005bf8: b94063e9    	ldr	w9, [sp, #0x60]
100005bfc: b9000109    	str	w9, [x8]
100005c00: b84633e8    	ldur	w8, [sp, #0x63]
100005c04: b90297e8    	str	w8, [sp, #0x294]
100005c08: f94027e8    	ldr	x8, [sp, #0x48]
100005c0c: f9014fe8    	str	x8, [sp, #0x298]
100005c10: f9401fe8    	ldr	x8, [sp, #0x38]
100005c14: f90153e8    	str	x8, [sp, #0x2a0]
100005c18: 91056148    	add	x8, x10, #0x158
100005c1c: ad4387e0    	ldp	q0, q1, [sp, #0x70]
100005c20: ad000500    	stp	q0, q1, [x8]
100005c24: 3dc027e0    	ldr	q0, [sp, #0x90]
100005c28: 3d800900    	str	q0, [x8, #0x20]
100005c2c: f94053e8    	ldr	x8, [sp, #0xa0]
100005c30: f9400be9    	ldr	x9, [sp, #0x10]
100005c34: f90157e9    	str	x9, [sp, #0x2a8]
100005c38: f90173e8    	str	x8, [sp, #0x2e0]
100005c3c: f9400b08    	ldr	x8, [x24, #0x10]
100005c40: ad4687e0    	ldp	q0, q1, [sp, #0xd0]
100005c44: ad110660    	stp	q0, q1, [x19, #0x220]
100005c48: ad400680    	ldp	q0, q1, [x20]
100005c4c: ad0b8660    	stp	q0, q1, [x19, #0x170]
100005c50: f941d7e9    	ldr	x9, [sp, #0x3a8]
100005c54: 5280002b    	mov	w11, #0x1               ; =1
100005c58: 5280002a    	mov	w10, #0x1               ; =1
100005c5c: f9000bea    	str	x10, [sp, #0x10]
100005c60: a915ebeb    	stp	x11, x26, [sp, #0x158]
100005c64: 5280004a    	mov	w10, #0x2               ; =2
100005c68: a916abf9    	stp	x25, x10, [sp, #0x168]
100005c6c: 910563f9    	add	x25, sp, #0x158
100005c70: 390ce3fc    	strb	w28, [sp, #0x338]
100005c74: 9107872a    	add	x10, x25, #0x1e1
100005c78: 7900015f    	strh	wzr, [x10]
100005c7c: f90177f6    	str	x22, [sp, #0x2e8]
100005c80: f9017bf5    	str	x21, [sp, #0x2f0]
100005c84: 9280002a    	mov	x10, #-0x2              ; =-2
100005c88: f90147e9    	str	x9, [sp, #0x288]
100005c8c: f9011bea    	str	x10, [sp, #0x230]
100005c90: f9017fff    	str	xzr, [sp, #0x2f8]
100005c94: f90187fb    	str	x27, [sp, #0x308]
100005c98: f9018be8    	str	x8, [sp, #0x310]
100005c9c: 910e23e8    	add	x8, sp, #0x388
100005ca0: 910563e0    	add	x0, sp, #0x158
100005ca4: 52800801    	mov	w1, #0x40               ; =64
100005ca8: 940114ee    	bl	0x10004b060 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_initial>
100005cac: f941c7e8    	ldr	x8, [sp, #0x388]
100005cb0: f100491f    	cmp	x8, #0x12
100005cb4: 54000381    	b.ne	0x100005d24 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x518>
100005cb8: 910202c0    	add	x0, x22, #0x80
100005cbc: 91056322    	add	x2, x25, #0x158
100005cc0: aa1803e1    	mov	x1, x24
100005cc4: 94001813    	bl	0x10000bd10 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::retain_operation>
100005cc8: f9411be8    	ldr	x8, [sp, #0x230]
100005ccc: 92800029    	mov	x9, #-0x2               ; =-2
100005cd0: f9011be9    	str	x9, [sp, #0x230]
100005cd4: b100091f    	cmn	x8, #0x2
100005cd8: 54000b60    	b.eq	0x100005e44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x638>
100005cdc: ad470720    	ldp	q0, q1, [x25, #0xe0]
100005ce0: 3c8182e0    	stur	q0, [x23, #0x18]
100005ce4: 3c8282e1    	stur	q1, [x23, #0x28]
100005ce8: 3dc04320    	ldr	q0, [x25, #0x100]
100005cec: 3c8382e0    	stur	q0, [x23, #0x38]
100005cf0: a900a2ff    	stp	xzr, x8, [x23, #0x8]
100005cf4: f90002ff    	str	xzr, [x23]
100005cf8: 910563e0    	add	x0, sp, #0x158
100005cfc: 94000d70    	bl	0x1000092bc <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005d00: f94037e8    	ldr	x8, [sp, #0x68]
100005d04: f9400109    	ldr	x9, [x8]
100005d08: f1000529    	subs	x9, x9, #0x1
100005d0c: f9000109    	str	x9, [x8]
100005d10: 540007c1    	b.ne	0x100005e08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x5fc>
100005d14: 52800013    	mov	w19, #0x0               ; =0
100005d18: 9101a3e0    	add	x0, sp, #0x68
100005d1c: 9401da6f    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100005d20: 1400003a    	b	0x100005e08 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x5fc>
100005d24: 54000083    	b.lo	0x100005d34 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x528>
100005d28: 927f0d08    	and	x8, x8, #0x1e
100005d2c: f100491f    	cmp	x8, #0x12
100005d30: 540000a0    	b.eq	0x100005d44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x538>
100005d34: 52800028    	mov	w8, #0x1                ; =1
100005d38: f9000be8    	str	x8, [sp, #0x10]
100005d3c: 910e23e0    	add	x0, sp, #0x388
100005d40: 94001280    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005d44: f94037e1    	ldr	x1, [sp, #0x68]
100005d48: ad4587e0    	ldp	q0, q1, [sp, #0xb0]
100005d4c: ad1a07e0    	stp	q0, q1, [sp, #0x340]
100005d50: a94027e8    	ldp	x8, x9, [sp]
100005d54: f901b3e9    	str	x9, [sp, #0x360]
100005d58: f901b7e8    	str	x8, [sp, #0x368]
100005d5c: f9000bff    	str	xzr, [sp, #0x10]
100005d60: 910e23e8    	add	x8, sp, #0x388
100005d64: 910d03e0    	add	x0, sp, #0x340
100005d68: 94008a71    	bl	0x10002872c <<raster::api::completion::Ticket<u64>>::pair_bounded>
100005d6c: ad400680    	ldp	q0, q1, [x20]
100005d70: ad1a07e0    	stp	q0, q1, [sp, #0x340]
100005d74: ad410680    	ldp	q0, q1, [x20, #0x20]
100005d78: ad1b07e0    	stp	q0, q1, [sp, #0x360]
100005d7c: 3dc01280    	ldr	q0, [x20, #0x40]
100005d80: 3d8007e0    	str	q0, [sp, #0x10]
100005d84: 91068320    	add	x0, x25, #0x1a0
100005d88: 94000715    	bl	0x1000079dc <core::ptr::drop_glue::<core::option::Option<raster::api::completion::Completer<u64>>>>
100005d8c: 3dc007e0    	ldr	q0, [sp, #0x10]
100005d90: 3d808260    	str	q0, [x19, #0x200]
100005d94: 52800034    	mov	w20, #0x1               ; =1
100005d98: 91044320    	add	x0, x25, #0x110
100005d9c: 94023871    	bl	0x100093f60 <<raster::engine::metrics::Monitor>::pending>
100005da0: 910e23e0    	add	x0, sp, #0x388
100005da4: 910563e1    	add	x1, sp, #0x158
100005da8: 52803d02    	mov	w2, #0x1e8              ; =488
100005dac: 9403217c    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
100005db0: 52803d00    	mov	w0, #0x1e8              ; =488
100005db4: 94003ccd    	bl	0x1000150e8 <alloc::boxed::box_new_uninit>
100005db8: aa0003f5    	mov	x21, x0
100005dbc: 910e23e1    	add	x1, sp, #0x388
100005dc0: 52803d02    	mov	w2, #0x1e8              ; =488
100005dc4: 94032176    	bl	0x1000ce39c <dyld_stub_binder+0x1000ce39c>
100005dc8: 52800014    	mov	w20, #0x0               ; =0
100005dcc: f0000843    	adrp	x3, 0x100110000 <dyld_stub_binder+0x100110000>
100005dd0: 9109a063    	add	x3, x3, #0x268
100005dd4: 91006300    	add	x0, x24, #0x18
100005dd8: f94007e1    	ldr	x1, [sp, #0x8]
100005ddc: aa1503e2    	mov	x2, x21
100005de0: 9400c9f3    	bl	0x1000385ac <<alloc::collections::btree::map::BTreeMap<u64, alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>::insert>
100005de4: 52800014    	mov	w20, #0x0               ; =0
100005de8: 940006ac    	bl	0x100007898 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn raster::engine::pending::PendingTask>>>>
100005dec: ad5a07e0    	ldp	q0, q1, [sp, #0x340]
100005df0: 3c8082e0    	stur	q0, [x23, #0x8]
100005df4: 3c8182e1    	stur	q1, [x23, #0x18]
100005df8: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
100005dfc: 3c8282e0    	stur	q0, [x23, #0x28]
100005e00: 3c8382e1    	stur	q1, [x23, #0x38]
100005e04: f90002ff    	str	xzr, [x23]
100005e08: f9401be0    	ldr	x0, [sp, #0x30]
100005e0c: b9402fe1    	ldr	w1, [sp, #0x2c]
100005e10: 94000f96    	bl	0x100009c68 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100005e14: 17ffff0b    	b	0x100005a40 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x234>
100005e18: 94031eb4    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
100005e1c: 3707dfe0    	tbnz	w0, #0x0, 0x100005a18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x20c>
100005e20: 52800028    	mov	w8, #0x1                ; =1
100005e24: f9401be9    	ldr	x9, [sp, #0x30]
100005e28: 39002128    	strb	w8, [x9, #0x8]
100005e2c: 17fffefb    	b	0x100005a18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x20c>
100005e30: 94031eae    	bl	0x1000cd8e8 <std::panicking::panic_count::is_zero_slow_path>
100005e34: 3707da00    	tbnz	w0, #0x0, 0x100005974 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x168>
100005e38: 52800028    	mov	w8, #0x1                ; =1
100005e3c: 39002268    	strb	w8, [x19, #0x8]
100005e40: 17fffecd    	b	0x100005974 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x168>
100005e44: 52800028    	mov	w8, #0x1                ; =1
100005e48: f9000be8    	str	x8, [sp, #0x10]
100005e4c: b00006a0    	adrp	x0, 0x1000da000 <GCC_except_table9+0x10>
100005e50: 9114b000    	add	x0, x0, #0x52c
100005e54: f0000842    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100005e58: 91094042    	add	x2, x2, #0x250
100005e5c: 528004c1    	mov	w1, #0x26               ; =38
100005e60: 94031fea    	bl	0x1000cde08 <core::option::expect_failed>
100005e64: 14000004    	b	0x100005e74 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x668>
100005e68: f0000840    	adrp	x0, 0x100110000 <dyld_stub_binder+0x100110000>
100005e6c: 9108e000    	add	x0, x0, #0x238
100005e70: 940320b3    	bl	0x1000ce13c <core::panicking::panic_const::panic_const_rem_by_zero>
100005e74: d4200020    	brk	#0x1
100005e78: aa0003f5    	mov	x21, x0
100005e7c: 52800013    	mov	w19, #0x0               ; =0
100005e80: 1400002a    	b	0x100005f28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x71c>
100005e84: aa0003f5    	mov	x21, x0
100005e88: 910e23e0    	add	x0, sp, #0x388
100005e8c: 94000d0c    	bl	0x1000092bc <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005e90: 52800014    	mov	w20, #0x0               ; =0
100005e94: 14000008    	b	0x100005eb4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6a8>
100005e98: 94032009    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
100005e9c: aa0003f5    	mov	x21, x0
100005ea0: 3dc007e0    	ldr	q0, [sp, #0x10]
100005ea4: 3d808260    	str	q0, [x19, #0x200]
100005ea8: 52800034    	mov	w20, #0x1               ; =1
100005eac: 14000002    	b	0x100005eb4 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6a8>
100005eb0: aa0003f5    	mov	x21, x0
100005eb4: 910d03e0    	add	x0, sp, #0x340
100005eb8: 94000c3f    	bl	0x100008fb4 <core::ptr::drop_glue::<raster::api::completion::Ticket<u64>>>
100005ebc: 52800013    	mov	w19, #0x0               ; =0
100005ec0: 52800016    	mov	w22, #0x0               ; =0
100005ec4: 370002b4    	tbnz	w20, #0x0, 0x100005f18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x70c>
100005ec8: 1400001f    	b	0x100005f44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x738>
100005ecc: aa0003f5    	mov	x21, x0
100005ed0: 9104a3e0    	add	x0, sp, #0x128
100005ed4: 9400121b    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005ed8: 14000002    	b	0x100005ee0 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6d4>
100005edc: aa0003f5    	mov	x21, x0
100005ee0: 910343e0    	add	x0, sp, #0xd0
100005ee4: 9400096d    	bl	0x100008498 <core::ptr::drop_glue::<core::option::Option<raster::engine::version_permit::VersionPermit>>>
100005ee8: 14000006    	b	0x100005f00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6f4>
100005eec: aa0003f5    	mov	x21, x0
100005ef0: 9103e3e0    	add	x0, sp, #0xf8
100005ef4: 94001213    	bl	0x10000a740 <core::ptr::drop_glue::<raster::types::error::Error>>
100005ef8: 14000002    	b	0x100005f00 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x6f4>
100005efc: aa0003f5    	mov	x21, x0
100005f00: 52800033    	mov	w19, #0x1               ; =1
100005f04: 14000009    	b	0x100005f28 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x71c>
100005f08: aa0003f5    	mov	x21, x0
100005f0c: 1400000e    	b	0x100005f44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x738>
100005f10: f9400bf6    	ldr	x22, [sp, #0x10]
100005f14: aa0003f5    	mov	x21, x0
100005f18: 910563e0    	add	x0, sp, #0x158
100005f1c: 94000ce8    	bl	0x1000092bc <core::ptr::drop_glue::<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>>
100005f20: 52800013    	mov	w19, #0x0               ; =0
100005f24: 36000116    	tbz	w22, #0x0, 0x100005f44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x738>
100005f28: f94037e8    	ldr	x8, [sp, #0x68]
100005f2c: f9400109    	ldr	x9, [x8]
100005f30: f1000529    	subs	x9, x9, #0x1
100005f34: f9000109    	str	x9, [x8]
100005f38: 54000061    	b.ne	0x100005f44 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x738>
100005f3c: 9101a3e0    	add	x0, sp, #0x68
100005f40: 9401d9e6    	bl	0x10007c6d8 <<alloc::rc::Rc<()>>::drop_slow>
100005f44: f9401be0    	ldr	x0, [sp, #0x30]
100005f48: b9402fe1    	ldr	w1, [sp, #0x2c]
100005f4c: 94000f47    	bl	0x100009c68 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<raster::engine::checkpoint::CheckpointRuntime>>>
100005f50: 37000093    	tbnz	w19, #0x0, 0x100005f60 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x754>
100005f54: 1400000b    	b	0x100005f80 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x774>
100005f58: 94031fd9    	bl	0x1000cdebc <core::panicking::panic_in_cleanup>
100005f5c: aa0003f5    	mov	x21, x0
100005f60: b94047e8    	ldr	w8, [sp, #0x44]
100005f64: 340000e8    	cbz	w8, 0x100005f80 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x774>
100005f68: f94027e8    	ldr	x8, [sp, #0x48]
100005f6c: b40000a8    	cbz	x8, 0x100005f80 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::rmw::<parity::Request>+0x774>
100005f70: f9401fe0    	ldr	x0, [sp, #0x38]
100005f74: f94027e1    	ldr	x1, [sp, #0x48]
100005f78: 52800022    	mov	w2, #0x1                ; =1
100005f7c: 9401252c    	bl	0x10004f42c <__rustc::__rust_dealloc>
100005f80: aa1503e0    	mov	x0, x21
100005f84: 940320af    	bl	0x1000ce240 <dyld_stub_binder+0x1000ce240>

