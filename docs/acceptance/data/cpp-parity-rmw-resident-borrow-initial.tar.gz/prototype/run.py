"""Measure resident RMW against its exact frozen direct parent."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/rmw-resident-borrow');base=Path('target/parity-profile/key-preparation-inline/candidate-bins');candidate=root/'candidate-bins'
cases=[('rmw-uniform','rmw/uniform/1'),('rmw-worker-four','rmw/worker-hot/4'),('rmw-shared-four','rmw/shared-hot/4'),('rmw-uniform-four','rmw/uniform/4'),('read-uniform','read/uniform/1'),('upsert-uniform','upsert/uniform/1'),('read-shared-four','read/shared-hot/4'),('aa-rmw-uniform','rmw/uniform/1'),('aa-rmw-worker-four','rmw/worker-hot/4')]
commands=[]
for name,case in cases:
 binary=base if name.startswith('aa-') else candidate
 commands.append((name,['python3','tools/performance/compare.py','--rust',str(binary/'parity'),'--baseline-rust',str(base/'parity'),'--case',case,'--min-throughput','.98','--max-p99','1.10']))
commands += [('variable',['python3','tools/performance/compare_repeat.py','--candidate',str(candidate/'benchmark_probe'),'--baseline',str(base/'benchmark_probe')]),('disk',['python3','tools/acceptance/paired_benchmark.py','--baseline',str(base/'benchmark'),'--candidate',str(candidate/'benchmark'),'--case','u64-hot-t4-disk-r1','--case','bytes-uniform-t1-disk-r1','--interleaved-control'])]
runs=[]
for name,cmd in commands:
 cmd+=['--output',str(root/name)];print('START',name,flush=True)
 with (root/(name+'.log')).open('w') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 runs.append({'name':name,'command':cmd,'exit_code':result.returncode});(root/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 assert (root/name/'comparison.json').exists(),name
 if name not in ['variable','disk']:print((root/(name+'.log')).read_text(),flush=True)
 else:print('DONE',name,'exit',result.returncode,flush=True)
