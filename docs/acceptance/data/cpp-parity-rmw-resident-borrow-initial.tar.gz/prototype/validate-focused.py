"""Check focused integer output and preserve all candidate/control failures."""
from pathlib import Path
import hashlib,json,statistics,sys
sys.path.insert(0,'tools/performance')
from cpu_profile import validate_output
root=Path('target/parity-profile/rmw-resident-borrow');base=Path('target/parity-profile/key-preparation-inline/candidate-bins')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path in ['src/api/session.rs','src/engine/rmw.rs','tests/p3_failures.rs']:assert Path(path).read_bytes()==(root/('candidate-'+Path(path).name)).read_bytes()
for name,digest in read(root/'binary-sha256.json').items():assert sha(root/'candidate-bins'/name)==digest
rows=[];outputs=0
for run in read(root/'runs.json'):
 name=run['name']
 if name in ['variable','disk']:continue
 d=root/name;env=read(d/'environment.json');comparison=read(d/'comparison.json');assert len(comparison)==1;row=comparison[0];case=row['case']
 assert env['binary_sha256']['baseline']==sha(base/'parity')
 assert env['binary_sha256']['rust']==sha((base if name.startswith('aa-') else root/'candidate-bins')/'parity')
 threads=int(case.split('/')[-1]);n=env['count']//threads;samples=threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
 for label in ['baseline','rust']:
  for i in range(-1,env['rounds']):
   prefix=d/f"{case.replace('/','-')}-{i}-{label}";raw=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,env['count'])
   assert raw['samples']==samples and not prefix.with_suffix('.stderr').read_text()
   if i>=0:assert raw==row['rows'][label][i]
   outputs+=1
 med=lambda label,key:statistics.median(r[key] for r in row['rows'][label]);t=med('baseline','elapsed_ns')/med('rust','elapsed_ns');p=med('rust','p99_ns')/med('baseline','p99_ns')
 assert row['throughput_ratio']==t and row['p99_ratio']==p and row['passed']==(t>=.98 and p<=1.1)
 rows.append({'name':name,'case':case,'throughput_ratio':t,'p99_ratio':p,'passed':row['passed']}|({'reciprocal_control_valid':.98<=t<=1/.98 and 1/1.1<=p<=1.1} if name.startswith('aa-') else {}))
assert outputs==90
strict=[{k:r[k] for k in ['case','throughput_ratio','p99_ratio','control_throughput_ratio','control_p99_ratio']}|{'candidate_passed':r['throughput_ratio']>=.98 and r['p99_ratio']<=1.1,'reciprocal_control_valid':.98<=r['control_throughput_ratio']<=1/.98 and 1/1.1<=r['control_p99_ratio']<=1.1} for r in read(root/'disk/comparison.json')]
report={'raw_integer_outputs':outputs,'checks':read(root/'checks.json'),'ordinary':rows,'variable':read(root/'variable/comparison.json')['comparisons'],'disk':strict,'lifecycle_validation':read(root/'lifecycle-validation.json'),'status':'Initial borrowed-RMW prototype: material integer gains but invalid four-thread control, valid-control variable throughput and disk P99 regressions. Not accepted.'}
(root/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
