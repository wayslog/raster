"""Compare the flat pause budget against exact57637a1."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/gate-flat-backoff');base=Path('target/parity-profile/rmw-narrow-progress/candidate-bins');candidate=root/'candidate-bins';runs=[]
commands=[('variable',['python3','tools/performance/compare_repeat.py','--baseline',str(base/'benchmark_probe'),'--candidate',str(candidate/'benchmark_probe')])]
for name,case in [('long-rmw-shared','rmw/shared-hot/4'),('long-upsert-shared','upsert/shared-hot/4'),('long-rmw-worker','rmw/worker-hot/4')]:
 commands.append((name,['python3',str(root/'long-case.py'),'--baseline',str(base/'parity'),'--candidate',str(candidate/'parity'),'--case',case,'--count','20000000','--allow-unpinned']))
for name,case in [('rmw-single','rmw/worker-hot/1'),('read-single','read/uniform/1')]:
 commands.append((name,['python3','tools/performance/compare.py','--baseline-rust',str(base/'parity'),'--rust',str(candidate/'parity'),'--case',case,'--min-throughput','.98','--max-p99','1.10']))
for name,command in commands:
 command+=['--output',str(root/name)];print('START',name,flush=True)
 with (root/(name+'.log')).open('w') as log:process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 runs.append({'name':name,'command':command,'exit_code':process.returncode});(root/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 result=json.loads((root/name/'comparison.json').read_text());print(name,result['comparisons'] if isinstance(result,dict) else [{k:v for k,v in r.items() if k!='rows'} for r in result],flush=True)
