"""Verify focused flat-backoff results, fixed inputs, identities and controls."""
from pathlib import Path
import hashlib,json,statistics,sys
sys.path.insert(0,'tools/performance')
from cpu_profile import validate_output
from focused_compare import LABELS,ORDERS,summarize
from compare_repeat import validate as repeat_validate,KINDS
root=Path('target/parity-profile/gate-flat-backoff');base=Path('target/parity-profile/rmw-narrow-progress/candidate-bins')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in read(root/'binary-sha256.json').items():assert sha(root/'candidate-bins'/name)==digest
for name,digest in read(root/'source-sha256.json').items():assert sha(Path(name))==digest
outputs=0;long={};ordinary=[]
for run in read(root/'runs.json'):
 name=run['name']
 if name=='variable':continue
 d=root/name;env=read(d/'environment.json');case=env.get('case') or read(d/'comparison.json')[0]['case'];count=env['count'];threads=int(case.split('/')[-1]);n=count//threads;samples=threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
 if name.startswith('long-'):
  assert count==20_000_000 and env['orders']==[list(o) for o in ORDERS]
  for label in LABELS:assert env['binary_sha256'][label]==sha((root/'candidate-bins' if label=='candidate' else base)/'parity')
  entries=[]
  for index,order in [(-1,LABELS),*enumerate(ORDERS)]:
   for label in order:
    prefix=d/f'round-{index}-{label}';row=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,count)
    assert row['samples']==samples and not prefix.with_suffix('.stderr').read_text()
    assert read(prefix.with_suffix('.command.json'))[1:]==[*case.split('/'),str(count),'64']
    if index>=0:entries.append({'round':index,'name':label,'result':row})
    outputs+=1
  result=summarize(entries);assert entries==read(d/'results.json') and result==read(d/'comparison.json')
  assert run['exit_code']==(0 if result['passed'] else 1);long[case]=result['comparisons']
 else:
  assert env['binary_sha256']['baseline']==sha(base/'parity') and env['binary_sha256']['rust']==sha(root/'candidate-bins/parity')
  rows=read(d/'comparison.json');assert len(rows)==1;r=rows[0]
  for label in ['baseline','rust']:
   for index in range(-1,env['rounds']):
    prefix=d/f"{case.replace('/','-')}-{index}-{label}";row=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,count)
    assert row['samples']==samples and not prefix.with_suffix('.stderr').read_text()
    if index>=0:assert row==r['rows'][label][index]
    outputs+=1
  med=lambda label,key:statistics.median(row[key] for row in r['rows'][label]);t=med('baseline','elapsed_ns')/med('rust','elapsed_ns');p=med('rust','p99_ns')/med('baseline','p99_ns')
  assert r['throughput_ratio']==t and r['p99_ratio']==p and r['passed']==(t>=.98 and p<=1.1)
  ordinary.append({k:v for k,v in r.items() if k!='rows'})
assert outputs==83
d=root/'variable';env=read(d/'environment.json');pairs=read(d/'pairs.json');assert len(pairs)==6
for label in LABELS:assert env['binary_sha256'][label]==sha((root/'candidate-bins' if label=='candidate' else base)/'benchmark_probe')
for index,pair in enumerate(pairs):
 assert pair['order']==list(ORDERS[index])
 for label in LABELS:assert repeat_validate(d/f'pair{index}-{label}',32)==pair['samples'][label]
medians={label:{'elapsed_ns':statistics.median(p['samples'][label]['elapsed_ns'] for p in pairs),'overall_p99_ns':statistics.median(p['samples'][label]['overall_p99_ns'] for p in pairs),'engine_ns':[statistics.median(p['samples'][label]['engine_ns'][i] for p in pairs) for i in range(4)]} for label in LABELS}
result=read(d/'comparison.json');assert result['medians']==medians
for label in ['candidate','control']:
 t=medians['baseline']['elapsed_ns']/medians[label]['elapsed_ns'];p=medians[label]['overall_p99_ns']/medians['baseline']['overall_p99_ns']
 assert result['comparisons'][label]=={'throughput_ratio':t,'p99_ratio':p,'passed':t>=.98 and p<=1.1,'operation_time_ratios':{kind:medians[label]['engine_ns'][i]/medians['baseline']['engine_ns'][i] for i,kind in enumerate(KINDS)}}
variable=result['comparisons'];c=variable['control'];c['reciprocal_control_valid']=.98<=c['throughput_ratio']<=1/.98 and 1/1.1<=c['p99_ratio']<=1.1
report={'integer_raw_outputs':outputs,'variable_processes':18,'variable_trajectories':576,'source_and_binary_identity':'verified','long':long,'ordinary':ordinary,'variable':variable,'checks':read(root/'checks.json'),'scope':'Focused local prototype evidence; not complete C++ or regression acceptance'}
(root/'validated.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
