from pathlib import Path
import hashlib, json, subprocess, shutil
root=Path('target/parity-profile/borrowed-read-after-epoch')
if (root/'checks.json').exists():
    (root/'checks.json').rename(root/'fixture-checks.json')
checks=[]
for name,cmd in [('fmt',['cargo','fmt','--all']),('tests',['cargo','test','--locked','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('build',['cargo','build','--locked','--release','--all-features','--example','parity','--example','parity_scan','--example','benchmark','--example','benchmark_probe'])]:
    result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (root/(name+'.log')).write_text(result.stdout.replace(str(Path.cwd()),'worktree').replace(str(Path.home()),'user_directory'))
    checks.append({'name':name,'command':cmd,'exit_code':result.returncode})
    (root/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:
        print(result.stdout[-2500:].replace(str(Path.cwd()),'worktree'))
        raise SystemExit(result.returncode)
manifest=json.loads((root/'manifest.json').read_text())
manifest['source_sha256']={}
for name in ['src/engine/mod.rs','src/engine/read.rs','src/engine/read_ownership_tests.rs','src/engine/task.rs']:
    source=Path(name);target=root/'source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    manifest['source_sha256'][name]=hashlib.sha256(source.read_bytes()).hexdigest()
manifest['candidate_sha256']={}
directory=root/'candidate-bins';directory.mkdir(exist_ok=False)
for name in ['parity','parity_scan','benchmark','benchmark_probe']:
    target=directory/name
    shutil.copyfile(Path('target/release/examples')/name,target)
    target.chmod(0o755)
    manifest['candidate_sha256'][name]=hashlib.sha256(target.read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Candidate sources and executables frozen.',flush=True)
