"""Measure the two local failures and ownership hypothesis with rotating controls."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/rmw-engine-borrow');base=Path('target/parity-profile/rmw-resident-copy/candidate-bins');runs=[]
for name,case in [('long-rmw-single','rmw/worker-hot/1'),('long-read-four','read/worker-hot/4'),('long-rmw-four','rmw/worker-hot/4')]:
    command=['python3',str(root/'long-case.py'),'--baseline',str(base/'parity'),'--candidate',str(root/'candidate-bins/parity'),'--case',case,'--count','20000000','--allow-unpinned','--output',str(root/name)]
    print('START',name,flush=True)
    with (root/(name+'.log')).open('w') as log: process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    runs.append({'name':name,'case':case,'command':command,'exit_code':process.returncode});(root/'long-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    result=json.loads((root/name/'comparison.json').read_text());print(name,result['comparisons'],flush=True)
