"""Independently check all rotating-control outputs and exact binary identity."""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,'tools/performance')
from cpu_profile import validate_output
from focused_compare import LABELS,ORDERS,summarize
root=Path('target/parity-profile/rmw-engine-borrow');base=Path('target/parity-profile/rmw-resident-copy/candidate-bins')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in read(root/'binary-sha256.json').items():assert sha(root/'candidate-bins'/name)==digest
for name in ['rmw.rs','mod.rs','rmw_ownership_tests.rs']:assert Path('src/engine',name).read_bytes()==(root/('candidate-'+name)).read_bytes()
outputs=0;comparisons={}
for run in read(root/'long-runs.json'):
 d=root/run['name'];env=read(d/'environment.json');case=run['case'];count=env['count']
 assert env['case']==case and count==20_000_000 and env['orders']==[list(o) for o in ORDERS]
 assert env['inherited_cpu_affinity'] is None
 for label in LABELS:assert env['binary_sha256'][label]==sha((root/'candidate-bins' if label=='candidate' else base)/'parity')
 entries=[]
 for index,order in [(-1,LABELS),*enumerate(ORDERS)]:
  for label in order:
   prefix=d/f'round-{index}-{label}'
   row=validate_output(prefix.with_suffix('.stdout').read_text(),'rust',case,count)
   assert not prefix.with_suffix('.stderr').read_text()
   command=read(prefix.with_suffix('.command.json'));assert command[1:]==[*case.split('/'),str(count),'64']
   threads=int(case.split('/')[-1]);n=count//threads
   assert row['samples']==threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
   if index>=0:entries.append({'round':index,'name':label,'result':row})
   outputs+=1
 assert read(d/'results.json')==entries
 result=summarize(entries);assert result==read(d/'comparison.json')
 assert run['exit_code']==(0 if result['passed'] else 1)
 comparisons[case]=result['comparisons']
assert outputs==63
report={'raw_outputs':outputs,'count_per_process':20_000_000,'source_and_binary_identity':'verified','business_and_exact_sampling':'verified','comparisons':comparisons,'scope':'Local unpinned direct-parent diagnostics; not complete C++ acceptance'}
(root/'long-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
