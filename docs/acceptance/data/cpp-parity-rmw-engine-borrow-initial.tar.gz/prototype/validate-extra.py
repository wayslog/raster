"""Validate full integer sample schedules and retain shared-Read observations."""
from pathlib import Path
import hashlib,json
root=Path('target/parity-profile/rmw-engine-borrow');base=Path('target/parity-profile/rmw-resident-copy/candidate-bins')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
observations={};outputs=0
for name in ['matrix','control']:
 d=root/('full-'+name);env=read(d/'environment.json')
 assert env['binary_sha256']['baseline']==sha(base/'parity') and env['binary_sha256']['rust']==sha((root/'candidate-bins' if name=='matrix' else base)/'parity')
 for p in d.glob('*.stdout'):
  r=read(p);n=env['count']//r['threads'];assert r['samples']==r['threads']*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)));outputs+=1
 row=next(r for r in read(d/'comparison.json') if r['case']=='read/shared-hot/4')
 observations[name]={k:v for k,v in row.items() if k!='rows'}|{'per_round':{label:{key:[r[key] for r in rows] for key in ['elapsed_ns','p99_ns','pending','retries']} for label,rows in row['rows'].items()}}
env=read(root/'full-scans/environment.json');assert env['binary_sha256']['baseline']==sha(base/'parity_scan') and env['binary_sha256']['candidate']==sha(root/'candidate-bins/parity_scan')
assert outputs==360
report={'scheduled_integer_samples':'verified for360outputs','binary_identity':'verified','shared_read_observations':observations,'conclusion':'Observations are preserved without interpreting failures or invalid controls as acceptance.'}
(root/'full-extra-validation.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified360sample schedules, binary identities and shared-Read observations.')
