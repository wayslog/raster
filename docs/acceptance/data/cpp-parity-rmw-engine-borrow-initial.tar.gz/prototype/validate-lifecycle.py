"""Validate full local lifecycle and repeated variable input evidence."""
from pathlib import Path
import csv,hashlib,itertools,json,statistics,sys
sys.path[:0]=['tools/acceptance','tools/performance']
from audit_benchmark import trace_audit
from compare_repeat import validate,KINDS
root=Path('target/parity-profile/rmw-engine-borrow')
base=Path('target/parity-profile/rmw-resident-copy/candidate-bins')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['baseline','candidate','control'];d=root/'full-variable';env=read(d/'environment.json');pairs=read(d/'pairs.json');assert len(pairs)==6
for label in labels:assert env['binary_sha256'][label]==sha((root/'candidate-bins' if label=='candidate' else base)/'benchmark_probe')
for number,pair in enumerate(pairs):
 assert pair['order']==list(itertools.permutations(labels))[number] or pair['order']==list(list(itertools.permutations(labels))[number])
 for label in labels:assert validate(d/f'pair{number}-{label}',32)==pair['samples'][label]
medians={label:{'elapsed_ns':statistics.median(p['samples'][label]['elapsed_ns'] for p in pairs),'overall_p99_ns':statistics.median(p['samples'][label]['overall_p99_ns'] for p in pairs),'engine_ns':[statistics.median(p['samples'][label]['engine_ns'][i] for p in pairs) for i in range(4)]} for label in labels}
result=read(d/'comparison.json');assert medians==result['medians']
for label in ['candidate','control']:
 t=medians['baseline']['elapsed_ns']/medians[label]['elapsed_ns'];p=medians[label]['overall_p99_ns']/medians['baseline']['overall_p99_ns']
 assert result['comparisons'][label]=={'throughput_ratio':t,'p99_ratio':p,'passed':t>=.98 and p<=1.1,'operation_time_ratios':{kind:medians[label]['engine_ns'][i]/medians['baseline']['engine_ns'][i] for i,kind in enumerate(KINDS)}}
d=root/'full-lifecycles';binaries=read(d/'binaries.json')
for label in labels:assert binaries[label]['sha256']==sha((root/'candidate-bins' if label=='candidate' else base)/'benchmark')
summary=read(d/'comparison.json');assert len(summary)==3
models={};processes=0
for comparison in summary:
 case=comparison['case'];pairs=read(d/(case+'-pairs.json'));assert len(pairs)==6
 for index,pair in enumerate(pairs,1):
  assert pair['pair']==index and pair['order']==list(list(itertools.permutations(labels))[index-1])
  for label in labels:
   output=d/f'{case}-pair{index}-{label}';rows=list(csv.DictReader((output/'matrix.csv').open()));assert len(rows)==1
   row=rows[0];assert row==pair[label]
   trace=output/(row['input_id']+'.trace');digest=sha(trace);assert digest==comparison['input_sha256']
   if digest not in models:models[digest]=trace_audit(trace,case.startswith('bytes'),'-hot-' in case,int(row['threads']))
   model=models[digest];assert int(row['operation_count'])==16384
   assert int(row['application_write_bytes'])==model['application_write_bytes']
   assert int(row['success'])+int(row['missing'])==16384 and model['success']<=int(row['success'])<=16384
   assert int(row['tombstone'])==model['tombstone']
   log=(d/f'{case}-pair{index}-{label}.txt').read_text()
   assert f'benchmark {case} passed:16384 steps_four_operations,' in log and '2048 keys_and_tombstone_validation' in log and 'panicked at' not in log
   for metric in comparison['medians'][label]:
    assert comparison['medians'][label][metric]==statistics.median(float(p[label][metric]) for p in pairs)
   processes+=1
 m=comparison['medians']
 for label,prefix in [('candidate',''),('control','control_')]:
  assert comparison[prefix+'throughput_ratio']==m[label]['operations_per_second']/m['baseline']['operations_per_second']
  assert comparison[prefix+'p99_ratio']==m[label]['P99nanoseconds']/m['baseline']['P99nanoseconds']
assert processes==54
report={'lifecycle_processes':processes,'independent_models':len(models),'variable_processes':18,'variable_trajectories':576,'binary_identity':'verified','business_recovery_markers':'verified','medians':'verified'}
(root/'lifecycle-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
