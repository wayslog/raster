"""Separate the success-flattening effect from the combined candidate."""
from pathlib import Path
import json, subprocess
root=Path('target/parity-profile/upsert-flat-result')
original='target/parity-profile/guarded-upsert-routing/candidate-bins/parity'
channel='target/parity-profile/upsert-result-channel/candidate-bins/parity'
candidate=str(root/'candidate-bins/parity')
runs=[]
comparisons=[(name,reference,case,False) for name,reference in [('component',channel),('combined',original)] for case in ['upsert/uniform/1','upsert/shared-hot/1','upsert/worker-hot/4']]
comparisons += [('control-channel',channel,'upsert/shared-hot/1',True),('control-original',original,'upsert/shared-hot/1',True)]
for name,reference,case,control in comparisons:
    out=root/(name+'-'+case.replace('/','-'))
    command=['python3','tools/performance/compare.py','--rust',reference if control else candidate,'--baseline-rust',reference,'--output',str(out),'--min-throughput','0.98','--max-p99','1.10','--case',case]
    p=subprocess.run(command,capture_output=True,text=True)
    (root/(out.name+'.log')).write_text(p.stdout+p.stderr)
    runs.append({'case':case,'name':name,'command':command,'exit_code':p.returncode})
    (root/'benchmark-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    if (out/'comparison.json').exists():
        for row in json.loads((out/'comparison.json').read_text()):
            print(name,case,{k:row[k] for k in ['throughput_ratio','p99_ratio','passed']},flush=True)
    else: raise RuntimeError(p.stderr)
