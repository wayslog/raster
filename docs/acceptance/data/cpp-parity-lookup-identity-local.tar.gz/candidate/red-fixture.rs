use super::*;
use crate::{device::memory::MemoryDevice, schema::builtin::AtomicU64Value, storage::SegmentedStorage};

fn owners() -> (HybridLog<AtomicU64Value>, SegmentedStorage) {
    let log = HybridLog::new(
        LogConfig { page_bytes: 256, memory_pages: 2, mutable_fraction: 0.5 },
        Arc::new(AtomicU64Value),
    ).unwrap();
    let storage = SegmentedStorage::new(Arc::new(MemoryDevice::new(16, 4096).unwrap()), 4096).unwrap();
    (log, storage)
}

#[test]
fn resident_lookup_identity_does_not_retain_shared_control_owners() {
    let (log, storage) = owners();
    let address = log.finish_initialization(log.reserve_record(b"key", None, 7).unwrap()).unwrap();
    let counts = (Arc::strong_count(&log.state), Arc::strong_count(&storage.identity));
    let mut lookup = log.lookup_deferred(&storage, b"key".to_vec(), Some(address), crate::device::CompletionRoute(7)).unwrap();
    let observed = (Arc::strong_count(&log.state), Arc::strong_count(&storage.identity));
    match lookup.step(&log, &storage, PollBudget::default()).unwrap() {
        lookup::LookupStep::Resident(lease) => assert_eq!(lease.read(|v| v).unwrap(), 7),
        _ => panic!("Expected an actual resident lookup"),
    }
    drop(lookup);
    assert_eq!((Arc::strong_count(&log.state), Arc::strong_count(&storage.identity)), counts);
    assert_eq!(observed, counts, "Identity checks must not increment shared reference counts for each query");
}
