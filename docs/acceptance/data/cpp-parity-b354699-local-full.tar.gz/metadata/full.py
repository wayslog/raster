"""Run broad local regression and all integer controls against fixed44."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/rmw-resident-copy');base=Path('target/parity-profile/key-preparation-inline/candidate-bins');candidate=root/'candidate-bins'
commands=[('matrix',['python3','tools/performance/compare.py','--rust',str(candidate/'parity'),'--baseline-rust',str(base/'parity'),'--min-throughput','.98','--max-p99','1.10']),('control',['python3','tools/performance/compare.py','--rust',str(base/'parity'),'--baseline-rust',str(base/'parity'),'--min-throughput','.98','--max-p99','1.10']),('scans',['python3','tools/performance/compare_scan.py','--baseline',str(base/'parity_scan'),'--candidate',str(candidate/'parity_scan')]),('lifecycles',['python3','tools/acceptance/paired_benchmark.py','--baseline',str(base/'benchmark'),'--candidate',str(candidate/'benchmark'),'--interleaved-control'])]
runs=[]
for name,cmd in commands:
 cmd+=['--output',str(root/('full-'+name))];print('START',name,flush=True)
 with (root/('full-'+name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 runs.append({'name':name,'command':cmd,'exit_code':p.returncode});(root/'full-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 rows=json.loads((root/('full-'+name)/'comparison.json').read_text())
 if name=='lifecycles':print([{k:r[k] for k in ['case','throughput_ratio','p99_ratio','control_throughput_ratio','control_p99_ratio']}|{'candidate_passed':r['throughput_ratio']>=.98 and r['p99_ratio']<=1.1,'reciprocal_control_valid':.98<=r['control_throughput_ratio']<=1/.98 and 1/1.1<=r['control_p99_ratio']<=1.1} for r in rows],flush=True)
 else:
  print(name,sum(r['passed'] for r in rows),'/',len(rows),flush=True)
  for r in rows:
   if not r['passed']:print({k:v for k,v in r.items() if k!='rows'},flush=True)
