from pathlib import Path
import json, subprocess
r=Path('target/parity-profile/upsert-result-channel');p=Path('src/engine/upsert.rs');s=(r/'upsert.rs.before').read_text()
s=s.replace('''enum UpsertStep<T> {
    Ready(OperationResult<T>),
    Retry,
}''','''// Keep the common return value independent of the public error payload.
// Failures are moved into the caller's local slot without allocating.
enum UpsertStep<T> {
    Ready(Outcome<T>),
    Retry,
    Failed,
}''')
s=s.replace('''    ) -> UpsertStep<O::Output> {
        if self.engine.failed.load(Ordering::SeqCst) {
            return UpsertStep::Ready(Err(OperationError {
                cause: Error::InvalidState("engine_failed_closed"),
                effect: self.effect,
            }));''','''        failure: &mut Option<OperationError>,
    ) -> UpsertStep<O::Output> {
        if self.engine.failed.load(Ordering::SeqCst) {
            *failure = Some(OperationError {
                cause: Error::InvalidState("engine_failed_closed"),
                effect: self.effect,
            });
            return UpsertStep::Failed;''')
s=s.replace('''                return UpsertStep::Ready(Err(OperationError {
                    cause,
                    effect: self.effect,
                }));''','''                *failure = Some(OperationError {
                    cause,
                    effect: self.effect,
                });
                return UpsertStep::Failed;''')
old='''        UpsertStep::Ready(
            result
                .map(|value| value.expect("Waiting space excluded"))
                .map_err(|cause| OperationError {
                    cause,
                    effect: self.effect,
                }),
        )'''
new='''        match result {
            Ok(value) => UpsertStep::Ready(value.expect("Waiting space excluded")),
            Err(cause) => {
                *failure = Some(OperationError {
                    cause,
                    effect: self.effect,
                });
                UpsertStep::Failed
            }
        }'''
assert old in s;s=s.replace(old,new)
old='''        match self.run_locked(None) {
            UpsertStep::Retry => TaskStep::Retry,
            UpsertStep::Ready(result) => {
                self.finish(result);
                TaskStep::Complete
            }
        }'''
new='''        let mut failure = None;
        match self.run_locked(None, &mut failure) {
            UpsertStep::Retry => TaskStep::Retry,
            UpsertStep::Ready(result) => {
                self.finish(Ok(result));
                TaskStep::Complete
            }
            UpsertStep::Failed => {
                self.finish(Err(failure.expect("Failed steps provide an error")));
                TaskStep::Complete
            }
        }'''
assert old in s;s=s.replace(old,new)
old='''        match task.run_locked(Some(&mut hint)) {
            UpsertStep::Ready(result) => {
                let result = task
                    .finalize(result)
                    .expect("Synchronous requests are terminated only once");
                self.record_ready(&mut task.monitor, task.mailbox.registered_id(), &result);
                self.retain_operation(session, &mut task.mailbox);
                Ok(Submission::Ready(result))
            }
            UpsertStep::Retry => {'''
new='''        let mut failure = None;
        let result = match task.run_locked(Some(&mut hint), &mut failure) {
            UpsertStep::Ready(result) => Ok(result),
            UpsertStep::Failed => Err(failure.expect("Failed steps provide an error")),
            UpsertStep::Retry => {'''
assert old in s;s=s.replace(old,new)
old='''                Ok(Submission::Pending(ticket))
            }
        }
    }
}'''
new='''                return Ok(Submission::Pending(ticket));
            }
        };
        let result = task
            .finalize(result)
            .expect("Synchronous requests are terminated only once");
        self.record_ready(&mut task.monitor, task.mailbox.registered_id(), &result);
        self.retain_operation(session, &mut task.mailbox);
        Ok(Submission::Ready(result))
    }
}'''
assert old in s;s=s.replace(old,new)
p.write_text(s+(r/'layout-probe.rs').read_text())
m=json.loads((r/'manifest.json').read_text());m.update(hypotheses=['Separating the failure slot shrinks the normal returned value and improves hot single-thread Upsert throughput by at least five percent.','Nested result wrappers cause additional result moves.','The full initial task state dominates after return-value costs.'],single_change='Return failures through a caller-owned local slot; retain public error payloads, ownership, allocation behavior and all admission/execution/finalization protocols.')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
