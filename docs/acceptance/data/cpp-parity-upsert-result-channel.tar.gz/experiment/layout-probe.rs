
#[cfg(test)]
#[test]
fn diagnostic_upsert_result_layout() {
    println!("error={} operation_error={} outcome={} operation_result={} upsert_step={} optional_result={}",
        std::mem::size_of::<Error>(), std::mem::size_of::<OperationError>(),
        std::mem::size_of::<Outcome<u64>>(), std::mem::size_of::<OperationResult<u64>>(),
        std::mem::size_of::<UpsertStep<u64>>(), std::mem::size_of::<Option<OperationResult<u64>>>());
}
