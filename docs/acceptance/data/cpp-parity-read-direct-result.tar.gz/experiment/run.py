"""Check direct Read result delivery against the frozen original runtime."""
from pathlib import Path
import json,subprocess
root=Path("target/parity-profile/read-direct-result")
base=Path("target/parity-profile/upsert-flat-result/candidate-bins")
candidate=root/"candidate-bins"
cases=[("read-uniform","read/uniform/1"),("read-shared","read/shared-hot/1"),("read-four","read/uniform/4"),("read-shared-four","read/shared-hot/4"),("upsert-uniform","upsert/uniform/1"),("upsert-four","upsert/worker-hot/4"),("rmw-shared","rmw/shared-hot/1"),("control-read","read/uniform/1"),("control-read-four","read/uniform/4")]
commands=[]
for name,case in cases:
 binary=(base if name.startswith("control") else candidate)/"parity"
 commands.append((name,["python3","tools/performance/compare.py","--rust",str(binary),"--baseline-rust",str(base/"parity"),"--case",case,"--min-throughput","0.98","--max-p99","1.10"]))
commands.append(("result-budget",["python3","tools/performance/compare_result_budget.py","--rust",str(candidate/"result_budget"),"--baseline-rust","target/parity-profile/result-budget-front/baseline-bins/result_budget"]))
runs=[]
for name,cmd in commands:
 cmd += ["--output",str(root/name)]
 print("START",name,flush=True)
 with (root/(name+".log")).open("w") as log:
  p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 runs.append({"name":name,"command":cmd,"exit_code":p.returncode})
 (root/"runs.json").write_text(json.dumps(runs,indent=2)+"\n")
 assert (root/name/"comparison.json").exists(),name
 print((root/(name+".log")).read_text(),flush=True)
