0000000100030080 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint>:
100030080: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100030084: a90167fa    	stp	x26, x25, [sp, #0x10]
100030088: a9025ff8    	stp	x24, x23, [sp, #0x20]
10003008c: a90357f6    	stp	x22, x21, [sp, #0x30]
100030090: a9044ff4    	stp	x20, x19, [sp, #0x40]
100030094: a9057bfd    	stp	x29, x30, [sp, #0x50]
100030098: 910143fd    	add	x29, sp, #0x50
10003009c: d10bc3ff    	sub	sp, sp, #0x2f0
1000300a0: aa0603f3    	mov	x19, x6
1000300a4: aa0003f4    	mov	x20, x0
1000300a8: a90217e4    	stp	x4, x5, [sp, #0x20]
1000300ac: f940005b    	ldr	x27, [x2]
1000300b0: 52838508    	mov	w8, #0x1c28             ; =7208
1000300b4: 8b08037a    	add	x26, x27, x8
1000300b8: 08dfff48    	ldarb	w8, [x26]
1000300bc: 340001a8    	cbz	w8, 0x1000300f0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x70>
1000300c0: f9400268    	ldr	x8, [x19]
1000300c4: b100051f    	cmn	x8, #0x1
1000300c8: 54000060    	b.eq	0x1000300d4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x54>
1000300cc: aa1303e0    	mov	x0, x19
1000300d0: 97fffddd    	bl	0x10002f844 <core::ptr::drop_glue::<raster::types::error::Error>>
1000300d4: 528000e8    	mov	w8, #0x7                ; =7
1000300d8: f0000549    	adrp	x9, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
1000300dc: 91322d29    	add	x9, x9, #0xc8b
1000300e0: a9002668    	stp	x8, x9, [x19]
1000300e4: 52800288    	mov	w8, #0x14               ; =20
1000300e8: f9000a68    	str	x8, [x19, #0x10]
1000300ec: 14000017    	b	0x100030148 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc8>
1000300f0: aa0303f7    	mov	x23, x3
1000300f4: aa0103f5    	mov	x21, x1
1000300f8: f940ac21    	ldr	x1, [x1, #0x158]
1000300fc: 910602a8    	add	x8, x21, #0x180
100030100: f940c2a9    	ldr	x9, [x21, #0x180]
100030104: f100013f    	cmp	x9, #0x0
100030108: 9a8803e2    	csel	x2, xzr, x8, eq
10003010c: 9100c3e8    	add	x8, sp, #0x30
100030110: 910d0360    	add	x0, x27, #0x340
100030114: 9400ba87    	bl	0x10005eb30 <<raster::engine::version_permit::VersionPermits>::ready_initial>
100030118: f9401be8    	ldr	x8, [sp, #0x30]
10003011c: b100051f    	cmn	x8, #0x1
100030120: 540002a0    	b.eq	0x100030174 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xf4>
100030124: f9400268    	ldr	x8, [x19]
100030128: b100051f    	cmn	x8, #0x1
10003012c: 54000060    	b.eq	0x100030138 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb8>
100030130: aa1303e0    	mov	x0, x19
100030134: 97fffdc4    	bl	0x10002f844 <core::ptr::drop_glue::<raster::types::error::Error>>
100030138: ad4187e0    	ldp	q0, q1, [sp, #0x30]
10003013c: ad000660    	stp	q0, q1, [x19]
100030140: 3dc017e0    	ldr	q0, [sp, #0x50]
100030144: 3d800a60    	str	q0, [x19, #0x20]
100030148: 3900c27f    	strb	wzr, [x19, #0x30]
10003014c: 52800088    	mov	w8, #0x4                ; =4
100030150: 39000288    	strb	w8, [x20]
100030154: 910bc3ff    	add	sp, sp, #0x2f0
100030158: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10003015c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100030160: a94357f6    	ldp	x22, x21, [sp, #0x30]
100030164: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100030168: a94167fa    	ldp	x26, x25, [sp, #0x10]
10003016c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100030170: d65f03c0    	ret
100030174: 3940e3e8    	ldrb	w8, [sp, #0x38]
100030178: 36004ca8    	tbz	w8, #0x0, 0x100030b0c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa8c>
10003017c: 910243f9    	add	x25, sp, #0x90
100030180: aa1503f6    	mov	x22, x21
100030184: f8418ec8    	ldr	x8, [x22, #0x18]!
100030188: 910243e9    	add	x9, sp, #0x90
10003018c: 9100412a    	add	x10, x9, #0x10
100030190: f9000fea    	str	x10, [sp, #0x18]
100030194: b27d013c    	orr	x28, x9, #0x8
100030198: f100091f    	cmp	x8, #0x2
10003019c: 540034e1    	b.ne	0x100030838 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x7b8>
1000301a0: f94013e8    	ldr	x8, [sp, #0x20]
1000301a4: b40002e8    	cbz	x8, 0x100030200 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x180>
1000301a8: f940aeb8    	ldr	x24, [x21, #0x158]
1000301ac: 910402a0    	add	x0, x21, #0x100
1000301b0: 94015fec    	bl	0x100088160 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
1000301b4: 39470368    	ldrb	w8, [x27, #0x1c0]
1000301b8: 36000528    	tbz	w8, #0x0, 0x10003025c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1dc>
1000301bc: aa0003e3    	mov	x3, x0
1000301c0: aa0103e4    	mov	x4, x1
1000301c4: 910803e8    	add	x8, sp, #0x200
1000301c8: 9109a360    	add	x0, x27, #0x268
1000301cc: 91020361    	add	x1, x27, #0x80
1000301d0: aa1803e2    	mov	x2, x24
1000301d4: 94015878    	bl	0x1000863b4 <<raster::cache::ReadCache>::resolve>
1000301d8: f94103e8    	ldr	x8, [sp, #0x200]
1000301dc: 910643e9    	add	x9, sp, #0x190
1000301e0: 3cc78120    	ldur	q0, [x9, #0x78]
1000301e4: 3cc88121    	ldur	q1, [x9, #0x88]
1000301e8: ad0c87e0    	stp	q0, q1, [sp, #0x190]
1000301ec: 3cc98120    	ldur	q0, [x9, #0x98]
1000301f0: 3d806fe0    	str	q0, [sp, #0x1b0]
1000301f4: f100091f    	cmp	x8, #0x2
1000301f8: 540009e0    	b.eq	0x100030334 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2b4>
1000301fc: 14000064    	b	0x10003038c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x30c>
100030200: f940aeb8    	ldr	x24, [x21, #0x158]
100030204: 910402a0    	add	x0, x21, #0x100
100030208: 94015fd6    	bl	0x100088160 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10003020c: aa0003e2    	mov	x2, x0
100030210: aa0103e3    	mov	x3, x1
100030214: 910803e8    	add	x8, sp, #0x200
100030218: 91020360    	add	x0, x27, #0x80
10003021c: aa1803e1    	mov	x1, x24
100030220: 97ff72d5    	bl	0x10000cd74 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index>
100030224: f94103e8    	ldr	x8, [sp, #0x200]
100030228: 910643e9    	add	x9, sp, #0x190
10003022c: 3cc78120    	ldur	q0, [x9, #0x78]
100030230: 3cc88121    	ldur	q1, [x9, #0x88]
100030234: ad0907e0    	stp	q0, q1, [sp, #0x120]
100030238: 3cc98120    	ldur	q0, [x9, #0x98]
10003023c: 3d8053e0    	str	q0, [sp, #0x140]
100030240: f100091f    	cmp	x8, #0x2
100030244: 54000361    	b.ne	0x1000302b0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x230>
100030248: ad4907e0    	ldp	q0, q1, [sp, #0x120]
10003024c: ad0487e0    	stp	q0, q1, [sp, #0x90]
100030250: 3dc053e0    	ldr	q0, [sp, #0x140]
100030254: 3d802fe0    	str	q0, [sp, #0xb0]
100030258: 14000208    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
10003025c: f94013e2    	ldr	x2, [sp, #0x20]
100030260: 910483e8    	add	x8, sp, #0x120
100030264: 91020360    	add	x0, x27, #0x80
100030268: aa1803e1    	mov	x1, x24
10003026c: 9400caf4    	bl	0x100062e3c <<raster::index::growth::MemIndex>::prepare_guarded>
100030270: a9522fe8    	ldp	x8, x11, [sp, #0x120]
100030274: a9532be9    	ldp	x9, x10, [sp, #0x130]
100030278: 3dc053e0    	ldr	q0, [sp, #0x140]
10003027c: 3d8077e0    	str	q0, [sp, #0x1d0]
100030280: f940abec    	ldr	x12, [sp, #0x150]
100030284: f900f3ec    	str	x12, [sp, #0x1e0]
100030288: f100091f    	cmp	x8, #0x2
10003028c: 540002a1    	b.ne	0x1000302e0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x260>
100030290: 3dc077e0    	ldr	q0, [sp, #0x1d0]
100030294: 3d808be0    	str	q0, [sp, #0x220]
100030298: f940f3e8    	ldr	x8, [sp, #0x1e0]
10003029c: f9011be8    	str	x8, [sp, #0x230]
1000302a0: f90107eb    	str	x11, [sp, #0x208]
1000302a4: f9010be9    	str	x9, [sp, #0x210]
1000302a8: f9010fea    	str	x10, [sp, #0x218]
1000302ac: 1400001c    	b	0x10003031c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x29c>
1000302b0: 3cca8120    	ldur	q0, [x9, #0xa8]
1000302b4: 910243ea    	add	x10, sp, #0x90
1000302b8: 3c868140    	stur	q0, [x10, #0x68]
1000302bc: 910643f9    	add	x25, sp, #0x190
1000302c0: 3ccb8120    	ldur	q0, [x9, #0xb8]
1000302c4: 3c878140    	stur	q0, [x10, #0x78]
1000302c8: f9412fe9    	ldr	x9, [sp, #0x258]
1000302cc: ad4907e0    	ldp	q0, q1, [sp, #0x120]
1000302d0: 3c838140    	stur	q0, [x10, #0x38]
1000302d4: 3c848141    	stur	q1, [x10, #0x48]
1000302d8: 3dc053e0    	ldr	q0, [sp, #0x140]
1000302dc: 14000037    	b	0x1000303b8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x338>
1000302e0: 3ccc8320    	ldur	q0, [x25, #0xc8]
1000302e4: 3c9883a0    	stur	q0, [x29, #-0x78]
1000302e8: 3dc077e0    	ldr	q0, [sp, #0x1d0]
1000302ec: 3c9703a0    	stur	q0, [x29, #-0x90]
1000302f0: f940f3ec    	ldr	x12, [sp, #0x1e0]
1000302f4: f81803ac    	stur	x12, [x29, #-0x80]
1000302f8: f100093f    	cmp	x9, #0x2
1000302fc: 54000261    	b.ne	0x100030348 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x2c8>
100030300: 528000e8    	mov	w8, #0x7                ; =7
100030304: d0000549    	adrp	x9, 0x1000da000 <GCC_except_table3>
100030308: 911b1129    	add	x9, x9, #0x6c4
10003030c: f90107e8    	str	x8, [sp, #0x208]
100030310: f9010be9    	str	x9, [sp, #0x210]
100030314: 52800468    	mov	w8, #0x23               ; =35
100030318: f9010fe8    	str	x8, [sp, #0x218]
10003031c: 910643e8    	add	x8, sp, #0x190
100030320: 3cc78100    	ldur	q0, [x8, #0x78]
100030324: 3cc88101    	ldur	q1, [x8, #0x88]
100030328: ad0c87e0    	stp	q0, q1, [sp, #0x190]
10003032c: 3cc98100    	ldur	q0, [x8, #0x98]
100030330: 3d806fe0    	str	q0, [sp, #0x1b0]
100030334: ad4c87e0    	ldp	q0, q1, [sp, #0x190]
100030338: ad0487e0    	stp	q0, q1, [sp, #0x90]
10003033c: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
100030340: 3d802fe0    	str	q0, [sp, #0xb0]
100030344: 140001cd    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030348: ad7b83a1    	ldp	q1, q0, [x29, #-0x90]
10003034c: ad1103e1    	stp	q1, q0, [sp, #0x220]
100030350: f85903ac    	ldur	x12, [x29, #-0x70]
100030354: f90103e8    	str	x8, [sp, #0x200]
100030358: f90107eb    	str	x11, [sp, #0x208]
10003035c: f9010be9    	str	x9, [sp, #0x210]
100030360: f9010fea    	str	x10, [sp, #0x218]
100030364: f90123ec    	str	x12, [sp, #0x240]
100030368: f90127e9    	str	x9, [sp, #0x248]
10003036c: f9012bea    	str	x10, [sp, #0x250]
100030370: f9012fff    	str	xzr, [sp, #0x258]
100030374: 910643e9    	add	x9, sp, #0x190
100030378: 3cc78120    	ldur	q0, [x9, #0x78]
10003037c: 3cc88121    	ldur	q1, [x9, #0x88]
100030380: 3cc98122    	ldur	q2, [x9, #0x98]
100030384: ad0d0be1    	stp	q1, q2, [sp, #0x1a0]
100030388: 3d8067e0    	str	q0, [sp, #0x190]
10003038c: 3cca8120    	ldur	q0, [x9, #0xa8]
100030390: 910243ea    	add	x10, sp, #0x90
100030394: 3c868140    	stur	q0, [x10, #0x68]
100030398: 910643f9    	add	x25, sp, #0x190
10003039c: 3ccb8120    	ldur	q0, [x9, #0xb8]
1000303a0: 3c878140    	stur	q0, [x10, #0x78]
1000303a4: f9412fe9    	ldr	x9, [sp, #0x258]
1000303a8: ad4c87e0    	ldp	q0, q1, [sp, #0x190]
1000303ac: 3c838140    	stur	q0, [x10, #0x38]
1000303b0: 3c848141    	stur	q1, [x10, #0x48]
1000303b4: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
1000303b8: 3c858140    	stur	q0, [x10, #0x58]
1000303bc: f9008fe9    	str	x9, [sp, #0x118]
1000303c0: f90063e8    	str	x8, [sp, #0xc0]
1000303c4: 39470368    	ldrb	w8, [x27, #0x1c0]
1000303c8: 360000c8    	tbz	w8, #0x0, 0x1000303e0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x360>
1000303cc: f9417f68    	ldr	x8, [x27, #0x2f8]
1000303d0: 52800038    	mov	w24, #0x1               ; =1
1000303d4: 91004100    	add	x0, x8, #0x10
1000303d8: 52800001    	mov	w1, #0x0                ; =0
1000303dc: 94018f2e    	bl	0x100094094 <<raster::engine::metrics::Metrics>::cache>
1000303e0: f9408ff8    	ldr	x24, [sp, #0x118]
1000303e4: b4000218    	cbz	x24, 0x100030424 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x3a4>
1000303e8: f81703b8    	stur	x24, [x29, #-0x90]
1000303ec: 910803e8    	add	x8, sp, #0x200
1000303f0: 91152360    	add	x0, x27, #0x548
1000303f4: 97ffadc4    	bl	0x10001bb04 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::frontiers>
1000303f8: f94103e9    	ldr	x9, [sp, #0x200]
1000303fc: f94107e8    	ldr	x8, [sp, #0x208]
100030400: f100053f    	cmp	x9, #0x1
100030404: 54000401    	b.ne	0x100030484 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x404>
100030408: ad5087e0    	ldp	q0, q1, [sp, #0x210]
10003040c: ad0907e0    	stp	q0, q1, [sp, #0x120]
100030410: f9411be9    	ldr	x9, [sp, #0x230]
100030414: f900a3e9    	str	x9, [sp, #0x140]
100030418: ad000780    	stp	q0, q1, [x28]
10003041c: f9001389    	str	x9, [x28, #0x20]
100030420: 1400001f    	b	0x10003049c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x41c>
100030424: f94013e8    	ldr	x8, [sp, #0x20]
100030428: b4000608    	cbz	x8, 0x1000304e8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x468>
10003042c: 52800038    	mov	w24, #0x1               ; =1
100030430: 910402a0    	add	x0, x21, #0x100
100030434: 94015f4b    	bl	0x100088160 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
100030438: aa0003e2    	mov	x2, x0
10003043c: aa0103e6    	mov	x6, x1
100030440: a95093e3    	ldp	x3, x4, [sp, #0x108]
100030444: 910803e8    	add	x8, sp, #0x200
100030448: 91152360    	add	x0, x27, #0x548
10003044c: 910083e5    	add	x5, sp, #0x20
100030450: aa0203e1    	mov	x1, x2
100030454: aa0603e2    	mov	x2, x6
100030458: a9008fe4    	stp	x4, x3, [sp, #0x8]
10003045c: 97ffa3e0    	bl	0x1000193dc <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head_borrowed>
100030460: f94103e8    	ldr	x8, [sp, #0x200]
100030464: f94107e3    	ldr	x3, [sp, #0x208]
100030468: b100051f    	cmn	x8, #0x1
10003046c: 54000680    	b.eq	0x10003053c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x4bc>
100030470: ad5087e0    	ldp	q0, q1, [sp, #0x210]
100030474: f9400fe9    	ldr	x9, [sp, #0x18]
100030478: ad000520    	stp	q0, q1, [x9]
10003047c: a9090fe8    	stp	x8, x3, [sp, #0x90]
100030480: 1400017e    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030484: f9401f09    	ldr	x9, [x24, #0x38]
100030488: eb08013f    	cmp	x9, x8
10003048c: 540001e2    	b.hs	0x1000304c8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x448>
100030490: 52801fe8    	mov	w8, #0xff               ; =255
100030494: 390263e8    	strb	w8, [sp, #0x98]
100030498: 92800008    	mov	x8, #-0x1               ; =-1
10003049c: f9004be8    	str	x8, [sp, #0x90]
1000304a0: f85703a8    	ldur	x8, [x29, #-0x90]
1000304a4: 92800009    	mov	x9, #-0x1               ; =-1
1000304a8: f8690108    	ldaddl	x9, x8, [x8]
1000304ac: f100051f    	cmp	x8, #0x1
1000304b0: 54002e41    	b.ne	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
1000304b4: d50339bf    	dmb	ishld
1000304b8: 52800018    	mov	w24, #0x0               ; =0
1000304bc: d10243a0    	sub	x0, x29, #0x90
1000304c0: 94013707    	bl	0x10007e0dc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
1000304c4: 1400016d    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
1000304c8: f85703a8    	ldur	x8, [x29, #-0x90]
1000304cc: f9400909    	ldr	x9, [x8, #0x10]
1000304d0: f100053f    	cmp	x9, #0x1
1000304d4: 54000621    	b.ne	0x100030598 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x518>
1000304d8: a941a909    	ldp	x9, x10, [x8, #0x18]
1000304dc: f9401129    	ldr	x9, [x9, #0x20]
1000304e0: 8b0a0120    	add	x0, x9, x10
1000304e4: 1400002e    	b	0x10003059c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x51c>
1000304e8: 52800038    	mov	w24, #0x1               ; =1
1000304ec: 910402a0    	add	x0, x21, #0x100
1000304f0: 94015f1c    	bl	0x100088160 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
1000304f4: aa0003e2    	mov	x2, x0
1000304f8: aa0103e5    	mov	x5, x1
1000304fc: a95093e3    	ldp	x3, x4, [sp, #0x108]
100030500: 910803e8    	add	x8, sp, #0x200
100030504: 91152360    	add	x0, x27, #0x548
100030508: aa0203e1    	mov	x1, x2
10003050c: aa0503e2    	mov	x2, x5
100030510: a9008fe4    	stp	x4, x3, [sp, #0x8]
100030514: 97ff9e58    	bl	0x100017e74 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::resident_head>
100030518: f94103e8    	ldr	x8, [sp, #0x200]
10003051c: f94107e2    	ldr	x2, [sp, #0x208]
100030520: b100051f    	cmn	x8, #0x1
100030524: 540008c0    	b.eq	0x10003063c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x5bc>
100030528: ad5087e0    	ldp	q0, q1, [sp, #0x210]
10003052c: f9400fe9    	ldr	x9, [sp, #0x18]
100030530: ad000520    	stp	q0, q1, [x9]
100030534: a9090be8    	stp	x8, x2, [sp, #0x90]
100030538: 14000150    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
10003053c: b4000a43    	cbz	x3, 0x100030684 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x604>
100030540: f94002a8    	ldr	x8, [x21]
100030544: f100051f    	cmp	x8, #0x1
100030548: 54003ca1    	b.ne	0x100030cdc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc5c>
10003054c: 394682a2    	ldrb	w2, [x21, #0x1a0]
100030550: 910803e0    	add	x0, sp, #0x200
100030554: 910022a1    	add	x1, x21, #0x8
100030558: 97fffda0    	bl	0x10002fbd8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::invoke_read>
10003055c: f94103e8    	ldr	x8, [sp, #0x200]
100030560: 910643e9    	add	x9, sp, #0x190
100030564: 3cc78120    	ldur	q0, [x9, #0x78]
100030568: 3d804be0    	str	q0, [sp, #0x120]
10003056c: b100051f    	cmn	x8, #0x1
100030570: 54003180    	b.eq	0x100030ba0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb20>
100030574: 3cc88120    	ldur	q0, [x9, #0x88]
100030578: 910243e9    	add	x9, sp, #0x90
10003057c: 3c818120    	stur	q0, [x9, #0x18]
100030580: f94117e9    	ldr	x9, [sp, #0x228]
100030584: 3dc04be0    	ldr	q0, [sp, #0x120]
100030588: 3d800380    	str	q0, [x28]
10003058c: f9005fe9    	str	x9, [sp, #0xb8]
100030590: f9004be8    	str	x8, [sp, #0x90]
100030594: 14000139    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030598: f9401100    	ldr	x0, [x8, #0x20]
10003059c: f9401501    	ldr	x1, [x8, #0x28]
1000305a0: 910803e8    	add	x8, sp, #0x200
1000305a4: 94011fc8    	bl	0x1000784c4 <<raster::format::record::Record>::decode>
1000305a8: f94103e8    	ldr	x8, [sp, #0x200]
1000305ac: f100091f    	cmp	x8, #0x2
1000305b0: 54000121    	b.ne	0x1000305d4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x554>
1000305b4: 910643e9    	add	x9, sp, #0x190
1000305b8: 3cc88120    	ldur	q0, [x9, #0x88]
1000305bc: 3cc98121    	ldur	q1, [x9, #0x98]
1000305c0: f9400fe8    	ldr	x8, [sp, #0x18]
1000305c4: ad000500    	stp	q0, q1, [x8]
1000305c8: 3cc78120    	ldur	q0, [x9, #0x78]
1000305cc: 3d8027e0    	str	q0, [sp, #0x90]
1000305d0: 17ffffb4    	b	0x1000304a0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x420>
1000305d4: f9410be8    	ldr	x8, [sp, #0x210]
1000305d8: f85703a9    	ldur	x9, [x29, #-0x90]
1000305dc: f9402129    	ldr	x9, [x9, #0x40]
1000305e0: eb09011f    	cmp	x8, x9
1000305e4: 540006c1    	b.ne	0x1000306bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x63c>
1000305e8: f9411ff6    	ldr	x22, [sp, #0x238]
1000305ec: f94123f7    	ldr	x23, [sp, #0x240]
1000305f0: f9417f68    	ldr	x8, [x27, #0x2f8]
1000305f4: 91004100    	add	x0, x8, #0x10
1000305f8: 52800021    	mov	w1, #0x1                ; =1
1000305fc: 94018ea6    	bl	0x100094094 <<raster::engine::metrics::Metrics>::cache>
100030600: f9406be8    	ldr	x8, [sp, #0xd0]
100030604: f100091f    	cmp	x8, #0x2
100030608: 54000681    	b.ne	0x1000306d8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x658>
10003060c: f9406fe1    	ldr	x1, [sp, #0xd8]
100030610: 910803e8    	add	x8, sp, #0x200
100030614: 9109a360    	add	x0, x27, #0x268
100030618: 940155bc    	bl	0x100085d08 <<raster::cache::ReadCache>::touch>
10003061c: f94103e8    	ldr	x8, [sp, #0x200]
100030620: b100051f    	cmn	x8, #0x1
100030624: 540005a0    	b.eq	0x1000306d8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x658>
100030628: ad5007e0    	ldp	q0, q1, [sp, #0x200]
10003062c: ad0487e0    	stp	q0, q1, [sp, #0x90]
100030630: 3dc08be0    	ldr	q0, [sp, #0x220]
100030634: 3d802fe0    	str	q0, [sp, #0xb0]
100030638: 17ffff9a    	b	0x1000304a0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x420>
10003063c: b4000242    	cbz	x2, 0x100030684 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x604>
100030640: f90103e2    	str	x2, [sp, #0x200]
100030644: 9101e448    	add	x8, x2, #0x79
100030648: 08dffd08    	ldarb	w8, [x8]
10003064c: 340030e8    	cbz	w8, 0x100030c68 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbe8>
100030650: 394682a8    	ldrb	w8, [x21, #0x1a0]
100030654: 11000508    	add	w8, w8, #0x1
100030658: 390263e8    	strb	w8, [sp, #0x98]
10003065c: 390267ff    	strb	wzr, [sp, #0x99]
100030660: 92800008    	mov	x8, #-0x1               ; =-1
100030664: f9004be8    	str	x8, [sp, #0x90]
100030668: f8680048    	ldaddl	x8, x8, [x2]
10003066c: f100051f    	cmp	x8, #0x1
100030670: 54002041    	b.ne	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030674: d50339bf    	dmb	ishld
100030678: 910803e0    	add	x0, sp, #0x200
10003067c: 940015b3    	bl	0x100035d48 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
100030680: 140000fe    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030684: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
100030688: ad0586a0    	stp	q0, q1, [x21, #0xb0]
10003068c: f94083e8    	ldr	x8, [sp, #0x100]
100030690: f9006aa8    	str	x8, [x21, #0xd0]
100030694: ad4603e1    	ldp	q1, q0, [sp, #0xc0]
100030698: ad0482a1    	stp	q1, q0, [x21, #0x90]
10003069c: 394402a8    	ldrb	w8, [x21, #0x100]
1000306a0: 7100051f    	cmp	w8, #0x1
1000306a4: 540004a1    	b.ne	0x100030738 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x6b8>
1000306a8: 910643e8    	add	x8, sp, #0x190
1000306ac: 91002108    	add	x8, x8, #0x8
1000306b0: 910422a0    	add	x0, x21, #0x108
1000306b4: 94003c1f    	bl	0x10003f730 <<alloc::vec::Vec<u8> as core::clone::Clone>::clone>
1000306b8: 14000026    	b	0x100030750 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x6d0>
1000306bc: 528000e8    	mov	w8, #0x7                ; =7
1000306c0: f0000549    	adrp	x9, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
1000306c4: 912d9d29    	add	x9, x9, #0xb67
1000306c8: a90927e8    	stp	x8, x9, [sp, #0x90]
1000306cc: 528003a8    	mov	w8, #0x1d               ; =29
1000306d0: f90053e8    	str	x8, [sp, #0xa0]
1000306d4: 17ffff73    	b	0x1000304a0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x420>
1000306d8: f942ab68    	ldr	x8, [x27, #0x550]
1000306dc: 52800029    	mov	w9, #0x1                ; =1
1000306e0: f8290108    	ldadd	x9, x8, [x8]
1000306e4: b7f83088    	tbnz	x8, #0x3f, 0x100030cf4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc74>
1000306e8: f942ab60    	ldr	x0, [x27, #0x550]
1000306ec: f942e363    	ldr	x3, [x27, #0x5c0]
1000306f0: 910803e8    	add	x8, sp, #0x200
1000306f4: aa1603e1    	mov	x1, x22
1000306f8: aa1703e2    	mov	x2, x23
1000306fc: 940053b7    	bl	0x1000455d8 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::decode>
100030700: f94103e8    	ldr	x8, [sp, #0x200]
100030704: 910643f6    	add	x22, sp, #0x190
100030708: 3cc782c0    	ldur	q0, [x22, #0x78]
10003070c: 3cc882c1    	ldur	q1, [x22, #0x88]
100030710: ad0c87e0    	stp	q0, q1, [sp, #0x190]
100030714: 3cc982c0    	ldur	q0, [x22, #0x98]
100030718: 3d806fe0    	str	q0, [sp, #0x1b0]
10003071c: f100091f    	cmp	x8, #0x2
100030720: 540025c1    	b.ne	0x100030bd8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb58>
100030724: ad4c87e0    	ldp	q0, q1, [sp, #0x190]
100030728: ad0487e0    	stp	q0, q1, [sp, #0x90]
10003072c: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
100030730: 3d802fe0    	str	q0, [sp, #0xb0]
100030734: 17ffff5b    	b	0x1000304a0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x420>
100030738: 52800018    	mov	w24, #0x0               ; =0
10003073c: 91040aa8    	add	x8, x21, #0x102
100030740: 3dc00100    	ldr	q0, [x8]
100030744: 3c802320    	stur	q0, [x25, #0x2]
100030748: 394406a8    	ldrb	w8, [x21, #0x101]
10003074c: 390647e8    	strb	w8, [sp, #0x191]
100030750: 390643f8    	strb	w24, [sp, #0x190]
100030754: f940a2a5    	ldr	x5, [x21, #0x140]
100030758: 910803e8    	add	x8, sp, #0x200
10003075c: 91152360    	add	x0, x27, #0x548
100030760: 91082361    	add	x1, x27, #0x208
100030764: 910643e2    	add	x2, sp, #0x190
100030768: a9408fe4    	ldp	x4, x3, [sp, #0x8]
10003076c: 97ff93dd    	bl	0x1000156e0 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::lookup_deferred::<raster::schema::encoded_key::EncodedKey>>
100030770: f94103f8    	ldr	x24, [sp, #0x200]
100030774: 910643e8    	add	x8, sp, #0x190
100030778: 3cc78100    	ldur	q0, [x8, #0x78]
10003077c: 3cc88101    	ldur	q1, [x8, #0x88]
100030780: ad0907e0    	stp	q0, q1, [sp, #0x120]
100030784: 3cc98100    	ldur	q0, [x8, #0x98]
100030788: 3d8053e0    	str	q0, [sp, #0x140]
10003078c: f1000b1f    	cmp	x24, #0x2
100030790: 54ffd5c0    	b.eq	0x100030248 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x1c8>
100030794: 3cca8100    	ldur	q0, [x8, #0xa8]
100030798: 3ccb8101    	ldur	q1, [x8, #0xb8]
10003079c: ad0c87e0    	stp	q0, q1, [sp, #0x190]
1000307a0: 3ccc8100    	ldur	q0, [x8, #0xc8]
1000307a4: 3d806fe0    	str	q0, [sp, #0x1b0]
1000307a8: 3ccd2100    	ldur	q0, [x8, #0xd2]
1000307ac: 910643f9    	add	x25, sp, #0x190
1000307b0: 3c82a100    	stur	q0, [x8, #0x2a]
1000307b4: 3949cbe8    	ldrb	w8, [sp, #0x272]
1000307b8: 3949cfe9    	ldrb	w9, [sp, #0x273]
1000307bc: b94277ea    	ldr	w10, [sp, #0x274]
1000307c0: b90013ea    	str	w10, [sp, #0x10]
1000307c4: ad4907e0    	ldp	q0, q1, [sp, #0x120]
1000307c8: ad0e87e0    	stp	q0, q1, [sp, #0x1d0]
1000307cc: 3dc053e0    	ldr	q0, [sp, #0x140]
1000307d0: 3d807fe0    	str	q0, [sp, #0x1f0]
1000307d4: 394542aa    	ldrb	w10, [x21, #0x150]
1000307d8: 7100015f    	cmp	w10, #0x0
1000307dc: 1a8913e9    	csel	w9, wzr, w9, ne
1000307e0: 1a9f0508    	csinc	w8, w8, wzr, eq
1000307e4: 2900a7e8    	stp	w8, w9, [sp, #0x4]
1000307e8: f9400ea8    	ldr	x8, [x21, #0x18]
1000307ec: f100091f    	cmp	x8, #0x2
1000307f0: 54000060    	b.eq	0x1000307fc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x77c>
1000307f4: aa1603e0    	mov	x0, x22
1000307f8: 97fffb66    	bl	0x10002f590 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
1000307fc: f9000eb8    	str	x24, [x21, #0x18]
100030800: ad4e87e0    	ldp	q0, q1, [sp, #0x1d0]
100030804: ad0106a0    	stp	q0, q1, [x21, #0x20]
100030808: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
10003080c: ad4c8be1    	ldp	q1, q2, [sp, #0x190]
100030810: ad0206a0    	stp	q0, q1, [x21, #0x40]
100030814: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
100030818: ad0302a2    	stp	q2, q0, [x21, #0x60]
10003081c: 3cc2a320    	ldur	q0, [x25, #0x2a]
100030820: 3c87a2a0    	stur	q0, [x21, #0x7a]
100030824: 2940a3e9    	ldp	w9, w8, [sp, #0x4]
100030828: 39022aa9    	strb	w9, [x21, #0x8a]
10003082c: 39022ea8    	strb	w8, [x21, #0x8b]
100030830: b94013e8    	ldr	w8, [sp, #0x10]
100030834: b9008ea8    	str	w8, [x21, #0x8c]
100030838: b94002a8    	ldr	w8, [x21]
10003083c: 36002288    	tbz	w8, #0x0, 0x100030c8c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc0c>
100030840: 910803e8    	add	x8, sp, #0x200
100030844: 91152361    	add	x1, x27, #0x548
100030848: 91082362    	add	x2, x27, #0x208
10003084c: aa1603e0    	mov	x0, x22
100030850: aa1703e3    	mov	x3, x23
100030854: 940028ce    	bl	0x10003ab8c <<raster::log::lookup::LogLookup>::step::<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>
100030858: f94103e8    	ldr	x8, [sp, #0x200]
10003085c: f94107e2    	ldr	x2, [sp, #0x208]
100030860: ad5087e0    	ldp	q0, q1, [sp, #0x210]
100030864: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
100030868: f9411be9    	ldr	x9, [sp, #0x230]
10003086c: f81603a9    	stur	x9, [x29, #-0xa0]
100030870: b100051f    	cmn	x8, #0x1
100030874: 540007a0    	b.eq	0x100030968 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x8e8>
100030878: 910643ea    	add	x10, sp, #0x190
10003087c: 3cca8140    	ldur	q0, [x10, #0xa8]
100030880: 910243e9    	add	x9, sp, #0x90
100030884: 3c8b8120    	stur	q0, [x9, #0xb8]
100030888: 3ccb8140    	ldur	q0, [x10, #0xb8]
10003088c: 3c8c8120    	stur	q0, [x9, #0xc8]
100030890: 3ccc8140    	ldur	q0, [x10, #0xc8]
100030894: 3c8d8120    	stur	q0, [x9, #0xd8]
100030898: f94137e9    	ldr	x9, [sp, #0x268]
10003089c: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
1000308a0: f85603aa    	ldur	x10, [x29, #-0xa0]
1000308a4: f900bfe9    	str	x9, [sp, #0x178]
1000308a8: f900a3ea    	str	x10, [sp, #0x140]
1000308ac: d1000909    	sub	x9, x8, #0x2
1000308b0: f100051f    	cmp	x8, #0x1
1000308b4: 9a9f8529    	csinc	x9, x9, xzr, hi
1000308b8: ad0907e0    	stp	q0, q1, [sp, #0x120]
1000308bc: f100093f    	cmp	x9, #0x2
1000308c0: 5400060c    	b.gt	0x100030980 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x900>
1000308c4: b40007c9    	cbz	x9, 0x1000309bc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x93c>
1000308c8: f100053f    	cmp	x9, #0x1
1000308cc: 54000801    	b.ne	0x1000309cc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x94c>
1000308d0: f90103e8    	str	x8, [sp, #0x200]
1000308d4: f90107e2    	str	x2, [sp, #0x208]
1000308d8: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
1000308dc: ad1187e0    	stp	q0, q1, [sp, #0x230]
1000308e0: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
1000308e4: ad1287e0    	stp	q0, q1, [sp, #0x250]
1000308e8: ad4907e0    	ldp	q0, q1, [sp, #0x120]
1000308ec: ad1087e0    	stp	q0, q1, [sp, #0x210]
1000308f0: f9404aa8    	ldr	x8, [x21, #0x90]
1000308f4: f100091f    	cmp	x8, #0x2
1000308f8: 54001d80    	b.eq	0x100030ca8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc28>
1000308fc: f940aea1    	ldr	x1, [x21, #0x158]
100030900: f90063e8    	str	x8, [sp, #0xc0]
100030904: 3cc982a0    	ldur	q0, [x21, #0x98]
100030908: 910243e8    	add	x8, sp, #0x90
10003090c: 3c838100    	stur	q0, [x8, #0x38]
100030910: 3cca82a0    	ldur	q0, [x21, #0xa8]
100030914: 3c848100    	stur	q0, [x8, #0x48]
100030918: 3ccb82a0    	ldur	q0, [x21, #0xb8]
10003091c: 3c858100    	stur	q0, [x8, #0x58]
100030920: 3ccc82a0    	ldur	q0, [x21, #0xc8]
100030924: 3c868100    	stur	q0, [x8, #0x68]
100030928: f9400ea8    	ldr	x8, [x21, #0x18]
10003092c: f100091f    	cmp	x8, #0x2
100030930: 54001c80    	b.eq	0x100030cc0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc40>
100030934: d10243a8    	sub	x8, x29, #0x90
100030938: 91020360    	add	x0, x27, #0x80
10003093c: 910303e2    	add	x2, sp, #0xc0
100030940: aa1603e3    	mov	x3, x22
100030944: 97ff7148    	bl	0x10000ce64 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::populate_cache>
100030948: f85703a8    	ldur	x8, [x29, #-0x90]
10003094c: b100051f    	cmn	x8, #0x1
100030950: 54000700    	b.eq	0x100030a30 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9b0>
100030954: ad7b87a0    	ldp	q0, q1, [x29, #-0x90]
100030958: ad0487e0    	stp	q0, q1, [sp, #0x90]
10003095c: 3cd903a0    	ldur	q0, [x29, #-0x70]
100030960: 3d802fe0    	str	q0, [sp, #0xb0]
100030964: 14000043    	b	0x100030a70 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f0>
100030968: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
10003096c: ad000780    	stp	q0, q1, [x28]
100030970: f85603a8    	ldur	x8, [x29, #-0xa0]
100030974: f9001388    	str	x8, [x28, #0x20]
100030978: f9004be2    	str	x2, [sp, #0x90]
10003097c: 1400003f    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030980: d1001528    	sub	x8, x9, #0x5
100030984: f100091f    	cmp	x8, #0x2
100030988: 54000082    	b.hs	0x100030998 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x918>
10003098c: 52801fe8    	mov	w8, #0xff               ; =255
100030990: 390263e8    	strb	w8, [sp, #0x98]
100030994: 14000007    	b	0x1000309b0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x930>
100030998: f1000d3f    	cmp	x9, #0x3
10003099c: 54000261    	b.ne	0x1000309e8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x968>
1000309a0: 394682a8    	ldrb	w8, [x21, #0x1a0]
1000309a4: 11000508    	add	w8, w8, #0x1
1000309a8: 390263e8    	strb	w8, [sp, #0x98]
1000309ac: 390267ff    	strb	wzr, [sp, #0x99]
1000309b0: 92800008    	mov	x8, #-0x1               ; =-1
1000309b4: f9004be8    	str	x8, [sp, #0x90]
1000309b8: 14000030    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
1000309bc: 910243e0    	add	x0, sp, #0x90
1000309c0: aa1503e1    	mov	x1, x21
1000309c4: 97fffd22    	bl	0x10002fe4c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
1000309c8: 1400002c    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
1000309cc: 528000e8    	mov	w8, #0x7                ; =7
1000309d0: f0000549    	adrp	x9, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
1000309d4: 912f2d29    	add	x9, x9, #0xbcb
1000309d8: a90927e8    	stp	x8, x9, [sp, #0x90]
1000309dc: 52800448    	mov	w8, #0x22               ; =34
1000309e0: f90053e8    	str	x8, [sp, #0xa0]
1000309e4: 14000025    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
1000309e8: f940aea1    	ldr	x1, [x21, #0x158]
1000309ec: 910803e8    	add	x8, sp, #0x200
1000309f0: 91020360    	add	x0, x27, #0x80
1000309f4: 9400cb7b    	bl	0x1000637e0 <<raster::index::growth::MemIndex>::prepare>
1000309f8: f94103e8    	ldr	x8, [sp, #0x200]
1000309fc: 910643e9    	add	x9, sp, #0x190
100030a00: 3cc78120    	ldur	q0, [x9, #0x78]
100030a04: 3cc88121    	ldur	q1, [x9, #0x88]
100030a08: ad3b87a0    	stp	q0, q1, [x29, #-0x90]
100030a0c: 3cc98120    	ldur	q0, [x9, #0x98]
100030a10: 3c9903a0    	stur	q0, [x29, #-0x70]
100030a14: f100091f    	cmp	x8, #0x2
100030a18: 54000821    	b.ne	0x100030b1c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa9c>
100030a1c: ad7b87a0    	ldp	q0, q1, [x29, #-0x90]
100030a20: ad0487e0    	stp	q0, q1, [sp, #0x90]
100030a24: 3cd903a0    	ldur	q0, [x29, #-0x70]
100030a28: 3d802fe0    	str	q0, [sp, #0xb0]
100030a2c: 14000013    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030a30: 910303e8    	add	x8, sp, #0xc0
100030a34: 910803e0    	add	x0, sp, #0x200
100030a38: 910022a1    	add	x1, x21, #0x8
100030a3c: 94004da2    	bl	0x1000440c4 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#2}>>
100030a40: a94c23ea    	ldp	x10, x8, [sp, #0xc0]
100030a44: f9406be9    	ldr	x9, [sp, #0xd0]
100030a48: 910243eb    	add	x11, sp, #0x90
100030a4c: 3cc48160    	ldur	q0, [x11, #0x48]
100030a50: 3cc58161    	ldur	q1, [x11, #0x58]
100030a54: ad3b87a0    	stp	q0, q1, [x29, #-0x90]
100030a58: f100055f    	cmp	x10, #0x1
100030a5c: 54000961    	b.ne	0x100030b88 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb08>
100030a60: ad7b87a0    	ldp	q0, q1, [x29, #-0x90]
100030a64: f9400fea    	ldr	x10, [sp, #0x18]
100030a68: ad000540    	stp	q0, q1, [x10]
100030a6c: a90927e8    	stp	x8, x9, [sp, #0x90]
100030a70: 910803e0    	add	x0, sp, #0x200
100030a74: 97fffa16    	bl	0x10002f2cc <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
100030a78: a94957f7    	ldp	x23, x21, [sp, #0x90]
100030a7c: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
100030a80: a90657f7    	stp	x23, x21, [sp, #0x60]
100030a84: ad0383e1    	stp	q1, q0, [sp, #0x70]
100030a88: 9e660036    	fmov	x22, d1
100030a8c: b1000aff    	cmn	x23, #0x2
100030a90: 54001e60    	b.eq	0x100030e5c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xddc>
100030a94: b10006ff    	cmn	x23, #0x1
100030a98: 54000101    	b.ne	0x100030ab8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa38>
100030a9c: 12001ea8    	and	w8, w21, #0xff
100030aa0: 7100051f    	cmp	w8, #0x1
100030aa4: 5400028c    	b.gt	0x100030af4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa74>
100030aa8: 35000368    	cbnz	w8, 0x100030b14 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa94>
100030aac: f9000696    	str	x22, [x20, #0x8]
100030ab0: 3900029f    	strb	wzr, [x20]
100030ab4: 17fffda8    	b	0x100030154 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd4>
100030ab8: f9400268    	ldr	x8, [x19]
100030abc: b100051f    	cmn	x8, #0x1
100030ac0: 54000060    	b.eq	0x100030acc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa4c>
100030ac4: aa1303e0    	mov	x0, x19
100030ac8: 97fffb5f    	bl	0x10002f844 <core::ptr::drop_glue::<raster::types::error::Error>>
100030acc: ad4307e0    	ldp	q0, q1, [sp, #0x60]
100030ad0: ad000660    	stp	q0, q1, [x19]
100030ad4: 3dc023e0    	ldr	q0, [sp, #0x80]
100030ad8: 3d800a60    	str	q0, [x19, #0x20]
100030adc: 3900c27f    	strb	wzr, [x19, #0x30]
100030ae0: 52800088    	mov	w8, #0x4                ; =4
100030ae4: 39000288    	strb	w8, [x20]
100030ae8: b1000aff    	cmn	x23, #0x2
100030aec: 54ffb341    	b.ne	0x100030154 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd4>
100030af0: 140000eb    	b	0x100030e9c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe1c>
100030af4: 7100091f    	cmp	w8, #0x2
100030af8: 540000a1    	b.ne	0x100030b0c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xa8c>
100030afc: d348fea8    	lsr	x8, x21, #8
100030b00: 39000688    	strb	w8, [x20, #0x1]
100030b04: 52800048    	mov	w8, #0x2                ; =2
100030b08: 17fffd92    	b	0x100030150 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd0>
100030b0c: 52800068    	mov	w8, #0x3                ; =3
100030b10: 17fffd90    	b	0x100030150 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd0>
100030b14: 52800028    	mov	w8, #0x1                ; =1
100030b18: 17fffd8e    	b	0x100030150 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd0>
100030b1c: 3cca8120    	ldur	q0, [x9, #0xa8]
100030b20: 910243e9    	add	x9, sp, #0x90
100030b24: 3c868120    	stur	q0, [x9, #0x68]
100030b28: ad7b87a0    	ldp	q0, q1, [x29, #-0x90]
100030b2c: 3c838120    	stur	q0, [x9, #0x38]
100030b30: 3c848121    	stur	q1, [x9, #0x48]
100030b34: 3cd903a0    	ldur	q0, [x29, #-0x70]
100030b38: 3c858120    	stur	q0, [x9, #0x58]
100030b3c: f90063e8    	str	x8, [sp, #0xc0]
100030b40: f8490ea8    	ldr	x8, [x21, #0x90]!
100030b44: f100091f    	cmp	x8, #0x2
100030b48: 540000e0    	b.eq	0x100030b64 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xae4>
100030b4c: 910303e1    	add	x1, sp, #0xc0
100030b50: aa1503e0    	mov	x0, x21
100030b54: 9400017e    	bl	0x10003114c <<raster::index::EntrySnapshot as core::cmp::PartialEq>::eq>
100030b58: 36000060    	tbz	w0, #0x0, 0x100030b64 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xae4>
100030b5c: 52800028    	mov	w8, #0x1                ; =1
100030b60: 17ffff8c    	b	0x100030990 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x910>
100030b64: f94002c8    	ldr	x8, [x22]
100030b68: f100091f    	cmp	x8, #0x2
100030b6c: 54000060    	b.eq	0x100030b78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xaf8>
100030b70: aa1603e0    	mov	x0, x22
100030b74: 97fffa87    	bl	0x10002f590 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
100030b78: 52800048    	mov	w8, #0x2                ; =2
100030b7c: f90002c8    	str	x8, [x22]
100030b80: f90002a8    	str	x8, [x21]
100030b84: 17ffff82    	b	0x10003098c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x90c>
100030b88: b100051f    	cmn	x8, #0x1
100030b8c: 54000180    	b.eq	0x100030bbc <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb3c>
100030b90: ad7b87a0    	ldp	q0, q1, [x29, #-0x90]
100030b94: f9400fea    	ldr	x10, [sp, #0x18]
100030b98: ad000540    	stp	q0, q1, [x10]
100030b9c: 1400000a    	b	0x100030bc4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xb44>
100030ba0: 3dc04be0    	ldr	q0, [sp, #0x120]
100030ba4: 3d8083e0    	str	q0, [sp, #0x200]
100030ba8: 910243e0    	add	x0, sp, #0x90
100030bac: 910803e2    	add	x2, sp, #0x200
100030bb0: aa1503e1    	mov	x1, x21
100030bb4: 940000d9    	bl	0x100030f18 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish_read_access>
100030bb8: 17ffffb0    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030bbc: 390263ff    	strb	wzr, [sp, #0x98]
100030bc0: f9400ffc    	ldr	x28, [sp, #0x18]
100030bc4: f9000389    	str	x9, [x28]
100030bc8: f9004be8    	str	x8, [sp, #0x90]
100030bcc: 910803e0    	add	x0, sp, #0x200
100030bd0: 97fff9bf    	bl	0x10002f2cc <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
100030bd4: 17ffffa9    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030bd8: 3cca82c0    	ldur	q0, [x22, #0xa8]
100030bdc: 910243ea    	add	x10, sp, #0x90
100030be0: 3c8c8140    	stur	q0, [x10, #0xc8]
100030be4: 3ccb82c0    	ldur	q0, [x22, #0xb8]
100030be8: 3c8d8140    	stur	q0, [x10, #0xd8]
100030bec: 3ccc82c0    	ldur	q0, [x22, #0xc8]
100030bf0: 3c8e8140    	stur	q0, [x10, #0xe8]
100030bf4: ad4c87e0    	ldp	q0, q1, [sp, #0x190]
100030bf8: 3c898140    	stur	q0, [x10, #0x98]
100030bfc: f94137e9    	ldr	x9, [sp, #0x268]
100030c00: 3c8a8141    	stur	q1, [x10, #0xa8]
100030c04: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
100030c08: 3c8b8140    	stur	q0, [x10, #0xb8]
100030c0c: f900c7e9    	str	x9, [sp, #0x188]
100030c10: f90093e8    	str	x8, [sp, #0x120]
100030c14: 910803e8    	add	x8, sp, #0x200
100030c18: 910483e0    	add	x0, sp, #0x120
100030c1c: aa1503e1    	mov	x1, x21
100030c20: 94004ca1    	bl	0x100043ea4 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<u64, raster::types::error::Error>, <raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint::{closure#0}::{closure#0}>>
100030c24: f94103ea    	ldr	x10, [sp, #0x200]
100030c28: f94107e9    	ldr	x9, [sp, #0x208]
100030c2c: f9410be8    	ldr	x8, [sp, #0x210]
100030c30: 3cc882c0    	ldur	q0, [x22, #0x88]
100030c34: 3cc982c1    	ldur	q1, [x22, #0x98]
100030c38: ad0c87e0    	stp	q0, q1, [sp, #0x190]
100030c3c: f100055f    	cmp	x10, #0x1
100030c40: 54000060    	b.eq	0x100030c4c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbcc>
100030c44: b100053f    	cmn	x9, #0x1
100030c48: 54000180    	b.eq	0x100030c78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbf8>
100030c4c: ad4c87e0    	ldp	q0, q1, [sp, #0x190]
100030c50: f9400fea    	ldr	x10, [sp, #0x18]
100030c54: ad000540    	stp	q0, q1, [x10]
100030c58: a90923e9    	stp	x9, x8, [sp, #0x90]
100030c5c: 910483e0    	add	x0, sp, #0x120
100030c60: 97fff99b    	bl	0x10002f2cc <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
100030c64: 17fffe0f    	b	0x1000304a0 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x420>
100030c68: 910243e0    	add	x0, sp, #0x90
100030c6c: aa1503e1    	mov	x1, x21
100030c70: 97fffc77    	bl	0x10002fe4c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::read_resident>
100030c74: 17ffff81    	b	0x100030a78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0x9f8>
100030c78: 390263ff    	strb	wzr, [sp, #0x98]
100030c7c: f90053e8    	str	x8, [sp, #0xa0]
100030c80: 92800008    	mov	x8, #-0x1               ; =-1
100030c84: f9004be8    	str	x8, [sp, #0x90]
100030c88: 17fffff5    	b	0x100030c5c <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xbdc>
100030c8c: f0000540    	adrp	x0, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030c90: 912e1000    	add	x0, x0, #0xb84
100030c94: 90000702    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100030c98: 91254042    	add	x2, x2, #0x950
100030c9c: 528004c1    	mov	w1, #0x26               ; =38
100030ca0: 94027413    	bl	0x1000cdcec <core::option::expect_failed>
100030ca4: 14000014    	b	0x100030cf4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc74>
100030ca8: 90000702    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100030cac: 9125a042    	add	x2, x2, #0x968
100030cb0: 52800281    	mov	w1, #0x14               ; =20
100030cb4: f0000540    	adrp	x0, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030cb8: 912edc00    	add	x0, x0, #0xbb7
100030cbc: 14000006    	b	0x100030cd4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc54>
100030cc0: 90000702    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100030cc4: 91260042    	add	x2, x2, #0x980
100030cc8: 528001a1    	mov	w1, #0xd                ; =13
100030ccc: f0000540    	adrp	x0, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030cd0: 912ea800    	add	x0, x0, #0xbaa
100030cd4: 94027406    	bl	0x1000cdcec <core::option::expect_failed>
100030cd8: 14000007    	b	0x100030cf4 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xc74>
100030cdc: f0000540    	adrp	x0, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030ce0: 912e1000    	add	x0, x0, #0xb84
100030ce4: 90000702    	adrp	x2, 0x100110000 <dyld_stub_binder+0x100110000>
100030ce8: 9124e042    	add	x2, x2, #0x938
100030cec: 528004c1    	mov	w1, #0x26               ; =38
100030cf0: 940273ff    	bl	0x1000cdcec <core::option::expect_failed>
100030cf4: d4200020    	brk	#0x1
100030cf8: 1400001b    	b	0x100030d64 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xce4>
100030cfc: aa0003f7    	mov	x23, x0
100030d00: f9000eb8    	str	x24, [x21, #0x18]
100030d04: ad4e87e0    	ldp	q0, q1, [sp, #0x1d0]
100030d08: ad0106a0    	stp	q0, q1, [x21, #0x20]
100030d0c: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
100030d10: ad4c8be1    	ldp	q1, q2, [sp, #0x190]
100030d14: ad0206a0    	stp	q0, q1, [x21, #0x40]
100030d18: 3dc06fe0    	ldr	q0, [sp, #0x1b0]
100030d1c: ad0302a2    	stp	q2, q0, [x21, #0x60]
100030d20: 3cc2a320    	ldur	q0, [x25, #0x2a]
100030d24: 3c87a2a0    	stur	q0, [x21, #0x7a]
100030d28: 2940a3e9    	ldp	w9, w8, [sp, #0x4]
100030d2c: 39022aa9    	strb	w9, [x21, #0x8a]
100030d30: 39022ea8    	strb	w8, [x21, #0x8b]
100030d34: 52800038    	mov	w24, #0x1               ; =1
100030d38: b94013e8    	ldr	w8, [sp, #0x10]
100030d3c: b9008ea8    	str	w8, [x21, #0x8c]
100030d40: 1400002e    	b	0x100030df8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd78>
100030d44: aa0003f7    	mov	x23, x0
100030d48: 910483e0    	add	x0, sp, #0x120
100030d4c: 97fff960    	bl	0x10002f2cc <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
100030d50: 14000009    	b	0x100030d74 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xcf4>
100030d54: aa0003f7    	mov	x23, x0
100030d58: 52800048    	mov	w8, #0x2                ; =2
100030d5c: f90002c8    	str	x8, [x22]
100030d60: 14000038    	b	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030d64: aa0003f7    	mov	x23, x0
100030d68: 52800038    	mov	w24, #0x1               ; =1
100030d6c: 14000023    	b	0x100030df8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd78>
100030d70: aa0003f7    	mov	x23, x0
100030d74: f85703a8    	ldur	x8, [x29, #-0x90]
100030d78: 92800009    	mov	x9, #-0x1               ; =-1
100030d7c: f8690108    	ldaddl	x9, x8, [x8]
100030d80: f100051f    	cmp	x8, #0x1
100030d84: 540005e1    	b.ne	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030d88: d50339bf    	dmb	ishld
100030d8c: d10243a0    	sub	x0, x29, #0x90
100030d90: 940134d3    	bl	0x10007e0dc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
100030d94: 1400002b    	b	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030d98: aa0003f4    	mov	x20, x0
100030d9c: ad4307e0    	ldp	q0, q1, [sp, #0x60]
100030da0: ad000660    	stp	q0, q1, [x19]
100030da4: 3dc023e0    	ldr	q0, [sp, #0x80]
100030da8: 3d800a60    	str	q0, [x19, #0x20]
100030dac: 3900c27f    	strb	wzr, [x19, #0x30]
100030db0: b1000aff    	cmn	x23, #0x2
100030db4: 540009a0    	b.eq	0x100030ee8 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe68>
100030db8: 14000056    	b	0x100030f10 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe90>
100030dbc: ad4187e0    	ldp	q0, q1, [sp, #0x30]
100030dc0: ad000660    	stp	q0, q1, [x19]
100030dc4: 3dc017e0    	ldr	q0, [sp, #0x50]
100030dc8: 3d800a60    	str	q0, [x19, #0x20]
100030dcc: 3900c27f    	strb	wzr, [x19, #0x30]
100030dd0: 940274d5    	bl	0x1000ce124 <dyld_stub_binder+0x1000ce124>
100030dd4: f0000548    	adrp	x8, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030dd8: 91322d08    	add	x8, x8, #0xc8b
100030ddc: 528000e9    	mov	w9, #0x7                ; =7
100030de0: a9002269    	stp	x9, x8, [x19]
100030de4: 52800288    	mov	w8, #0x14               ; =20
100030de8: f9000a68    	str	x8, [x19, #0x10]
100030dec: 3900c27f    	strb	wzr, [x19, #0x30]
100030df0: 940274cd    	bl	0x1000ce124 <dyld_stub_binder+0x1000ce124>
100030df4: aa0003f7    	mov	x23, x0
100030df8: 34000258    	cbz	w24, 0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030dfc: f9408fe8    	ldr	x8, [sp, #0x118]
100030e00: b4000208    	cbz	x8, 0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030e04: 92800009    	mov	x9, #-0x1               ; =-1
100030e08: f8690108    	ldaddl	x9, x8, [x8]
100030e0c: f100051f    	cmp	x8, #0x1
100030e10: 54000181    	b.ne	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030e14: 910303e8    	add	x8, sp, #0xc0
100030e18: d50339bf    	dmb	ishld
100030e1c: 91016100    	add	x0, x8, #0x58
100030e20: 940134af    	bl	0x10007e0dc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
100030e24: 14000007    	b	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030e28: aa0003f7    	mov	x23, x0
100030e2c: 910803e0    	add	x0, sp, #0x200
100030e30: 97fff927    	bl	0x10002f2cc <core::ptr::drop_glue::<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
100030e34: 14000003    	b	0x100030e40 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdc0>
100030e38: 940273da    	bl	0x1000cdda0 <core::panicking::panic_in_cleanup>
100030e3c: aa0003f7    	mov	x23, x0
100030e40: aa1703e0    	mov	x0, x23
100030e44: 940272aa    	bl	0x1000cd8ec <std::panicking::catch_unwind::cleanup>
100030e48: aa0003f5    	mov	x21, x0
100030e4c: aa0103f6    	mov	x22, x1
100030e50: a90687e0    	stp	x0, x1, [sp, #0x68]
100030e54: 92800028    	mov	x8, #-0x2               ; =-2
100030e58: f90033e8    	str	x8, [sp, #0x60]
100030e5c: 52800028    	mov	w8, #0x1                ; =1
100030e60: 089fff48    	stlrb	w8, [x26]
100030e64: f9400268    	ldr	x8, [x19]
100030e68: b100051f    	cmn	x8, #0x1
100030e6c: 54000060    	b.eq	0x100030e78 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xdf8>
100030e70: aa1303e0    	mov	x0, x19
100030e74: 97fffa74    	bl	0x10002f844 <core::ptr::drop_glue::<raster::types::error::Error>>
100030e78: 528000e8    	mov	w8, #0x7                ; =7
100030e7c: f0000549    	adrp	x9, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030e80: 9131e129    	add	x9, x9, #0xc78
100030e84: a9002668    	stp	x8, x9, [x19]
100030e88: 52800268    	mov	w8, #0x13               ; =19
100030e8c: f9000a68    	str	x8, [x19, #0x10]
100030e90: 3900c27f    	strb	wzr, [x19, #0x30]
100030e94: 52800088    	mov	w8, #0x4                ; =4
100030e98: 39000288    	strb	w8, [x20]
100030e9c: f94002c8    	ldr	x8, [x22]
100030ea0: b4000068    	cbz	x8, 0x100030eac <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe2c>
100030ea4: aa1503e0    	mov	x0, x21
100030ea8: d63f0100    	blr	x8
100030eac: f94006c1    	ldr	x1, [x22, #0x8]
100030eb0: b4ff9521    	cbz	x1, 0x100030154 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd4>
100030eb4: f9400ac2    	ldr	x2, [x22, #0x10]
100030eb8: aa1503e0    	mov	x0, x21
100030ebc: 94007915    	bl	0x10004f310 <__rustc::__rust_dealloc>
100030ec0: 17fffca5    	b	0x100030154 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xd4>
100030ec4: 94027406    	bl	0x1000cdedc <core::panicking::panic_cannot_unwind>
100030ec8: aa0003f4    	mov	x20, x0
100030ecc: f0000548    	adrp	x8, 0x1000db000 <_anon.5bfeabdcda646be48e759f4da0e56e88.105+0x89>
100030ed0: 9131e108    	add	x8, x8, #0xc78
100030ed4: 528000e9    	mov	w9, #0x7                ; =7
100030ed8: a9002269    	stp	x9, x8, [x19]
100030edc: 52800268    	mov	w8, #0x13               ; =19
100030ee0: f9000a68    	str	x8, [x19, #0x10]
100030ee4: 3900c27f    	strb	wzr, [x19, #0x30]
100030ee8: 910183e0    	add	x0, sp, #0x60
100030eec: 97fff8a4    	bl	0x10002f17c <core::ptr::drop_glue::<core::result::Result<core::result::Result<core::option::Option<raster::api::completion::Outcome<u64>>, raster::types::error::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
100030ef0: 14000008    	b	0x100030f10 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe90>
100030ef4: 940273ab    	bl	0x1000cdda0 <core::panicking::panic_in_cleanup>
100030ef8: aa0003f4    	mov	x20, x0
100030efc: f94006c1    	ldr	x1, [x22, #0x8]
100030f00: b4000081    	cbz	x1, 0x100030f10 <<raster::engine::read::ReadTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::step_with_hint+0xe90>
100030f04: f9400ac2    	ldr	x2, [x22, #0x10]
100030f08: aa1503e0    	mov	x0, x21
100030f0c: 94007901    	bl	0x10004f310 <__rustc::__rust_dealloc>
100030f10: aa1403e0    	mov	x0, x20
100030f14: 94027484    	bl	0x1000ce124 <dyld_stub_binder+0x1000ce124>

