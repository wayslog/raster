"""Summarize preserved native acceptance and leaf-PC profiling evidence."""
from pathlib import Path
from collections import Counter
import argparse, gzip, hashlib, json, re, sys

sys.path.insert(0, str(Path('tools/performance').resolve()))
from cpu_profile import validate_output


def profile(root):
    metadata = json.loads((root / 'cpu-profile/environment.json').read_text())
    results = json.loads((root / 'cpu-profile/results.json').read_text())
    summaries = []
    for row in results:
        folder = root / 'cpu-profile' / (row['case'].replace('/', '-') + '-' + row['engine'])
        observed = validate_output((folder / 'record.stdout').read_text(), row['engine'], row['case'], metadata['count'])
        assert observed == row['verified_result']
        digest = hashlib.sha256()
        with gzip.open(folder / 'perf.data.gz', 'rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        assert digest.hexdigest() == row['perf_data_sha256']
        leaves, offsets, thread_counts = Counter(), Counter(), Counter()
        total = single = unknown_callers = 0
        frames, thread = [], None
        def finish():
            nonlocal total, single, unknown_callers
            if thread is None:
                return
            assert frames, 'CPU event has no frame'
            total += 1
            single += len(frames) == 1
            unknown_callers += any('[unknown]' in symbol for symbol in frames[1:])
            thread_counts[thread] += 1
            leaf = frames[0]
            leaves[re.sub(r'\+0x[0-9a-f]+$', '', leaf)] += 1
            offsets[leaf] += 1
        with gzip.open(folder / 'stacks.txt.gz', 'rt') as stream:
            for line in stream:
                if re.search(r'\bcpu-clock(?::u)?:', line):
                    finish()
                    frames = []
                    thread = line.split()[1]
                elif line.strip():
                    match = re.match(r'\s+[0-9a-f]+ (.*) \(.*\)\s*$', line)
                    assert match, line
                    frames.append(match[1])
            finish()
        assert total == row['cpu_samples']
        summaries.append({'case': row['case'], 'engine': row['engine'], 'samples': total,
                          'single_frame_events': single, 'unknown_caller_events': unknown_callers,
                          'top_leaf_symbols': leaves.most_common(35), 'leaf_offsets': offsets.most_common(120),
                          'thread_samples': dict(thread_counts)})
    return summaries


def native(root):
    def read(name): return json.loads((root / name / 'comparison.json').read_text())
    result = {}
    for name in ['memory', 'rust-baseline', 'rust-baseline-control', 'rust-baseline-anchor']:
        rows = read(name)
        assert len(rows) == 18 and len({r['case'] for r in rows}) == 18
        threshold = .9 if name == 'memory' else .98
        for row in rows:
            assert row['passed'] == (row['throughput_ratio'] >= threshold and row['p99_ratio'] <= 1.10)
        result[name] = {'passed': sum(row['passed'] for row in rows), 'total': len(rows),
                        'throughput_range': [min(r['throughput_ratio'] for r in rows), max(r['throughput_ratio'] for r in rows)],
                        'cases': [{k: row[k] for k in ['case', 'throughput_ratio', 'p99_ratio', 'passed']} for row in rows]}
    scans = read('resident-scans')
    assert len(scans) == 2
    result['resident-scans'] = [{k:v for k,v in row.items() if k != 'rows'} for row in scans]
    result['variable-repeat'] = read('variable-repeat')['comparisons']
    rows = read('lifecycles')
    assert len(rows) == 3
    result['lifecycles-strict'] = [
        {k: row[k] for k in ['case', 'throughput_ratio', 'p99_ratio', 'control_throughput_ratio', 'control_p99_ratio']} |
        {'candidate_passed': row['throughput_ratio'] >= .98 and row['p99_ratio'] <= 1.10,
         'control_passed': row['control_throughput_ratio'] >= .98 and row['control_p99_ratio'] <= 1.10}
        for row in rows]
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['native', 'profile'])
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    result = globals()[args.mode](args.root)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('Validated and summarized', args.mode, 'evidence')
