"""Validate complete local regression scope against the frozen 74d4d4 runtime."""
from pathlib import Path
import json,subprocess
root=Path('target/parity-profile/read-inline-access')
base=Path('target/parity-profile/upsert-flat-result/candidate-bins')
cand=root/'candidate-bins'
commands=[('matrix',['python3','tools/performance/compare.py','--rust',str(cand/'parity'),'--baseline-rust',str(base/'parity'),'--min-throughput','0.98','--max-p99','1.10'])]
for name,case in [('aa-upsert','upsert/shared-hot/1'),('aa-read','read/uniform/4')]:
 commands.append((name,['python3','tools/performance/compare.py','--rust',str(base/'parity'),'--baseline-rust',str(base/'parity'),'--min-throughput','0.98','--max-p99','1.10','--case',case]))
commands += [('scans',['python3','tools/performance/compare_scan.py','--baseline',str(base/'parity_scan'),'--candidate',str(cand/'parity_scan')]),('variable',['python3','tools/performance/compare_repeat.py','--baseline',str(base/'benchmark_probe'),'--candidate',str(cand/'benchmark_probe')]),('lifecycles',['python3','tools/acceptance/paired_benchmark.py','--baseline',str(base/'benchmark'),'--candidate',str(cand/'benchmark'),'--interleaved-control'])]
runs=[]
for name,command in commands:
 out=root/('full-'+name);command += ['--output',str(out)]
 print('START',name,flush=True)
 with (root/('full-'+name+'.log')).open('w') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 runs.append({'name':name,'command':command,'exit_code':p.returncode})
 (root/'full-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 result=out/'comparison.json';assert result.exists(),name
 rows=json.loads(result.read_text())
 if name=='variable':print(name,rows['comparisons'],flush=True)
 elif name=='lifecycles':
  summary=[{k:row[k] for k in ['case','throughput_ratio','p99_ratio','control_throughput_ratio','control_p99_ratio']} | {'candidate_passed':row['throughput_ratio']>=.98 and row['p99_ratio']<=1.10,'control_passed':row['control_throughput_ratio']>=.98 and row['control_p99_ratio']<=1.10} for row in rows]
  (root/'strict-lifecycles.json').write_text(json.dumps(summary,indent=2)+'\n');print(name,summary,flush=True)
 else:
  print(name,sum(x['passed'] for x in rows),'/',len(rows),flush=True)
  for row in rows:
   if not row['passed']:print({k:v for k,v in row.items() if k!='rows'},flush=True)
