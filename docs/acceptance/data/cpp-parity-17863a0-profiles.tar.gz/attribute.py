"""Attribute sampled mutex waits to the nearest RasterKV ancestor frame."""
import collections
import json
from pathlib import Path
import re

root = Path(__file__).parent
for label in ("read-uniform-1", "read-uniform-4", "upsert-worker-hot-4"):
    data = (root / (label + ".sample.txt")).read_text()
    graph = data.split("Call graph:\n", 1)[1].split("Total number in stack", 1)[0]
    counts = collections.Counter()
    workers = 0
    stack = []
    active = False
    for line in graph.splitlines():
        thread = re.match(r"^\s+(\d+) Thread_", line)
        if thread:
            active = "com.apple.main-thread" not in line
            if active:
                workers += int(thread[1])
            stack.clear()
            continue
        frame = re.match(r"^([ +!|:]*)((?:\d)+) (.*)$", line)
        if not active or not frame:
            continue
        depth, count, symbol = len(frame[1]), int(frame[2]), frame[3]
        while stack and stack[-1][0] >= depth:
            stack.pop()
        if symbol.startswith("__psynch_mutexwait "):
            nearest = next((name for _, name in reversed(stack) if "6raster" in name), "unknown")
            if "HybridLog" in nearest and "5lease" in nearest:
                category = "resident record lease"
            elif "coordination" in nearest:
                category = "session coordination"
            else:
                category = nearest
            counts[category] += count
        stack.append((depth, symbol))
    collapsed = re.findall(r"^\s+__psynch_mutexwait.*?\s+(\d+)\s*$", data, re.M)
    assert sum(counts.values()) == sum(map(int, collapsed))
    path = root / (label + ".json")
    metadata = json.loads(path.read_text())
    metadata["attribution"] = {
        "worker_samples": workers,
        "mutex_wait_samples_by_nearest_engine_frame": dict(counts),
        "note": "Sample counts are not exclusive CPU time and do not establish causal speedup.",
    }
    path.write_text(json.dumps(metadata, indent=2) + "\n")
    print(label, metadata["attribution"])
