"""Sample fixed workloads without using sampled timings for performance gates."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess
root=Path(__file__).parent
binary=Path("target/parity-profile/session-metrics/parity")
spec=importlib.util.spec_from_file_location("compare", "tools/performance/compare.py")
compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
for operation,distribution,threads in [("read","uniform",1),("read","uniform",4),("upsert","worker-hot",4)]:
 label=f"{operation}-{distribution}-{threads}"
 cmd=[str(binary),operation,distribution,str(threads),"80000000","64"]
 with (root/(label+".stdout")).open("w") as out,(root/(label+".stderr")).open("w") as err:
  p=subprocess.Popen(cmd,stdout=out,stderr=err)
  sample=root/(label+".sample.txt")
  sampled=subprocess.run(["sample",str(p.pid),"5","1","-file",str(sample)],capture_output=True,text=True)
  code=p.wait(timeout=180)
 raw=sample.read_text().replace(str(Path.cwd()),"worktree").replace(str(Path.home()),"user_directory")
 import re
 raw=re.sub(r"/" r"Users/[^/\s]+/", "user_directory/",raw)
 sample.write_text(raw)
 assert sampled.returncode==0 and code==0
 rows=[json.loads(line) for line in (root/(label+".stdout")).read_text().splitlines() if line.startswith('{"engine":')]
 assert len(rows)==1
 assert all(rows[0][k]==v for k,v in compare.expected(operation,distribution,threads,80000000).items())
 metadata={"commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),"command":cmd,"sampling_seconds":5,"sampling_interval_ms":1,"row":rows[0],"note":"Sampled timings are excluded from performance gates."}
 (root/(label+".json")).write_text(json.dumps(metadata,indent=2)+"\n")
 print(label,"completed and independently verified",flush=True)
subprocess.run(["python3",str(root/"attribute.py")],check=True)
