use super::*;
fn put(index: &MemIndex, hash: KeyHash, head: IndexHead) {
    let expected = index.prepare(hash).unwrap();
    assert!(matches!(
        index.compare_publish(expected, head),
        Ok(PublishResult::Published)
    ));
}
#[test]
fn failed_migration_publishes_its_completed_prefix_before_returning() {
    let index = MemIndex::new(IndexConfig { buckets: 2 }).unwrap();
    put(&index, KeyHash(0), IndexHead::Log(LogAddress(64)));
    put(
        &index,
        KeyHash((1 << 48) | 1),
        IndexHead::Cache(CacheAddress(32)),
    );
    index.begin_growth().unwrap();
    assert!(
        index
            .grow_step(PollBudget(std::num::NonZeroUsize::new(2).unwrap()))
            .is_err()
    );
    assert_eq!(
        index.prepare(KeyHash(0)).unwrap().table_generation,
        Generation(1)
    );
    assert_eq!(
        index
            .prepare(KeyHash((1 << 48) | 1))
            .unwrap()
            .table_generation,
        Generation(0)
    );
    put(&index, KeyHash(0), IndexHead::Log(LogAddress(128)));
    assert_eq!(
        index.prepare(KeyHash(0)).unwrap().head,
        IndexHead::Log(LogAddress(128))
    );
}
#[test]
fn routing_guards_keep_retired_tables_alive_until_the_guard_is_released() {
    let index = MemIndex::new(IndexConfig { buckets: 1 }).unwrap();
    let old = Arc::downgrade(&index.state.read().unwrap().active);
    let guard = index.routing.load();
    index.begin_growth().unwrap();
    index
        .grow_step(PollBudget(std::num::NonZeroUsize::new(1).unwrap()))
        .unwrap();
    index.release_retired(Generation(0)).unwrap();
    assert!(old.upgrade().is_some());
    drop(guard);
    assert!(old.upgrade().is_none());
}
#[test]
fn a_new_panic_poisons_routing_instead_of_serving_an_old_snapshot() {
    let index = MemIndex::new(IndexConfig { buckets: 1 }).unwrap();
    put(&index, KeyHash(0), IndexHead::Log(LogAddress(64)));
    std::thread::scope(|scope| {
        assert!(
            scope
                .spawn(|| {
                    let _guard = index.write_state().unwrap();
                    panic!("Poison routing state");
                })
                .join()
                .is_err()
        );
    });
    assert!(index.prepare(KeyHash(0)).is_err());
}
#[test]
fn successful_cleanup_during_existing_unwind_still_publishes_routing() {
    struct FinishGrowth<'a>(&'a MemIndex);
    impl Drop for FinishGrowth<'_> {
        fn drop(&mut self) {
            self.0.begin_growth().unwrap();
            self.0
                .grow_step(PollBudget(std::num::NonZeroUsize::new(1).unwrap()))
                .unwrap();
        }
    }
    let index = MemIndex::new(IndexConfig { buckets: 1 }).unwrap();
    assert!(
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _finish = FinishGrowth(&index);
            panic!("Outer unwind");
        }))
        .is_err()
    );
    assert!(!index.state.is_poisoned());
    assert_eq!(
        index.prepare(KeyHash(0)).unwrap().table_generation,
        Generation(1)
    );
}
