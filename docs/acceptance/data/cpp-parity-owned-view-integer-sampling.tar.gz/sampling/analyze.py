"""Attribute sampled stacks inside public Read calls; keep inlined work unassigned."""
from pathlib import Path
import collections
import json
import re

root = Path(__file__).parent
for threads in (1, 4):
    text = (root / str(threads) / "sample.txt").read_text()
    nodes, stack = [], []
    for line in text.split("Call graph:", 1)[1].split("Total number in stack", 1)[0].splitlines():
        match = re.match(r"^([ +!:|]*)(\d+) (.+)$", line)
        if not match:
            continue
        frame = match.group(3)
        if "(in " not in frame and not frame.startswith("Thread_"):
            continue
        node = {"depth": len(match.group(1)), "samples": int(match.group(2)),
                "symbol": frame.split("  (in ", 1)[0], "children": []}
        while stack and nodes[stack[-1]]["depth"] >= node["depth"]:
            stack.pop()
        node["parent"] = stack[-1] if stack else None
        if stack:
            nodes[stack[-1]]["children"].append(len(nodes))
        nodes.append(node)
        stack.append(len(nodes) - 1)
    roots = {i for i, n in enumerate(nodes) if "3api7session" in n["symbol"] and "4read" in n["symbol"]}
    for i in roots:
        parent = nodes[i]["parent"]
        while parent is not None:
            assert parent not in roots, "Do not double-count nested matching roots"
            parent = nodes[parent]["parent"]
    categories, own = collections.Counter(), collections.Counter()

    def visit(i, trail):
        node = nodes[i]
        trail = trail + [node["symbol"]]
        joined = " ".join(trail)
        exclusive = node["samples"] - sum(nodes[c]["samples"] for c in node["children"])
        assert exclusive >= 0
        if "HybridLog" in joined and "5lease" in joined:
            category = "resident record lease"
        elif "MemIndex7prepare" in joined:
            category = "index lookup"
        elif any(t in joined for t in ("EpochManager", "EpochGuard", "ParticipantSlot")):
            category = "epoch protection"
        elif "observe_session" in joined or "Coordinator" in joined:
            category = "session phase observation"
        elif any(t in joined for t in ("CompletionHub", "OperationRoute")):
            category = "request identity and I/O routing"
        elif "reserve_result" in joined:
            category = "result quota"
        elif "read_resident" in joined:
            category = "value access and callback"
        elif any(t in joined for t in ("7metrics", "5Timer", "7Monitor")):
            category = "metrics"
        else:
            category = "other or inlined work"
        categories[category] += exclusive
        own[node["symbol"]] += exclusive
        for child in node["children"]:
            visit(child, trail)

    for i in sorted(roots):
        visit(i, [])
    total = sum(nodes[i]["samples"] for i in roots)
    assert total and sum(categories.values()) == total
    result = {
        "scope": "Exclusive stack samples within public Session::read only. Samples include blocked threads and are not CPU-time fractions. Inlined work without a visible call-site owner remains unattributed.",
        "session_read_samples": total,
        "categories": [{"category": name, "samples": n, "fraction": n / total} for name, n in categories.most_common()],
        "exclusive_symbols": [{"symbol": name, "samples": n} for name, n in own.most_common(20)],
    }
    (root / str(threads) / "read-samples.json").write_text(json.dumps(result, indent=2) + "\n")
    print(threads, total, dict(categories))
