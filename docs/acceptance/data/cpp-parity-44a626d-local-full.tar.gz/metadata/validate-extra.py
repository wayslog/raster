"""Check scheduled samples, scan controls, and exact source identities."""
from pathlib import Path
import hashlib,json,statistics
root=Path('target/parity-profile/key-preparation-inline');base=Path('target/parity-profile/read-inline-access/candidate-bins')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
for name in ['matrix','aa-upsert','aa-read']:
 d=root/('full-'+name);env=read(d/'environment.json')
 assert env['binary_sha256']['baseline']==sha(base/'parity')
 assert env['binary_sha256']['rust']==sha((root/'candidate-bins' if name=='matrix' else base)/'parity')
 for p in d.glob('*.stdout'):
  r=read(p);threads=r['threads'];n=env['count']//threads
  assert r['samples']==threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
controls=[]
for name in ['full-scans','scan-aa']:
 d=root/name;env=read(d/'environment.json')
 assert env['binary_sha256']['baseline']==sha(base/'parity_scan')
 assert env['binary_sha256']['candidate']==sha((base if name=='scan-aa' else root/'candidate-bins')/'parity_scan')
 for row in read(d/'comparison.json'):
  n=row['records'];checksum=(sum(k^0x7261737465720001 for k in range(n))*8)%(1<<64)
  for label in ['baseline','candidate']:
   for i in range(-1,env['rounds']):
    prefix=d/f'{n}-{i}-{label}';r=read(prefix.with_suffix('.stdout'))
    assert r['records']==n and r['scans']==8 and r['checksum']==checksum and r['samples']==n*8//64
    assert not prefix.with_suffix('.stderr').read_text()
    if i>=0:assert r==row['rows'][label][i]
  med=lambda label,key:statistics.median(r[key] for r in row['rows'][label])
  a=med('baseline','append_ns')/med('candidate','append_ns');s=med('baseline','scan_ns')/med('candidate','scan_ns');p=med('candidate','p99_ns')/med('baseline','p99_ns')
  assert [row[k] for k in ['append_throughput_ratio','scan_throughput_ratio','p99_ratio']]==[a,s,p]
  assert row['passed']==(a>=.98 and s>=.98 and p<=1.1)
  if name=='scan-aa':controls.append({'records':n,'append_throughput_ratio':a,'scan_throughput_ratio':s,'p99_ratio':p,'reciprocal_control_valid':.98<=a<=1/.98 and .98<=s<=1/.98 and 1/1.1<=p<=1.1})
(root/'full-extra-validation.json').write_text(json.dumps({'integer_samples':'all scheduled samples verified','binary_identity':'verified','scan_outputs':40,'scan_controls':controls},indent=2)+'\n')
print(json.dumps(controls))
