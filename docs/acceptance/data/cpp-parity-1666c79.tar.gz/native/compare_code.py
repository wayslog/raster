from pathlib import Path
import re,json,hashlib,collections
root=Path(__file__).parent/'cpp-rust-parity/native-code'
def read(path):
    functions={};counts=collections.Counter();key=None
    for line in path.read_text().splitlines():
        header=re.match(r'^([0-9a-f]+) <(.*)>:$',line)
        if header:
            name=header[2];counts[name]+=1;key=(name,counts[name])
            functions[key]={'address':int(header[1],16),'raw':bytearray(),'ops':[]};continue
        code=re.match(r'^\s*[0-9a-f]+:\s*((?:[0-9a-f]{2}(?:\s+|$))+)(.*)$',line)
        if key is None or not code:continue
        functions[key]['raw'].extend(bytes.fromhex(code[1]))
        if code[2]:functions[key]['ops'].append(code[2].strip())
    return functions
candidate=read(root/'candidate-parity.asm');baseline=read(root/'baseline-parity.asm');control=read(root/'memory-baseline-parity.asm')
assert set(candidate)==set(control)
assert all(candidate[k]['raw']==control[k]['raw'] and candidate[k]['address']==control[k]['address'] for k in candidate)
changed=[]
for key in candidate.keys() & baseline.keys():
    a=candidate[key];b=baseline[key]
    if a['raw']!=b['raw'] or a['address']!=b['address']:
        changed.append({'function':key[0],'occurrence':key[1],'candidate_address':a['address'],'baseline_address':b['address'],'candidate_bytes':len(a['raw']),'baseline_bytes':len(b['raw']),'same_bytes':a['raw']==b['raw']})
result={'scope':'Exact decoded instruction bytes and symbol start addresses from objdump; does not compare other ELF sections or pointed-to constants.','candidate_symbols':len(candidate),'baseline_symbols':len(baseline),'same_source_control_exact_code':True,'changed':changed,'candidate_only':[k[0] for k in candidate.keys()-baseline.keys()],'baseline_only':[k[0] for k in baseline.keys()-candidate.keys()]}
(Path(__file__).parent/'code-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('functions:',len(candidate),len(baseline),'changes:',len(changed),'added:',len(result['candidate_only']),'removed:',len(result['baseline_only']))
for row in changed[:20]:print(row)
