"""Separate the direct-reference component and retain ordinary-path checks."""
from pathlib import Path
import json,subprocess
root=Path("target/parity-profile/result-budget-first-slot")
candidate=root/"candidate-bins"
original=Path("target/parity-profile/upsert-flat-result/candidate-bins")
position=Path("target/parity-profile/result-budget-front/candidate-bins")
commands=[("retained-original",["python3","tools/performance/compare_result_budget.py","--rust",str(candidate/"result_budget"),"--baseline-rust","target/parity-profile/result-budget-front/baseline-bins/result_budget"]),("retained-component",["python3","tools/performance/compare_result_budget.py","--rust",str(candidate/"result_budget"),"--baseline-rust",str(position/"result_budget"),"--retained","0"])]
for name,case in [("upsert-shared","upsert/shared-hot/1"),("upsert-uniform","upsert/uniform/1"),("upsert-four","upsert/worker-hot/4"),("read-shared","read/shared-hot/1"),("rmw-shared","rmw/shared-hot/1"),("control-upsert","upsert/shared-hot/1"),("control-read","read/shared-hot/1")]:
 commands.append((name,["python3","tools/performance/compare.py","--rust",str((original if name.startswith("control") else candidate)/"parity"),"--baseline-rust",str(original/"parity"),"--case",case,"--min-throughput","0.98","--max-p99","1.10"]))
runs=[]
for name,cmd in commands:
 out=root/name;command=cmd+["--output",str(out)]
 print("START",name,flush=True)
 result=subprocess.run(command,capture_output=True,text=True)
 (root/(name+".log")).write_text(result.stdout+result.stderr)
 runs.append({"name":name,"command":command,"exit_code":result.returncode})
 (root/"runs.json").write_text(json.dumps(runs,indent=2)+"\n")
 assert (out/"comparison.json").exists(),result.stderr
 print(result.stdout,flush=True)
