000000010004de24 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked>:
10004de24: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10004de28: a90167fa    	stp	x26, x25, [sp, #0x10]
10004de2c: a9025ff8    	stp	x24, x23, [sp, #0x20]
10004de30: a90357f6    	stp	x22, x21, [sp, #0x30]
10004de34: a9044ff4    	stp	x20, x19, [sp, #0x40]
10004de38: a9057bfd    	stp	x29, x30, [sp, #0x50]
10004de3c: 910143fd    	add	x29, sp, #0x50
10004de40: d10e03ff    	sub	sp, sp, #0x380
10004de44: f9400008    	ldr	x8, [x0]
10004de48: b4000268    	cbz	x8, 0x10004de94 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x70>
10004de4c: aa0003f3    	mov	x19, x0
10004de50: f9400034    	ldr	x20, [x1]
10004de54: 52838508    	mov	w8, #0x1c28             ; =7208
10004de58: 8b080299    	add	x25, x20, x8
10004de5c: 08dfff28    	ldarb	w8, [x25]
10004de60: 340002c8    	cbz	w8, 0x10004deb8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x94>
10004de64: 39476a68    	ldrb	w8, [x19, #0x1da]
10004de68: 90000489    	adrp	x9, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004de6c: 91201929    	add	x9, x9, #0x806
10004de70: 528000ea    	mov	w10, #0x7               ; =7
10004de74: a91d27ea    	stp	x10, x9, [sp, #0x1d0]
10004de78: 52800289    	mov	w9, #0x14               ; =20
10004de7c: f900f3e9    	str	x9, [sp, #0x1e0]
10004de80: 390803e8    	strb	w8, [sp, #0x200]
10004de84: 910743e2    	add	x2, sp, #0x1d0
10004de88: aa1303e0    	mov	x0, x19
10004de8c: aa1403e1    	mov	x1, x20
10004de90: 9400057e    	bl	0x10004f488 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004de94: 52800000    	mov	w0, #0x0                ; =0
10004de98: 910e03ff    	add	sp, sp, #0x380
10004de9c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10004dea0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10004dea4: a94357f6    	ldp	x22, x21, [sp, #0x30]
10004dea8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10004deac: a94167fa    	ldp	x26, x25, [sp, #0x10]
10004deb0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10004deb4: d65f03c0    	ret
10004deb8: aa0303f6    	mov	x22, x3
10004debc: aa0203f5    	mov	x21, x2
10004dec0: f940ca61    	ldr	x1, [x19, #0x190]
10004dec4: 9106e268    	add	x8, x19, #0x1b8
10004dec8: f940de69    	ldr	x9, [x19, #0x1b8]
10004decc: f100013f    	cmp	x9, #0x0
10004ded0: 9a8803e2    	csel	x2, xzr, x8, eq
10004ded4: 910943e8    	add	x8, sp, #0x250
10004ded8: 910d0280    	add	x0, x20, #0x340
10004dedc: 9400459b    	bl	0x10005f548 <<raster::engine::version_permit::VersionPermits>::ready_initial>
10004dee0: f9412be8    	ldr	x8, [sp, #0x250]
10004dee4: b100051f    	cmn	x8, #0x1
10004dee8: 1a9f17e0    	cset	w0, eq
10004deec: 540001c0    	b.eq	0x10004df24 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x100>
10004def0: ad5287e0    	ldp	q0, q1, [sp, #0x250]
10004def4: ad0e87e0    	stp	q0, q1, [sp, #0x1d0]
10004def8: 3dc09fe0    	ldr	q0, [sp, #0x270]
10004defc: 3d807fe0    	str	q0, [sp, #0x1f0]
10004df00: 39476a68    	ldrb	w8, [x19, #0x1da]
10004df04: 390803e8    	strb	w8, [sp, #0x200]
10004df08: 910743e2    	add	x2, sp, #0x1d0
10004df0c: aa0003f5    	mov	x21, x0
10004df10: aa1303e0    	mov	x0, x19
10004df14: aa1403e1    	mov	x1, x20
10004df18: 9400055c    	bl	0x10004f488 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::finish>
10004df1c: aa1503e0    	mov	x0, x21
10004df20: 17ffffde    	b	0x10004de98 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x74>
10004df24: 394963e8    	ldrb	w8, [sp, #0x258]
10004df28: 7100051f    	cmp	w8, #0x1
10004df2c: 54fffb61    	b.ne	0x10004de98 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x74>
10004df30: 910943fa    	add	x26, sp, #0x250
10004df34: 910583fb    	add	x27, sp, #0x160
10004df38: aa1303fc    	mov	x28, x19
10004df3c: f8418f89    	ldr	x9, [x28, #0x18]!
10004df40: f100093f    	cmp	x9, #0x2
10004df44: 54001fe1    	b.ne	0x10004e340 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x51c>
10004df48: b4000716    	cbz	x22, 0x10004e028 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x204>
10004df4c: f940ca78    	ldr	x24, [x19, #0x190]
10004df50: 9104e260    	add	x0, x19, #0x138
10004df54: 94006665    	bl	0x1000678e8 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004df58: aa0003e2    	mov	x2, x0
10004df5c: aa0103e3    	mov	x3, x1
10004df60: f94002d7    	ldr	x23, [x22]
10004df64: 910743e8    	add	x8, sp, #0x1d0
10004df68: 91020280    	add	x0, x20, #0x80
10004df6c: aa1803e1    	mov	x1, x24
10004df70: aa1703e4    	mov	x4, x23
10004df74: 97fefd4d    	bl	0x10000d4a8 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index_guarded>
10004df78: f940ebe8    	ldr	x8, [sp, #0x1d0]
10004df7c: 3cc78360    	ldur	q0, [x27, #0x78]
10004df80: 3cc88361    	ldur	q1, [x27, #0x88]
10004df84: ad1607e0    	stp	q0, q1, [sp, #0x2c0]
10004df88: 3cc98360    	ldur	q0, [x27, #0x98]
10004df8c: 3d80bbe0    	str	q0, [sp, #0x2e0]
10004df90: f100091f    	cmp	x8, #0x2
10004df94: 54002260    	b.eq	0x10004e3e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5bc>
10004df98: 3cca8360    	ldur	q0, [x27, #0xa8]
10004df9c: 3c838340    	stur	q0, [x26, #0x38]
10004dfa0: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004dfa4: 3c848340    	stur	q0, [x26, #0x48]
10004dfa8: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004dfac: 3c808340    	stur	q0, [x26, #0x8]
10004dfb0: f94117e9    	ldr	x9, [sp, #0x228]
10004dfb4: 3c818341    	stur	q1, [x26, #0x18]
10004dfb8: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004dfbc: 3c828340    	stur	q0, [x26, #0x28]
10004dfc0: f90157e9    	str	x9, [sp, #0x2a8]
10004dfc4: f9012be8    	str	x8, [sp, #0x250]
10004dfc8: 394a4be8    	ldrb	w8, [sp, #0x292]
10004dfcc: 7100051f    	cmp	w8, #0x1
10004dfd0: 54000661    	b.ne	0x10004e09c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x278>
10004dfd4: 39476668    	ldrb	w8, [x19, #0x1d9]
10004dfd8: 37000628    	tbnz	w8, #0x0, 0x10004e09c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x278>
10004dfdc: 9104e260    	add	x0, x19, #0x138
10004dfe0: 94006642    	bl	0x1000678e8 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004dfe4: aa0003e2    	mov	x2, x0
10004dfe8: aa0103e5    	mov	x5, x1
10004dfec: f9414fe3    	ldr	x3, [sp, #0x298]
10004dff0: f94153e4    	ldr	x4, [sp, #0x2a0]
10004dff4: 910743e8    	add	x8, sp, #0x1d0
10004dff8: 91152280    	add	x0, x20, #0x548
10004dffc: aa0203e1    	mov	x1, x2
10004e000: aa0503e2    	mov	x2, x5
10004e004: aa1603e5    	mov	x5, x22
10004e008: 97ff2c95    	bl	0x10001925c <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::mutable_head_borrowed>
10004e00c: a95d5be8    	ldp	x8, x22, [sp, #0x1d0]
10004e010: b100051f    	cmn	x8, #0x1
10004e014: 54003220    	b.eq	0x10004e658 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x834>
10004e018: ad4f07e0    	ldp	q0, q1, [sp, #0x1e0]
10004e01c: ad0487e0    	stp	q0, q1, [sp, #0x90]
10004e020: a9085be8    	stp	x8, x22, [sp, #0x80]
10004e024: 14000274    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004e028: f940ca76    	ldr	x22, [x19, #0x190]
10004e02c: 9104e260    	add	x0, x19, #0x138
10004e030: 9400662e    	bl	0x1000678e8 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004e034: aa0003e2    	mov	x2, x0
10004e038: aa0103e3    	mov	x3, x1
10004e03c: 910743e8    	add	x8, sp, #0x1d0
10004e040: 91020280    	add	x0, x20, #0x80
10004e044: aa1603e1    	mov	x1, x22
10004e048: 97fefaf4    	bl	0x10000cc18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index>
10004e04c: f940ebe8    	ldr	x8, [sp, #0x1d0]
10004e050: 3cc78360    	ldur	q0, [x27, #0x78]
10004e054: 3cc88361    	ldur	q1, [x27, #0x88]
10004e058: ad1607e0    	stp	q0, q1, [sp, #0x2c0]
10004e05c: 3cc98360    	ldur	q0, [x27, #0x98]
10004e060: 3d80bbe0    	str	q0, [sp, #0x2e0]
10004e064: f100091f    	cmp	x8, #0x2
10004e068: 54001bc0    	b.eq	0x10004e3e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5bc>
10004e06c: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e070: 3c838340    	stur	q0, [x26, #0x38]
10004e074: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e078: 3c848340    	stur	q0, [x26, #0x48]
10004e07c: f94117e9    	ldr	x9, [sp, #0x228]
10004e080: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e084: 3c808340    	stur	q0, [x26, #0x8]
10004e088: 3c818341    	stur	q1, [x26, #0x18]
10004e08c: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e090: 3c828340    	stur	q0, [x26, #0x28]
10004e094: f90157e9    	str	x9, [sp, #0x2a8]
10004e098: f9012be8    	str	x8, [sp, #0x250]
10004e09c: 394a4be8    	ldrb	w8, [sp, #0x292]
10004e0a0: 36000208    	tbz	w8, #0x0, 0x10004e0e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x2bc>
10004e0a4: ad5387e0    	ldp	q0, q1, [sp, #0x270]
10004e0a8: ad0987e0    	stp	q0, q1, [sp, #0x130]
10004e0ac: f9414be8    	ldr	x8, [sp, #0x290]
10004e0b0: f900abe8    	str	x8, [sp, #0x150]
10004e0b4: ad5283e1    	ldp	q1, q0, [sp, #0x250]
10004e0b8: ad0883e1    	stp	q1, q0, [sp, #0x110]
10004e0bc: 3944e268    	ldrb	w8, [x19, #0x138]
10004e0c0: 7100051f    	cmp	w8, #0x1
10004e0c4: 540008c1    	b.ne	0x10004e1dc <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x3b8>
10004e0c8: 910583e8    	add	x8, sp, #0x160
10004e0cc: 91002108    	add	x8, x8, #0x8
10004e0d0: 91050260    	add	x0, x19, #0x140
10004e0d4: 97ffe68f    	bl	0x100047b10 <<alloc::vec::Vec<u8> as core::clone::Clone>::clone>
10004e0d8: 52800028    	mov	w8, #0x1                ; =1
10004e0dc: 14000047    	b	0x10004e1f8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x3d4>
10004e0e0: ad5387e0    	ldp	q0, q1, [sp, #0x270]
10004e0e4: ad0f87e0    	stp	q0, q1, [sp, #0x1f0]
10004e0e8: f9414be8    	ldr	x8, [sp, #0x290]
10004e0ec: f9010be8    	str	x8, [sp, #0x210]
10004e0f0: ad5283e1    	ldp	q1, q0, [sp, #0x250]
10004e0f4: ad0e83e1    	stp	q1, q0, [sp, #0x1d0]
10004e0f8: 910b03e8    	add	x8, sp, #0x2c0
10004e0fc: 91020280    	add	x0, x20, #0x80
10004e100: 910743e1    	add	x1, sp, #0x1d0
10004e104: 9400554c    	bl	0x100063634 <<raster::index::growth::MemIndex>::reserve_empty>
10004e108: f94163e8    	ldr	x8, [sp, #0x2c0]
10004e10c: b100051f    	cmn	x8, #0x1
10004e110: 54002980    	b.eq	0x10004e640 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x81c>
10004e114: f100091f    	cmp	x8, #0x2
10004e118: 54004661    	b.ne	0x10004e9e4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbc0>
10004e11c: f940ca76    	ldr	x22, [x19, #0x190]
10004e120: 9104e260    	add	x0, x19, #0x138
10004e124: 940065f1    	bl	0x1000678e8 <<raster::schema::encoded_key::EncodedKey as core::ops::deref::Deref>::deref>
10004e128: aa0003e2    	mov	x2, x0
10004e12c: aa0103e3    	mov	x3, x1
10004e130: 910743e8    	add	x8, sp, #0x1d0
10004e134: 91020280    	add	x0, x20, #0x80
10004e138: aa1603e1    	mov	x1, x22
10004e13c: 97fefab7    	bl	0x10000cc18 <<raster::engine::Engine<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>::resolve_index>
10004e140: f940ebf6    	ldr	x22, [sp, #0x1d0]
10004e144: 3cc78360    	ldur	q0, [x27, #0x78]
10004e148: 3cc88361    	ldur	q1, [x27, #0x88]
10004e14c: ad1607e0    	stp	q0, q1, [sp, #0x2c0]
10004e150: 3cc98360    	ldur	q0, [x27, #0x98]
10004e154: 3d80bbe0    	str	q0, [sp, #0x2e0]
10004e158: f1000adf    	cmp	x22, #0x2
10004e15c: 54000700    	b.eq	0x10004e23c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x418>
10004e160: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e164: 3ccb8361    	ldur	q1, [x27, #0xb8]
10004e168: ad0587e0    	stp	q0, q1, [sp, #0xb0]
10004e16c: f94117e8    	ldr	x8, [sp, #0x228]
10004e170: f9006be8    	str	x8, [sp, #0xd0]
10004e174: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e178: ad0707e0    	stp	q0, q1, [sp, #0xe0]
10004e17c: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e180: 3d8043e0    	str	q0, [sp, #0x100]
10004e184: f94157e8    	ldr	x8, [sp, #0x2a8]
10004e188: b4000128    	cbz	x8, 0x10004e1ac <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x388>
10004e18c: 92800009    	mov	x9, #-0x1               ; =-1
10004e190: f8690108    	ldaddl	x9, x8, [x8]
10004e194: f100051f    	cmp	x8, #0x1
10004e198: 540000a1    	b.ne	0x10004e1ac <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x388>
10004e19c: 910943e8    	add	x8, sp, #0x250
10004e1a0: d50339bf    	dmb	ishld
10004e1a4: 91016100    	add	x0, x8, #0x58
10004e1a8: 9400b4d5    	bl	0x10007b4fc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e1ac: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
10004e1b0: 3c808340    	stur	q0, [x26, #0x8]
10004e1b4: 3c818341    	stur	q1, [x26, #0x18]
10004e1b8: 3dc043e0    	ldr	q0, [sp, #0x100]
10004e1bc: 3c828340    	stur	q0, [x26, #0x28]
10004e1c0: ad4587e0    	ldp	q0, q1, [sp, #0xb0]
10004e1c4: 3c838340    	stur	q0, [x26, #0x38]
10004e1c8: 3c848341    	stur	q1, [x26, #0x48]
10004e1cc: f9406be8    	ldr	x8, [sp, #0xd0]
10004e1d0: f9012bf6    	str	x22, [sp, #0x250]
10004e1d4: f90157e8    	str	x8, [sp, #0x2a8]
10004e1d8: 17ffffb3    	b	0x10004e0a4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x280>
10004e1dc: 52800008    	mov	w8, #0x0                ; =0
10004e1e0: 9104ea69    	add	x9, x19, #0x13a
10004e1e4: 3dc00120    	ldr	q0, [x9]
10004e1e8: 910203e9    	add	x9, sp, #0x80
10004e1ec: 3c8e2120    	stur	q0, [x9, #0xe2]
10004e1f0: 3944e669    	ldrb	w9, [x19, #0x139]
10004e1f4: 390587e9    	strb	w9, [sp, #0x161]
10004e1f8: 390583e8    	strb	w8, [sp, #0x160]
10004e1fc: f9414fe3    	ldr	x3, [sp, #0x298]
10004e200: f94153e4    	ldr	x4, [sp, #0x2a0]
10004e204: f940be65    	ldr	x5, [x19, #0x178]
10004e208: 910743e8    	add	x8, sp, #0x1d0
10004e20c: 91152280    	add	x0, x20, #0x548
10004e210: 91082281    	add	x1, x20, #0x208
10004e214: 910583e2    	add	x2, sp, #0x160
10004e218: 97ff1d0f    	bl	0x100015654 <<raster::log::HybridLog<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::lookup_deferred::<raster::schema::encoded_key::EncodedKey>>
10004e21c: f940ebf6    	ldr	x22, [sp, #0x1d0]
10004e220: 3cc78360    	ldur	q0, [x27, #0x78]
10004e224: 3cc88361    	ldur	q1, [x27, #0x88]
10004e228: ad1607e0    	stp	q0, q1, [sp, #0x2c0]
10004e22c: 3cc98360    	ldur	q0, [x27, #0x98]
10004e230: 3d80bbe0    	str	q0, [sp, #0x2e0]
10004e234: f1000adf    	cmp	x22, #0x2
10004e238: 540000c1    	b.ne	0x10004e250 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x42c>
10004e23c: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e240: ad0407e0    	stp	q0, q1, [sp, #0x80]
10004e244: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e248: 3d802be0    	str	q0, [sp, #0xa0]
10004e24c: 140001ea    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004e250: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e254: 3ccb8361    	ldur	q1, [x27, #0xb8]
10004e258: ad0b07e0    	stp	q0, q1, [sp, #0x160]
10004e25c: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e260: 3d8063e0    	str	q0, [sp, #0x180]
10004e264: 3ccd2360    	ldur	q0, [x27, #0xd2]
10004e268: 3c82a360    	stur	q0, [x27, #0x2a]
10004e26c: 39490be8    	ldrb	w8, [sp, #0x242]
10004e270: 39490fe9    	ldrb	w9, [sp, #0x243]
10004e274: b94247ea    	ldr	w10, [sp, #0x244]
10004e278: b9000fea    	str	w10, [sp, #0xc]
10004e27c: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e280: ad0d07e0    	stp	q0, q1, [sp, #0x1a0]
10004e284: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e288: 3d8073e0    	str	q0, [sp, #0x1c0]
10004e28c: 3946226a    	ldrb	w10, [x19, #0x188]
10004e290: 7100015f    	cmp	w10, #0x0
10004e294: 1a8913f8    	csel	w24, wzr, w9, ne
10004e298: 1a9f0517    	csinc	w23, w8, wzr, eq
10004e29c: f9400e68    	ldr	x8, [x19, #0x18]
10004e2a0: f100091f    	cmp	x8, #0x2
10004e2a4: 54000060    	b.eq	0x10004e2b0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x48c>
10004e2a8: 91018260    	add	x0, x19, #0x60
10004e2ac: 97fffdf2    	bl	0x10004da74 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e2b0: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10004e2b4: ad010780    	stp	q0, q1, [x28, #0x20]
10004e2b8: ad4883e1    	ldp	q1, q0, [sp, #0x110]
10004e2bc: ad000381    	stp	q1, q0, [x28]
10004e2c0: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
10004e2c4: 3c868260    	stur	q0, [x19, #0x68]
10004e2c8: 3c878261    	stur	q1, [x19, #0x78]
10004e2cc: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10004e2d0: 3c888260    	stur	q0, [x19, #0x88]
10004e2d4: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004e2d8: 3c8c2260    	stur	q0, [x19, #0xc2]
10004e2dc: ad4b87e0    	ldp	q0, q1, [sp, #0x170]
10004e2e0: 3c8b8261    	stur	q1, [x19, #0xb8]
10004e2e4: 3dc05be1    	ldr	q1, [sp, #0x160]
10004e2e8: 3c8a8260    	stur	q0, [x19, #0xa8]
10004e2ec: f940abe8    	ldr	x8, [sp, #0x150]
10004e2f0: f9002388    	str	x8, [x28, #0x40]
10004e2f4: f9003276    	str	x22, [x19, #0x60]
10004e2f8: 3c898261    	stur	q1, [x19, #0x98]
10004e2fc: 39034a77    	strb	w23, [x19, #0xd2]
10004e300: 39034e78    	strb	w24, [x19, #0xd3]
10004e304: b9400fe8    	ldr	w8, [sp, #0xc]
10004e308: b900d668    	str	w8, [x19, #0xd4]
10004e30c: f94157e8    	ldr	x8, [sp, #0x2a8]
10004e310: b4000128    	cbz	x8, 0x10004e334 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x510>
10004e314: 92800009    	mov	x9, #-0x1               ; =-1
10004e318: f8690108    	ldaddl	x9, x8, [x8]
10004e31c: f100051f    	cmp	x8, #0x1
10004e320: 540000a1    	b.ne	0x10004e334 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x510>
10004e324: 910943e8    	add	x8, sp, #0x250
10004e328: d50339bf    	dmb	ishld
10004e32c: 91016100    	add	x0, x8, #0x58
10004e330: 9400b473    	bl	0x10007b4fc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004e334: f9400388    	ldr	x8, [x28]
10004e338: f100091f    	cmp	x8, #0x2
10004e33c: 54003a20    	b.eq	0x10004ea80 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc5c>
10004e340: 910743e8    	add	x8, sp, #0x1d0
10004e344: 91018260    	add	x0, x19, #0x60
10004e348: 91152281    	add	x1, x20, #0x548
10004e34c: 91082282    	add	x2, x20, #0x208
10004e350: aa1503e3    	mov	x3, x21
10004e354: 97ff802d    	bl	0x10002e408 <<raster::log::lookup::LogLookup>::step::<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>
10004e358: f940ebe8    	ldr	x8, [sp, #0x1d0]
10004e35c: 3cc78360    	ldur	q0, [x27, #0x78]
10004e360: 3cc88361    	ldur	q1, [x27, #0x88]
10004e364: ad1607e0    	stp	q0, q1, [sp, #0x2c0]
10004e368: 3cc98360    	ldur	q0, [x27, #0x98]
10004e36c: 3d80bbe0    	str	q0, [sp, #0x2e0]
10004e370: b100051f    	cmn	x8, #0x1
10004e374: 54000360    	b.eq	0x10004e3e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5bc>
10004e378: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e37c: 3c838340    	stur	q0, [x26, #0x38]
10004e380: 3ccb8360    	ldur	q0, [x27, #0xb8]
10004e384: 3c848340    	stur	q0, [x26, #0x48]
10004e388: 3ccc8360    	ldur	q0, [x27, #0xc8]
10004e38c: 3c858340    	stur	q0, [x26, #0x58]
10004e390: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e394: 3c808340    	stur	q0, [x26, #0x8]
10004e398: f9411fe9    	ldr	x9, [sp, #0x238]
10004e39c: 3c818341    	stur	q1, [x26, #0x18]
10004e3a0: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e3a4: 3c828340    	stur	q0, [x26, #0x28]
10004e3a8: f9015fe9    	str	x9, [sp, #0x2b8]
10004e3ac: f9012be8    	str	x8, [sp, #0x250]
10004e3b0: f100191f    	cmp	x8, #0x6
10004e3b4: 54000b49    	b.ls	0x10004e51c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x6f8>
10004e3b8: 52801fe8    	mov	w8, #0xff               ; =255
10004e3bc: 390223e8    	strb	w8, [sp, #0x88]
10004e3c0: 92800008    	mov	x8, #-0x1               ; =-1
10004e3c4: f90043e8    	str	x8, [sp, #0x80]
10004e3c8: f9412be8    	ldr	x8, [sp, #0x250]
10004e3cc: d1000909    	sub	x9, x8, #0x2
10004e3d0: f100051f    	cmp	x8, #0x1
10004e3d4: 9a9f8528    	csinc	x8, x9, xzr, hi
10004e3d8: b5000d08    	cbnz	x8, 0x10004e578 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x754>
10004e3dc: 14000141    	b	0x10004e8e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xabc>
10004e3e0: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10004e3e4: ad0407e0    	stp	q0, q1, [sp, #0x80]
10004e3e8: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10004e3ec: 3d802be0    	str	q0, [sp, #0xa0]
10004e3f0: a94857e8    	ldp	x8, x21, [sp, #0x80]
10004e3f4: ad4487e0    	ldp	q0, q1, [sp, #0x90]
10004e3f8: 3d8013e1    	str	q1, [sp, #0x40]
10004e3fc: b100091f    	cmn	x8, #0x2
10004e400: 540001c0    	b.eq	0x10004e438 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x614>
10004e404: 3dc013e1    	ldr	q1, [sp, #0x40]
10004e408: a90157e8    	stp	x8, x21, [sp, #0x10]
10004e40c: ad0107e0    	stp	q0, q1, [sp, #0x20]
10004e410: 52801feb    	mov	w11, #0xff              ; =255
10004e414: 6a35017f    	bics	wzr, w11, w21
10004e418: 1a9f17e9    	cset	w9, eq
10004e41c: b100051f    	cmn	x8, #0x1
10004e420: 1a9f17ea    	cset	w10, eq
10004e424: 540003c1    	b.ne	0x10004e49c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x678>
10004e428: 6a35017f    	bics	wzr, w11, w21
10004e42c: 54000381    	b.ne	0x10004e49c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x678>
10004e430: 52800020    	mov	w0, #0x1                ; =1
10004e434: 17fffe99    	b	0x10004de98 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x74>
10004e438: 9e660016    	fmov	x22, d0
10004e43c: 52800028    	mov	w8, #0x1                ; =1
10004e440: 089fff28    	stlrb	w8, [x25]
10004e444: f0000468    	adrp	x8, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004e448: 911f7108    	add	x8, x8, #0x7dc
10004e44c: 528000e9    	mov	w9, #0x7                ; =7
10004e450: a90123e9    	stp	x9, x8, [sp, #0x10]
10004e454: 52800288    	mov	w8, #0x14               ; =20
10004e458: f90013e8    	str	x8, [sp, #0x20]
10004e45c: f94002c8    	ldr	x8, [x22]
10004e460: b4000068    	cbz	x8, 0x10004e46c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x648>
10004e464: aa1503e0    	mov	x0, x21
10004e468: d63f0100    	blr	x8
10004e46c: f94006c1    	ldr	x1, [x22, #0x8]
10004e470: b4000081    	cbz	x1, 0x10004e480 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x65c>
10004e474: f9400ac2    	ldr	x2, [x22, #0x10]
10004e478: aa1503e0    	mov	x0, x21
10004e47c: 9400062b    	bl	0x10004fd28 <__rustc::__rust_dealloc>
10004e480: 5280000a    	mov	w10, #0x0               ; =0
10004e484: f0000475    	adrp	x21, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004e488: 911f72b5    	add	x21, x21, #0x7dc
10004e48c: 52801fe8    	mov	w8, #0xff               ; =255
10004e490: 6a35011f    	bics	wzr, w8, w21
10004e494: 1a9f17e9    	cset	w9, eq
10004e498: 528000e8    	mov	w8, #0x7                ; =7
10004e49c: b100051f    	cmn	x8, #0x1
10004e4a0: 540000c0    	b.eq	0x10004e4b8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x694>
10004e4a4: 39476a6b    	ldrb	w11, [x19, #0x1da]
10004e4a8: 7100097f    	cmp	w11, #0x2
10004e4ac: 54000061    	b.ne	0x10004e4b8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x694>
10004e4b0: 5280002b    	mov	w11, #0x1               ; =1
10004e4b4: 089fff2b    	stlrb	w11, [x25]
10004e4b8: 910043eb    	add	x11, sp, #0x10
10004e4bc: 3600014a    	tbz	w10, #0x0, 0x10004e4e4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x6c0>
10004e4c0: 37003269    	tbnz	w9, #0x0, 0x10004eb0c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xce8>
10004e4c4: f8409168    	ldur	x8, [x11, #0x9]
10004e4c8: f80493e8    	stur	x8, [sp, #0x49]
10004e4cc: f8410168    	ldur	x8, [x11, #0x10]
10004e4d0: f9002be8    	str	x8, [sp, #0x50]
10004e4d4: 390123f5    	strb	w21, [sp, #0x48]
10004e4d8: 92800008    	mov	x8, #-0x1               ; =-1
10004e4dc: f90023e8    	str	x8, [sp, #0x40]
10004e4e0: 1400000d    	b	0x10004e514 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x6f0>
10004e4e4: 3cc283e0    	ldur	q0, [sp, #0x28]
10004e4e8: 3c8583e0    	stur	q0, [sp, #0x58]
10004e4ec: f9401fe9    	ldr	x9, [sp, #0x38]
10004e4f0: f90037e9    	str	x9, [sp, #0x68]
10004e4f4: f8409169    	ldur	x9, [x11, #0x9]
10004e4f8: f80493e9    	stur	x9, [sp, #0x49]
10004e4fc: f8410169    	ldur	x9, [x11, #0x10]
10004e500: f9002be9    	str	x9, [sp, #0x50]
10004e504: 39476a69    	ldrb	w9, [x19, #0x1da]
10004e508: f90023e8    	str	x8, [sp, #0x40]
10004e50c: 390123f5    	strb	w21, [sp, #0x48]
10004e510: 3901c3e9    	strb	w9, [sp, #0x70]
10004e514: 910103e2    	add	x2, sp, #0x40
10004e518: 17fffe5c    	b	0x10004de88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x64>
10004e51c: f940ca61    	ldr	x1, [x19, #0x190]
10004e520: 52800038    	mov	w24, #0x1               ; =1
10004e524: 910743e8    	add	x8, sp, #0x1d0
10004e528: 91020280    	add	x0, x20, #0x80
10004e52c: 52800037    	mov	w23, #0x1               ; =1
10004e530: 94005732    	bl	0x1000641f8 <<raster::index::growth::MemIndex>::prepare>
10004e534: f940ebe8    	ldr	x8, [sp, #0x1d0]
10004e538: 3cc78360    	ldur	q0, [x27, #0x78]
10004e53c: 3cc88361    	ldur	q1, [x27, #0x88]
10004e540: ad3b07a0    	stp	q0, q1, [x29, #-0xa0]
10004e544: 3cc98360    	ldur	q0, [x27, #0x98]
10004e548: 3c9803a0    	stur	q0, [x29, #-0x80]
10004e54c: f100091f    	cmp	x8, #0x2
10004e550: 540001e1    	b.ne	0x10004e58c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x768>
10004e554: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
10004e558: ad0407e0    	stp	q0, q1, [sp, #0x80]
10004e55c: 3cd803a0    	ldur	q0, [x29, #-0x80]
10004e560: 3d802be0    	str	q0, [sp, #0xa0]
10004e564: f9412be8    	ldr	x8, [sp, #0x250]
10004e568: d1000909    	sub	x9, x8, #0x2
10004e56c: f100051f    	cmp	x8, #0x1
10004e570: 9a9f8528    	csinc	x8, x9, xzr, hi
10004e574: b4001b68    	cbz	x8, 0x10004e8e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xabc>
10004e578: f100051f    	cmp	x8, #0x1
10004e57c: 54fff3a1    	b.ne	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e580: 910943e0    	add	x0, sp, #0x250
10004e584: 97fffc76    	bl	0x10004d75c <core::ptr::drop_glue::<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e588: 17ffff9a    	b	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e58c: 52800015    	mov	w21, #0x0               ; =0
10004e590: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e594: 3c8a8340    	stur	q0, [x26, #0xa8]
10004e598: f90163e8    	str	x8, [sp, #0x2c0]
10004e59c: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
10004e5a0: 3c878340    	stur	q0, [x26, #0x78]
10004e5a4: 3c888341    	stur	q1, [x26, #0x88]
10004e5a8: 3cd803a0    	ldur	q0, [x29, #-0x80]
10004e5ac: 3c898340    	stur	q0, [x26, #0x98]
10004e5b0: f94173e8    	ldr	x8, [sp, #0x2e0]
10004e5b4: f9401e69    	ldr	x9, [x19, #0x38]
10004e5b8: eb09011f    	cmp	x8, x9
10004e5bc: 540007c1    	b.ne	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e5c0: f94177e8    	ldr	x8, [sp, #0x2e8]
10004e5c4: f9402269    	ldr	x9, [x19, #0x40]
10004e5c8: eb09011f    	cmp	x8, x9
10004e5cc: 54000741    	b.ne	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e5d0: 794603e8    	ldrh	w8, [sp, #0x300]
10004e5d4: 7940b269    	ldrh	w9, [x19, #0x58]
10004e5d8: 6b09011f    	cmp	w8, w9
10004e5dc: 540006c1    	b.ne	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e5e0: f9416beb    	ldr	x11, [sp, #0x2d0]
10004e5e4: f9401668    	ldr	x8, [x19, #0x28]
10004e5e8: eb08017f    	cmp	x11, x8
10004e5ec: 54000621    	b.ne	0x10004e6b0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x88c>
10004e5f0: f9417be9    	ldr	x9, [sp, #0x2f0]
10004e5f4: f9417fe8    	ldr	x8, [sp, #0x2f8]
10004e5f8: 394c0bea    	ldrb	w10, [sp, #0x302]
10004e5fc: b40000cb    	cbz	x11, 0x10004e614 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x7f0>
10004e600: f9416fec    	ldr	x12, [sp, #0x2d8]
10004e604: f100057f    	cmp	x11, #0x1
10004e608: f9401a6b    	ldr	x11, [x19, #0x30]
10004e60c: eb0b019f    	cmp	x12, x11
10004e610: 54000501    	b.ne	0x10004e6b0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x88c>
10004e614: 52800015    	mov	w21, #0x0               ; =0
10004e618: 39416a6b    	ldrb	w11, [x19, #0x5a]
10004e61c: 6b0b015f    	cmp	w10, w11
10004e620: 540004a1    	b.ne	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e624: f940266a    	ldr	x10, [x19, #0x48]
10004e628: eb0a013f    	cmp	x9, x10
10004e62c: 54000441    	b.ne	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e630: f9402a69    	ldr	x9, [x19, #0x50]
10004e634: eb09011f    	cmp	x8, x9
10004e638: 1a9f17f5    	cset	w21, eq
10004e63c: 1400001e    	b	0x10004e6b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x890>
10004e640: 3cc78340    	ldur	q0, [x26, #0x78]
10004e644: 3cc88341    	ldur	q1, [x26, #0x88]
10004e648: ad0407e0    	stp	q0, q1, [sp, #0x80]
10004e64c: 3cc98340    	ldur	q0, [x26, #0x98]
10004e650: 3d802be0    	str	q0, [sp, #0xa0]
10004e654: 140000e8    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004e658: b4ffd236    	cbz	x22, 0x10004e09c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x278>
10004e65c: 9101a6c8    	add	x8, x22, #0x69
10004e660: 08dffd08    	ldarb	w8, [x8]
10004e664: 35ffd1c8    	cbnz	w8, 0x10004e09c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x278>
10004e668: f940ca61    	ldr	x1, [x19, #0x190]
10004e66c: 910743e8    	add	x8, sp, #0x1d0
10004e670: 91020280    	add	x0, x20, #0x80
10004e674: aa1703e2    	mov	x2, x23
10004e678: 94005477    	bl	0x100063854 <<raster::index::growth::MemIndex>::prepare_guarded>
10004e67c: f940ebe8    	ldr	x8, [sp, #0x1d0]
10004e680: 3cc78360    	ldur	q0, [x27, #0x78]
10004e684: 3cc88361    	ldur	q1, [x27, #0x88]
10004e688: ad0887e0    	stp	q0, q1, [sp, #0x110]
10004e68c: 3cc98360    	ldur	q0, [x27, #0x98]
10004e690: 3d804fe0    	str	q0, [sp, #0x130]
10004e694: f100091f    	cmp	x8, #0x2
10004e698: 54001381    	b.ne	0x10004e908 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xae4>
10004e69c: ad4887e0    	ldp	q0, q1, [sp, #0x110]
10004e6a0: ad0407e0    	stp	q0, q1, [sp, #0x80]
10004e6a4: 3dc04fe0    	ldr	q0, [sp, #0x130]
10004e6a8: 3d802be0    	str	q0, [sp, #0xa0]
10004e6ac: 140000d2    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004e6b0: 52800015    	mov	w21, #0x0               ; =0
10004e6b4: f9400388    	ldr	x8, [x28]
10004e6b8: f100091f    	cmp	x8, #0x2
10004e6bc: 54000060    	b.eq	0x10004e6c8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x8a4>
10004e6c0: 91018260    	add	x0, x19, #0x60
10004e6c4: 97fffcec    	bl	0x10004da74 <core::ptr::drop_glue::<raster::log::lookup::LogLookup>>
10004e6c8: 52800048    	mov	w8, #0x2                ; =2
10004e6cc: f9000388    	str	x8, [x28]
10004e6d0: 34ffe755    	cbz	w21, 0x10004e3b8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x594>
10004e6d4: b9400268    	ldr	w8, [x19]
10004e6d8: 360024c8    	tbz	w8, #0x0, 0x10004eb70 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xd4c>
10004e6dc: f9412be8    	ldr	x8, [sp, #0x250]
10004e6e0: d1000909    	sub	x9, x8, #0x2
10004e6e4: f100051f    	cmp	x8, #0x1
10004e6e8: 9a9f8528    	csinc	x8, x9, xzr, hi
10004e6ec: f100091f    	cmp	x8, #0x2
10004e6f0: 5400042c    	b.gt	0x10004e774 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x950>
10004e6f4: b4000608    	cbz	x8, 0x10004e7b4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x990>
10004e6f8: f100051f    	cmp	x8, #0x1
10004e6fc: 54000941    	b.ne	0x10004e824 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xa00>
10004e700: ad5487e0    	ldp	q0, q1, [sp, #0x290]
10004e704: ad1087e0    	stp	q0, q1, [sp, #0x210]
10004e708: 3dc0afe0    	ldr	q0, [sp, #0x2b0]
10004e70c: 3d808fe0    	str	q0, [sp, #0x230]
10004e710: ad5287e0    	ldp	q0, q1, [sp, #0x250]
10004e714: ad0e87e0    	stp	q0, q1, [sp, #0x1d0]
10004e718: ad5383e1    	ldp	q1, q0, [sp, #0x270]
10004e71c: ad0f83e1    	stp	q1, q0, [sp, #0x1f0]
10004e720: d10283a8    	sub	x8, x29, #0xa0
10004e724: 910743e0    	add	x0, sp, #0x1d0
10004e728: 91002261    	add	x1, x19, #0x8
10004e72c: 97ffb0e1    	bl	0x10003aab0 <<raster::log::value::TemporaryValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::read::<core::result::Result<(u64, u64), raster::types::error::Error>, <raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::advance::{closure#4}>>
10004e730: b85603a9    	ldur	w9, [x29, #-0xa0]
10004e734: a976dba8    	ldp	x8, x22, [x29, #-0x98]
10004e738: f85783b5    	ldur	x21, [x29, #-0x88]
10004e73c: 3cd803a0    	ldur	q0, [x29, #-0x80]
10004e740: 3c9403a0    	stur	q0, [x29, #-0xc0]
10004e744: f85903aa    	ldur	x10, [x29, #-0x70]
10004e748: f81503aa    	stur	x10, [x29, #-0xb0]
10004e74c: 37000ae9    	tbnz	w9, #0x0, 0x10004e8a8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xa84>
10004e750: b100051f    	cmn	x8, #0x1
10004e754: 54000aa1    	b.ne	0x10004e8a8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xa84>
10004e758: 52800038    	mov	w24, #0x1               ; =1
10004e75c: 52800017    	mov	w23, #0x0               ; =0
10004e760: 910743e0    	add	x0, sp, #0x1d0
10004e764: 97fffbfe    	bl	0x10004d75c <core::ptr::drop_glue::<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e768: 52800017    	mov	w23, #0x0               ; =0
10004e76c: 52800038    	mov	w24, #0x1               ; =1
10004e770: 14000009    	b	0x10004e794 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x970>
10004e774: d1000d08    	sub	x8, x8, #0x3
10004e778: f100091f    	cmp	x8, #0x2
10004e77c: 540020a2    	b.hs	0x10004eb90 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xd6c>
10004e780: 39476268    	ldrb	w8, [x19, #0x1d8]
10004e784: 52800038    	mov	w24, #0x1               ; =1
10004e788: 36000668    	tbz	w8, #0x0, 0x10004e854 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xa30>
10004e78c: 52800036    	mov	w22, #0x1               ; =1
10004e790: 52800035    	mov	w21, #0x1               ; =1
10004e794: 910203e0    	add	x0, sp, #0x80
10004e798: 910b03e5    	add	x5, sp, #0x2c0
10004e79c: aa1303e1    	mov	x1, x19
10004e7a0: aa1403e2    	mov	x2, x20
10004e7a4: aa1603e3    	mov	x3, x22
10004e7a8: aa1503e4    	mov	x4, x21
10004e7ac: 940001cb    	bl	0x10004eed8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::append_record>
10004e7b0: 17ffff10    	b	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e7b4: f9412fe9    	ldr	x9, [sp, #0x258]
10004e7b8: f81403a9    	stur	x9, [x29, #-0xc0]
10004e7bc: 39476668    	ldrb	w8, [x19, #0x1d9]
10004e7c0: 360004e8    	tbz	w8, #0x0, 0x10004e85c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xa38>
10004e7c4: 910743e8    	add	x8, sp, #0x1d0
10004e7c8: 91004120    	add	x0, x9, #0x10
10004e7cc: 91002261    	add	x1, x19, #0x8
10004e7d0: 97ffb4a1    	bl	0x10003ba54 <<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::try_read::<core::result::Result<(u64, u64), raster::types::error::Error>, <raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::advance::{closure#3}>>
10004e7d4: a95d23e9    	ldp	x9, x8, [sp, #0x1d0]
10004e7d8: a95e57f6    	ldp	x22, x21, [sp, #0x1e0]
10004e7dc: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
10004e7e0: 3c9603a0    	stur	q0, [x29, #-0xa0]
10004e7e4: f94103ea    	ldr	x10, [sp, #0x200]
10004e7e8: f81703aa    	stur	x10, [x29, #-0x90]
10004e7ec: f100053f    	cmp	x9, #0x1
10004e7f0: 540000a0    	b.eq	0x10004e804 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x9e0>
10004e7f4: b100051f    	cmn	x8, #0x1
10004e7f8: 54000d80    	b.eq	0x10004e9a8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xb84>
10004e7fc: b100091f    	cmn	x8, #0x2
10004e800: 54000ce0    	b.eq	0x10004e99c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xb78>
10004e804: 3cd603a0    	ldur	q0, [x29, #-0xa0]
10004e808: 910203e9    	add	x9, sp, #0x80
10004e80c: 3c818120    	stur	q0, [x9, #0x18]
10004e810: f85703a9    	ldur	x9, [x29, #-0x90]
10004e814: a9085be8    	stp	x8, x22, [sp, #0x80]
10004e818: f90057e9    	str	x9, [sp, #0xa8]
10004e81c: f9004bf5    	str	x21, [sp, #0x90]
10004e820: 14000086    	b	0x10004ea38 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc14>
10004e824: 528000e8    	mov	w8, #0x7                ; =7
10004e828: f0000469    	adrp	x9, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004e82c: 91218929    	add	x9, x9, #0x862
10004e830: a90827e8    	stp	x8, x9, [sp, #0x80]
10004e834: 52800448    	mov	w8, #0x22               ; =34
10004e838: f9004be8    	str	x8, [sp, #0x90]
10004e83c: f9412be8    	ldr	x8, [sp, #0x250]
10004e840: d1000909    	sub	x9, x8, #0x2
10004e844: f100051f    	cmp	x8, #0x1
10004e848: 9a9f8528    	csinc	x8, x9, xzr, hi
10004e84c: b5ffe968    	cbnz	x8, 0x10004e578 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x754>
10004e850: 14000024    	b	0x10004e8e0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xabc>
10004e854: 390223f8    	strb	w24, [sp, #0x88]
10004e858: 17fffeda    	b	0x10004e3c0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x59c>
10004e85c: 52800048    	mov	w8, #0x2                ; =2
10004e860: 39076a68    	strb	w8, [x19, #0x1da]
10004e864: f940da61    	ldr	x1, [x19, #0x1b0]
10004e868: 910743e8    	add	x8, sp, #0x1d0
10004e86c: 91004120    	add	x0, x9, #0x10
10004e870: 91002262    	add	x2, x19, #0x8
10004e874: 97ffb319    	bl	0x10003b4d8 <<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::update_at_version::<raster::api::operation::UpdateDecision<u64>, <raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::advance::{closure#2}>>
10004e878: a95d27ea    	ldp	x10, x9, [sp, #0x1d0]
10004e87c: f940f3e8    	ldr	x8, [sp, #0x1e0]
10004e880: b100055f    	cmn	x10, #0x1
10004e884: 54000840    	b.eq	0x10004e98c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xb68>
10004e888: 3cc88360    	ldur	q0, [x27, #0x88]
10004e88c: 910203eb    	add	x11, sp, #0x80
10004e890: 3c818160    	stur	q0, [x11, #0x18]
10004e894: f940ffeb    	ldr	x11, [sp, #0x1f8]
10004e898: a90827ea    	stp	x10, x9, [sp, #0x80]
10004e89c: f90057eb    	str	x11, [sp, #0xa8]
10004e8a0: f9004be8    	str	x8, [sp, #0x90]
10004e8a4: 14000065    	b	0x10004ea38 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc14>
10004e8a8: 3cd403a0    	ldur	q0, [x29, #-0xc0]
10004e8ac: 910203e9    	add	x9, sp, #0x80
10004e8b0: 3c818120    	stur	q0, [x9, #0x18]
10004e8b4: f85503a9    	ldur	x9, [x29, #-0xb0]
10004e8b8: a9085be8    	stp	x8, x22, [sp, #0x80]
10004e8bc: f90057e9    	str	x9, [sp, #0xa8]
10004e8c0: f9004bf5    	str	x21, [sp, #0x90]
10004e8c4: 52800038    	mov	w24, #0x1               ; =1
10004e8c8: 52800017    	mov	w23, #0x0               ; =0
10004e8cc: 910743e0    	add	x0, sp, #0x1d0
10004e8d0: 97fffba3    	bl	0x10004d75c <core::ptr::drop_glue::<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004e8d4: f9412be8    	ldr	x8, [sp, #0x250]
10004e8d8: f100091f    	cmp	x8, #0x2
10004e8dc: 54ffd8a1    	b.ne	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e8e0: f9412fe8    	ldr	x8, [sp, #0x258]
10004e8e4: 92800009    	mov	x9, #-0x1               ; =-1
10004e8e8: f8690108    	ldaddl	x9, x8, [x8]
10004e8ec: f100051f    	cmp	x8, #0x1
10004e8f0: 54ffd801    	b.ne	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e8f4: d50339bf    	dmb	ishld
10004e8f8: 910943e8    	add	x8, sp, #0x250
10004e8fc: 91002100    	add	x0, x8, #0x8
10004e900: 97ffadf6    	bl	0x10003a0d8 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004e904: 17fffebb    	b	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e908: 3cca8360    	ldur	q0, [x27, #0xa8]
10004e90c: 3c8a8340    	stur	q0, [x26, #0xa8]
10004e910: ad4887e0    	ldp	q0, q1, [sp, #0x110]
10004e914: 3c878340    	stur	q0, [x26, #0x78]
10004e918: 3c888341    	stur	q1, [x26, #0x88]
10004e91c: 3dc04fe0    	ldr	q0, [sp, #0x130]
10004e920: 3c898340    	stur	q0, [x26, #0x98]
10004e924: f90163e8    	str	x8, [sp, #0x2c0]
10004e928: 910b03e0    	add	x0, sp, #0x2c0
10004e92c: 910943e1    	add	x1, sp, #0x250
10004e930: 940003a4    	bl	0x10004f7c0 <<raster::index::EntrySnapshot as core::cmp::PartialEq>::eq>
10004e934: 34000580    	cbz	w0, 0x10004e9e4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbc0>
10004e938: 52800048    	mov	w8, #0x2                ; =2
10004e93c: 39076a68    	strb	w8, [x19, #0x1da]
10004e940: b9400268    	ldr	w8, [x19]
10004e944: 36001368    	tbz	w8, #0x0, 0x10004ebb0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xd8c>
10004e948: f940da61    	ldr	x1, [x19, #0x1b0]
10004e94c: 910743e8    	add	x8, sp, #0x1d0
10004e950: 91002262    	add	x2, x19, #0x8
10004e954: aa1603e0    	mov	x0, x22
10004e958: 97ffb2e0    	bl	0x10003b4d8 <<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::update_at_version::<raster::api::operation::UpdateDecision<u64>, <raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::advance::{closure#2}>>
10004e95c: a95d27ea    	ldp	x10, x9, [sp, #0x1d0]
10004e960: f940f3e8    	ldr	x8, [sp, #0x1e0]
10004e964: b100055f    	cmn	x10, #0x1
10004e968: 54000360    	b.eq	0x10004e9d4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbb0>
10004e96c: 3cc88360    	ldur	q0, [x27, #0x88]
10004e970: 910203eb    	add	x11, sp, #0x80
10004e974: 3c818160    	stur	q0, [x11, #0x18]
10004e978: f940ffeb    	ldr	x11, [sp, #0x1f8]
10004e97c: a90827ea    	stp	x10, x9, [sp, #0x80]
10004e980: f90057eb    	str	x11, [sp, #0xa8]
10004e984: f9004be8    	str	x8, [sp, #0x90]
10004e988: 1400001b    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004e98c: b40004a9    	cbz	x9, 0x10004ea20 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbfc>
10004e990: b100053f    	cmn	x9, #0x1
10004e994: 540006c1    	b.ne	0x10004ea6c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc48>
10004e998: 39076a7f    	strb	wzr, [x19, #0x1da]
10004e99c: 52801fe8    	mov	w8, #0xff               ; =255
10004e9a0: 390223e8    	strb	w8, [sp, #0x88]
10004e9a4: 14000023    	b	0x10004ea30 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc0c>
10004e9a8: f85403a8    	ldur	x8, [x29, #-0xc0]
10004e9ac: 92800009    	mov	x9, #-0x1               ; =-1
10004e9b0: f8690108    	ldaddl	x9, x8, [x8]
10004e9b4: f100051f    	cmp	x8, #0x1
10004e9b8: 540000a1    	b.ne	0x10004e9cc <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xba8>
10004e9bc: d50339bf    	dmb	ishld
10004e9c0: 52800018    	mov	w24, #0x0               ; =0
10004e9c4: d10303a0    	sub	x0, x29, #0xc0
10004e9c8: 97ffadc4    	bl	0x10003a0d8 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004e9cc: 52800018    	mov	w24, #0x0               ; =0
10004e9d0: 17ffff71    	b	0x10004e794 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x970>
10004e9d4: b4000649    	cbz	x9, 0x10004ea9c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc78>
10004e9d8: b100053f    	cmn	x9, #0x1
10004e9dc: 540006a1    	b.ne	0x10004eab0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc8c>
10004e9e0: 39076a7f    	strb	wzr, [x19, #0x1da]
10004e9e4: 52801fe8    	mov	w8, #0xff               ; =255
10004e9e8: 390223e8    	strb	w8, [sp, #0x88]
10004e9ec: 92800008    	mov	x8, #-0x1               ; =-1
10004e9f0: f90043e8    	str	x8, [sp, #0x80]
10004e9f4: f94157e8    	ldr	x8, [sp, #0x2a8]
10004e9f8: b4ffcfc8    	cbz	x8, 0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004e9fc: 92800009    	mov	x9, #-0x1               ; =-1
10004ea00: f8690108    	ldaddl	x9, x8, [x8]
10004ea04: f100051f    	cmp	x8, #0x1
10004ea08: 54ffcf41    	b.ne	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004ea0c: 910943e8    	add	x8, sp, #0x250
10004ea10: d50339bf    	dmb	ishld
10004ea14: 91016100    	add	x0, x8, #0x58
10004ea18: 9400b2b9    	bl	0x10007b4fc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004ea1c: 17fffe75    	b	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004ea20: 52800029    	mov	w9, #0x1                ; =1
10004ea24: 39076a69    	strb	w9, [x19, #0x1da]
10004ea28: 390223ff    	strb	wzr, [sp, #0x88]
10004ea2c: f9004be8    	str	x8, [sp, #0x90]
10004ea30: 92800008    	mov	x8, #-0x1               ; =-1
10004ea34: f90043e8    	str	x8, [sp, #0x80]
10004ea38: f85403a8    	ldur	x8, [x29, #-0xc0]
10004ea3c: 92800009    	mov	x9, #-0x1               ; =-1
10004ea40: f8690108    	ldaddl	x9, x8, [x8]
10004ea44: f100051f    	cmp	x8, #0x1
10004ea48: 540000a1    	b.ne	0x10004ea5c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xc38>
10004ea4c: d50339bf    	dmb	ishld
10004ea50: 52800018    	mov	w24, #0x0               ; =0
10004ea54: d10303a0    	sub	x0, x29, #0xc0
10004ea58: 97ffada0    	bl	0x10003a0d8 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004ea5c: f9412be8    	ldr	x8, [sp, #0x250]
10004ea60: f100091f    	cmp	x8, #0x2
10004ea64: 54ffcc62    	b.hs	0x10004e3f0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x5cc>
10004ea68: 17fffec6    	b	0x10004e580 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x75c>
10004ea6c: 91076668    	add	x8, x19, #0x1d9
10004ea70: 52800029    	mov	w9, #0x1                ; =1
10004ea74: 79000109    	strh	w9, [x8]
10004ea78: f85403a9    	ldur	x9, [x29, #-0xc0]
10004ea7c: 17ffff52    	b	0x10004e7c4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x9a0>
10004ea80: f0000460    	adrp	x0, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004ea84: 9120bc00    	add	x0, x0, #0x82f
10004ea88: f0000602    	adrp	x2, 0x100111000 <_anon.728a1a1afb8dece440878b786d86119a.24+0x8>
10004ea8c: 912de042    	add	x2, x2, #0xb78
10004ea90: 528001a1    	mov	w1, #0xd                ; =13
10004ea94: 9401fec5    	bl	0x1000ce5a8 <core::option::expect_failed>
10004ea98: 1400004c    	b	0x10004ebc8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xda4>
10004ea9c: 52800029    	mov	w9, #0x1                ; =1
10004eaa0: 39076a69    	strb	w9, [x19, #0x1da]
10004eaa4: 390223ff    	strb	wzr, [sp, #0x88]
10004eaa8: f9004be8    	str	x8, [sp, #0x90]
10004eaac: 17ffffd0    	b	0x10004e9ec <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbc8>
10004eab0: 91076668    	add	x8, x19, #0x1d9
10004eab4: 52800029    	mov	w9, #0x1                ; =1
10004eab8: 79000109    	strh	w9, [x8]
10004eabc: 910743e8    	add	x8, sp, #0x1d0
10004eac0: 91002261    	add	x1, x19, #0x8
10004eac4: aa1603e0    	mov	x0, x22
10004eac8: 97ffb182    	bl	0x10003b0d0 <<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>::try_read_live::<core::result::Result<(u64, u64), raster::types::error::Error>, <raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::advance::{closure#1}>>
10004eacc: a95d23e9    	ldp	x9, x8, [sp, #0x1d0]
10004ead0: a95e13e3    	ldp	x3, x4, [sp, #0x1e0]
10004ead4: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
10004ead8: 3d80b3e0    	str	q0, [sp, #0x2c0]
10004eadc: f94103ea    	ldr	x10, [sp, #0x200]
10004eae0: f9016bea    	str	x10, [sp, #0x2d0]
10004eae4: f100053f    	cmp	x9, #0x1
10004eae8: 540001e1    	b.ne	0x10004eb24 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xd00>
10004eaec: 3dc0b3e0    	ldr	q0, [sp, #0x2c0]
10004eaf0: 910203e9    	add	x9, sp, #0x80
10004eaf4: 3c818120    	stur	q0, [x9, #0x18]
10004eaf8: f9416be9    	ldr	x9, [sp, #0x2d0]
10004eafc: a9080fe8    	stp	x8, x3, [sp, #0x80]
10004eb00: f90057e9    	str	x9, [sp, #0xa8]
10004eb04: f9004be4    	str	x4, [sp, #0x90]
10004eb08: 17ffffbb    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004eb0c: f0000460    	adrp	x0, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004eb10: 911fc000    	add	x0, x0, #0x7f0
10004eb14: f0000602    	adrp	x2, 0x100111000 <_anon.728a1a1afb8dece440878b786d86119a.24+0x8>
10004eb18: 912d2042    	add	x2, x2, #0xb48
10004eb1c: 528002c1    	mov	w1, #0x16               ; =22
10004eb20: 9401fea2    	bl	0x1000ce5a8 <core::option::expect_failed>
10004eb24: b100051f    	cmn	x8, #0x1
10004eb28: 540000c0    	b.eq	0x10004eb40 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xd1c>
10004eb2c: b100091f    	cmn	x8, #0x2
10004eb30: 54fff5a0    	b.eq	0x10004e9e4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbc0>
10004eb34: b1000d1f    	cmn	x8, #0x3
10004eb38: 54fff560    	b.eq	0x10004e9e4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbc0>
10004eb3c: 17ffffec    	b	0x10004eaec <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xcc8>
10004eb40: ad5387e0    	ldp	q0, q1, [sp, #0x270]
10004eb44: ad0f87e0    	stp	q0, q1, [sp, #0x1f0]
10004eb48: f9414be8    	ldr	x8, [sp, #0x290]
10004eb4c: f9010be8    	str	x8, [sp, #0x210]
10004eb50: ad5283e1    	ldp	q1, q0, [sp, #0x250]
10004eb54: ad0e83e1    	stp	q1, q0, [sp, #0x1d0]
10004eb58: 910203e0    	add	x0, sp, #0x80
10004eb5c: 910743e5    	add	x5, sp, #0x1d0
10004eb60: aa1303e1    	mov	x1, x19
10004eb64: aa1403e2    	mov	x2, x20
10004eb68: 940000dc    	bl	0x10004eed8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::append_record>
10004eb6c: 17ffffa2    	b	0x10004e9f4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xbd0>
10004eb70: 52800038    	mov	w24, #0x1               ; =1
10004eb74: f0000460    	adrp	x0, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004eb78: 9120f000    	add	x0, x0, #0x83c
10004eb7c: f0000602    	adrp	x2, 0x100111000 <_anon.728a1a1afb8dece440878b786d86119a.24+0x8>
10004eb80: 912e4042    	add	x2, x2, #0xb90
10004eb84: 528004c1    	mov	w1, #0x26               ; =38
10004eb88: 9401fe88    	bl	0x1000ce5a8 <core::option::expect_failed>
10004eb8c: 1400000f    	b	0x10004ebc8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xda4>
10004eb90: 52800038    	mov	w24, #0x1               ; =1
10004eb94: f0000460    	adrp	x0, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004eb98: 91221000    	add	x0, x0, #0x884
10004eb9c: f0000602    	adrp	x2, 0x100111000 <_anon.728a1a1afb8dece440878b786d86119a.24+0x8>
10004eba0: 912ea042    	add	x2, x2, #0xba8
10004eba4: 52800ee1    	mov	w1, #0x77               ; =119
10004eba8: 9401ff0f    	bl	0x1000ce7e4 <core::panicking::panic_fmt>
10004ebac: 14000007    	b	0x10004ebc8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xda4>
10004ebb0: f0000460    	adrp	x0, 0x1000dd000 <_anon.728a1a1afb8dece440878b786d86119a.31+0x108>
10004ebb4: 91206800    	add	x0, x0, #0x81a
10004ebb8: f0000602    	adrp	x2, 0x100111000 <_anon.728a1a1afb8dece440878b786d86119a.24+0x8>
10004ebbc: 912d8042    	add	x2, x2, #0xb60
10004ebc0: 528002a1    	mov	w1, #0x15               ; =21
10004ebc4: 9401fe79    	bl	0x1000ce5a8 <core::option::expect_failed>
10004ebc8: d4200020    	brk	#0x1
10004ebcc: aa0003f5    	mov	x21, x0
10004ebd0: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
10004ebd4: 3c808340    	stur	q0, [x26, #0x8]
10004ebd8: 3c818341    	stur	q1, [x26, #0x18]
10004ebdc: 3dc043e0    	ldr	q0, [sp, #0x100]
10004ebe0: 3c828340    	stur	q0, [x26, #0x28]
10004ebe4: ad4587e0    	ldp	q0, q1, [sp, #0xb0]
10004ebe8: 3c838340    	stur	q0, [x26, #0x38]
10004ebec: 3c848341    	stur	q1, [x26, #0x48]
10004ebf0: f9406be8    	ldr	x8, [sp, #0xd0]
10004ebf4: f9012bf6    	str	x22, [sp, #0x250]
10004ebf8: f90157e8    	str	x8, [sp, #0x2a8]
10004ebfc: 1400003f    	b	0x10004ecf8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xed4>
10004ec00: aa0003f5    	mov	x21, x0
10004ec04: 910743e0    	add	x0, sp, #0x1d0
10004ec08: 97fffad5    	bl	0x10004d75c <core::ptr::drop_glue::<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004ec0c: 52800017    	mov	w23, #0x0               ; =0
10004ec10: 52800038    	mov	w24, #0x1               ; =1
10004ec14: 14000045    	b	0x10004ed28 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf04>
10004ec18: aa0003f5    	mov	x21, x0
10004ec1c: f85403a8    	ldur	x8, [x29, #-0xc0]
10004ec20: 92800009    	mov	x9, #-0x1               ; =-1
10004ec24: f8690108    	ldaddl	x9, x8, [x8]
10004ec28: f100051f    	cmp	x8, #0x1
10004ec2c: 54000081    	b.ne	0x10004ec3c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xe18>
10004ec30: d50339bf    	dmb	ishld
10004ec34: d10303a0    	sub	x0, x29, #0xc0
10004ec38: 97ffad28    	bl	0x10003a0d8 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004ec3c: 52800018    	mov	w24, #0x0               ; =0
10004ec40: 52800037    	mov	w23, #0x1               ; =1
10004ec44: 14000039    	b	0x10004ed28 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf04>
10004ec48: aa0003f5    	mov	x21, x0
10004ec4c: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10004ec50: ad010780    	stp	q0, q1, [x28, #0x20]
10004ec54: ad4883e1    	ldp	q1, q0, [sp, #0x110]
10004ec58: ad000381    	stp	q1, q0, [x28]
10004ec5c: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
10004ec60: 3c868260    	stur	q0, [x19, #0x68]
10004ec64: 3c878261    	stur	q1, [x19, #0x78]
10004ec68: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10004ec6c: 3c888260    	stur	q0, [x19, #0x88]
10004ec70: 3cc2a360    	ldur	q0, [x27, #0x2a]
10004ec74: 3c8c2260    	stur	q0, [x19, #0xc2]
10004ec78: ad4b87e0    	ldp	q0, q1, [sp, #0x170]
10004ec7c: 3c8b8261    	stur	q1, [x19, #0xb8]
10004ec80: 3dc05be1    	ldr	q1, [sp, #0x160]
10004ec84: 3c8a8260    	stur	q0, [x19, #0xa8]
10004ec88: f940abe8    	ldr	x8, [sp, #0x150]
10004ec8c: f9002388    	str	x8, [x28, #0x40]
10004ec90: f9003276    	str	x22, [x19, #0x60]
10004ec94: 3c898261    	stur	q1, [x19, #0x98]
10004ec98: 39034a77    	strb	w23, [x19, #0xd2]
10004ec9c: 39034e78    	strb	w24, [x19, #0xd3]
10004eca0: b9400fe8    	ldr	w8, [sp, #0xc]
10004eca4: b900d668    	str	w8, [x19, #0xd4]
10004eca8: 14000014    	b	0x10004ecf8 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xed4>
10004ecac: aa0003f5    	mov	x21, x0
10004ecb0: 52800048    	mov	w8, #0x2                ; =2
10004ecb4: f9000388    	str	x8, [x28]
10004ecb8: 52800038    	mov	w24, #0x1               ; =1
10004ecbc: 52800037    	mov	w23, #0x1               ; =1
10004ecc0: 1400001a    	b	0x10004ed28 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf04>
10004ecc4: 1400000c    	b	0x10004ecf4 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xed0>
10004ecc8: aa0003f3    	mov	x19, x0
10004eccc: f94006c1    	ldr	x1, [x22, #0x8]
10004ecd0: b4000081    	cbz	x1, 0x10004ece0 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xebc>
10004ecd4: f9400ac2    	ldr	x2, [x22, #0x10]
10004ecd8: aa1503e0    	mov	x0, x21
10004ecdc: 94000413    	bl	0x10004fd28 <__rustc::__rust_dealloc>
10004ece0: 910043e0    	add	x0, sp, #0x10
10004ece4: 97fffbba    	bl	0x10004dbcc <core::ptr::drop_glue::<raster::types::error::Error>>
10004ece8: aa1303e0    	mov	x0, x19
10004ecec: 9401ff3d    	bl	0x1000ce9e0 <dyld_stub_binder+0x1000ce9e0>
10004ecf0: 9401fe5b    	bl	0x1000ce65c <core::panicking::panic_in_cleanup>
10004ecf4: aa0003f5    	mov	x21, x0
10004ecf8: f94157e8    	ldr	x8, [sp, #0x2a8]
10004ecfc: b4000468    	cbz	x8, 0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed00: 92800009    	mov	x9, #-0x1               ; =-1
10004ed04: f8690108    	ldaddl	x9, x8, [x8]
10004ed08: f100051f    	cmp	x8, #0x1
10004ed0c: 540003e1    	b.ne	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed10: 910943e8    	add	x8, sp, #0x250
10004ed14: d50339bf    	dmb	ishld
10004ed18: 91016100    	add	x0, x8, #0x58
10004ed1c: 9400b1f8    	bl	0x10007b4fc <<alloc::sync::Arc<raster::cache::CachedRecord>>::drop_slow>
10004ed20: 1400001a    	b	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed24: aa0003f5    	mov	x21, x0
10004ed28: f9412be8    	ldr	x8, [sp, #0x250]
10004ed2c: d1000909    	sub	x9, x8, #0x2
10004ed30: f100051f    	cmp	x8, #0x1
10004ed34: 9a9f8528    	csinc	x8, x9, xzr, hi
10004ed38: b40000e8    	cbz	x8, 0x10004ed54 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf30>
10004ed3c: f100051f    	cmp	x8, #0x1
10004ed40: 54000241    	b.ne	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed44: 36000237    	tbz	w23, #0x0, 0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed48: 910943e0    	add	x0, sp, #0x250
10004ed4c: 97fffa84    	bl	0x10004d75c <core::ptr::drop_glue::<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>
10004ed50: 1400000e    	b	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed54: 360001b8    	tbz	w24, #0x0, 0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed58: f9412fe8    	ldr	x8, [sp, #0x258]
10004ed5c: 92800009    	mov	x9, #-0x1               ; =-1
10004ed60: f8690108    	ldaddl	x9, x8, [x8]
10004ed64: f100051f    	cmp	x8, #0x1
10004ed68: 54000101    	b.ne	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed6c: d50339bf    	dmb	ishld
10004ed70: 910943e8    	add	x8, sp, #0x250
10004ed74: 91002100    	add	x0, x8, #0x8
10004ed78: 97ffacd8    	bl	0x10003a0d8 <<alloc::sync::Arc<raster::log::value::PageValue<raster::schema::SharedValue<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>>>>>::drop_slow>
10004ed7c: 14000003    	b	0x10004ed88 <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0xf64>
10004ed80: 9401fe37    	bl	0x1000ce65c <core::panicking::panic_in_cleanup>
10004ed84: aa0003f5    	mov	x21, x0
10004ed88: aa1503e0    	mov	x0, x21
10004ed8c: 9401fd07    	bl	0x1000ce1a8 <std::panicking::catch_unwind::cleanup>
10004ed90: aa0003f5    	mov	x21, x0
10004ed94: aa0103f6    	mov	x22, x1
10004ed98: 17fffda9    	b	0x10004e43c <<raster::engine::rmw::RmwTask<raster::schema::builtin::SchemaPair<raster::schema::builtin::U64Key, raster::schema::builtin::AtomicU64Value>, parity::Request>>::run_locked+0x618>
10004ed9c: 9401fe7f    	bl	0x1000ce798 <core::panicking::panic_cannot_unwind>

