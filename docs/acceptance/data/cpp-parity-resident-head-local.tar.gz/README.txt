Matching resident read head experiment, runtime based on 8b84661.
All 494 tests pass. Full memory gate 15/18, scans 2/2, lifecycle recheck 2/3 under strict 0.98 throughput and 1.10 P99 thresholds.
The first lifecycle attempt stopped when local storage was exhausted. Its completed negative case and partial files are preserved. Only regenerable incremental compiler caches were removed; frozen binaries and evidence were retained.
The original collision fixture did not select the same index bucket and failed to detect a deliberately removed key check. The strengthened same-bucket fixture detects it. Both observations are preserved.
Trace bytes are deduplicated by SHA-256; trace-references.json maps each original relative name to inputs/<digest>.trace. Runtime binaries are excluded; their SHA-256 values and exact modified source are included.
No C++ parity claim: the candidate awaits native verification, and the full performance goal remains incomplete.
