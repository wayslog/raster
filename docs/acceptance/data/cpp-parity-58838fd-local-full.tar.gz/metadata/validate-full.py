"""Recompute full local gates and check integer/scan outputs independently."""
from pathlib import Path
import json,statistics,sys
sys.path.insert(0,"tools/performance")
from cpu_profile import validate_output
root=Path("target/parity-profile/result-budget-first-slot")
summary={};integer_outputs=0;scan_outputs=0
for name,expected_cases in [("matrix",18),("aa-upsert",1),("aa-read",1)]:
 directory=root/("full-"+name);env=json.loads((directory/"environment.json").read_text())
 rows=json.loads((directory/"comparison.json").read_text());assert len(rows)==expected_cases
 assert len({r["case"] for r in rows})==expected_cases
 for row in rows:
  case=row["case"];prefix=case.replace("/","-")
  for label in ["baseline","rust"]:
   for index in range(-1,env["rounds"]):
    data=validate_output((directory/f"{prefix}-{index}-{label}.stdout").read_text(),"rust",case,env["count"])
    assert not (directory/f"{prefix}-{index}-{label}.stderr").read_text()
    if index>=0:assert data==row["rows"][label][index]
    integer_outputs+=1
  med=lambda label,key:statistics.median(r[key] for r in row["rows"][label])
  throughput=med("baseline","elapsed_ns")/med("rust","elapsed_ns")
  p99=med("rust","p99_ns")/med("baseline","p99_ns")
  assert row["throughput_ratio"]==throughput and row["p99_ratio"]==p99
  assert row["passed"]==(throughput>=.98 and p99<=1.10)
 summary[name]=[{k:v for k,v in row.items() if k!="rows"} for row in rows]
directory=root/"full-scans";env=json.loads((directory/"environment.json").read_text())
rows=json.loads((directory/"comparison.json").read_text());assert {r["records"] for r in rows}=={4096,65536}
for row in rows:
 n=row["records"];scans=row["scans"];assert scans==8
 checksum=(sum(key^0x7261737465720001 for key in range(n))*scans)%(1<<64)
 for name in ["baseline","candidate"]:
  for i in range(-1,env["rounds"]):
   raw=json.loads((directory/f"{n}-{i}-{name}.stdout").read_text())
   assert raw["records"]==n and raw["scans"]==scans and raw["checksum"]==checksum and raw["samples"]==n*scans//64
   assert all(raw[k]>0 for k in ["append_ns","scan_ns","p99_ns"])
   assert not (directory/f"{n}-{i}-{name}.stderr").read_text()
   if i>=0:assert raw==row["rows"][name][i]
   scan_outputs+=1
 med=lambda name,key:statistics.median(r[key] for r in row["rows"][name])
 a=med("baseline","append_ns")/med("candidate","append_ns");s=med("baseline","scan_ns")/med("candidate","scan_ns");p=med("candidate","p99_ns")/med("baseline","p99_ns")
 assert [row[k] for k in ["append_throughput_ratio","scan_throughput_ratio","p99_ratio"]]==[a,s,p]
 assert row["passed"]==(a>=.98 and s>=.98 and p<=1.1)
summary["scans"]=[{k:v for k,v in row.items() if k!="rows"} for row in rows]
summary["variable"]=json.loads((root/"full-variable/comparison.json").read_text())["comparisons"]
rows=json.loads((root/"full-lifecycles/comparison.json").read_text());assert {r["case"] for r in rows}=={"u64-hot-t4-disk-r1","bytes-uniform-t1-disk-r1","bytes-hot-t1-memory-r1"}
summary["lifecycles"]=[{k:r[k] for k in ["case","throughput_ratio","p99_ratio","control_throughput_ratio","control_p99_ratio"]}|{"candidate_passed":r["throughput_ratio"]>=.98 and r["p99_ratio"]<=1.1,"reciprocal_control_valid":.98<=r["control_throughput_ratio"]<=1/.98 and 1/1.1<=r["control_p99_ratio"]<=1.1} for r in rows]
summary.update(integer_outputs_verified=integer_outputs,scan_outputs_verified=scan_outputs,scope="Local Rust regression evidence only; full C++ acceptance remains incomplete.")
(root/"full-analysis.json").write_text(json.dumps(summary,indent=2)+"\n")
print("Verified",integer_outputs,"integer outputs and",scan_outputs,"scan outputs; matrix",sum(r["passed"] for r in summary["matrix"]),"/18, scans",sum(r["passed"] for r in summary["scans"]),"/2; lifecycle candidates",sum(r["candidate_passed"] for r in summary["lifecycles"]),"/3, reciprocal controls",sum(r["reciprocal_control_valid"] for r in summary["lifecycles"]),"/3.")
