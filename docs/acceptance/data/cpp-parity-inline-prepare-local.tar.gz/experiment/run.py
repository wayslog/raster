"""Isolated all-feature preparation experiment with an identical control."""
from pathlib import Path
import json, subprocess
root=Path('target/parity-profile/inline-prepare')
baseline='target/parity-profile/guarded-upsert-routing/candidate-bins/parity'
candidate=str(root/'candidate-bins/parity')
runs=[]
for case in ['read/uniform/1','upsert/uniform/1','upsert/shared-hot/1','rmw/shared-hot/1','control']:
    control=case=='control'
    selected='upsert/shared-hot/1' if control else case
    out=root/('control-upsert-shared-hot-1' if control else case.replace('/','-'))
    command=['python3','tools/performance/compare.py','--rust',baseline if control else candidate,'--baseline-rust',baseline,'--output',str(out),'--min-throughput','0.98','--max-p99','1.10','--case',selected]
    p=subprocess.run(command,capture_output=True,text=True)
    (root/(out.name+'.log')).write_text(p.stdout+p.stderr)
    runs.append({'case':case,'command':command,'exit_code':p.returncode})
    (root/'benchmark-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    if (out/'comparison.json').exists():
        rows=json.loads((out/'comparison.json').read_text())
        for row in rows: print(case,{k:row[k] for k in ['throughput_ratio','p99_ratio','passed']},flush=True)
    else:
        raise RuntimeError(p.stderr)
