//! Immutable disk record cache;Index condition release,Geocoding and elimination of shared control locks.
mod arena;
use crate::{
    config::CacheConfig,
    format::Record,
    index::{EntrySnapshot, IndexHead, MemIndex, PublishResult},
    types::*,
};
use std::{
    collections::BTreeMap,
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, AtomicUsize, Ordering},
    },
};

enum Bytes {
    Owned(Vec<u8>),
    Reserved(arena::Lease),
}
impl Bytes {
    fn as_slice(&self) -> &[u8] {
        match self {
            Self::Owned(bytes) => bytes,
            Self::Reserved(lease) => lease.bytes(),
        }
    }
}
impl Default for Bytes {
    fn default() -> Self {
        Self::Owned(Vec::new())
    }
}
pub(crate) struct CachedRecord {
    pub source: LogAddress,
    pub version: CheckpointVersion,
    head: LogAddress,
    hash: KeyHash,
    bytes: Bytes,
    position: AtomicU64,
    charge: usize,
    allocated: Arc<AtomicUsize>,
}
impl CachedRecord {
    pub fn encoded(&self) -> &[u8] {
        self.bytes.as_slice()
    }
}
impl Drop for CachedRecord {
    fn drop(&mut self) {
        drop(std::mem::take(&mut self.bytes));
        self.allocated.fetch_sub(self.charge, Ordering::SeqCst);
    }
}
pub(crate) struct Resolved {
    pub entry: EntrySnapshot,
    pub head: Option<LogAddress>,
    pub cached: Option<Arc<CachedRecord>>,
}
#[derive(Default)]
struct State {
    owner: Option<u64>,
    next: u64,
    clock: u64,
    order: BTreeMap<u64, u64>,
    entries: BTreeMap<u64, Arc<CachedRecord>>,
}
pub(crate) struct ReadCache {
    config: CacheConfig,
    arena: Option<Arc<arena::Arena>>,
    metrics: Arc<crate::engine::metrics::Core>,
    allocated: Arc<AtomicUsize>,
    state: Mutex<State>,
}
impl ReadCache {
    pub fn new(config: CacheConfig) -> Self {
        Self {
            metrics: crate::engine::metrics::Metrics::new(false).observer(),
            config,
            arena: None,
            allocated: Arc::new(AtomicUsize::new(0)),
            state: Mutex::new(State::default()),
        }
    }
    pub fn preallocate(&mut self) -> Result<(), Error> {
        if self.config.enabled && self.config.pre_allocate && self.arena.is_none() {
            self.arena = Some(arena::Arena::new(self.config.capacity_bytes)?);
        }
        Ok(())
    }
    pub fn reserved_bytes(&self) -> usize {
        self.arena.as_ref().map_or(0, |arena| arena.capacity())
    }
    /// Only adjust the elimination order of immutable records;Do not change index header,Log address or bytes being read.
    pub fn touch(&self, address: CacheAddress) -> Result<(), Error> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| Error::InvalidState("cache_control_lock_poisoned"))?;
        let Some(record) = state.entries.get(&address.0).cloned() else {
            return Ok(());
        };
        let old = record.position.load(Ordering::Relaxed);
        let recent = (self.config.capacity_bytes as f64 * self.config.mutable_fraction) as u64;
        if state.clock.saturating_sub(old) <= recent {
            return Ok(());
        }
        let Some(next) = state.clock.checked_add(record.charge as u64) else {
            return Ok(());
        };
        state.order.remove(&old);
        let position = state.clock;
        record.position.store(position, Ordering::Relaxed);
        state.order.insert(position, address.0);
        state.clock = next;
        self.metrics
            .cache(crate::engine::metrics::CacheEvent::Promote);
        Ok(())
    }
    pub fn set_metrics(&mut self, metrics: Arc<crate::engine::metrics::Metrics>) {
        self.metrics = metrics.observer();
    }
    pub fn max_record_bytes(&self) -> usize {
        self.config
            .capacity_bytes
            .saturating_sub(std::mem::size_of::<CachedRecord>())
    }
    fn bind(state: &mut State, index: &MemIndex) -> Result<(), Error> {
        let owner = index.identity()?;
        if state.owner.is_some_and(|old| old != owner) {
            return Err(Error::InvalidState(
                "The cache belongs to another index identity",
            ));
        }
        state.owner = Some(owner);
        Ok(())
    }
    fn head(state: &State, entry: EntrySnapshot) -> Result<Option<LogAddress>, Error> {
        match entry.head {
            IndexHead::Empty => Ok(None),
            IndexHead::Log(address) => Ok(Some(address)),
            IndexHead::Cache(address) => state
                .entries
                .get(&address.0)
                .map(|record| Some(record.head))
                .ok_or(Error::InvalidState(
                    "Index references a cache record that does not exist",
                )),
        }
    }
    /// Selecting the index header and obtaining the cache lease are the same critical section,Avoid parsing expired cache addresses after elimination.
    pub fn resolve(&self, index: &MemIndex, hash: KeyHash, key: &[u8]) -> Result<Resolved, Error> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| Error::InvalidState("cache_control_lock_poisoned"))?;
        Self::bind(&mut state, index)?;
        let entry = index.prepare(hash)?;
        let head = Self::head(&state, entry)?;
        let cached = if let IndexHead::Cache(address) = entry.head {
            let record = state
                .entries
                .get(&address.0)
                .expect("Cache header verified");
            (Record::decode(record.encoded())?.key == key).then(|| record.clone())
        } else {
            None
        };
        Ok(Resolved {
            entry,
            head,
            cached,
        })
    }
    /// Source must be a verified cold record,hash The canonical key of the corresponding record;Misses or budget shortfalls are not business errors.
    pub fn insert_if_current(
        &self,
        index: &MemIndex,
        expected: EntrySnapshot,
        hash: KeyHash,
        source: LogAddress,
        bytes: Vec<u8>,
    ) -> Result<Option<CacheAddress>, Error> {
        if !self.config.enabled {
            return Ok(None);
        }
        source.validate()?;
        let record = Record::decode(&bytes)?;
        if record.header.invalid || record.header.tombstone {
            return Ok(None);
        }
        if record
            .header
            .previous
            .is_some_and(|previous| previous >= source)
        {
            return Err(Error::InvalidFormat(
                "Cache source record predecessor is not decremented",
            ));
        }
        let version = record.header.version;
        let charge = if self.arena.is_some() {
            bytes.len()
        } else {
            bytes.capacity()
        }
        .checked_add(std::mem::size_of::<CachedRecord>())
        .ok_or(Error::CapacityExceeded)?;
        if charge > self.config.capacity_bytes {
            return Ok(None);
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| Error::InvalidState("cache_control_lock_poisoned"))?;
        Self::bind(&mut state, index)?;
        if index.prepare(hash)? != expected {
            return Ok(None);
        }
        let head = Self::head(&state, expected)?.ok_or(Error::InvalidState(
            "Empty index header cannot install cache",
        ))?;
        if source > head {
            return Err(Error::InvalidFormat(
                "Cache source records past the main log link head",
            ));
        }
        while self
            .allocated
            .load(Ordering::SeqCst)
            .checked_add(charge)
            .is_none_or(|bytes| bytes > self.config.capacity_bytes)
        {
            let Some(address) = state.order.first_key_value().map(|(_, &address)| address) else {
                return Ok(None);
            };
            self.remove(&mut state, index, address)?;
        }
        let bytes = if let Some(arena) = &self.arena {
            let mut lease = loop {
                if let Some(lease) = arena.allocate(bytes.len())? {
                    break lease;
                }
                let Some(address) = state.order.first_key_value().map(|(_, &address)| address)
                else {
                    return Ok(None);
                };
                self.remove(&mut state, index, address)?;
            };
            lease.initialize(&bytes);
            Bytes::Reserved(lease)
        } else {
            Bytes::Owned(bytes)
        };
        // Elimination may be restored expected itself,Retake the snapshot but do not accept chain changes caused by other writes.
        let current = index.prepare(hash)?;
        if current != expected {
            return Ok(None);
        }
        let address = CacheAddress(state.next);
        if address.validate().is_err() {
            return Ok(None);
        }
        state.next = state.next.checked_add(1).ok_or(Error::CapacityExceeded)?;
        let position = state.clock;
        state.clock = state
            .clock
            .checked_add(charge as u64)
            .ok_or(Error::CapacityExceeded)?;
        self.allocated.fetch_add(charge, Ordering::SeqCst);
        let record = Arc::new(CachedRecord {
            source,
            version,
            head,
            hash,
            bytes,
            position: AtomicU64::new(position),
            charge,
            allocated: self.allocated.clone(),
        });
        match index.compare_publish(expected, IndexHead::Cache(address))? {
            PublishResult::Conflict(_) => Ok(None),
            PublishResult::Published => {
                state.entries.insert(address.0, record);
                state.order.insert(position, address.0);
                self.metrics
                    .cache(crate::engine::metrics::CacheEvent::Insert);
                if let IndexHead::Cache(old) = expected.head
                    && let Some(old) = state.entries.remove(&old.0)
                {
                    state.order.remove(&old.position.load(Ordering::Relaxed));
                }
                Ok(Some(address))
            }
        }
    }
    fn remove(&self, state: &mut State, index: &MemIndex, address: u64) -> Result<(), Error> {
        let record = state
            .entries
            .get(&address)
            .ok_or(Error::InvalidState("Cache item does not exist"))?;
        let current = index.prepare(record.hash)?;
        if current.head == IndexHead::Cache(CacheAddress(address)) {
            // Non-cached writes can be replaced preemptively;No need to overwrite its new link head in case of conflict.
            index.compare_publish(current, IndexHead::Log(record.head))?;
        }
        let position = record.position.load(Ordering::Relaxed);
        state.order.remove(&position);
        state.entries.remove(&address);
        self.metrics
            .cache(crate::engine::metrics::CacheEvent::Evict);
        Ok(())
    }
    #[cfg(test)]
    pub fn invalidate(&self, index: &MemIndex, address: CacheAddress) -> Result<(), Error> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| Error::InvalidState("cache_control_lock_poisoned"))?;
        Self::bind(&mut state, index)?;
        if state.entries.contains_key(&address.0) {
            self.remove(&mut state, index, address.0)?;
        }
        Ok(())
    }
    /// The caller performs index snapshot or migration in this critical section,Cannot insert user callbacks or waits I/O.
    pub fn with_normalized_index<T>(
        &self,
        index: &MemIndex,
        operation: impl FnOnce() -> Result<T, Error>,
    ) -> Result<T, Error> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| Error::InvalidState("cache_control_lock_poisoned"))?;
        Self::bind(&mut state, index)?;
        while let Some(address) = state.entries.keys().next().copied() {
            self.remove(&mut state, index, address)?;
        }
        operation()
    }
    pub fn allocated_bytes(&self) -> usize {
        self.allocated.load(Ordering::SeqCst)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::IndexConfig, format::RecordHeader};
    fn bytes(key: &[u8], value: &[u8]) -> Vec<u8> {
        let header = RecordHeader {
            previous: None,
            version: CheckpointVersion(3),
            key_bytes: key.len() as u32,
            value_bytes: value.len() as u32,
            capacity_bytes: value.len() as u32,
            tombstone: false,
            invalid: false,
            final_record: false,
        };
        let mut bytes = vec![0; header.encoded_len().unwrap()];
        Record { header, key, value }.encode(&mut bytes).unwrap();
        bytes
    }
    fn index() -> MemIndex {
        MemIndex::new(IndexConfig { buckets: 2 }).unwrap()
    }
    fn head(index: &MemIndex, hash: KeyHash, address: u64) -> EntrySnapshot {
        index
            .compare_publish(
                index.prepare(hash).unwrap(),
                IndexHead::Log(LogAddress(address)),
            )
            .unwrap();
        index.prepare(hash).unwrap()
    }
    fn cache(capacity: usize) -> ReadCache {
        ReadCache::new(CacheConfig {
            enabled: true,
            capacity_bytes: capacity,
            ..Default::default()
        })
    }
    #[test]
    fn the_eviction_lease_of_the_pre_allocated_cache_continues_to_be_billed_and_can_be_reused_until_the_last_reader_exits()
     {
        let index = index();
        let encoded = bytes(b"a", b"v");
        let charge = encoded.len() + std::mem::size_of::<CachedRecord>();
        let mut cache = cache(charge);
        cache.config.pre_allocate = true;
        cache.preallocate().unwrap();
        assert_eq!(cache.reserved_bytes(), charge);
        assert_eq!(cache.allocated_bytes(), 0);
        let first = head(&index, KeyHash(0), 10);
        let second = head(&index, KeyHash(1), 20);
        cache
            .insert_if_current(&index, first, KeyHash(0), LogAddress(10), encoded)
            .unwrap()
            .unwrap();
        let pinned = cache
            .resolve(&index, KeyHash(0), b"a")
            .unwrap()
            .cached
            .unwrap();
        let pointer = pinned.encoded().as_ptr();
        assert!(
            cache
                .insert_if_current(
                    &index,
                    second,
                    KeyHash(1),
                    LogAddress(20),
                    bytes(b"b", b"x")
                )
                .unwrap()
                .is_none()
        );
        assert_eq!(cache.allocated_bytes(), charge);
        assert_eq!(Record::decode(pinned.encoded()).unwrap().value, b"v");
        drop(pinned);
        cache
            .insert_if_current(
                &index,
                second,
                KeyHash(1),
                LogAddress(20),
                bytes(b"b", b"x"),
            )
            .unwrap()
            .unwrap();
        let pinned = cache
            .resolve(&index, KeyHash(1), b"b")
            .unwrap()
            .cached
            .unwrap();
        assert_eq!(pinned.encoded().as_ptr(), pointer);
        cache.with_normalized_index(&index, || Ok(())).unwrap();
        assert_eq!(cache.allocated_bytes(), charge);
        drop(cache);
        assert_eq!(Record::decode(pinned.encoded()).unwrap().value, b"x");
    }
    #[test]
    fn recent_window_scale_control_hits_refresh_while_old_readers_and_index_headers_remain_valid() {
        for fraction in [0.0, 0.75] {
            let index = index();
            let charge = bytes(b"a", b"v").capacity() + std::mem::size_of::<CachedRecord>();
            let mut cache = cache(charge * 3);
            cache.config.mutable_fraction = fraction;
            let metrics = Arc::new(crate::engine::metrics::Metrics::new(true));
            cache.set_metrics(metrics.clone());
            let hashes = std::array::from_fn::<_, 4, _>(|i| KeyHash((i as u64 + 1) << 48));
            let mut addresses = Vec::new();
            for (i, &hash) in hashes[..2].iter().enumerate() {
                let expected = head(&index, hash, 10 + i as u64);
                addresses.push(
                    cache
                        .insert_if_current(
                            &index,
                            expected,
                            hash,
                            LogAddress(10 + i as u64),
                            bytes(&[b'a' + i as u8], b"v"),
                        )
                        .unwrap()
                        .unwrap(),
                );
            }
            let pinned = cache
                .resolve(&index, hashes[0], b"a")
                .unwrap()
                .cached
                .unwrap();
            let snapshot = index.prepare(hashes[0]).unwrap();
            cache.touch(addresses[0]).unwrap();
            assert_eq!(index.prepare(hashes[0]).unwrap(), snapshot);
            assert_eq!(Record::decode(pinned.encoded()).unwrap().value, b"v");
            drop(pinned);
            for (i, &hash) in hashes.iter().enumerate().skip(2) {
                let expected = head(&index, hash, 10 + i as u64);
                cache
                    .insert_if_current(
                        &index,
                        expected,
                        hash,
                        LogAddress(10 + i as u64),
                        bytes(&[b'a' + i as u8], b"v"),
                    )
                    .unwrap()
                    .unwrap();
            }
            assert_eq!(
                cache
                    .resolve(&index, hashes[0], b"a")
                    .unwrap()
                    .cached
                    .is_some(),
                fraction == 0.0
            );
            assert_eq!(
                cache
                    .resolve(&index, hashes[1], b"b")
                    .unwrap()
                    .cached
                    .is_some(),
                fraction != 0.0
            );
            assert_eq!(
                metrics.snapshot().cache.promotions,
                u64::from(fraction == 0.0)
            );
            assert_eq!(metrics.snapshot().cache.evictions, 1);
        }
    }
    #[test]
    fn cache_condition_installation_complete_key_hit_and_snapshot_restore_log_address_first() {
        let index = index();
        let cache = cache(4096);
        let expected = head(&index, KeyHash(0), 10);
        let address = cache
            .insert_if_current(
                &index,
                expected,
                KeyHash(0),
                LogAddress(8),
                bytes(b"a", b"value"),
            )
            .unwrap()
            .unwrap();
        let resolved = cache.resolve(&index, KeyHash(0), b"a").unwrap();
        assert_eq!(resolved.entry.head, IndexHead::Cache(address));
        assert_eq!(resolved.head, Some(LogAddress(10)));
        let pinned = resolved.cached.unwrap();
        assert_eq!(pinned.source, LogAddress(8));
        assert_eq!(pinned.version, CheckpointVersion(3));
        assert_eq!(Record::decode(pinned.encoded()).unwrap().value, b"value");
        assert!(
            cache
                .resolve(&index, KeyHash(0), b"b")
                .unwrap()
                .cached
                .is_none()
        );
        assert!(index.snapshot().is_err());
        let image = cache
            .with_normalized_index(&index, || index.snapshot())
            .unwrap();
        assert_eq!(image.entries[0].head, IndexHead::Log(LogAddress(10)));
        image.encode().unwrap();
        assert!(
            cache.allocated_bytes() > 0,
            "Loaned records are still included in the budget"
        );
        drop(pinned);
        assert_eq!(cache.allocated_bytes(), 0);
    }
    #[test]
    fn borrowing_during_elimination_will_continue_to_be_billed_and_old_cache_addresses_cannot_accidentally_damage_new_items()
     {
        let index = index();
        let record = bytes(b"a", b"v");
        let charge = record.capacity() + std::mem::size_of::<CachedRecord>();
        let cache = cache(charge);
        let first = head(&index, KeyHash(0), 10);
        let second = head(&index, KeyHash(1), 20);
        let old = cache
            .insert_if_current(&index, first, KeyHash(0), LogAddress(10), record)
            .unwrap()
            .unwrap();
        let pinned = cache
            .resolve(&index, KeyHash(0), b"a")
            .unwrap()
            .cached
            .unwrap();
        assert!(
            cache
                .insert_if_current(
                    &index,
                    second,
                    KeyHash(1),
                    LogAddress(20),
                    bytes(b"b", b"v")
                )
                .unwrap()
                .is_none()
        );
        assert_eq!(cache.allocated_bytes(), charge);
        assert_eq!(
            index.prepare(KeyHash(0)).unwrap().head,
            IndexHead::Log(LogAddress(10))
        );
        assert_eq!(Record::decode(pinned.encoded()).unwrap().key, b"a");
        drop(pinned);
        assert_eq!(cache.allocated_bytes(), 0);
        let new = cache
            .insert_if_current(
                &index,
                second,
                KeyHash(1),
                LogAddress(20),
                bytes(b"b", b"v"),
            )
            .unwrap()
            .unwrap();
        assert_ne!(old, new);
        cache.invalidate(&index, old).unwrap();
        assert!(
            cache
                .resolve(&index, KeyHash(1), b"b")
                .unwrap()
                .cached
                .is_some()
        );
        assert_eq!(cache.allocated_bytes(), charge);
    }
    #[test]
    fn late_installation_and_different_index_identity_rejection_and_the_same_tag_key_does_not_string_values()
     {
        let index = index();
        let cache = cache(4096);
        let stale = head(&index, KeyHash(0), 10);
        let current = head(&index, KeyHash(0), 20);
        assert!(
            cache
                .insert_if_current(
                    &index,
                    stale,
                    KeyHash(0),
                    LogAddress(10),
                    bytes(b"a", b"old")
                )
                .unwrap()
                .is_none()
        );
        let old = cache
            .insert_if_current(
                &index,
                current,
                KeyHash(0),
                LogAddress(20),
                bytes(b"a", b"new"),
            )
            .unwrap()
            .unwrap();
        let expected = cache.resolve(&index, KeyHash(2), b"b").unwrap().entry;
        cache
            .insert_if_current(
                &index,
                expected,
                KeyHash(2),
                LogAddress(8),
                bytes(b"b", b"other"),
            )
            .unwrap()
            .unwrap();
        assert!(
            cache
                .resolve(&index, KeyHash(0), b"a")
                .unwrap()
                .cached
                .is_none()
        );
        let record = cache
            .resolve(&index, KeyHash(2), b"b")
            .unwrap()
            .cached
            .unwrap();
        assert_eq!(Record::decode(record.encoded()).unwrap().value, b"other");
        cache.invalidate(&index, old).unwrap();
        let foreign = MemIndex::new(IndexConfig { buckets: 2 }).unwrap();
        assert!(cache.resolve(&foreign, KeyHash(0), b"a").is_err());
        assert!(
            cache
                .resolve(&index, KeyHash(2), b"b")
                .unwrap()
                .cached
                .is_some()
        );
    }
}
