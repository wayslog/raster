use super::*;
use crate::{
    RasterKV, Submission,
    api::{Outcome, operation::*},
    config::Config,
    schema::{KeyCodec, ValueUpdate, builtin::{AtomicU64Value, SchemaPair, U64Key}},
};
type Schema = SchemaPair<U64Key, AtomicU64Value>;
struct Put;
impl Keyed<Schema> for Put {
    fn key(&self) -> &u64 { &7 }
}
impl UpsertOperation<Schema> for Put {
    type Output = ();
    fn replacement(&mut self) -> Result<(u64, ()), Error> { Ok((42, ())) }
    fn update_in_place(&mut self, _: ValueUpdate<'_, Schema>) -> Result<UpdateDecision<()>, Error> {
        Ok(UpdateDecision::Append)
    }
}
#[test]
fn engine_epoch_alone_must_retain_a_retired_record_before_borrowed_access_is_safe() {
    let mut config = Config::default();
    config.log.page_bytes = 4096;
    config.log.memory_pages = 4;
    let store = RasterKV::builder(SchemaPair::new(U64Key, AtomicU64Value))
        .config(config).device(Box::new(crate::device::null::NullDeviceFactory))
        .create().unwrap();
    let mut session = store.start_session(Default::default()).unwrap();
    assert!(matches!(session.upsert(Serial(0), Put),
        Ok(Submission::Ready(Ok(Outcome::Success(()))))));
    let guard = store.inner.epoch.enter(session.participant.as_ref().unwrap()).unwrap();
    let entry = store.inner.index.prepare(U64Key.hash(&7)).unwrap();
    let crate::index::IndexHead::Log(address) = entry.head else { panic!("missing record") };
    let lease = store.inner.log.lease(address).unwrap();
    let weak = Arc::downgrade(&lease.value);
    drop(lease);
    assert!(weak.upgrade().is_some());
    store.inner.index.compare_publish(entry, crate::index::IndexHead::Empty).unwrap();
    assert_eq!(store.inner.index.prepare(U64Key.hash(&7)).unwrap().head,
        crate::index::IndexHead::Empty);
    store.inner.log.retire(address).unwrap();
    assert!(weak.upgrade().is_some(),
        "an active engine epoch does not retain the retired PageValue owner");
    drop(guard);
}
