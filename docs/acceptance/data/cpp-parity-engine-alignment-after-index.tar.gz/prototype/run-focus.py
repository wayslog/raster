import json,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
parent=Path('target/parity-profile/index-route-after-borrow/baseline-bins/parity')
candidate=root/'candidate-bins/parity'
component=root/'baseline-bins/parity'
cases=['read/uniform/1','read/uniform/4','read/worker-hot/4','read/shared-hot/4','upsert/uniform/1','upsert/uniform/4','upsert/worker-hot/4','rmw/worker-hot/4']
jobs=[('component',case,candidate,component) for case in ['upsert/worker-hot/4','rmw/worker-hot/4','read/uniform/4']]
jobs += [('parent',case,candidate,parent) for case in cases]
jobs += [('control',case,parent,parent) for case in ['upsert/worker-hot/4','read/uniform/4']]
results=[]
for role,case,subject,baseline in jobs:
    output=root/'focus'/role/case.replace('/','-')
    command=[sys.executable,'tools/performance/compare.py','--rust',str(subject),'--baseline-rust',str(baseline),'--case',case,'--output',str(output),'--min-throughput','.98','--max-p99','1.10']
    run=subprocess.run(command,capture_output=True,text=True)
    print(role,run.stdout,flush=True)
    results.append({'role':role,'case':case,'command':command,'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
    (root/'focus-runs.json').write_text(json.dumps(results,indent=2)+'\n')
    if not (output/'comparison.json').exists(): raise RuntimeError(run.stderr)
