from pathlib import Path
import hashlib, json, os, re, shutil, subprocess
root=Path('target/parity-profile/engine-alignment-after-index')
checks=[]
commands=[('miri',['cargo','+nightly','miri','test','--locked','--lib','index::growth::epoch_tests']),('tests',['cargo','test','--locked','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('build',['cargo','build','--locked','--release','--all-features','--example','parity','--example','parity_scan','--example','benchmark','--example','benchmark_probe'])]
for name,cmd in commands:
    r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (root/(name+'.log')).write_text(r.stdout.replace(str(Path.cwd()),'worktree').replace(str(Path.home()),'user_directory'))
    checks.append({'name':name,'command':cmd,'exit_code':r.returncode,'MIRIFLAGS':os.environ.get('MIRIFLAGS','')})
    (root/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,r.returncode,flush=True)
    if r.returncode:
        print(r.stdout[-2500:].replace(str(Path.cwd()),'worktree'))
        raise SystemExit(r.returncode)
manifest=json.loads((root/'manifest.json').read_text())
manifest['source_sha256']={}
for name in ['src/engine/mod.rs','src/api/store.rs','src/api/recover.rs','src/engine/cache.rs','src/engine/growth.rs','src/engine/read.rs','src/epoch/mod.rs','src/index/mod.rs','src/index/growth.rs','src/index/growth/epoch_tests.rs','src/index/route_read_tests.rs']:
    source=Path(name);target=root/'source'/name
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
    manifest['source_sha256'][name]=hashlib.sha256(source.read_bytes()).hexdigest()
manifest['candidate_sha256']={};directory=root/'candidate-bins';directory.mkdir(exist_ok=False)
for name in ['parity','parity_scan','benchmark','benchmark_probe']:
    target=directory/name;shutil.copyfile(Path('target/release/examples')/name,target);target.chmod(0o755)
    manifest['candidate_sha256'][name]=hashlib.sha256(target.read_bytes()).hexdigest()
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',(root/'tests.log').read_text())
manifest['tests']={'passed':sum(int(a) for a,b in rows),'failed':sum(int(b) for a,b in rows)}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Sources and executables frozen:',manifest['tests'],flush=True)
