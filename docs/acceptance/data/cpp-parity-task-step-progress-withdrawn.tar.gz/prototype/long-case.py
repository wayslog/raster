"""Local interleaved diagnostic for one- or four-thread ownership scenarios."""
import sys
sys.path.insert(0,'tools/performance')
import focused_compare as focused
from cpu_profile import validate_output

def validate_case(case):
    parts=case.split('/')
    if len(parts)!=3 or parts[0] not in ('read','upsert','rmw') or parts[1] not in ('uniform','worker-hot','shared-hot') or parts[2] not in ('1','4'):
        raise ValueError('Invalid direct-engine scenario')
    return parts

def validate_measurement(output,case,count):
    row=validate_output(output,'rust',case,count)
    threads=int(case.split('/')[-1]);n=count//threads
    samples=threads*(n//4096*64+sum((j&63)==((j//64)&63) for j in range(n%4096)))
    assert row['samples']==samples
    return row

assert not hasattr(focused.os,'sched_setaffinity'),'This local four-thread diagnostic must not pin all workers to one CPU'
focused.validate_case=validate_case
focused.validate_measurement=validate_measurement
focused.main()
