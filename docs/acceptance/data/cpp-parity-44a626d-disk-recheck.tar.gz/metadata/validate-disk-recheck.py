"""Validate both disk comparisons and retain the original failed gate."""
from pathlib import Path
import csv,hashlib,itertools,json,statistics,sys
sys.path.insert(0,'tools/acceptance')
from audit_benchmark import trace_audit
root=Path('target/parity-profile/key-preparation-inline');case='u64-hot-t4-disk-r1';labels=['baseline','candidate','control'];models={};allrows=[];results=[]
for name in ['full-lifecycles','disk-recheck']:
 d=root/name;pairs=json.loads((d/(case+'-pairs.json')).read_text());comparisons=json.loads((d/'comparison.json').read_text());comparison=next(r for r in comparisons if r['case']==case)
 hashes=json.loads((d/'binaries.json').read_text());assert hashes['baseline']==hashes['control']
 expected_hashes=json.loads((root/'full-lifecycles/binaries.json').read_text());assert hashes==expected_hashes
 assert len(pairs)==6
 for i,pair in enumerate(pairs,1):
  assert pair['pair']==i and pair['order']==list(list(itertools.permutations(labels))[i-1])
  for label in labels:
   out=d/f'{case}-pair{i}-{label}';rows=list(csv.DictReader((out/'matrix.csv').open()));assert len(rows)==1
   row=rows[0];assert row==pair[label];trace=out/(row['input_id']+'.trace');digest=hashlib.sha256(trace.read_bytes()).hexdigest();assert digest==comparison['input_sha256']
   if digest not in models:models[digest]=trace_audit(trace,False,True,4)
   model=models[digest];assert int(row['success'])+int(row['missing'])==16384 and int(row['success'])>=model['success']
   assert int(row['application_write_bytes'])==model['application_write_bytes']
   log=(d/f'{case}-pair{i}-{label}.txt').read_text();assert f'benchmark {case} passed:16384 steps_four_operations,' in log and '2048 keys_and_tombstone_validation' in log and 'panicked at' not in log
   allrows.append(row)
 for label in labels:
  for metric,value in comparison['medians'][label].items():assert value==statistics.median(float(p[label][metric]) for p in pairs)
 m=comparison['medians'];t=m['candidate']['operations_per_second']/m['baseline']['operations_per_second'];p=m['candidate']['P99nanoseconds']/m['baseline']['P99nanoseconds'];ct=m['control']['operations_per_second']/m['baseline']['operations_per_second'];cp=m['control']['P99nanoseconds']/m['baseline']['P99nanoseconds']
 assert [comparison[k] for k in ['throughput_ratio','p99_ratio','control_throughput_ratio','control_p99_ratio']]==[t,p,ct,cp]
 results.append({'run':name,'candidate':{'throughput_ratio':t,'p99_ratio':p,'passed':t>=.98 and p<=1.1},'control':{'throughput_ratio':ct,'p99_ratio':cp,'valid':.98<=ct<=1/.98 and 1/1.1<=cp<=1.1}})
fields=['operation_count','readoperation_count','writeoperation_count','RMWoperation_count','deleteoperation_count','readpending_count','writepending_count','RMWpending_count','deletepending_count','Deny retry','post_workload_read_bytes','post_workload_write_bytes','application_write_bytes']
observed={k:sorted(set(int(r[k]) for r in allrows)) for k in fields}
assert len(allrows)==36 and len(models)==1 and all(len(v)==1 for v in observed.values())
report={'processes':36,'fixed_input_sha256':next(iter(models)),'same_source_binaries':'verified','business_recovery':'verified','workload_counters':observed,'comparisons':results,'conclusion':'Original failure remains. Recheck candidate passes but control is invalid. Workload and I/O volume differences are ruled out for these samples; stable candidate-specific attribution is not established.'}
(root/'disk-recheck-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
