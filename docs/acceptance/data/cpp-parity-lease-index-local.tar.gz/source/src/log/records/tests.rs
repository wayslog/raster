use super::*;
use crate::schema::builtin::AtomicU64Value;
use std::{panic::AssertUnwindSafe, sync::Barrier};

fn log() -> HybridLog<AtomicU64Value> {
    HybridLog::new(
        LogConfig {
            page_bytes: 256,
            memory_pages: 1,
            mutable_fraction: 0.5,
        },
        Arc::new(AtomicU64Value),
    )
    .unwrap()
}
fn publish(log: &HybridLog<AtomicU64Value>, value: u64) -> LogAddress {
    log.finish_initialization(log.reserve_record(b"key", None, value).unwrap())
        .unwrap()
}
fn entries(log: &HybridLog<AtomicU64Value>) -> usize {
    log.records
        .lookup
        .shards
        .iter()
        .map(|shard| shard.lock().unwrap().len())
        .sum()
}

#[test]
fn cached_leases_observe_live_updates_and_tombstones() {
    let log = log();
    let address = publish(&log, 7);
    assert_eq!(entries(&log), 0);
    let lease = log.lease(address).unwrap();
    assert_eq!(entries(&log), 1);
    lease
        .update(|value| {
            value.store(11, Ordering::SeqCst);
            Ok(())
        })
        .unwrap();
    assert_eq!(log.lease(address).unwrap().read(|value| value).unwrap(), 11);
    assert!(matches!(
        lease.tombstone_at_version(CheckpointVersion(0), || Ok(true)),
        Ok(ValueAccess::Ready(Some(true)))
    ));
    assert!(matches!(
        log.lease(address).unwrap().try_read_live(|_| panic!(
            "A cached address must not return a value hidden by a tombstone"
        )),
        Ok(ValueAccess::Ready(None))
    ));
}

#[test]
fn retirement_removes_cached_visibility_but_preserves_an_owned_lease() {
    let log = log();
    let address = publish(&log, 7);
    let lease = log.lease(address).unwrap();
    let weak = Arc::downgrade(&lease.value);
    log.retire(address).unwrap();
    assert_eq!(entries(&log), 0);
    assert!(matches!(log.lease(address), Err(Error::RangeTruncated)));
    assert_eq!(lease.read(|value| value).unwrap(), 7);
    assert!(matches!(
        log.release_page(PageId(0), Generation(0)),
        Err(Error::Busy)
    ));
    drop(lease);
    assert!(weak.upgrade().is_none());
    // Retaining even the weak control block cannot retain the log page.
    log.release_page(PageId(0), Generation(0)).unwrap();
    let next = publish(&log, 19);
    assert!(next > address);
    assert_eq!(log.lease(next).unwrap().generation(), Generation(1));
    assert_eq!(log.lease(next).unwrap().read(|value| value).unwrap(), 19);
    assert!(matches!(log.lease(address), Err(Error::RangeTruncated)));
}

#[test]
fn a_miss_selected_before_retirement_cannot_reinsert_a_retired_address() {
    let log = log();
    let address = publish(&log, 7);
    let selected = Barrier::new(2);
    let retired = Barrier::new(2);
    std::thread::scope(|scope| {
        let worker = scope.spawn(|| {
            // Pause the real miss path after selecting its owned reference
            // and releasing the ordered lock, before remembering the address.
            let record = log.records.lock().unwrap().get(&address).unwrap().clone();
            selected.wait();
            retired.wait();
            log.records.lookup.remember(address, &record).unwrap();
            assert_eq!(record.read(|value| value).unwrap(), 7);
        });
        selected.wait();
        log.retire(address).unwrap();
        retired.wait();
        worker.join().unwrap();
    });
    assert_eq!(entries(&log), 0);
    assert!(matches!(log.lease(address), Err(Error::RangeTruncated)));
    log.release_page(PageId(0), Generation(0)).unwrap();
}

#[test]
fn cached_and_ordered_access_fail_closed_after_either_index_is_poisoned() {
    for shard_poison in [false, true] {
        let log = log();
        let first = publish(&log, 7);
        let second = publish(&log, 11);
        assert_ne!(
            LeaseIndex::<AtomicU64Value>::shard(first),
            LeaseIndex::<AtomicU64Value>::shard(second)
        );
        drop(log.lease(first).unwrap());
        drop(log.lease(second).unwrap());
        let panic = std::panic::catch_unwind(AssertUnwindSafe(|| {
            if shard_poison {
                let _ = log.records.lookup.with_entries(first, |_| {
                    panic!("Poison a lease index shard through its normal access path")
                });
            } else {
                let _guard = log.records.lock().unwrap();
                panic!("Poison ordered record metadata after warming the lookup index");
            }
        }));
        assert!(panic.is_err());
        for address in [first, second, LogAddress(192)] {
            assert!(matches!(log.lease(address), Err(Error::InvalidState(_))));
        }
        assert!(matches!(
            log.snapshot_next(first, log.frontiers().unwrap().tail),
            Err(Error::InvalidState(_))
        ));
        assert!(matches!(log.retire(first), Err(Error::InvalidState(_))));
    }
}

#[test]
fn repeated_lease_retirement_and_page_reuse_leave_no_cached_history() {
    let mut log = log();
    log.preallocate().unwrap();
    let mut previous = None;
    for cycle in 0..512 {
        let address = publish(&log, cycle);
        assert!(previous.is_none_or(|previous| address > previous));
        let lease = log.lease(address).unwrap();
        assert_eq!(lease.read(|value| value).unwrap(), cycle);
        assert_eq!(entries(&log), 1);
        // Only the ordered table and the caller own this value.
        assert_eq!(Arc::strong_count(&lease.value), 2);
        let generation = lease.generation();
        drop(lease);
        log.retire(address).unwrap();
        assert_eq!(entries(&log), 0);
        assert!(log.records.lock().unwrap().is_empty());
        log.release_page(address.page_offset(256).unwrap().0, generation)
            .unwrap();
        assert_eq!(log.memory_usage().unwrap(), (0, 256));
        previous = Some(address);
    }
}
