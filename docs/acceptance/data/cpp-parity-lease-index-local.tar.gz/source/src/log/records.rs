//! Ordered publication and an on-demand index for resident record leases.
use super::{value::PageValue, *};
use std::sync::{
    Mutex, MutexGuard, Weak,
    atomic::{AtomicBool, Ordering},
};

const SHARDS: usize = 64;
type Ordered<V> = BTreeMap<LogAddress, Arc<PublishedRecord<V>>>;
type Entries<V> = BTreeMap<LogAddress, Weak<PublishedRecord<V>>>;

pub(super) struct PublishedRecord<V: ValueLayout> {
    value: PageValue<V>,
    visible: AtomicBool,
}
impl<V: ValueLayout> PublishedRecord<V> {
    pub fn new(value: PageValue<V>) -> Self {
        Self {
            value,
            visible: AtomicBool::new(true),
        }
    }
}
impl<V: ValueLayout> std::ops::Deref for PublishedRecord<V> {
    type Target = PageValue<V>;
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

struct LeaseIndex<V: ValueLayout> {
    shards: [Mutex<Entries<V>>; SHARDS],
    failed: AtomicBool,
}
struct FailOnUnwind<'a>(&'a AtomicBool);
impl Drop for FailOnUnwind<'_> {
    fn drop(&mut self) {
        if std::thread::panicking() {
            self.0.store(true, Ordering::Release);
        }
    }
}
impl<V: ValueLayout> LeaseIndex<V> {
    fn shard(address: LogAddress) -> usize {
        // Mix low record offsets with page bits; correctness does not depend
        // on the allocation alignment or the resulting distribution.
        ((address.0 >> 6) ^ (address.0 >> 18)) as usize & (SHARDS - 1)
    }
    fn ensure_healthy(&self) -> Result<(), Error> {
        if self.failed.load(Ordering::Acquire) {
            Err(Error::InvalidState("Record lease index lock poisoning"))
        } else {
            Ok(())
        }
    }
    fn with_entries<R>(
        &self,
        address: LogAddress,
        f: impl FnOnce(&mut Entries<V>) -> R,
    ) -> Result<R, Error> {
        self.ensure_healthy()?;
        let mut entries = self.shards[Self::shard(address)].lock().map_err(|_| {
            self.failed.store(true, Ordering::Release);
            Error::InvalidState("Record lease index lock poisoning")
        })?;
        self.ensure_healthy()?;
        let _failure = FailOnUnwind(&self.failed);
        Ok(f(&mut entries))
    }
    fn get(&self, address: LogAddress) -> Result<Option<Arc<PublishedRecord<V>>>, Error> {
        let (record, visible) = self.with_entries(address, |entries| {
            let record = entries.get(&address).and_then(Weak::upgrade);
            let visible = record
                .as_ref()
                .is_some_and(|record| record.visible.load(Ordering::Acquire));
            (record, visible)
        })?;
        // Even an invalidated strong reference must be dropped outside the
        // shard: its final destructor may invoke a user value layout.
        Ok(if visible { record } else { None })
    }
    fn remember(&self, address: LogAddress, record: &Arc<PublishedRecord<V>>) -> Result<(), Error> {
        self.with_entries(address, |entries| {
            // A miss can retain an owned lease across retirement. Check under
            // the same shard lock as invalidation so it cannot reinsert a
            // retired address after the ordered table has removed it.
            if record.visible.load(Ordering::Acquire) {
                entries.insert(address, Arc::downgrade(record));
            }
        })
    }
    fn invalidate(&self, address: LogAddress, record: &PublishedRecord<V>) -> Result<(), Error> {
        self.with_entries(address, |entries| {
            record.visible.store(false, Ordering::Release);
            entries.remove(&address);
        })
    }
}

pub(super) struct Records<V: ValueLayout> {
    ordered: Mutex<Ordered<V>>,
    lookup: Box<LeaseIndex<V>>,
}
impl<V: ValueLayout> Records<V> {
    pub fn new() -> Self {
        Self {
            ordered: Mutex::new(BTreeMap::new()),
            lookup: Box::new(LeaseIndex {
                shards: std::array::from_fn(|_| Mutex::new(BTreeMap::new())),
                failed: AtomicBool::new(false),
            }),
        }
    }
    fn ensure_healthy(&self) -> Result<(), Error> {
        if self.ordered.is_poisoned() {
            return Err(Error::InvalidState("Record table lock poisoning"));
        }
        self.lookup.ensure_healthy()
    }
    pub fn lock(&self) -> Result<MutexGuard<'_, Ordered<V>>, Error> {
        self.ensure_healthy()?;
        let guard = self
            .ordered
            .lock()
            .map_err(|_| Error::InvalidState("Record table lock poisoning"))?;
        self.ensure_healthy()?;
        Ok(guard)
    }
    pub fn get(&self, address: LogAddress) -> Result<Arc<PublishedRecord<V>>, Error> {
        self.ensure_healthy()?;
        if let Some(record) = self.lookup.get(address)? {
            return Ok(record);
        }
        // Never wait for ordered metadata while holding a lookup shard.
        // Publication, retirement and eviction use ordered -> shard order.
        let record = self
            .lock()?
            .get(&address)
            .cloned()
            .ok_or(Error::RangeTruncated)?;
        self.lookup.remember(address, &record)?;
        Ok(record)
    }
    /// Called under the ordered table lock, before removing its strong owner.
    pub fn invalidate(
        &self,
        address: LogAddress,
        record: &PublishedRecord<V>,
    ) -> Result<(), Error> {
        self.lookup.invalidate(address, record)
    }
}

#[cfg(test)]
mod tests;
