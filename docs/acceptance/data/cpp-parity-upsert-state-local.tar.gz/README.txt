Upsert execution-state ownership experiments on runtime 1768626.
The original state-owning guard remains a candidate awaiting native verification. It passes all 496 tests but only 13/18 memory cases, 1/2 append/scan cases, and 2/3 strict lifecycle cases. Its repeated variable-memory regression remains unresolved.
The reference-guard refinement is withdrawn after 12/18 memory cases and another variable-memory failure. Both full matrices and interleaved identical-binary controls are retained; threshold crossings are not rounded to passes.
The original source and three frozen release binaries were restored exactly. The first restoration preserved old source modification times and hit stale Cargo artifacts; the hash verifier caught the mismatch. Source timestamps were refreshed before rebuilding, and the final hashes match.
Trace bytes are deduplicated by SHA-256; trace-references.json maps original relative names to inputs/<digest>.trace. Runtime binaries are excluded, but exact modified sources and binary hashes are retained.
The full C++ parity goal is incomplete.
