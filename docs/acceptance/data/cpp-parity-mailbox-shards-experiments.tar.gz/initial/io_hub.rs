//! Device completion only passes owned buffers across threads;Mailbox does not hold user requests or callbacks.
use crate::{
    device::{CompletionRoute, Device, IoCompletion},
    types::*,
};
use std::{
    collections::BTreeMap,
    sync::{
        Mutex,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
    },
};
const MAX_SHARDS: usize = 64;
struct Mailbox {
    id: RequestId,
    completion: Option<IoCompletion>,
    completions: u64,
}
#[repr(align(64))]
struct Shard(Mutex<Mailboxes>);
#[repr(align(64))]
struct RouteSequence(AtomicU64);
#[repr(align(64))]
struct Capacity {
    limit: usize,
    occupied: AtomicUsize,
}
struct Reservation<'a> {
    capacity: &'a Capacity,
    committed: bool,
}
impl Capacity {
    fn reserve(&self) -> Result<Reservation<'_>, Error> {
        self.occupied
            .fetch_update(Ordering::AcqRel, Ordering::Acquire, |count| {
                (count < self.limit).then(|| count + 1)
            })
            .map_err(|_| Error::Busy)?;
        Ok(Reservation {
            capacity: self,
            committed: false,
        })
    }
}
impl Drop for Reservation<'_> {
    fn drop(&mut self) {
        if !self.committed {
            self.capacity.occupied.fetch_sub(1, Ordering::Release);
        }
    }
}
struct PoisonNotification<'a> {
    mailboxes: &'a Mutex<Mailboxes>,
    failed: &'a AtomicBool,
}
impl Drop for PoisonNotification<'_> {
    fn drop(&mut self) {
        // The actual mutex guard drops first, including during unwinding.
        if self.mailboxes.is_poisoned() {
            self.failed.store(true, Ordering::Release);
        }
    }
}
/// Reuse a few slots for synchronous requests without moving tree leaf payloads.
/// Overflow retains exact routing and is bounded by the hub's existing capacity.
struct Mailboxes {
    inline: [Option<Mailbox>; 4],
    overflow: BTreeMap<u64, Mailbox>,
}
impl Mailboxes {
    fn new() -> Self {
        Self {
            inline: std::array::from_fn(|_| None),
            overflow: BTreeMap::new(),
        }
    }
    #[cfg(test)]
    fn len(&self) -> usize {
        self.inline.iter().flatten().count() + self.overflow.len()
    }
    fn get(&self, route: &u64) -> Option<&Mailbox> {
        self.inline
            .iter()
            .flatten()
            .find(|mailbox| mailbox.id.slot == *route)
            .or_else(|| self.overflow.get(route))
    }
    fn get_mut(&mut self, route: &u64) -> Option<&mut Mailbox> {
        self.inline
            .iter_mut()
            .flatten()
            .find(|mailbox| mailbox.id.slot == *route)
            .or_else(|| self.overflow.get_mut(route))
    }
    fn insert(&mut self, route: u64, mailbox: Mailbox) {
        if let Some(slot) = self.inline.iter_mut().find(|slot| slot.is_none()) {
            *slot = Some(mailbox);
        } else {
            self.overflow.insert(route, mailbox);
        }
    }
    fn remove(&mut self, route: &u64) {
        if let Some(slot) = self.inline.iter_mut().find(|slot| {
            slot.as_ref()
                .is_some_and(|mailbox| mailbox.id.slot == *route)
        }) {
            *slot = None;
        } else {
            self.overflow.remove(route);
        }
    }
    fn values_mut(&mut self) -> impl Iterator<Item = &mut Mailbox> {
        self.inline
            .iter_mut()
            .flatten()
            .chain(self.overflow.values_mut())
    }
}
pub(crate) struct CompletionHub {
    store: StoreId,
    capacity: Capacity,
    next: RouteSequence,
    shards: Box<[Shard]>,
    failed: AtomicBool,
    polling: Mutex<()>,
}
impl CompletionHub {
    fn healthy(&self) -> Result<(), Error> {
        if self.failed.load(Ordering::Acquire) {
            return Err(Error::InvalidState("completion_mailbox_lock_poisoned"));
        }
        Ok(())
    }
    fn with_mailboxes<R>(
        &self,
        route: u64,
        use_mailboxes: impl FnOnce(&mut Mailboxes) -> Result<R, Error>,
    ) -> Result<R, Error> {
        self.healthy()?;
        let shard = &self.shards[route as usize & (self.shards.len() - 1)].0;
        let _notification = PoisonNotification {
            mailboxes: shard,
            failed: &self.failed,
        };
        let mut mailboxes = shard.lock().map_err(|_| {
            self.failed.store(true, Ordering::Release);
            Error::InvalidState("completion_mailbox_lock_poisoned")
        })?;
        self.healthy()?;
        use_mailboxes(&mut mailboxes)
    }
    pub fn new(store: StoreId, capacity: usize) -> Result<Self, Error> {
        store.validate()?;
        if capacity == 0 {
            return Err(Error::CapacityExceeded);
        }
        let count = capacity.min(MAX_SHARDS).next_power_of_two();
        let mut shards = Vec::new();
        shards
            .try_reserve_exact(count)
            .map_err(|_| Error::OutOfMemory)?;
        shards.resize_with(count, || Shard(Mutex::new(Mailboxes::new())));
        Ok(Self {
            store,
            capacity: Capacity {
                limit: capacity,
                occupied: AtomicUsize::new(0),
            },
            next: RouteSequence(AtomicU64::new(0)),
            shards: shards.into_boxed_slice(),
            failed: AtomicBool::new(false),
            polling: Mutex::new(()),
        })
    }
    pub fn reserve(&self, session: SessionId) -> Result<RequestId, Error> {
        session.validate()?;
        self.healthy()?;
        let mut reservation = self.capacity.reserve()?;
        let slot = self
            .next
            .0
            .fetch_update(Ordering::AcqRel, Ordering::Acquire, |next| {
                next.checked_add(1)
            })
            .map_err(|_| Error::CapacityExceeded)?;
        let id = RequestId {
            store: self.store,
            session,
            slot,
            generation: Generation(0),
        };
        self.with_mailboxes(slot, |mailboxes| {
            mailboxes.insert(
                slot,
                Mailbox {
                    id,
                    completion: None,
                    completions: 0,
                },
            );
            // The mailbox owns the global credit until an identity-checked release.
            reservation.committed = true;
            Ok(())
        })?;
        Ok(id)
    }
    /// Route numbers are assigned monotonically within the engine to which the device belongs.,Do not reuse slot numbers,Reject when exhausted.
    pub fn route(id: RequestId) -> CompletionRoute {
        CompletionRoute(id.slot)
    }
    pub fn take(&self, id: RequestId) -> Result<Option<IoCompletion>, Error> {
        self.with_mailboxes(id.slot, |mailboxes| {
            let mailbox = mailboxes
                .get_mut(&id.slot)
                .ok_or(Error::InvalidState("The request email does not exist"))?;
            if mailbox.id != id {
                return Err(Error::InvalidState(
                    "request mailbox ownership does not match",
                ));
            }
            Ok(mailbox.completion.take())
        })
    }
    pub fn completion_count(&self, id: RequestId) -> Result<u64, Error> {
        self.with_mailboxes(id.slot, |mailboxes| {
            mailboxes
                .get(&id.slot)
                .filter(|mailbox| mailbox.id == id)
                .map(|mailbox| mailbox.completions)
                .ok_or(Error::InvalidState("Completion count route does not exist"))
        })
    }
    /// Logout when requesting termination or session abandonment;The device still has the I/O buffer.
    pub fn release(&self, id: RequestId) -> Result<(), Error> {
        self.with_mailboxes(id.slot, |mailboxes| {
            if mailboxes
                .get(&id.slot)
                .is_none_or(|mailbox| mailbox.id != id)
            {
                return Err(Error::InvalidState(
                    "request mailbox ownership does not match",
                ));
            }
            mailboxes.remove(&id.slot);
            self.capacity.occupied.fetch_sub(1, Ordering::Release);
            Ok(())
        })
    }
    /// Only if the device has shutdown,Called after all publishing threads have exited;The final state only discards possession completion,No more delivering tasks.
    pub(crate) fn discard_after_device_shutdown(&self, device: &dyn Device) -> Result<(), Error> {
        // Equipment poll of panic Possible poisoning of serialization locks;Shut down terminated device,Final state recycling does not restore running permissions.
        let _polling = self
            .polling
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let mut completions = Vec::new();
        loop {
            device.poll(PollBudget::default(), &mut completions)?;
            if completions.is_empty() {
                break;
            }
            completions.clear();
        }
        for route in 0..self.shards.len() as u64 {
            self.with_mailboxes(route, |mailboxes| {
                for mailbox in mailboxes.values_mut() {
                    mailbox.completion = None;
                }
                Ok(())
            })?;
        }
        Ok(())
    }
    pub fn poll(&self, device: &dyn Device, budget: PollBudget) -> Result<usize, Error> {
        let _polling = match self.polling.try_lock() {
            Ok(guard) => guard,
            Err(std::sync::TryLockError::WouldBlock) => return Ok(0),
            Err(_) => return Err(Error::InvalidState("Complete polling lock poisoning")),
        };
        let mut completions = Vec::new();
        let limit = budget.0.get().min(self.capacity.limit);
        let mut error = device
            .poll(
                PollBudget(std::num::NonZeroUsize::new(limit).expect("Capacity is non-zero")),
                &mut completions,
            )
            .err();
        self.healthy()?;
        let count = completions.len();
        for completion in completions {
            self.with_mailboxes(completion.route.0, |mailboxes| {
                if let Some(mailbox) = mailboxes.get_mut(&completion.route.0) {
                    mailbox.completions = mailbox.completions.saturating_add(1);
                    if mailbox.completion.is_some() {
                        error.get_or_insert(Error::InvalidState(
                            "There are multiple uncollected requests for one request I/O completed",
                        ));
                    } else {
                        mailbox.completion = Some(completion);
                    }
                } else if completion.route.0 >= self.next.0.load(Ordering::Acquire) {
                    error.get_or_insert(Error::InvalidState(
                        "Device returns unassigned completion route",
                    ));
                }
                Ok(())
            })?;
            // Unregistered historical routes only release the completion buffer,Abandoned user requests are not invoked.
        }
        match error {
            Some(error) => Err(error),
            None => Ok(count),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::device::{IoOperation, IoRequest, memory::MemoryDevice};
    #[test]
    fn unrelated_route_storage_does_not_block_taking_an_existing_mailbox() {
        let hub = CompletionHub::new(StoreId([1; 16]), 64).unwrap();
        let first = hub.reserve(SessionId([1; 16])).unwrap();
        let second = hub.reserve(SessionId([2; 16])).unwrap();
        let (send, receive) = std::sync::mpsc::channel();
        let result = std::thread::scope(|scope| {
            let mut reader = None;
            let received = hub
                .with_mailboxes(first.slot, |_| {
                    reader = Some(scope.spawn(|| {
                        send.send(hub.take(second).map(|value| value.is_none()))
                            .unwrap();
                    }));
                    Ok(receive.recv_timeout(std::time::Duration::from_secs(2)))
                })
                .unwrap();
            // Release the held storage before joining, including after timeout.
            reader.unwrap().join().unwrap();
            received
        });
        assert!(matches!(result, Ok(Ok(true))), "{result:?}");
    }
    #[test]
    fn released_inline_routes_cannot_consume_late_completions_or_displace_overflow() {
        let capacity = MAX_SHARDS * 7;
        let hub = CompletionHub::new(StoreId([1; 16]), capacity).unwrap();
        let device = MemoryDevice::new(16, 64).unwrap();
        let session = SessionId([2; 16]);
        let all: Vec<_> = (0..capacity)
            .map(|_| hub.reserve(session).unwrap())
            .collect();
        // Seven routes share one shard, exercising its inline and overflow storage.
        let original: Vec<_> = all.iter().step_by(MAX_SHARDS).copied().collect();
        assert_eq!(
            hub.with_mailboxes(0, |mailboxes| Ok(mailboxes.len()))
                .unwrap(),
            7
        );
        assert!(matches!(hub.reserve(session), Err(Error::Busy)));
        for id in &original {
            device
                .submit(IoRequest {
                    route: CompletionHub::route(*id),
                    operation: IoOperation::CreateDirectory(format!("route-{}", id.slot).into()),
                })
                .unwrap();
        }
        hub.release(original[0]).unwrap();
        hub.release(original[3]).unwrap();
        let first = hub.reserve(session).unwrap();
        let second = hub.reserve(session).unwrap();
        assert!(first.slot > all.last().unwrap().slot && second.slot > first.slot);
        assert!(matches!(hub.reserve(session), Err(Error::Busy)));
        assert_eq!(hub.poll(&device, PollBudget::default()).unwrap(), 7);
        for id in [first, second] {
            assert!(hub.take(id).unwrap().is_none());
            assert_eq!(hub.completion_count(id).unwrap(), 0);
        }
        for index in [1, 2, 4, 5, 6] {
            let id = original[index];
            assert!(hub.take(id).unwrap().unwrap().result.is_ok());
            assert_eq!(hub.completion_count(id).unwrap(), 1);
        }
        for id in all
            .into_iter()
            .filter(|id| ![original[0], original[3]].contains(id))
        {
            hub.release(id).unwrap();
        }
        for id in [first, second] {
            hub.release(id).unwrap();
        }
        assert!(hub.release(original[0]).is_err());
        assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 0);
        for route in 0..hub.shards.len() as u64 {
            assert_eq!(
                hub.with_mailboxes(route, |mailboxes| Ok(mailboxes.len()))
                    .unwrap(),
                0
            );
        }
    }
    #[test]
    fn concurrent_reservations_share_one_capacity_and_never_reuse_routes() {
        let hub = CompletionHub::new(StoreId([1; 16]), 3).unwrap();
        let mut assigned = std::collections::BTreeSet::new();
        for _ in 0..32 {
            let start = std::sync::Barrier::new(12);
            let results = std::thread::scope(|scope| {
                let threads: Vec<_> = (1..=12)
                    .map(|session| {
                        let hub = &hub;
                        let start = &start;
                        scope.spawn(move || {
                            start.wait();
                            hub.reserve(SessionId([session; 16]))
                        })
                    })
                    .collect();
                threads
                    .into_iter()
                    .map(|thread| thread.join().unwrap())
                    .collect::<Vec<_>>()
            });
            let mut accepted = Vec::new();
            for result in results {
                match result {
                    Ok(id) => {
                        assert!(assigned.insert(id.slot));
                        accepted.push(id);
                    }
                    Err(Error::Busy) => {}
                    Err(error) => panic!("unexpected admission error: {error:?}"),
                }
            }
            assert_eq!(accepted.len(), 3);
            assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 3);
            for id in accepted {
                let mut wrong = id;
                wrong.generation = Generation(1);
                assert!(hub.release(wrong).is_err());
                assert!(hub.take(id).unwrap().is_none());
                hub.release(id).unwrap();
                assert!(hub.release(id).is_err());
            }
            assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 0);
        }
        assert_eq!(hub.next.0.load(Ordering::Acquire), assigned.len() as u64);
    }
    #[test]
    fn route_exhaustion_returns_the_uncommitted_capacity_credit() {
        let hub = CompletionHub::new(StoreId([1; 16]), 2).unwrap();
        let session = SessionId([1; 16]);
        hub.next.0.store(u64::MAX - 1, Ordering::Release);
        let last = hub.reserve(session).unwrap();
        assert_eq!(last.slot, u64::MAX - 1);
        assert!(matches!(hub.reserve(session), Err(Error::CapacityExceeded)));
        assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 1);
        hub.release(last).unwrap();
        assert!(matches!(hub.reserve(session), Err(Error::CapacityExceeded)));
        assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 0);
        assert_eq!(hub.next.0.load(Ordering::Acquire), u64::MAX);
    }
    #[test]
    fn one_shard_poisoning_closes_every_route_and_admission() {
        let hub = CompletionHub::new(StoreId([1; 16]), 4).unwrap();
        let first = hub.reserve(SessionId([1; 16])).unwrap();
        let second = hub.reserve(SessionId([2; 16])).unwrap();
        assert!(
            std::panic::catch_unwind(|| {
                let _ = hub.with_mailboxes(first.slot, |_| -> Result<(), Error> {
                    panic!("injected mailbox shard poison");
                });
            })
            .is_err()
        );
        assert!(hub.take(second).is_err());
        assert!(hub.completion_count(second).is_err());
        assert!(hub.release(second).is_err());
        assert!(hub.reserve(second.session).is_err());
        let device = MemoryDevice::new(4, 64).unwrap();
        assert!(hub.poll(&device, PollBudget::default()).is_err());
        assert_eq!(hub.capacity.occupied.load(Ordering::Acquire), 2);
    }
    #[test]
    fn normal_access_during_existing_unwind_does_not_poison_the_hub() {
        struct Cleanup<'a>(&'a CompletionHub, RequestId);
        impl Drop for Cleanup<'_> {
            fn drop(&mut self) {
                assert!(self.0.take(self.1).unwrap().is_none());
            }
        }
        let hub = CompletionHub::new(StoreId([1; 16]), 2).unwrap();
        let id = hub.reserve(SessionId([1; 16])).unwrap();
        assert!(
            std::panic::catch_unwind(|| {
                let _cleanup = Cleanup(&hub, id);
                panic!("outer panic before mailbox access");
            })
            .is_err()
        );
        assert!(hub.take(id).unwrap().is_none());
        hub.release(id).unwrap();
        assert!(hub.reserve(id.session).is_ok());
    }
    #[test]
    fn after_other_session_polling_the_results_will_remain_in_the_original_mailbox_and_cannot_be_collected_if_the_identity_is_wrong()
     {
        let hub = CompletionHub::new(StoreId([1; 16]), 2).unwrap();
        let device = MemoryDevice::new(4, 64).unwrap();
        let first = hub.reserve(SessionId([1; 16])).unwrap();
        let second = hub.reserve(SessionId([2; 16])).unwrap();
        assert!(matches!(hub.reserve(SessionId([3; 16])), Err(Error::Busy)));
        for id in [first, second] {
            device
                .submit(IoRequest {
                    route: CompletionHub::route(id),
                    operation: IoOperation::CreateDirectory(format!("directory{}", id.slot).into()),
                })
                .unwrap();
        }
        assert_eq!(hub.poll(&device, PollBudget::default()).unwrap(), 2);
        let mut wrong = first;
        wrong.session = second.session;
        assert!(hub.take(wrong).is_err());
        assert!(hub.release(wrong).is_err());
        assert!(hub.take(second).unwrap().unwrap().result.is_ok());
        assert!(hub.take(first).unwrap().unwrap().result.is_ok());
        assert!(hub.take(first).unwrap().is_none());
        hub.release(first).unwrap();
        let next = hub.reserve(first.session).unwrap();
        assert!(next.slot > second.slot);
    }
    #[test]
    fn late_completion_after_logging_out_only_recycles_the_buffer_and_does_not_accidentally_throw_new_requests()
     {
        let hub = CompletionHub::new(StoreId([1; 16]), 1).unwrap();
        let device = MemoryDevice::new(4, 64).unwrap();
        let old = hub.reserve(SessionId([1; 16])).unwrap();
        device
            .submit(IoRequest {
                route: CompletionHub::route(old),
                operation: IoOperation::Read {
                    file: crate::device::FileId {
                        slot: 999,
                        generation: Generation(0),
                    },
                    offset: 0,
                    buffer: crate::device::AlignedBuffer::new_zeroed(8, 8).unwrap(),
                },
            })
            .unwrap();
        hub.release(old).unwrap();
        let new = hub.reserve(old.session).unwrap();
        hub.poll(&device, PollBudget::default()).unwrap();
        assert!(hub.take(new).unwrap().is_none());
    }
    #[test]
    fn repeated_uncollected_completion_and_unknown_routing_errors_are_reported_but_other_mailboxes_are_not_covered_or_lost()
     {
        let hub = CompletionHub::new(StoreId([1; 16]), 4).unwrap();
        let device = MemoryDevice::new(4, 64).unwrap();
        let first = hub.reserve(SessionId([1; 16])).unwrap();
        let second = hub.reserve(SessionId([2; 16])).unwrap();
        let submit = |route, name: &str| {
            device
                .submit(IoRequest {
                    route,
                    operation: IoOperation::CreateDirectory(name.into()),
                })
                .unwrap()
        };
        let first_io = submit(CompletionHub::route(first), "first time");
        submit(CompletionHub::route(first), "Repeat");
        let second_io = submit(CompletionHub::route(second), "another session");
        assert!(matches!(
            hub.poll(&device, PollBudget::default()),
            Err(Error::InvalidState(_))
        ));
        assert_eq!(hub.take(first).unwrap().unwrap().id, first_io);
        assert!(hub.take(first).unwrap().is_none());
        assert_eq!(hub.take(second).unwrap().unwrap().id, second_io);
        submit(CompletionRoute(999), "unknown route");
        assert!(matches!(
            hub.poll(&device, PollBudget::default()),
            Err(Error::InvalidState(_))
        ));
        assert!(hub.take(first).unwrap().is_none());
        assert!(hub.take(second).unwrap().is_none());
    }
}
