//! Atomically published first-block snapshots. Overflow and unstable reads use
//! the authoritative bucket lock. All shared fields are atomic; no seqlock reads
//! race with ordinary memory. The publication counter never wraps.
use super::{Bucket, Entry, IndexHead, SLOTS};
use crate::{
    sync::{AtomicU64, PUBLISH_ORDER},
    types::{CacheAddress, LogAddress},
};
use std::sync::atomic::AtomicBool;

struct Slot {
    metadata: AtomicU64,
    address: AtomicU64,
    revision: AtomicU64,
}
impl Slot {
    fn new() -> Self {
        Self {
            metadata: AtomicU64::new(0),
            address: AtomicU64::new(0),
            revision: AtomicU64::new(0),
        }
    }
    fn publish(&self, entry: Option<Entry>) {
        let metadata = if let Some(entry) = entry {
            let (kind, address) = match entry.head {
                IndexHead::Empty => (1, 0),
                IndexHead::Log(address) => (2, address.0),
                IndexHead::Cache(address) => (3, address.0),
            };
            replace(&self.address, address);
            replace(&self.revision, entry.revision);
            (kind << 16) | u64::from(entry.tag)
        } else {
            0
        };
        replace(&self.metadata, metadata);
    }
    fn read(&self, tag: u16) -> Option<Entry> {
        let metadata = self.metadata.load(PUBLISH_ORDER);
        let kind = metadata >> 16;
        if kind == 0 || metadata as u16 != tag {
            return None;
        }
        let address = self.address.load(PUBLISH_ORDER);
        let head = match kind {
            1 => IndexHead::Empty,
            2 => IndexHead::Log(LogAddress(address)),
            3 => IndexHead::Cache(CacheAddress(address)),
            _ => unreachable!("Published slot kind is valid"),
        };
        Some(Entry {
            tag,
            head,
            revision: self.revision.load(PUBLISH_ORDER),
        })
    }
}
fn replace(target: &AtomicU64, value: u64) {
    if target.load(PUBLISH_ORDER) != value {
        target.store(value, PUBLISH_ORDER);
    }
}
#[repr(align(64))]
pub(super) struct BucketSnapshot {
    clock: AtomicU64,
    writing: AtomicBool,
    enabled: AtomicBool,
    overflow: AtomicBool,
    empty_revision: AtomicU64,
    slots: [Slot; SLOTS],
}
impl BucketSnapshot {
    pub fn new() -> Self {
        Self {
            clock: AtomicU64::new(0),
            writing: AtomicBool::new(false),
            enabled: AtomicBool::new(true),
            overflow: AtomicBool::new(false),
            empty_revision: AtomicU64::new(0),
            slots: std::array::from_fn(|_| Slot::new()),
        }
    }
    // The caller holds the authoritative bucket lock (or exclusive table access).
    fn publish(&self, bucket: &Bucket, only: Option<usize>) {
        if !self.enabled.load(PUBLISH_ORDER) {
            return;
        }
        let Some(next) = self.clock.load(PUBLISH_ORDER).checked_add(1) else {
            self.enabled.store(false, PUBLISH_ORDER);
            return;
        };
        self.writing.store(true, PUBLISH_ORDER);
        if let Some(slot) = only {
            if slot < SLOTS {
                self.slots[slot].publish(bucket.blocks[0][slot]);
            }
        } else {
            for (index, slot) in self.slots.iter().enumerate() {
                slot.publish(bucket.blocks.first().and_then(|block| block[index]));
            }
        }
        replace(&self.empty_revision, bucket.empty_revision);
        let overflow = bucket.blocks.len() > 1;
        if self.overflow.load(PUBLISH_ORDER) != overflow {
            self.overflow.store(overflow, PUBLISH_ORDER);
        }
        self.clock.store(next, PUBLISH_ORDER);
        self.writing.store(false, PUBLISH_ORDER);
    }
    pub fn publish_slot(&self, bucket: &Bucket, slot: usize) {
        self.publish(bucket, Some(slot));
    }
    pub fn publish_all(&self, bucket: &Bucket) {
        self.publish(bucket, None);
    }
    pub fn read(&self, tag: u16) -> Option<(Option<Entry>, u64)> {
        let before = self.clock.load(PUBLISH_ORDER);
        if !self.enabled.load(PUBLISH_ORDER) || self.writing.load(PUBLISH_ORDER) {
            return None;
        }
        let entry = self.slots.iter().find_map(|slot| slot.read(tag));
        if entry.is_none() && self.overflow.load(PUBLISH_ORDER) {
            return None;
        }
        let empty_revision = self.empty_revision.load(PUBLISH_ORDER);
        // Sequential consistency places these reads and both publication markers
        // in one order. A concurrent field change must expose writing or a new
        // clock value. Exhaustion disables this shortcut instead of wrapping.
        if self.writing.load(PUBLISH_ORDER)
            || self.clock.load(PUBLISH_ORDER) != before
            || !self.enabled.load(PUBLISH_ORDER)
        {
            return None;
        }
        Some((entry, empty_revision))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        config::IndexConfig,
        index::{PublishResult, Table},
        types::KeyHash,
    };
    use std::sync::Barrier;
    fn put(table: &Table, hash: KeyHash, head: IndexHead) {
        let expected = table.prepare(hash).unwrap();
        assert!(matches!(
            table.compare_publish(expected, head),
            Ok(PublishResult::Published)
        ));
    }
    #[test]
    fn concurrent_snapshots_never_mix_a_head_with_another_revision() {
        let table = Table::new(IndexConfig { buckets: 1 }).unwrap();
        let hash = KeyHash(7 << 48);
        put(&table, hash, IndexHead::Log(LogAddress(64)));
        let start = Barrier::new(5);
        std::thread::scope(|scope| {
            for _ in 0..4 {
                let table = &table;
                let start = &start;
                scope.spawn(move || {
                    start.wait();
                    for _ in 0..20_000 {
                        let entry = table.prepare(hash).unwrap();
                        assert!(entry.present);
                        assert_eq!(entry.head, IndexHead::Log(LogAddress(entry.revision * 64)));
                    }
                });
            }
            start.wait();
            for revision in 2..=5000 {
                put(&table, hash, IndexHead::Log(LogAddress(revision * 64)));
            }
        });
        assert_eq!(table.prepare(hash).unwrap().revision, 5000);
    }
    #[test]
    fn full_width_addresses_reserved_entries_and_overflow_keep_their_meaning() {
        let table = Table::new(IndexConfig { buckets: 1 }).unwrap();
        for tag in 0..10 {
            put(
                &table,
                KeyHash(tag << 48),
                IndexHead::Log(LogAddress(u64::MAX - 1 - tag)),
            );
        }
        for tag in 0..10 {
            assert_eq!(
                table.prepare(KeyHash(tag << 48)).unwrap().head,
                IndexHead::Log(LogAddress(u64::MAX - 1 - tag))
            );
        }
        put(
            &table,
            KeyHash(0),
            IndexHead::Cache(CacheAddress(u64::MAX - 1)),
        );
        assert_eq!(
            table.prepare(KeyHash(0)).unwrap().head,
            IndexHead::Cache(CacheAddress(u64::MAX - 1))
        );
        let missing = table.prepare(KeyHash(20 << 48)).unwrap();
        assert!(!missing.present);
        assert!(matches!(
            table.compare_publish_mode(missing, IndexHead::Empty, true),
            Ok(PublishResult::Published)
        ));
        let reserved = table.prepare(KeyHash(20 << 48)).unwrap();
        assert!(reserved.present);
        assert_eq!(reserved.head, IndexHead::Empty);
    }
    #[test]
    fn poisoned_authoritative_buckets_cannot_serve_old_published_values() {
        let table = Table::new(IndexConfig { buckets: 1 }).unwrap();
        put(&table, KeyHash(0), IndexHead::Log(LogAddress(64)));
        std::thread::scope(|scope| {
            assert!(
                scope
                    .spawn(|| {
                        let _guard = table.buckets[0].lock().unwrap();
                        panic!("Poison the authoritative bucket");
                    })
                    .join()
                    .is_err()
            );
        });
        assert!(table.prepare(KeyHash(0)).is_err());
        assert!(table.prepare(KeyHash(7 << 48)).is_err());
    }
    #[test]
    fn publication_counter_exhaustion_disables_the_shortcut_without_rejecting_updates() {
        let table = Table::new(IndexConfig { buckets: 1 }).unwrap();
        put(&table, KeyHash(0), IndexHead::Log(LogAddress(64)));
        table.published[0].clock.store(u64::MAX, PUBLISH_ORDER);
        put(&table, KeyHash(0), IndexHead::Log(LogAddress(128)));
        assert!(!table.published[0].enabled.load(PUBLISH_ORDER));
        assert_eq!(
            table.prepare(KeyHash(0)).unwrap().head,
            IndexHead::Log(LogAddress(128))
        );
        assert_eq!(table.prepare(KeyHash(0)).unwrap().revision, 2);
    }
}
