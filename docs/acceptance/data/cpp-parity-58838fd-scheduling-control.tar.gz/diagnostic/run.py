"""Observe whole-process CPU usage for an identical single-thread binary."""
from pathlib import Path
import hashlib,json,platform,resource,subprocess,sys,time
sys.path.insert(0,"tools/performance")
from cpu_profile import validate_output
root=Path("target/parity-profile/58838fd-scheduling-control")
binary=Path("target/parity-profile/result-budget-first-slot/candidate-bins/parity")
command=[str(binary),"upsert","shared-hot","1","20000000","64"]
metadata={"scope":"Scheduling diagnosis only; whole-process CPU includes setup and verification, not a performance acceptance metric.","commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"platform":platform.platform(),"command":command,"binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),"count":20000000}
(root/"environment.json").write_text(json.dumps(metadata,indent=2)+"\n")
rows=[]
for index in range(6):
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns()
 result=subprocess.run(command,capture_output=True,text=True,timeout=180)
 wall=time.perf_counter_ns()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
 (root/f"sample-{index}.stdout").write_text(result.stdout);(root/f"sample-{index}.stderr").write_text(result.stderr)
 assert result.returncode==0,result.stderr
 body=validate_output(result.stdout,"rust","upsert/shared-hot/1",20000000)
 assert body["samples"]==312500
 cpu=(after.ru_utime-before.ru_utime)+(after.ru_stime-before.ru_stime)
 row={"index":index,"business":body,"process_wall_ns":wall,"process_cpu_seconds":cpu,"cpu_to_wall_ratio":cpu/(wall/1e9),"voluntary_switches":after.ru_nvcsw-before.ru_nvcsw,"involuntary_switches":after.ru_nivcsw-before.ru_nivcsw}
 rows.append(row);(root/"results.json").write_text(json.dumps(rows,indent=2)+"\n")
 print(index,"business_ms",round(body["elapsed_ns"]/1e6,2),"wall_ms",round(wall/1e6,2),"cpu_ms",round(cpu*1000,2),"cpu/wall",round(row["cpu_to_wall_ratio"],4),"involuntary",row["involuntary_switches"],flush=True)
