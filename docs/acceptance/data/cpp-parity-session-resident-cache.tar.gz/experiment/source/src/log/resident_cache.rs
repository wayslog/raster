//! Bounded, thread-local hints retain weak ownership only. The record directory
//! remains authoritative; retirement invalidates hints before unlinking values.
use super::*;
use std::sync::Weak;

const BITS: u32 = 9;
const CAPACITY: usize = 1 << BITS;
struct Entry<V: ValueLayout> {
    address: LogAddress,
    value: Weak<value::PageValue<V>>,
}
pub(crate) struct ResidentCache<V: ValueLayout> {
    owner: Weak<LogControl>,
    entries: Vec<Entry<V>>,
}
impl<V: ValueLayout> Default for ResidentCache<V> {
    fn default() -> Self {
        Self {
            owner: Weak::new(),
            entries: Vec::new(),
        }
    }
}
impl<V: ValueLayout> ResidentCache<V> {
    pub fn clear(&mut self) {
        *self = Self::default();
    }
    fn bind(&mut self, owner: &Arc<LogControl>) {
        // The weak owner prevents allocation-address reuse while hints exist.
        if self.owner.as_ptr() != Arc::as_ptr(owner) {
            self.entries.clear();
            self.owner = Arc::downgrade(owner);
        }
    }
    fn slot(address: LogAddress) -> usize {
        // Selection may collide; the complete address is always checked.
        ((address.0 >> 3).wrapping_mul(0x9e37_79b9_7f4a_7c15) >> (64 - BITS)) as usize
    }
    fn get(&self, address: LogAddress) -> Option<RecordLease<V>> {
        let entry = self.entries.get(Self::slot(address))?;
        if entry.address != address {
            return None;
        }
        let value = entry.value.upgrade()?;
        value.directory_visible().then_some(RecordLease {
            value,
            local: PhantomData,
        })
    }
    fn insert(&mut self, address: LogAddress, lease: &RecordLease<V>) {
        if !lease.value.directory_visible() {
            return;
        }
        if self.entries.is_empty() {
            // Hints are optional. Allocation failure cannot reject an operation
            // that already obtained its authoritative record lease.
            if self.entries.try_reserve_exact(CAPACITY).is_err() {
                return;
            }
            self.entries.resize_with(CAPACITY, || Entry {
                address: LogAddress(0),
                value: Weak::new(),
            });
        }
        self.entries[Self::slot(address)] = Entry {
            address,
            value: Arc::downgrade(&lease.value),
        };
    }
}
impl<V: ValueLayout> HybridLog<V> {
    pub fn lease_cached(
        &self,
        address: LogAddress,
        cache: &mut ResidentCache<V>,
    ) -> Result<RecordLease<V>, Error> {
        address.validate()?;
        if self.records.is_poisoned() {
            return Err(Error::InvalidState("Record table lock poisoning"));
        }
        cache.bind(&self.state);
        if let Some(lease) = cache.get(address) {
            if self.records.is_poisoned() {
                return Err(Error::InvalidState("Record table lock poisoning"));
            }
            return Ok(lease);
        }
        let lease = self.lease(address)?;
        cache.insert(address, &lease);
        Ok(lease)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::schema::builtin::AtomicU64Value;
    use std::sync::atomic::Ordering;

    fn log(bytes: usize) -> HybridLog<AtomicU64Value> {
        HybridLog::new(
            LogConfig {
                page_bytes: bytes,
                memory_pages: 2,
                mutable_fraction: 0.9,
            },
            Arc::new(AtomicU64Value),
        )
        .unwrap()
    }
    fn put(log: &HybridLog<AtomicU64Value>, value: u64) -> LogAddress {
        log.finish_initialization(log.reserve(value).unwrap())
            .unwrap()
    }
    #[test]
    fn cached_values_stay_fresh_but_retirement_is_not_revived_by_an_old_lease() {
        let log = log(64);
        let mut cache = ResidentCache::default();
        let address = put(&log, 7);
        let old = log.lease_cached(address, &mut cache).unwrap();
        old.update(|v| {
            v.store(42, Ordering::SeqCst);
            Ok(())
        })
        .unwrap();
        assert_eq!(
            log.lease_cached(address, &mut cache)
                .unwrap()
                .read(|v| v)
                .unwrap(),
            42
        );
        log.retire(address).unwrap();
        assert!(matches!(
            log.lease_cached(address, &mut cache),
            Err(Error::RangeTruncated)
        ));
        assert_eq!(old.read(|v| v).unwrap(), 42);
        assert!(log.release_page(PageId(0), Generation(0)).is_err());
        drop(old);
        // A weak hint retains no live value, page lease, or page allocation.
        log.release_page(PageId(0), Generation(0)).unwrap();
        let next = put(&log, 99);
        assert_eq!(
            log.lease_cached(next, &mut cache)
                .unwrap()
                .read(|v| v)
                .unwrap(),
            99
        );
        assert!(log.lease_cached(address, &mut cache).is_err());
    }
    #[test]
    fn identical_addresses_in_different_logs_cannot_share_a_hint() {
        let first = log(64);
        let second = log(64);
        let a = put(&first, 7);
        let b = put(&second, 42);
        assert_eq!(a, b);
        let mut cache = ResidentCache::default();
        assert_eq!(
            first
                .lease_cached(a, &mut cache)
                .unwrap()
                .read(|v| v)
                .unwrap(),
            7
        );
        assert_eq!(
            second
                .lease_cached(b, &mut cache)
                .unwrap()
                .read(|v| v)
                .unwrap(),
            42
        );
        drop(first);
        assert_eq!(
            second
                .lease_cached(b, &mut cache)
                .unwrap()
                .read(|v| v)
                .unwrap(),
            42
        );
    }
    #[test]
    fn directory_poisoning_rejects_an_otherwise_live_cached_value() {
        let log = log(64);
        let address = put(&log, 7);
        let mut cache = ResidentCache::default();
        drop(log.lease_cached(address, &mut cache).unwrap());
        assert!(
            std::panic::catch_unwind(|| {
                let _guard = log.records.lock().unwrap();
                panic!("injected directory poison");
            })
            .is_err()
        );
        assert!(log.lease_cached(address, &mut cache).is_err());
    }
    #[test]
    fn hint_storage_is_bounded_and_clear_releases_its_allocations() {
        let log = log(16384);
        let mut cache = ResidentCache::default();
        for value in 0..(CAPACITY + 64) as u64 {
            let address = put(&log, value);
            let lease = log.lease_cached(address, &mut cache).unwrap();
            assert_eq!(lease.read(|v| v).unwrap(), value);
            log.retire(address).unwrap();
            drop(lease);
            assert!(cache.entries.len() <= CAPACITY);
        }
        assert_eq!(cache.entries.len(), CAPACITY);
        assert!(
            cache
                .entries
                .iter()
                .all(|entry| entry.value.upgrade().is_none())
        );
        cache.clear();
        assert_eq!(cache.entries.capacity(), 0);
        assert_eq!(cache.owner.strong_count(), 0);
    }
    #[test]
    fn eviction_invalidates_a_hint_before_waiting_for_old_readers() {
        let log = log(128);
        let address = log
            .finish_initialization(log.reserve_record(b"key", None, 7).unwrap())
            .unwrap();
        let mut cache = ResidentCache::default();
        let old = log.lease_cached(address, &mut cache).unwrap();
        let boundary = log.pad_tail().unwrap();
        log.advance_read_only(boundary).unwrap();
        // Model the already-completed I/O boundary for this eviction unit test.
        // Full engine tests separately exercise actual flushes and recovery.
        log.state.write().unwrap().frontiers.flushed_until = boundary;
        assert_eq!(log.evict_next().unwrap().completed, 0);
        assert!(matches!(
            log.lease_cached(address, &mut cache),
            Err(Error::RangeTruncated)
        ));
        assert_eq!(old.read(|v| v).unwrap(), 7);
        drop(old);
        assert_eq!(log.evict_next().unwrap().completed, 1);
    }
}
