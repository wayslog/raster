
#[cfg(test)]
#[allow(dead_code)]
mod temporary_layout_probe {
    use super::*;
    struct PreviousOwners {
    owner: Arc<LogControl>,
    storage: Arc<crate::sync::InstanceId>,
    key: EncodedKey,
    next: Option<LogAddress>,
    route: CompletionRoute,
    reading: Option<(PageId, PageRead)>,
    cached: Option<(PageId, ReadPage)>,
    ended: bool,
    matched: Option<LogAddress>,
    needs_value: bool,
    io_enabled: bool,
    awaiting_route: bool,
    }
    struct NonzeroFields {
    owner: std::num::NonZeroU64,
    storage: std::num::NonZeroU64,
    key: EncodedKey,
    next: Option<LogAddress>,
    route: CompletionRoute,
    reading: Option<(PageId, PageRead)>,
    cached: Option<(PageId, ReadPage)>,
    ended: bool,
    matched: Option<LogAddress>,
    needs_value: bool,
    io_enabled: bool,
    awaiting_route: bool,
    }
    #[test]
    fn probe_lookup_layout() {
        use std::mem::{size_of, offset_of};
        println!("current {} {} owner={} storage={} key={}", size_of::<LogLookup>(), size_of::<Option<LogLookup>>(), offset_of!(LogLookup, owner), offset_of!(LogLookup, storage), offset_of!(LogLookup, key));
        println!("previous {} {} owner={} storage={} key={}", size_of::<PreviousOwners>(), size_of::<Option<PreviousOwners>>(), offset_of!(PreviousOwners, owner), offset_of!(PreviousOwners, storage), offset_of!(PreviousOwners, key));
        println!("nonzero {} {} owner={} storage={} key={}", size_of::<NonzeroFields>(), size_of::<Option<NonzeroFields>>(), offset_of!(NonzeroFields, owner), offset_of!(NonzeroFields, storage), offset_of!(NonzeroFields, key));
    }
}
